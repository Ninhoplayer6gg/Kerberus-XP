Kerberus XP 6.1.2 Legacy18 Runtime checkpoint

- Ruby 1.8 uses a dedicated compatibility bootstrap.
- Ruby 3.1 keeps the full modern compatibility sweep.
- Known mkxp-z HTTP Ruby 1.8 build fixes are integrated in source.
- Goal: run original RGSS1 scripts under native Ruby 1.8 semantics.
