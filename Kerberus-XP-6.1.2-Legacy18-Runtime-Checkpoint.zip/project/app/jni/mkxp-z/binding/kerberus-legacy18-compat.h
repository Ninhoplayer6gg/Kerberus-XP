#pragma once
static const char *KERBERUS_LEGACY18_COMPAT_RUBY = R"K18(
# Kerberus XP 6.1.2 - native Ruby 1.8 compatibility bootstrap.
# Keep this file valid on MRI 1.8: no refinements, Encoding, keyword hashes,
# prepend, define_singleton_method, caller_locations or post-splat arguments.
module KerberusLegacy18
  VERSION = '6.1.2'
  WINDOW = 1
  ERROR_CALL_NOT_IMPLEMENTED = 120
  ERROR_DEVICE_NOT_CONNECTED = 1167

  @events = {}
  @native = {}
  @last_error = 0
  @capture = 0
  @cursor = 0
  @bgm = nil

  def self.meta(object)
    class << object
      self
    end
  end

  def self.event(kind, api, detail)
    key = kind.to_s + ':' + api.to_s
    return if @events[key]
    @events[key] = true
    line = '[' + kind.to_s + '] ' + api.to_s
    line += ' ' + detail.to_s unless detail.nil? || detail.to_s.empty?
    System.puts(line) if defined?(System) && System.respond_to?(:puts)
  rescue Exception
    nil
  end

  def self.remember_native
    return if @remembered
    @remembered = true
    if defined?(Input)
      [:update, :press?, :trigger?, :repeat?, :release?, :count,
       :pressex?, :triggerex?, :repeatex?, :releaseex?, :repeatcount,
       :mouse_x, :mouse_y, :scroll_v, :gets, :text_input=].each do |name|
        begin
          @native[['Input', name]] = Input.method(name) if Input.respond_to?(name)
        rescue Exception
        end
      end
    end
    if defined?(Audio)
      [:bgm_play, :bgm_stop, :bgm_fade, :bgm_pos,
       :bgs_play, :bgs_stop, :bgs_fade, :bgs_pos,
       :me_play, :me_stop, :me_fade, :se_play, :se_stop].each do |name|
        begin
          @native[['Audio', name]] = Audio.method(name) if Audio.respond_to?(name)
        rescue Exception
        end
      end
    end
    if defined?(Graphics)
      [:width, :height, :snap_to_bitmap, :resize_screen].each do |name|
        begin
          @native[['Graphics', name]] = Graphics.method(name) if Graphics.respond_to?(name)
        rescue Exception
        end
      end
    end
  end

  def self.native(mod, name, *args)
    method = @native[[mod, name]]
    raise RuntimeError, 'Kerberus native binding ausente: ' + mod.to_s + '.' + name.to_s unless method
    method.call(*args)
  end

  def self.null?(value)
    value.nil? || value == 0
  end

  def self.string(value)
    raise ArgumentError, 'String necessaria' unless value.is_a?(String)
    value.split("\0", 2)[0].to_s
  end

  def self.buffer(value, size, writable)
    writable = true if writable.nil?
    raise ArgumentError, 'Tamanho de buffer invalido' unless size.is_a?(Integer) && size >= 0 && size <= 16 * 1024 * 1024
    raise ArgumentError, 'Buffer Ruby necessario' unless value.is_a?(String) && value.length >= size
    raise ArgumentError, 'Buffer congelado' if writable && value.frozen?
    value
  end

  def self.put(buffer, data)
    buffer(buffer, data.length, true)
    i = 0
    while i < data.length
      buffer[i] = data[i]
      i += 1
    end
    data.length
  end

  def self.slice_bytes(value, start, length)
    result = value[start, length]
    result.nil? ? '' : result
  end

  def self.pack_u64(value)
    low = value & 0xffffffff
    high = (value >> 32) & 0xffffffff
    [low, high].pack('V2')
  end

  def self.relative_file(path)
    value = string(path).tr('\\', '/')
    full = File.expand_path(value, Dir.pwd)
    base = File.expand_path(Dir.pwd)
    prefix = base[-1, 1] == '/' ? base : base + '/'
    raise ArgumentError, 'Caminho fora do jogo' unless full == base || full.index(prefix) == 0
    full
  end

  module Registry
    @handles = {}
    @next_handle = 0x10000
    VALUES = {
      [0x80000001, 'software\\enterbrain\\rgss'] => {
        'playmusic' => [4, [1].pack('V')],
        'playsound' => [4, [1].pack('V')]
      }
    }

    def self.open(root, subkey, reserved, access, output)
      KerberusLegacy18.buffer(output, 4, true)
      return 87 unless reserved == 0 && access.is_a?(Integer)
      key = [root & 0xffffffff, KerberusLegacy18.string(subkey).tr('/', '\\').downcase]
      return 2 unless VALUES.has_key?(key)
      return 8 if @handles.size >= 64
      handle = @next_handle
      @next_handle += 1
      @handles[handle] = key
      KerberusLegacy18.put(output, [handle].pack('V'))
      0
    end

    def self.close(handle)
      @handles.delete(handle) ? 0 : 6
    end

    def self.query(handle, name, reserved, type, data, size)
      KerberusLegacy18.buffer(size, 4, true)
      KerberusLegacy18.buffer(type, 4, true) unless KerberusLegacy18.null?(type)
      return 87 unless KerberusLegacy18.null?(reserved)
      key = @handles[handle]
      return 6 unless key
      value = VALUES[key][KerberusLegacy18.string(name).downcase]
      return 2 unless value
      kind = value[0]
      bytes = value[1]
      capacity = size.unpack('V')[0]
      KerberusLegacy18.buffer(data, capacity, true) unless KerberusLegacy18.null?(data)
      KerberusLegacy18.put(size, [bytes.length].pack('V'))
      KerberusLegacy18.put(type, [kind].pack('V')) unless KerberusLegacy18.null?(type)
      return 0 if KerberusLegacy18.null?(data)
      return 234 if capacity < bytes.length
      KerberusLegacy18.put(data, bytes)
      0
    end
  end

  module Ini
    def self.read(section, key, default, output, capacity, filename)
      KerberusLegacy18.buffer(output, capacity, true)
      return 0 if capacity == 0
      path = KerberusLegacy18.relative_file(filename)
      values = {}
      current = ''
      if File.file?(path)
        raise ArgumentError, 'INI excede 64 KiB' if File.size(path) > 65536
        content = File.open(path, 'rb') { |file| file.read }
        content.each_line do |line|
          line = line.strip
          if line =~ /^\[[^\]]+\]$/
            current = line[1, line.length - 2].downcase
            values[current] ||= {}
          elsif line[0, 1] != ';' && line[0, 1] != '#' && line.index('=')
            pair = line.split('=', 2)
            (values[current] ||= {})[pair[0].strip.downcase] = pair[1].to_s.strip
          end
        end
      end
      list = KerberusLegacy18.null?(section) || KerberusLegacy18.null?(key)
      if KerberusLegacy18.null?(section)
        value = values.keys.join("\0") + "\0"
      elsif KerberusLegacy18.null?(key)
        group = values[KerberusLegacy18.string(section).downcase] || {}
        value = group.keys.join("\0") + "\0"
      else
        fallback = KerberusLegacy18.null?(default) ? '' : KerberusLegacy18.string(default)
        group = values[KerberusLegacy18.string(section).downcase] || {}
        wanted = KerberusLegacy18.string(key).downcase
        value = group.has_key?(wanted) ? group[wanted] : fallback
      end
      suffix = list && capacity >= 2 ? "\0\0" : "\0"
      available = capacity - suffix.length
      available = 0 if available < 0
      bytes = KerberusLegacy18.slice_bytes(value, 0, available)
      KerberusLegacy18.put(output, bytes + suffix)
      bytes.length
    end
  end

  module Win32
    SUPPORTED = {}
    %w[
      GetCurrentThreadId GetWindowThreadProcessId GetCurrentProcess FindWindowEx
      GetForegroundWindow GetClientRect GetWindowRect GetSystemMetrics GetCursorPos
      ScreenToClient GetAsyncKeyState GetKeyState GetKeyboardState SetWindowTextA
      SetCapture ReleaseCapture ShowCursor GetTickCount GetTickCount64 timeGetTime
      QueryPerformanceCounter QueryPerformanceFrequency RegOpenKeyExA RegQueryValueExA
      RegCloseKey GetPrivateProfileString RtlMoveMemory GetLastError FormatMessageA
      GetUserName GetUserDefaultLangID GetUserGeoID GetSystemPowerStatus
      SHGetKnownFolderPath SHGetSpecialFolderLocation SHGetPathFromIDList CoTaskMemFree
      InputGetWheelDelta waveOutGetNumDevs waveOutOpen waveOutClose waveOutPrepareHeader
      waveOutUnprepareHeader waveOutWrite waveOutSetVolume mciSendString mciGetErrorString
      PeekMessage MapVirtualKey ToUnicode TakeScreenshot LoadLibrary FreeLibrary
      RegisterHotKey SetPriorityClass SetWindowPos SetWindowLong ShowWindow PostMessage
      SendMessage AddFontResource WriteProfileString XInputGetState XInputSetState
    ].each { |name| SUPPORTED[name] = true }

    class Call
      def initialize(dll, function, imports, exports)
        @dll = dll
        @function = function
        @imports = Win32.normalize(imports)
        @exports = Win32.normalize(exports)
        @applied = false
      end

      def call(*args)
        if !@imports.empty? && args.length != @imports.length
          raise ArgumentError, @function + ' espera ' + @imports.length.to_s + ' argumentos; recebeu ' + args.length.to_s
        end
        result = Win32.dispatch(@dll, @function, args)
        unless @applied
          KerberusLegacy18.event('APPLIED', @dll + '!' + @function, 'provider legacy18')
          @applied = true
        end
        @exports.empty? ? nil : result
      end
      alias Call call
    end

    def self.normalize(value)
      if value.is_a?(Array)
        joined = ''
        value.each { |item| joined << item.to_s }
        value = joined
      end
      return '' if value.nil? || value == 0
      raise ArgumentError, 'Assinatura deve ser String/Array' unless value.is_a?(String) && value.length <= 128
      text = value.upcase.strip.gsub(/[\s,]/, '')
      return '' if text.empty? || text == 'V'
      raise ArgumentError, 'Tipo de assinatura desconhecido' unless text =~ /^[PLINS]+$/
      text.tr('LNS', 'III')
    end

    def self.library(value)
      raise ArgumentError, 'DLL deve ser String' unless value.is_a?(String) && value.length <= 256
      name = value.tr('\\', '/').split('/').last.to_s.downcase
      name.sub(/\.dll$/, '')
    end

    def self.install
      return if @installed
      @installed = true
      @owner_thread = thread_id
      original = ::Win32API.method(:new)
      eigen = KerberusLegacy18.meta(::Win32API)
      eigen.send(:define_method, :new) do |*argv|
        raise ArgumentError, 'Win32API.new requer DLL e funcao' if argv.length < 2
        dll = argv[0]
        function = argv[1].to_s
        imports = argv.length > 2 ? argv[2] : ''
        exports = argv.length > 3 ? argv[3] : ''
        name = KerberusLegacy18::Win32.library(dll)
        if KerberusLegacy18::Win32::SUPPORTED[function]
          KerberusLegacy18::Win32::Call.new(name, function, imports, exports)
        else
          original.call(*argv)
        end
      end
      KerberusLegacy18.event('LEGACY18', 'Win32API', 'Ruby 1.8 provider ativo')
    end

    def self.thread_id
      return KerberusNative.thread_id if defined?(KerberusNative) && KerberusNative.respond_to?(:thread_id)
      Process.pid
    end

    def self.focused?
      return KerberusNative.focused? if defined?(KerberusNative) && KerberusNative.respond_to?(:focused?)
      true
    end

    def self.key_pressed?(key)
      return false unless key.is_a?(Integer) && key >= 0 && key <= 255
      return false unless defined?(Input)
      if Input.respond_to?(:pressex?)
        KerberusLegacy18.native('Input', :pressex?, key) ? true : false
      else
        false
      end
    end

    def self.tick
      (Time.now.to_f * 1000.0).to_i
    end

    def self.fallback(function, result, reason)
      KerberusLegacy18.instance_variable_set(:@last_error, ERROR_CALL_NOT_IMPLEMENTED)
      KerberusLegacy18.event('UNAVAILABLE', function, reason)
      result
    end

    def self.dispatch(dll, fn, a)
      case fn
      when 'GetCurrentThreadId'
        thread_id
      when 'GetWindowThreadProcessId'
        KerberusLegacy18.buffer(a[1], 4, true) unless KerberusLegacy18.null?(a[1])
        return 0 unless a[0] == WINDOW
        KerberusLegacy18.put(a[1], [Process.pid].pack('V')) unless KerberusLegacy18.null?(a[1])
        @owner_thread
      when 'GetCurrentProcess'
        -1
      when 'FindWindowEx'
        return 0 unless KerberusLegacy18.null?(a[1])
        WINDOW
      when 'GetForegroundWindow'
        focused? ? WINDOW : 0
      when 'GetClientRect', 'GetWindowRect'
        KerberusLegacy18.buffer(a[1], 16, true)
        return 0 unless a[0] == WINDOW
        KerberusLegacy18.put(a[1], [0, 0, Graphics.width, Graphics.height].pack('l4'))
        1
      when 'GetSystemMetrics'
        return Graphics.width if a[0] == 0 || a[0] == 16 || a[0] == 78
        return Graphics.height if a[0] == 1 || a[0] == 17 || a[0] == 79
        fallback(fn, 0, 'Metrica de desktop indisponivel')
      when 'GetCursorPos'
        x = Input.respond_to?(:mouse_x) ? KerberusLegacy18.native('Input', :mouse_x) : 0
        y = Input.respond_to?(:mouse_y) ? KerberusLegacy18.native('Input', :mouse_y) : 0
        KerberusLegacy18.put(a[0], [x, y].pack('l2'))
        1
      when 'ScreenToClient'
        KerberusLegacy18.buffer(a[1], 8, true)
        a[0] == WINDOW ? 1 : 0
      when 'GetAsyncKeyState', 'GetKeyState'
        focused? && key_pressed?(a[0]) ? 0x8000 : 0
      when 'GetKeyboardState'
        KerberusLegacy18.buffer(a[0], 256, true)
        i = 0
        while i < 256
          a[0][i] = focused? && key_pressed?(i) ? 0x80 : 0
          i += 1
        end
        1
      when 'SetWindowTextA'
        return 0 unless a[0] == WINDOW
        System.set_window_title(KerberusLegacy18.string(a[1])) if defined?(System) && System.respond_to?(:set_window_title)
        1
      when 'SetCapture'
        return 0 unless a[0] == WINDOW
        previous = @capture
        @capture = WINDOW
        previous
      when 'ReleaseCapture'
        previous = @capture
        @capture = 0
        previous == 0 ? 0 : 1
      when 'ShowCursor'
        @cursor += a[0] == 0 ? -1 : 1
        @cursor
      when 'GetTickCount', 'timeGetTime'
        tick & 0xffffffff
      when 'GetTickCount64'
        tick
      when 'QueryPerformanceCounter'
        KerberusLegacy18.put(a[0], KerberusLegacy18.pack_u64((Time.now.to_f * 1000000.0).to_i))
        1
      when 'QueryPerformanceFrequency'
        KerberusLegacy18.put(a[0], KerberusLegacy18.pack_u64(1000000))
        1
      when 'RegOpenKeyExA'
        Registry.open(*a)
      when 'RegQueryValueExA'
        Registry.query(*a)
      when 'RegCloseKey'
        Registry.close(*a)
      when 'GetPrivateProfileString'
        Ini.read(*a)
      when 'RtlMoveMemory'
        KerberusLegacy18.buffer(a[0], a[2], true)
        KerberusLegacy18.buffer(a[1], a[2], false)
        KerberusLegacy18.put(a[0], KerberusLegacy18.slice_bytes(a[1], 0, a[2]))
        0
      when 'GetLastError'
        KerberusLegacy18.instance_variable_get(:@last_error) || 0
      when 'FormatMessageA'
        return 0 if a[5].to_i <= 0
        message = 'Kerberus: erro ' + a[2].to_s
        message = KerberusLegacy18.slice_bytes(message, 0, a[5] - 1)
        KerberusLegacy18.put(a[4], message + "\0")
        message.length
      when 'GetUserName'
        KerberusLegacy18.buffer(a[1], 4, true)
        capacity = a[1].unpack('V')[0]
        KerberusLegacy18.put(a[1], [7].pack('V'))
        return 0 if capacity < 7
        KerberusLegacy18.buffer(a[0], capacity, true)
        KerberusLegacy18.put(a[0], "Player\0")
        1
      when 'GetUserDefaultLangID'
        fallback(fn, 0x0409, 'LANGID neutro en-US')
      when 'GetUserGeoID'
        fallback(fn, -1, 'GEOID indisponivel')
      when 'GetSystemPowerStatus'
        fallback(fn, 0, 'Status de bateria nao exposto')
      when 'SHGetKnownFolderPath', 'SHGetSpecialFolderLocation'
        fallback(fn, 0x80004001, 'Use a pasta de saves do Kerberus')
      when 'SHGetPathFromIDList'
        fallback(fn, 0, 'PIDL Windows indisponivel')
      when 'CoTaskMemFree'
        0
      when 'InputGetWheelDelta'
        Input.respond_to?(:scroll_v) ? KerberusLegacy18.native('Input', :scroll_v).to_i * 120 : 0
      when 'waveOutGetNumDevs'
        fallback(fn, 0, 'waveOut sem backend; Audio nativo ativo')
      when 'waveOutOpen', 'waveOutClose', 'waveOutPrepareHeader', 'waveOutUnprepareHeader', 'waveOutWrite', 'waveOutSetVolume'
        fallback(fn, 8, 'MMSYSERR_NOTSUPPORTED')
      when 'mciSendString'
        fallback(fn, 274, 'MCI nao suportado')
      when 'mciGetErrorString'
        return 0 if a[2].to_i <= 0
        text = KerberusLegacy18.slice_bytes('MCI indisponivel no Android', 0, a[2] - 1)
        KerberusLegacy18.put(a[1], text + "\0")
        1
      when 'PeekMessage', 'MapVirtualKey', 'ToUnicode'
        fallback(fn, 0, 'Fila/conversao Win32 substituida por SDL')
      when 'XInputGetState'
        if a.length > 1 && a[1].is_a?(String) && a[1].length >= 16
          i = 0
          while i < 16
            a[1][i] = 0
            i += 1
          end
        end
        ERROR_DEVICE_NOT_CONNECTED
      when 'XInputSetState'
        ERROR_DEVICE_NOT_CONNECTED
      when 'TakeScreenshot'
        path = KerberusLegacy18.relative_file(a[0])
        bitmap = KerberusLegacy18.native('Graphics', :snap_to_bitmap)
        begin
          bitmap.to_file(path)
        ensure
          bitmap.dispose if bitmap && !bitmap.disposed?
        end
        1
      when 'LoadLibrary', 'FreeLibrary', 'RegisterHotKey', 'SetPriorityClass', 'SetWindowPos',
           'SetWindowLong', 'ShowWindow', 'PostMessage', 'SendMessage', 'AddFontResource', 'WriteProfileString'
        fallback(fn, 0, 'Operacao desktop indisponivel no Android')
      else
        raise RuntimeError, 'Kerberus legacy18 API sem provider: ' + dll.to_s + '!' + fn.to_s
      end
    end
  end

  def self.install_audio
    return if @audio_installed
    @audio_installed = true
    Kernel.module_eval <<'KERBERUS_AUDIO18'
      def Audio_bgm_play(name, volume=100, pitch=100, position=0)
        KerberusLegacy18.instance_variable_set(:@bgm, [name, volume, pitch])
        KerberusLegacy18.native('Audio', :bgm_play, name, volume, pitch, position.to_f)
      end
      def Audio_bgm_stop
        KerberusLegacy18.instance_variable_set(:@bgm, nil)
        KerberusLegacy18.native('Audio', :bgm_stop)
      end
      def Audio_bgm_fade(ms)
        KerberusLegacy18.native('Audio', :bgm_fade, ms.to_i)
      end
      def Audio_bgm_get_position
        KerberusLegacy18.native('Audio', :bgm_pos)
      end
      def Audio_bgm_get_volume
        value = KerberusLegacy18.instance_variable_get(:@bgm)
        value ? value[1] : 0
      end
      def Audio_bgm_set_volume(value)
        state = KerberusLegacy18.instance_variable_get(:@bgm)
        return value unless state
        Audio_bgm_play(state[0], value, state[2], Audio_bgm_get_position)
        value
      end
      def Audio_bgm_name
        value = KerberusLegacy18.instance_variable_get(:@bgm)
        value ? value[0] : ''
      end
      def Audio_bgm_pitch
        value = KerberusLegacy18.instance_variable_get(:@bgm)
        value ? value[2] : 100
      end
      def Audio_bgm_playing?
        !KerberusLegacy18.instance_variable_get(:@bgm).nil?
      end
      def Audio_bgm_fadein(ms)
        nil
      end
      def audio_control_volume(value)
        Audio_bgm_set_volume(value)
      end
      def safeExists?(file)
        File.file?(file)
      end
      def getPlayMusic
        true
      end
      def getPlaySound
        true
      end
      module_function :Audio_bgm_play, :Audio_bgm_stop, :Audio_bgm_fade,
                      :Audio_bgm_get_position, :Audio_bgm_get_volume,
                      :Audio_bgm_set_volume, :Audio_bgm_name, :Audio_bgm_pitch,
                      :Audio_bgm_playing?, :Audio_bgm_fadein,
                      :audio_control_volume, :safeExists?, :getPlayMusic, :getPlaySound
KERBERUS_AUDIO18
    event('PROFILE_REPLACED', 'Uranium Audio', 'FMOD substituido por Audio nativo no Ruby 1.8')
  end

  def self.install_loader
    return if @loader_installed
    @loader_installed = true
    Kernel.module_eval <<'KERBERUS_LOADER18'
      def load_module(library, symbol)
        name = library.to_s.tr('\\', '/').split('/').last.to_s.downcase.sub(/\.dll$/, '')
        if (name == 'rgss fmodex' || name == 'rgss_fmodex' || name == 'fmodex') && symbol.to_s == 'Init_FmodEx'
          KerberusLegacy18.install_audio
          true
        else
          raise RuntimeError, 'Kerberus legacy18: extensao RGSS nao classificada: ' + library.to_s + '!' + symbol.to_s
        end
      end
      module_function :load_module
KERBERUS_LOADER18
    event('PROFILE_REPLACED', 'RGSS Linker', 'loader de FMOD substituido')
  end

  def self.install_gif
    return if defined?(::GifBitmap) && ::GifBitmap.instance_methods.include?('kerberus_native18')
    if defined?(::GifBitmap)
      klass = ::GifBitmap
      klass.class_eval do
        def kerberus_native18
          true
        end
      end
    end
  end

  def self.patch_scripts(scripts)
    uranium = false
    scripts.each do |entry|
      next unless entry.is_a?(Array)
      source = entry[3].to_s
      if source.index('RGSSLinker_Initialize') && source.index('Uranium.ini')
        uranium = true
      end
    end
    return false unless uranium

    install_loader
    install_audio

    patched = 0
    scripts.each do |entry|
      next unless entry.is_a?(Array)
      source = entry[3].to_s
      if source.index('RGSSLinker_Initialize') && source.index('def load_module')
        entry[3] = "# Kerberus legacy18: RGSS Linker replaced by native adapter\n"
        patched += 1
      elsif source.index('Init_FmodEx') && source.index('LOOP_TABLE') && source.index('bgmvolume')
        entry[3] = "# Kerberus legacy18: FMOD replaced by native Audio adapter\n"
        patched += 1
      end
    end
    event('LEGACY18_READY', 'Pokemon Uranium', patched.to_s + ' sections replaced; original RGSS1 semantics preserved')
    true
  end

  def self.activate(scripts)
    remember_native
    Win32.install
    if patch_scripts(scripts)
      $KERBERUS_URANIUM_COMPAT_ACTIVE = true
      event('STATIC_OK', 'uranium', 'legacy18 bootstrap ativo; scripts originais preservados salvo FMOD/RGSSLinker')
    else
      event('PROFILE_SKIP', 'legacy18', 'Uranium nao detectado; somente provider Win32 seguro ativo')
    end
  end
end

KerberusLegacy18.activate($RGSS_SCRIPTS) if defined?($RGSS_SCRIPTS) && $RGSS_SCRIPTS

)K18";
