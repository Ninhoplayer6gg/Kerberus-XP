#ifndef KERBERUS_POKEMON_NATIVE_H
#define KERBERUS_POKEMON_NATIVE_H
#include <unistd.h>
#include <sys/syscall.h>
#include <SDL.h>
// No pointers or Windows handles cross this boundary.
static VALUE kerberusPokemonThreadId(VALUE) {
    return LONG2NUM(::syscall(SYS_gettid));
}
static VALUE kerberusPokemonFocused(VALUE) {
    return SDL_GetKeyboardFocus() ? Qtrue : Qfalse;
}
static void kerberusPokemonNativeInit() {
    VALUE module = rb_define_module("KerberusNative");
    rb_define_singleton_method(module, "thread_id", RUBY_METHOD_FUNC(kerberusPokemonThreadId), 0);
    rb_define_singleton_method(module, "focused?", RUBY_METHOD_FUNC(kerberusPokemonFocused), 0);
}
#endif
