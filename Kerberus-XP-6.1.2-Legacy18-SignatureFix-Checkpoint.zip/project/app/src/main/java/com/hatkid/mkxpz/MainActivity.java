package com.hatkid.mkxpz;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.InputDevice;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.os.storage.StorageManager;
import android.os.storage.OnObbStateChangeListener;
import android.net.Uri;
import android.provider.Settings;
import android.util.Log;
import java.util.Locale;
import java.io.File;

import org.libsdl.app.SDLActivity;
import com.hatkid.mkxpz.gamepad.Gamepad;
import com.hatkid.mkxpz.gamepad.GamepadConfig;

public class MainActivity extends SDLActivity
{
    // This activity inherits from SDLActivity activity.
    // Put your Java-side stuff here.

    private static final String TAG = "mkxp-z[Activity]";
    private static final String GAME_PATH_DEFAULT = "";
    public static final String EXTRA_GAME_PATH = "kerberus_game_path";
    public static final String EXTRA_RUBY_RUNTIME = "kerberus_ruby_runtime";
    public static final String EXTRA_RUBY_REASON = "kerberus_ruby_reason";
    private static final String RUNTIME_LEGACY18 = "legacy18";
    private static final String RUNTIME_MODERN31 = "modern31";
    private static String ACTIVE_RUNTIME = RUNTIME_MODERN31;
    private static String ACTIVE_ENGINE_LIBRARY = "mkxp-z31";
    private static String GAME_PATH = GAME_PATH_DEFAULT;
    private static String OBB_MAIN_FILENAME;
    private static boolean DEBUG = false;

    protected boolean mStarted = false;

    private StorageManager mStorageManager;

    // In-screen gamepad
    private final Gamepad mGamepad = new Gamepad();
    private com.kerberus.launcher.RuntimeControls mKerberusControls;
    private com.kerberus.toolkit.SessionLock kerberusSession;

    private void runSDLThread()
    {
        if (!mStarted) {
            Log.i(TAG, "Game path: " + GAME_PATH);
        }

        mStarted = true;

        // Run (resume) native SDL thread
        if (mHasMultiWindow) {
            resumeNativeThread();
        }
    }

    OnObbStateChangeListener obbListener = new OnObbStateChangeListener()
    {
        @Override
        public void onObbStateChange(String path, int state)
        {
            super.onObbStateChange(path, state);

            Log.v(TAG, "OBB state of " + path + " changed to " + state);

            switch (state)
            {
                case OnObbStateChangeListener.MOUNTED:
                    String obbPath = mStorageManager.getMountedObbPath(path);
                    Log.v(TAG, "OBB " + path + " is mounted to " + obbPath);
                    GAME_PATH = obbPath;
                    break;

                case OnObbStateChangeListener.UNMOUNTED:
                    Log.v(TAG, "OBB " + path + " is unmounted");
                    GAME_PATH = GAME_PATH_DEFAULT;
                    break;

                default:
                    Log.e(TAG, "Failed to mount OBB " + path + ": Got state " + state);
                    break;
            }

            runSDLThread();
        }
    };

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == 110) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R && !Environment.isExternalStorageManager()) {
                // Close the App because the User did not allow the all files access permission to be used.
                mSingleton.finish();
            }
        }
    }

    @Override
    protected String[] getLibraries()
    {
        String requested = getIntent() != null ? getIntent().getStringExtra(EXTRA_RUBY_RUNTIME) : null;
        boolean legacy = RUNTIME_LEGACY18.equalsIgnoreCase(requested);
        String candidate = legacy ? "mkxp-z18" : "mkxp-z31";
        File nativeDir = new File(getApplicationInfo().nativeLibraryDir);
        File engine = new File(nativeDir, "lib" + candidate + ".so");

        // Never silently substitute another Ruby ABI. Missing engines are loader errors.
        ACTIVE_RUNTIME = legacy ? RUNTIME_LEGACY18 : RUNTIME_MODERN31;
        ACTIVE_ENGINE_LIBRARY = candidate;
        if (GAME_PATH != null && !GAME_PATH.isEmpty()) {
            com.kerberus.launcher.RuntimeReport.boot(new File(GAME_PATH),
                    "Native loader: " + ACTIVE_RUNTIME + " -> lib" + ACTIVE_ENGINE_LIBRARY + ".so");
        }

        if (legacy) {
            return new String[] { "SDL2", "SDL2_image", "SDL2_ttf", "SDL2_sound", "openal", "mkxp-z18" };
        }
        return new String[] { "SDL2", "SDL2_image", "SDL2_ttf", "SDL2_sound", "openal", "ruby", "mkxp-z31" };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        String requestedGamePath = getIntent().getStringExtra(EXTRA_GAME_PATH);
        if (requestedGamePath != null) GAME_PATH = requestedGamePath;
        if (GAME_PATH != null && !GAME_PATH.isEmpty()) {
            try {
                java.io.File reportGame = new java.io.File(GAME_PATH);
                com.kerberus.launcher.RuntimeReport.begin(reportGame);
                String requestedRuntime = getIntent().getStringExtra(EXTRA_RUBY_RUNTIME);
                String runtimeReason = getIntent().getStringExtra(EXTRA_RUBY_REASON);
                com.kerberus.launcher.RuntimeReport.boot(reportGame, "Runtime solicitado: " + requestedRuntime
                        + (runtimeReason == null ? "" : "; motivo: " + runtimeReason));
            } catch (java.io.IOException error) {
                android.util.Log.w("Kerberus", "Não foi possível iniciar o relatório", error);
            }
        }
        super.onCreate(savedInstanceState);
        if (SDLActivity.mBrokenLibraries) {
            if (GAME_PATH != null && !GAME_PATH.isEmpty())
                com.kerberus.launcher.RuntimeReport.boot(new File(GAME_PATH), "Falha ao carregar bibliotecas nativas para " + ACTIVE_RUNTIME);
            return;
        }
        com.kerberus.launcher.DisplayPreferences.apply(this,GAME_PATH);
        SDLActivity.nativeSetenv("KERBERUS_RUBY_RUNTIME", ACTIVE_RUNTIME);
        SDLActivity.nativeSetenv("KERBERUS_ENGINE_LIBRARY", ACTIVE_ENGINE_LIBRARY);
        if (GAME_PATH != null && !GAME_PATH.isEmpty()) {
            java.io.File game = new java.io.File(GAME_PATH);
            try {
                kerberusSession=com.kerberus.toolkit.SessionLock.acquire(game);
                com.kerberus.launcher.GameIni ini = com.kerberus.launcher.GameIni.find(game);
                if (!ini.scripts.isEmpty() && !com.kerberus.launcher.GameIni.safeRelative(ini.scripts))
                    throw new java.io.IOException("Caminho de scripts inválido na configuração.");
                String archive = ini.archiveName(game);
                SDLActivity.nativeSetenv("KERBERUS_EXEC_NAME", ini.baseName);
                SDLActivity.nativeSetenv("KERBERUS_INI_NAME", ini.name);
                SDLActivity.nativeSetenv("KERBERUS_ARCHIVE_NAME", archive);
                com.kerberus.x.morph.MorphRuntime morph = com.kerberus.x.morph.MorphRuntime.prepare(this, game, ini.engine);
                SDLActivity.nativeSetenv("KERBERUS_MORPH_PLAN", morph.plan);
                SDLActivity.nativeSetenv("KERBERUS_MORPH_LOG", morph.log);
                SDLActivity.nativeSetenv("KERBERUS_MORPH_SESSION", morph.session);
                SDLActivity.nativeSetenv("KERBERUS_COMPAT_MODE", com.kerberus.x.compat.CompatibilityService.enabled(this,game)?"auto":"off");
                SDLActivity.nativeSetenv("KERBERUS_COMPAT_LOG", com.kerberus.x.compat.CompatibilityService.logFile(this,game).getAbsolutePath());
                if (!morph.warning.isEmpty()) com.kerberus.launcher.RuntimeReport.boot(game, morph.warning);
                com.kerberus.launcher.RuntimeReport.boot(game, "Configuração: " + ini.name
                        + (archive.isEmpty() ? "; arquivos soltos" : "; pacote: " + archive));
            } catch (java.io.IOException error) {
                com.kerberus.launcher.RuntimeReport.boot(game, "Falha: " + error.getMessage());
                android.widget.Toast.makeText(this, error.getMessage(), android.widget.Toast.LENGTH_LONG).show();
                finish();
                return;
            }
        }
        if (GAME_PATH == null || GAME_PATH.isEmpty()) {
            android.util.Log.e("Kerberus", "Runtime started without a game path");
            finish();
            return;
        }

        mStorageManager = (StorageManager) getSystemService(STORAGE_SERVICE);

        // Get main OBB filepath
        final String obbPrefix = "main"; // "main", "patch"
        final int obbVersion = 1;
        OBB_MAIN_FILENAME = getObbDir() + "/" + obbPrefix + "." + obbVersion + "." + getPackageName() + ".obb";

        // Get Debug flag
        try {
            ActivityInfo actInfo = getPackageManager().getActivityInfo(this.getComponentName(), PackageManager.GET_META_DATA);
            DEBUG = actInfo.metaData.getBoolean("mkxp_debug");
        } catch (PackageManager.NameNotFoundException e) {
            Log.w(TAG, "Failed to set debug flag: " + e);
            e.printStackTrace();
        }

        // Check for all files access permission (Android 11+)
        if (false && Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            if (!Environment.isExternalStorageManager()) {
                // Request all files access permission
                // TODO: AlertDialog: polite notice that mkxp-z requires All Files Access permission.
                Uri uri = Uri.parse("package:" + getPackageName());
                Intent intent = new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, uri);
                startActivityForResult(intent, 110);
            }
        }

        // Setup in-screen gamepad
        // Legacy Gamepad remains only as a physical-controller event mapper.
        // The Kerberus RuntimeControls overlay is the single touch HUD.
        GamepadConfig gpadConfig = new GamepadConfig();
        mGamepad.init(gpadConfig, true);
        mGamepad.setOnKeyDownListener(SDLActivity::onNativeKeyDown);
        mGamepad.setOnKeyUpListener(SDLActivity::onNativeKeyUp);

        if (mLayout != null) {
            mKerberusControls = new com.kerberus.launcher.RuntimeControls(this, mLayout,
                    new com.kerberus.launcher.ControlInput.Sink() {
                        public void down(int key) { SDLActivity.onNativeKeyDown(key); }
                        public void up(int key) { SDLActivity.onNativeKeyUp(key); }
                    }, this::toggleKerberusKeyboard, GAME_PATH);
        }
    }

    @Override
    protected void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
        String requested = intent.getStringExtra(EXTRA_GAME_PATH);
        if (requested != null && !requested.isEmpty()
                && !com.kerberus.launcher.GameIdentity.of(new java.io.File(requested)).equals(
                    com.kerberus.launcher.GameIdentity.of(new java.io.File(GAME_PATH)))) {
            // Ruby cannot be initialized for a second game in the existing process.
            // Keep the current game and controls intact until the user ends the session.
            new android.app.AlertDialog.Builder(this).setTitle("Outro jogo está aberto")
                    .setMessage("Para trocar de jogo, salve seu progresso no jogo atual e encerre a sessão. Depois toque em Jogar novamente na biblioteca.")
                    .setNegativeButton("Continuar jogo atual", null)
                    .setPositiveButton("Encerrar sessão", (dialog, which) -> finish()).show();
        }
    }

    @Override public void onBackPressed(){if(mKerberusControls!=null)mKerberusControls.showQuickMenu();else super.onBackPressed();}

    private void toggleKerberusKeyboard() {
        if (SDLActivity.isScreenKeyboardShown()) {
            android.view.View editor = mTextEdit;
            if (editor != null) {
                android.view.inputmethod.InputMethodManager input =
                        (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                input.hideSoftInputFromWindow(editor.getWindowToken(), 0);
                editor.setLayoutParams(new android.widget.RelativeLayout.LayoutParams(0, 0));
            }
            mScreenKeyboardShown = false;
            mSurface.requestFocus();
        } else {
            SDLActivity.showTextInput(0, 0, 1, 1);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mKerberusControls != null) mKerberusControls.resume();
    }

    @Override
    protected void onPause() {
        if (mKerberusControls != null) mKerberusControls.pause();
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (mKerberusControls != null) mKerberusControls.focusChanged(hasFocus);
    }

    @Override
    protected void onStart()
    {
        super.onStart();

        // KERBERUS_BROKEN_LIB_GUARD_5201 — retained in 6.1
        if (SDLActivity.mBrokenLibraries) {
            Log.e(TAG, "[KerberusNativeLoad] onStart aborted because native loading failed");
            return;
        }
        if (OBB_MAIN_FILENAME == null || OBB_MAIN_FILENAME.isEmpty()) {
            Log.e(TAG, "[KerberusNativeLoad] onStart aborted: runtime boot did not initialize OBB path");
            return;
        }

        if (!mStarted) {
            // Check for main OBB file
            if (new File(OBB_MAIN_FILENAME).exists()) {
                Log.v(TAG, "Main OBB file found, starting with main OBB mount");

                // Try to mount main OBB file
                mStorageManager.mountObb(OBB_MAIN_FILENAME, null, obbListener);
            } else {
                Log.v(TAG, "Main OBB file not found, starting without main OBB mount");

                // Run from default game directory
                runSDLThread();
            }
        } else {
            // onStart: Resume SDL thread
            runSDLThread();
        }
    }

    @Override
    protected void onDestroy()
    {
        if (mKerberusControls != null) mKerberusControls.close();
        if(kerberusSession!=null)try{kerberusSession.close();}catch(java.io.IOException ignored){}
        super.onDestroy();

        // HACK: Exiting the JVM (process) since Ruby does not likes when we
        // trying to re-initialize Ruby VM in mkxp-z (JNI native library)
        // that leads to segmentation fault, even we have cleanup the Ruby VM.
        System.exit(0);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent evt)
    {
        if (mGamepad.processGamepadEvent(evt))
            return true;

        return super.dispatchKeyEvent(evt);
    }

    @Override
    public boolean onGenericMotionEvent(MotionEvent evt)
    {
        if (mGamepad.processDPadEvent(evt))
            return true;

        return super.onGenericMotionEvent(evt);
    }

    /**
     * This method is for arguments for launching native mkxp-z.
     * 
     * @return arguments for the mkxp-z
     */
    @Override
    protected String[] getArguments()
    {
        String[] args;

        if (DEBUG) {
            // Arguments in Debug mode
            args = new String[] { "debug" };
        } else {
            // Arguments in normal mode
            args = new String[] {};
        }

        return args;
    }

    /**
     * This static method is used in native mkxp-z. (see systemImpl.cpp)
     * This method returns a string of current device locale tag. (e.g. "en_US")
     * 
     * @return string of locale tag
     */
    @SuppressWarnings("unused")
    private static String getSystemLanguage()
    {
        return Locale.getDefault().toString();
    }

    /**
     * This static method is used in native mkxp-z. (see android-binding.cpp)
     * This method returns a boolean indicating that the device has a vibrator or not.
     * 
     * @return boolean
     */
    @SuppressWarnings("unused")
    private static boolean hasVibrator()
    {
        Vibrator vib = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
        return vib.hasVibrator();
    }

    /**
     * This static method is used in native mkxp-z. (see android-binding.cpp)
     * This method makes device vibrating with given milliseconds duration.
     * 
     * @param duration milliseconds duration of vibration
     */
    @SuppressWarnings("unused")
    private static void vibrate(int duration)
    {
        Vibrator vib = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vib.vibrate(VibrationEffect.createOneShot(duration, VibrationEffect.EFFECT_HEAVY_CLICK));
        } else {
            vib.vibrate(duration);
        }
    }

    /**
     * This static method is used in native mkxp-z. (see android-binding.cpp)
     * This method turns off the current device vibration.
     */
    @SuppressWarnings("unused")
    private static void vibrateStop()
    {
        Vibrator vib = (Vibrator) getContext().getSystemService(Context.VIBRATOR_SERVICE);
        vib.cancel();
    }

    /**
     * This static method is used in native mkxp-z. (see android-binding.cpp)
     * This method returns a boolean indicating the app is in multi window mode or not.
     * (Multi-window mode supports from Android 7.0 Nougat (API 24) and higher.)
     * 
     * @param activity current MainActivity instance
     * @return boolean
     */
    @SuppressWarnings("unused")
    private static boolean inMultiWindow(Activity activity)
    {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && activity.isInMultiWindowMode();
    }
}