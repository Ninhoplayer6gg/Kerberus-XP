package com.kerberus.launcher;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;

/**
 * Selects the Ruby/engine runtime before SDL loads any native library.
 * The primary rule is engine-level: RGSS1 uses the legacy Ruby runtime.
 * Known-good exceptions can stay on the modern runtime to avoid regressions.
 */
public final class RuntimeSelector {
    public static final String OVERRIDE_FILE = ".kerberus-runtime";

    public enum Runtime {
        LEGACY18("legacy18", "mkxp-z18", "Ruby 1.8 / RGSS1 Legacy"),
        MODERN31("modern31", "mkxp-z31", "Ruby 3.1 / mkxp-z Modern");

        public final String id;
        public final String engineLibrary;
        public final String label;
        Runtime(String id, String engineLibrary, String label) {
            this.id = id;
            this.engineLibrary = engineLibrary;
            this.label = label;
        }

        public static Runtime fromId(String id) {
            if (id == null) return null;
            for (Runtime value : values()) if (value.id.equalsIgnoreCase(id.trim())) return value;
            return null;
        }
    }

    public static final class Selection {
        public final Runtime runtime;
        public final String reason;
        public final boolean overridden;
        Selection(Runtime runtime, String reason, boolean overridden) {
            this.runtime = runtime;
            this.reason = reason;
            this.overridden = overridden;
        }
    }

    private RuntimeSelector() {}

    public static Selection select(File game) throws IOException {
        if (game == null || !game.isDirectory()) throw new IOException("A pasta do jogo não foi encontrada.");

        Runtime forced = readOverride(game);
        if (forced != null)
            return new Selection(forced, "override local " + OVERRIDE_FILE, true);

        GameIni ini = GameIni.find(game);
        if (ini.engine != 1)
            return new Selection(Runtime.MODERN31, "RGSS" + ini.engine + " não usa o runtime legado de XP", false);

        String identity = normalizedIdentity(game);
        // Infinite Fusion is intentionally kept on the already proven modern path.
        if (identity.contains("infinite fusion") || identity.contains("infinitefusion"))
            return new Selection(Runtime.MODERN31, "perfil preservado: Infinite Fusion já validado no runtime moderno", false);

        // These profiles are explicit test priorities, but the decision does not depend on them:
        // every other ordinary RGSS1 title also receives the legacy runtime by default.
        if (identity.contains("uranium"))
            return new Selection(Runtime.LEGACY18, "RGSS1 legado; perfil prioritário Pokémon Uranium", false);
        if (identity.contains("insurgence"))
            return new Selection(Runtime.LEGACY18, "RGSS1 legado; perfil prioritário Pokémon Insurgence", false);
        if (identity.contains("xenoverse") || identity.contains("xeno verse"))
            return new Selection(Runtime.LEGACY18, "RGSS1 legado; perfil prioritário Pokémon Xenoverse", false);

        return new Selection(Runtime.LEGACY18, "RPG Maker XP/RGSS1: parser e semântica Ruby 1.8 preferidos", false);
    }

    private static Runtime readOverride(File game) throws IOException {
        File file = new File(game, OVERRIDE_FILE);
        if (!file.isFile()) return null;
        if (file.length() > 64) throw new IOException(OVERRIDE_FILE + " excede o limite de 64 bytes.");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[64]; int count;
            while ((count = in.read(buffer)) != -1) bytes.write(buffer, 0, count);
        }
        Runtime runtime = Runtime.fromId(new String(bytes.toByteArray(), StandardCharsets.UTF_8).trim());
        if (runtime == null)
            throw new IOException(OVERRIDE_FILE + " deve conter legacy18 ou modern31.");
        return runtime;
    }

    private static String normalizedIdentity(File game) {
        StringBuilder text = new StringBuilder(game.getName());
        try {
            GameIntelligence.Result info = GameIntelligence.inspect(game);
            text.append(' ').append(info.title);
        } catch (IOException ignored) { /* GameIni already validated the launch above. */ }
        return text.toString().toLowerCase(Locale.ROOT)
                .replace('é', 'e').replace('ê', 'e').replace('ó', 'o').replace('ô', 'o')
                .replace('á', 'a').replace('ã', 'a').replace('í', 'i').replace('ú', 'u');
    }
}
