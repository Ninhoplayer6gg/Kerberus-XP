package com.kerberus.x.compat;

import android.content.Context;
import com.kerberus.launcher.GameIdentity;
import com.kerberus.x.shared.AtomicProperties;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/** Per-game UI/cache/settings. Invoke analyze on an existing worker, never UI. */
public final class CompatibilityService {
    private static final String VERSION="6.0-dev1-external";
    private static File directory(Context context,File game) throws IOException {
        String managed=new File(context.getFilesDir(),"games").getCanonicalPath()+File.separator;
        if(!game.getCanonicalPath().startsWith(managed) || !game.isDirectory()) throw new IOException("Jogo fora da biblioteca.");
        File directory=new File(new File(context.getFilesDir(),"kerberus-x/compat"),GameIdentity.of(game));
        if(!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Não foi possível criar diagnóstico.");
        return directory;
    }
    public static File logFile(Context context,File game) throws IOException { return new File(directory(context,game),"events.log"); }
    private static Properties read(File file) throws IOException {
        Properties values=new Properties();
        if(file.isFile()) {
            if(file.length()>131072) throw new IOException("Configuração de compatibilidade excede limite.");
            try(InputStream in=new FileInputStream(file)) {
                values.load(new ByteArrayInputStream(ScriptPackReader.bounded(in,131072)));
            } catch(IllegalArgumentException error) { throw new IOException("Configuração de compatibilidade inválida.",error); }
        }
        return values;
    }
    public static synchronized boolean enabled(Context context,File game) throws IOException {
        return !read(new File(directory(context,game),"settings.properties")).getProperty("enabled","true").equals("false");
    }
    public static synchronized void enabled(Context context,File game,boolean value) throws IOException {
        File file=new File(directory(context,game),"settings.properties"); Properties values=read(file);
        values.setProperty("enabled",Boolean.toString(value));
        AtomicProperties.write(file,values);
    }
    public static String analyze(Context context,File game) throws IOException {
        File directory=directory(context,game);
        byte[] pack=ScriptPackReader.locate(game); String digest=ScriptPackReader.fingerprint(game);
        File cache=new File(directory,"analysis.properties"); Properties old=read(cache);
        if(VERSION.equals(old.getProperty("version")) && digest.equals(old.getProperty("sha256"))) return old.getProperty("report","");
        CompatibilityAnalyzer analyzer=new CompatibilityAnalyzer(context.getAssets().open("kerberus/compat/api-catalog.tsv"),
                context.getAssets().open("kerberus/compat/script-audit.tsv"));
        String report=analyzer.analyze(game,pack).report();
        Properties next=new Properties(); next.setProperty("version",VERSION); next.setProperty("sha256",digest); next.setProperty("report",report);
        AtomicProperties.write(cache,next,131072);
        return report;
    }
    public static String cached(Context context,File game) {
        try { return read(new File(directory(context,game),"analysis.properties")).getProperty("report","Análise ainda não executada."); }
        catch(IOException error) { return "Não foi possível ler a análise: "+error.getMessage(); }
    }
    public static String events(Context context,File game) {
        try {
            File file=logFile(context,game);
            if(!file.isFile()) return "Nenhuma chamada de compatibilidade registrada nesta instalação.";
            try(RandomAccessFile in=new RandomAccessFile(file,"r")) {
                int count=(int)Math.min(32768,in.length()); in.seek(in.length()-count); byte[] data=new byte[count]; in.readFully(data);
                return new String(data,StandardCharsets.UTF_8);
            }
        } catch(IOException error) { return "Registros indisponíveis: "+error.getMessage(); }
    }
}
