#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

need_file(){ [[ -f "$1" ]] || { echo "[PRECHECK][ERRO] arquivo ausente: $1" >&2; exit 1; }; }
need_text(){ grep -Fq -- "$2" "$1" || { echo "[PRECHECK][ERRO] $1 não contém: $2" >&2; exit 1; }; }

need_file app/build.gradle
need_file build.gradle
need_file gradle/wrapper/gradle-wrapper.properties
need_file app/jni/Application.mk
need_file app/jni/Makefile
need_file app/jni/get_deps.sh
need_file app/jni/mkxp-z18.mk
need_file app/jni/mkxp-z31.mk
need_file app/jni/ruby18.mk
need_file app/jni/ruby.mk

need_text build.gradle "version '7.3.1'"
need_text gradle/wrapper/gradle-wrapper.properties 'gradle-7.4.2-bin.zip'
need_text app/build.gradle "abiFilters 'arm64-v8a'"
need_text app/jni/Application.mk 'max-page-size=16384'
need_text app/jni/Application.mk 'common-page-size=16384'
need_text app/jni/Makefile 'ALSOFT_BACKEND_OPENSL=ON'
need_text app/jni/Makefile '--disable-arm-a64-neon'
need_text app/jni/Makefile 'install-nodoc INSTRUBY_OPTS='
need_text app/jni/get_deps.sh 'OpenSSL_1_1_1w'

if grep -Rqs 'Finish me! rb_' app/jni/mkxp-z/binding; then
  echo '[PRECHECK][ERRO] shim Ruby legado TODO ainda presente' >&2
  exit 1
fi

bash scripts/validate-host.sh

echo KERBERUS_HARDENED_R2_SOURCE_PREFLIGHT_OK
