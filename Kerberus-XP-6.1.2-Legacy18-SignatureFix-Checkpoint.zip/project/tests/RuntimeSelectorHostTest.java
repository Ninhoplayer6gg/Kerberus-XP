package com.kerberus.launcher;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
public final class RuntimeSelectorHostTest {
  static File game(File root,String folder,String title,String ext)throws Exception{
    File g=new File(root,folder);new File(g,"Data").mkdirs();String script="Data/Scripts."+ext;
    Files.write(new File(g,"Game.ini").toPath(),("[Game]\nTitle="+title+"\nScripts="+script+"\nLibrary=RGSS102E.dll\n").getBytes(StandardCharsets.UTF_8));
    new File(g,script).createNewFile();return g;
  }
  static void expect(RuntimeSelector.Runtime r,File g)throws Exception{RuntimeSelector.Selection s=RuntimeSelector.select(g);if(s.runtime!=r)throw new AssertionError(g+" -> "+s.runtime+" expected "+r);System.out.println("OK "+g.getName()+" -> "+s.runtime.id+" | "+s.reason);}
  public static void main(String[]a)throws Exception{File root=Files.createTempDirectory("k61").toFile();File generic=game(root,"ClassicXP","Meu RPG","rxdata");File fusion=game(root,"Pokemon Infinite Fusion","Pokemon Infinite Fusion","rxdata");File uranium=game(root,"Pokemon Uranium","Pokemon Uranium","rxdata");expect(RuntimeSelector.Runtime.LEGACY18,generic);expect(RuntimeSelector.Runtime.MODERN31,fusion);expect(RuntimeSelector.Runtime.LEGACY18,uranium);Files.write(new File(generic,RuntimeSelector.OVERRIDE_FILE).toPath(),"modern31\n".getBytes(StandardCharsets.UTF_8));expect(RuntimeSelector.Runtime.MODERN31,generic);System.out.println("KERBERUS_RUNTIME_SELECTOR_HOST_TEST_OK");}
}
