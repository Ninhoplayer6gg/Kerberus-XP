# Kerberus XP 6.1.2 — Hardened R2

This checkpoint hardens the Android ARM64 build after analysis of the GitHub Actions failures.

## Build fixes baked into source
- AGP 7.3.1 paired with Gradle 7.4.2.
- arm64-v8a enforced with Gradle ndk.abiFilters.
- 16 KB ELF linker flags added for project shared libraries and native dependencies.
- Pixman AArch64 legacy assembly disabled for NDK r23/Clang compatibility.
- OpenAL OpenSL backend forced.
- OpenSSL Android toolchain path fixed and dependency moved from 1.1.1t to 1.1.1w.
- Ruby 3.1 install avoids writing gems to the host system.
- Ruby 1.8 build workflow patches cross-build rbconfig/version handling, PIC, include paths, and host-tool isolation.
- Legacy Ruby binding TODO shims replaced with real formatting/arity helpers; exception message pointer corrected.
- Obsolete bundled GitHub workflow disabled.

## Important
OpenSSL 1.1.1w is still an end-of-life compatibility dependency. Moving the runtime to OpenSSL 3.x should be treated as a separate compatibility migration after the dual-runtime APK is stable.

NDK r23 is retained because this project currently depends on it. The project libraries are linked for 16 KB page alignment, but NDK r23's bundled libc++_shared may still limit full 16 KB compatibility on some devices.
