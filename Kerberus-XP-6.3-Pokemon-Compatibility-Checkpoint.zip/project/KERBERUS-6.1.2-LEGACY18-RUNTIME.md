Kerberus XP 6.1.2 Legacy18 Runtime checkpoint

- Ruby 1.8 uses a dedicated compatibility bootstrap.
- Ruby 3.1 keeps the full modern compatibility sweep.
- Known mkxp-z HTTP Ruby 1.8 build fixes are integrated in source.
- Goal: run original RGSS1 scripts under native Ruby 1.8 semantics.

## Signature parser fix (v19)

Legacy18 Win32API signatures now accept the classic Ruby forms P/N/L/I/V,
MiniFFI BOOL B, string-pointer S, string "0" for void, arrays of one-character
prototype items, and the legacy combined form `imports:export` such as `PPI:I`.
Unknown prototype characters still fail closed and now report their raw value.
