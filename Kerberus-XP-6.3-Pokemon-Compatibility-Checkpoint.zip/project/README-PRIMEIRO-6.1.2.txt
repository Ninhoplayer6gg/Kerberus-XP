KERBERUS XP 6.1.2 — PRIMEIRO PASSO

Este pacote é o SOURCE COMPLETO da continuação do checkpoint Landscape.
Ele não é um APK.

No Termux, com seu ambiente Kerberus já configurado:

  cd <pasta-do-projeto>
  chmod +x TERMUX-BUILD-KERBERUS-6.1.2.sh
  ./TERMUX-BUILD-KERBERUS-6.1.2.sh

O script:
- roda testes Java de host;
- preserva o caminho modern31 para Infinite Fusion;
- prepara Ruby 1.8 legado para RGSS1;
- aplica o shim Android mblen/mbrlen do Ruby 1.8;
- compila a APK ARM64;
- audita libmkxp-z18.so/libmkxp-z31.so/libruby.so;
- copia o resultado para ~/KerberusXP/dist e, se disponível, ~/storage/downloads.

Se o script reclamar de ANDROID_HOME/ANDROID_NDK_HOME, use primeiro o setup/hydrator que você já utiliza no Kerberus.

============================================================
HARDENED R2 — BUILD RECOMENDADO
============================================================
Para GitHub Actions, use o pacote Kerberus-XP-6.1.2-Hardened-R2-Source.zip
com o workflow Kerberus-XP-6.1.2-GitHub-Build-v11-Hardened.yml.

O workflow R2 valida o source antes de gastar tempo compilando, isola as
ferramentas de host do Ruby 1.8, usa Gradle/JDK compatíveis com AGP 7.3.1,
verifica os dois runtimes e audita a APK ARM64 antes de publicar o artifact.
