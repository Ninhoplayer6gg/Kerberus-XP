KERBERUS XP 6.3 — PRIMEIRO PASSO

Este pacote é o SOURCE COMPLETO. Ele não é um APK.

GitHub Actions: coloque este zip na raiz do repositório com o workflow
Kerberus-XP-6.3-GitHub-Build-v20-Pokemon-Compatibility.yml e rode o workflow.

Termux (ARM64), com o ambiente Kerberus já configurado:
  chmod +x TERMUX-BUILD-KERBERUS-6.3.sh
  ./TERMUX-BUILD-KERBERUS-6.3.sh
  (opcional) RUBY18=/caminho/ruby-1.8.7 ./TERMUX-BUILD-KERBERUS-6.3.sh

Testes de host (PC/CI):
  RUBY18=<ruby 1.8.7> RUBY31=<ruby 3.1> scripts/run-all-host-tests.sh

Leia KERBERUS-6.3-COMPATIBILITY-REPORT.md antes de testar os jogos.
