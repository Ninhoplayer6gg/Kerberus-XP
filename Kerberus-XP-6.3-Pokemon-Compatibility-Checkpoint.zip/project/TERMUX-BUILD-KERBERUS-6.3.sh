#!/data/data/com.termux/files/usr/bin/bash
# Kerberus XP 6.3 — full-source Termux build helper (ARM64)
set -euo pipefail

HERE="$(cd "$(dirname "$0")" && pwd)"
if [[ -f "$HERE/app/build.gradle" ]]; then ROOT="${KERBERUS_ROOT:-$HERE}"; else ROOT="${KERBERUS_ROOT:-$HOME/KerberusXP/worktree}"; fi
JNI="$ROOT/app/jni"
ENV_FILE="${KERBERUS_TOOLS_HOME:-$HOME/.kerberus-tools}/env.sh"
CPU_JOBS="$(nproc 2>/dev/null || echo 2)"; (( CPU_JOBS > 4 )) && CPU_JOBS=4; (( CPU_JOBS < 1 )) && CPU_JOBS=1
JOBS="${KERBERUS_JOBS:-$CPU_JOBS}"
PIN_RUBY18="50783b870e31259ed5c91badbd5c8e41f8e56273"
PIN_ONIG="4ef89209a239c1aea328cf13c05a2807e5c146d1"
OUT_NAME="Kerberus-XP-6.4.2-pokemon-compatibility-arm64-debug.apk"

log(){ printf '\n[Kerberus 6.3] %s\n' "$*"; }
die(){ printf '\n[ERRO] %s\n' "$*" >&2; exit 1; }

[[ -d "$ROOT" && -f "$ROOT/app/build.gradle" ]] || die "projeto não encontrado em $ROOT"
grep -q 'versionName "6.4.2-pokemon-compatibility"' "$ROOT/app/build.gradle" || die "esta pasta não é o source 6.3 esperado"
[[ -f "$ENV_FILE" ]] && source "$ENV_FILE"
: "${ANDROID_HOME:=${ANDROID_SDK_ROOT:-}}"
: "${ANDROID_SDK_ROOT:=$ANDROID_HOME}"
: "${ANDROID_NDK_HOME:=${NDK_HOME:-}}"
[[ -n "${ANDROID_HOME:-}" && -d "$ANDROID_HOME" ]] || die "ANDROID_HOME não configurado. Use seu setup/hydrator do Kerberus."
[[ -n "${ANDROID_NDK_HOME:-}" && -d "$ANDROID_NDK_HOME" ]] || die "ANDROID_NDK_HOME não configurado."
case "$(uname -m)" in aarch64|arm64) ;; *) die "esta build é para Termux ARM64";; esac
[[ "$ROOT" != /storage/* && "$ROOT" != /sdcard/* ]] || die "mantenha o projeto dentro de $HOME; /storage pode ser noexec"
for c in git python javac java autoconf make unzip; do command -v "$c" >/dev/null || die "ferramenta ausente: $c"; done
JAVA_MAJOR="$(java -version 2>&1 | awk -F'[".]' '/version/ {print ($2 == "1" ? $3 : $2); exit}')"
[[ "$JAVA_MAJOR" =~ ^[0-9]+$ ]] || die "não foi possível detectar a versão do Java"
(( JAVA_MAJOR >= 11 && JAVA_MAJOR <= 17 )) || die "Kerberus 6.3 usa Gradle 7.4.2/AGP 7.3.1. Use JDK 11 ou 17 (detectado: $JAVA_MAJOR)."
[[ -x "$ANDROID_NDK_HOME/ndk-build" ]] || die "ndk-build não encontrado em $ANDROID_NDK_HOME"

HOST_TAG="${KERBERUS_NDK_HOST_TAG:-linux-aarch64}"
TC="$ANDROID_NDK_HOME/toolchains/llvm/prebuilt/$HOST_TAG"
[[ -d "$TC" ]] || die "toolchain NDK ausente: $TC"
CC="$TC/bin/aarch64-linux-android23-clang"; CXX="$TC/bin/aarch64-linux-android23-clang++"
AR="$TC/bin/llvm-ar"; RANLIB="$TC/bin/llvm-ranlib"; NM="$TC/bin/llvm-nm"; READELF="$TC/bin/llvm-readelf"
[[ -x "$CC" && -x "$CXX" && -x "$AR" && -x "$READELF" ]] || die "ferramentas ARM64 do NDK incompletas"
CC_CMD=("$CC"); CXX_CMD=("$CXX")
if command -v ccache >/dev/null 2>&1; then
  export CCACHE_DIR="${CCACHE_DIR:-$HOME/.ccache}"; mkdir -p "$CCACHE_DIR"
  CC_CMD=(ccache "$CC"); CXX_CMD=(ccache "$CXX"); log "ccache ativo"
fi

log "1/8 Validando fontes puros Java e o bootstrap Legacy18"
bash "$ROOT/scripts/validate-host.sh"
python "$ROOT/tools/gen-legacy18-header.py" --check
if [[ -n "${RUBY18:-}" ]]; then
  RUBY18="$RUBY18" bash "$ROOT/tests/legacy18/run-legacy18-tests.sh"
else
  log "RUBY18 nao definido: testes Ruby 1.8 do bootstrap rodam no GitHub Actions (workflow v20)"
fi

log "2/8 Preparando dependências modernas"
if [[ ! -d "$JNI/SDL2" || ! -d "$JNI/ruby" ]]; then (cd "$JNI" && bash -e get_deps.sh); fi
mkdir -p "$JNI/.kerberus-termux"
cat > "$JNI/.kerberus-termux/c-launcher.sh" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH LIBRARY_PATH SDKROOT 2>/dev/null || true
if command -v ccache >/dev/null 2>&1; then export CCACHE_DIR="${CCACHE_DIR:-$HOME/.ccache}"; exec ccache "$@"; fi
exec "$@"
EOF
cp -f "$JNI/.kerberus-termux/c-launcher.sh" "$JNI/.kerberus-termux/cxx-launcher.sh"; chmod +x "$JNI/.kerberus-termux/"*-launcher.sh

cat > "$JNI/kerberus-stage-ruby.sh" <<'EOF'
#!/data/data/com.termux/files/usr/bin/bash
set -euo pipefail
OUT="${1:?}"; ARCH="${2:?}"; JNI_DIR="$(cd "$(dirname "$0")" && pwd)"; RUBY="$JNI_DIR/ruby"
[[ -s "$RUBY/libruby.so.3.1.0" ]] || { echo "libruby 3.1 ausente" >&2; exit 1; }
mkdir -p "$OUT/lib" "$OUT/include/ruby-3.1.0"
cp -f "$RUBY/libruby.so.3.1.0" "$OUT/lib/"
ln -sfn libruby.so.3.1.0 "$OUT/lib/libruby.so.3.1"; ln -sfn libruby.so.3.1.0 "$OUT/lib/libruby.so"
cp -aL "$RUBY/include/." "$OUT/include/ruby-3.1.0/"
[[ -d "$RUBY/.ext/include" ]] && cp -aL "$RUBY/.ext/include/." "$OUT/include/ruby-3.1.0/"
[[ -f "$OUT/include/ruby-3.1.0/$ARCH/ruby/config.h" ]] || { echo "ruby/config.h $ARCH ausente" >&2; exit 1; }
EOF
chmod +x "$JNI/kerberus-stage-ruby.sh"

python - "$JNI/Makefile" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
old='\tcd ruby; make -j$(NPROC); make install\n'
new='\tcd ruby; make -j$(NPROC)\n\tbash ./kerberus-stage-ruby.sh "$(BUILD_PREFIX)" "$(HOST)-android"\n'
if old in s: s=s.replace(old,new,1)
marker='KERBERUS_ANDROID_CMAKE_FIND_ROOT_5202'
if marker not in s:
    anchor='\t-DCMAKE_C_FLAGS="$(CFLAGS)" \\\n'
    if anchor in s:
        s=s.replace(anchor, anchor+'\t-DKERBERUS_ANDROID_CMAKE_FIND_ROOT_5202=ON \\\n\t-DCMAKE_FIND_ROOT_PATH="$(TOOLCHAIN)/sysroot" \\\n\t-DCMAKE_FIND_ROOT_PATH_MODE_LIBRARY=ONLY \\\n\t-DCMAKE_FIND_ROOT_PATH_MODE_INCLUDE=ONLY \\\n\t-DCMAKE_FIND_ROOT_PATH_MODE_PACKAGE=ONLY \\\n',1)
p.write_text(s)
PY

export ARCH="$HOST_TAG" ANDROID_NDK_HOME NDK="$ANDROID_NDK_HOME"
unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH LIBRARY_PATH SDKROOT 2>/dev/null || true
MODERN="$JNI/build-arm64-v8a"
required=(libpixman-1.a libiconv.a libopenal.so libssl.a libcrypto.a)
missing=0; for x in "${required[@]}"; do [[ -e "$MODERN/lib/$x" ]] || missing=1; done
if (( missing )); then (cd "$JNI" && HOST=aarch64-linux-android TARGET=aarch64-linux-android ABI=arm64-v8a make -j"$JOBS"); fi
if [[ ! -s "$JNI/ruby/libruby.so.3.1.0" ]]; then (cd "$JNI/ruby" && make -j"$JOBS"); fi
bash "$JNI/kerberus-stage-ruby.sh" "$MODERN" "aarch64-linux-android-android"
[[ -e "$JNI/build-arm64" ]] || (cd "$JNI" && ln -s build-arm64-v8a build-arm64)

log "3/8 Compilando/stageando Ruby 1.8 legado"
R18="$JNI/ruby18-src"
if [[ ! -d "$R18/.git" ]]; then git clone -q -b ruby_1_8 https://github.com/joiplay/ruby "$R18"; fi
git -C "$R18" fetch -q origin ruby_1_8 || true
PREV_R18_HEAD="$(git -C "$R18" rev-parse HEAD 2>/dev/null || true)"
git -C "$R18" checkout -q "$PIN_RUBY18"; git -C "$R18" reset --hard -q "$PIN_RUBY18"
if [[ -n "$PREV_R18_HEAD" && "$PREV_R18_HEAD" != "$PIN_RUBY18" ]]; then git -C "$R18" clean -fdxq; fi
# Oniguruma v6.9.10 (BSD 2-Clause) for the RGSS1 regex syntax that the GNU
# engine of Ruby 1.8 rejects (scripts/patch-ruby18-oniguruma.py).
ONIG="$JNI/oniguruma-src"
if [[ ! -d "$ONIG/.git" ]]; then git clone -q --depth 1 -b v6.9.10 https://github.com/kkos/oniguruma "$ONIG"; fi
git -C "$ONIG" checkout -q -f "$PIN_ONIG" 2>/dev/null || die "commit do Oniguruma não encontrado: $PIN_ONIG"
[[ "$(git -C "$ONIG" rev-parse HEAD)" == "$PIN_ONIG" ]] || die "commit do Oniguruma diferente de $PIN_ONIG"
for name in config.guess config.sub; do aux="$PREFIX/share/libtool/build-aux/$name"; [[ -f "$aux" ]] && cp -f "$aux" "$R18/$name"; done
sed -i 's/=>TRUE/=>true/g' "$R18/mkconfig.rb" 2>/dev/null || true
python - "$R18/mkconfig.rb" <<'PY_MKCONFIG'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
old="""module RbConfig
  RUBY_VERSION == "#{version}" or
    raise "ruby lib version (#{version}) doesn't match executable version (\#{RUBY_VERSION})"

"""
new="""module RbConfig
  unless defined?(CROSS_COMPILING)
    RUBY_VERSION == "#{version}" or
      raise "ruby lib version (#{version}) doesn't match executable version (\#{RUBY_VERSION})"
  end

"""
if old in s:
    p.write_text(s.replace(old,new,1))
elif 'unless defined?(CROSS_COMPILING)' not in s:
    raise SystemExit('[ERRO] guarda de versão esperado não encontrado em mkconfig.rb')
PY_MKCONFIG
python - "$R18/ruby.c" <<'PY_R18'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
old='''#ifndef CharNext\t\t/* defined as CharNext[AW] on Windows. */\n#define CharNext(p) ((p) + mblen(p, RUBY_MBCHAR_MAXSIZE))\n#endif'''
new='''#if defined(__ANDROID__)\n#include <wchar.h>\nstatic int kerberus_android_mblen(const char *s, size_t n)\n{\n    mbstate_t state = {0};\n    size_t r = mbrlen(s, n, &state);\n    if (r == (size_t)-1 || r == (size_t)-2) return -1;\n    return (int)r;\n}\n#define KERBERUS_MBLEN(s,n) kerberus_android_mblen((s),(n))\n#else\n#define KERBERUS_MBLEN(s,n) mblen((s),(n))\n#endif\n\n#ifndef CharNext\t\t/* defined as CharNext[AW] on Windows. */\n#define CharNext(p) ((p) + KERBERUS_MBLEN(p, RUBY_MBCHAR_MAXSIZE))\n#endif'''
if old in s: p.write_text(s.replace(old,new,1))
elif 'KERBERUS_MBLEN' not in s: raise SystemExit('[ERRO] macro CharNext não encontrada em ruby.c')
PY_R18
python "$ROOT/scripts/patch-ruby18-rgss1.py" "$R18/eval.c" || die "patch RGSS1 do eval.c falhou"
python "$ROOT/scripts/patch-ruby18-performance.py" "$R18" || die "patch de desempenho do Ruby 1.8 falhou"
python "$ROOT/scripts/patch-ruby18-oniguruma.py" "$R18" "$ONIG" || die "patch Oniguruma do Ruby 1.8 falhou"
if [[ ! -f "$R18/configure" || "$R18/configure.in" -nt "$R18/configure" ]]; then (cd "$R18" && autoconf); fi
RES="$("$CC" -print-resource-dir)"
R18INC="-I$R18 -I. -nostdinc -isystem $RES/include -isystem $TC/sysroot/usr/include/aarch64-linux-android -isystem $TC/sysroot/usr/include"
R18CFLAGS="-std=gnu89 -O2 -fPIC -fno-stack-protector -fno-strict-aliasing -fwrapv -Wno-implicit-function-declaration -Wno-implicit-int -Wno-incompatible-pointer-types -Wno-int-conversion -Wno-incompatible-function-pointer-types --sysroot=$TC/sysroot $R18INC"
(
  cd "$R18"; rm -f config.cache config.status conftest conftest.* 2>/dev/null || true
  export RUBYOPT="--disable-gems"
  HOST_BUILD="$(./config.guess 2>/dev/null || echo aarch64-unknown-linux-android)"
  CC="$CC" AR="$AR" RANLIB="$RANLIB" NM="$NM" RUBY="ruby --disable-gems" BASERUBY="ruby --disable-gems" CFLAGS="$R18CFLAGS" CPPFLAGS="$R18INC" LDFLAGS="--sysroot=$TC/sysroot -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384 -ldl -lm -lz" \
  ./configure --host=aarch64-linux-android --build="$HOST_BUILD" --disable-shared --with-static-linked-ext ac_cv_func_fork=no ac_cv_func_memcmp=yes ac_cv_header_pwd_h=no ac_cv_header_langinfo_h=no
  cat > kerberus-host-ruby <<'EOF_R18_HOST'
#!/data/data/com.termux/files/usr/bin/bash
exec ruby --disable-gems "$@"
EOF_R18_HOST
  chmod +x kerberus-host-ruby
  make -j1 fake || true
  FAKE_RB="$(find . -maxdepth 1 -type f -name '*-fake.rb' -print -quit || true)"
  if [[ -n "$FAKE_RB" ]]; then
    FAKE_MOD="$(basename "$FAKE_RB" .rb)"
    HOST_MINIRUBY="$R18/kerberus-host-ruby -rrbconfig -rfileutils -rerb -I$R18 -r$FAKE_MOD"
  else
    HOST_MINIRUBY="$R18/kerberus-host-ruby"
  fi
  make -j1 CC="${CC_CMD[*]}" MINIRUBY="$HOST_MINIRUBY" RUBY="$R18/kerberus-host-ruby" BASERUBY="$R18/kerberus-host-ruby" CPPFLAGS="$R18INC" CFLAGS="$R18CFLAGS" libruby-static.a
)
[[ -s "$R18/libruby-static.a" ]] || die "Ruby 1.8 não produziu libruby-static.a"
R18OUT="$MODERN/ruby18"; rm -rf "$R18OUT"; mkdir -p "$R18OUT/lib" "$R18OUT/include" "$R18OUT/obj"
cp -f "$R18/libruby-static.a" "$R18OUT/lib/libruby18-static.a"; find "$R18" -maxdepth 1 -type f -name '*.h' -exec cp -f {} "$R18OUT/include/" \;
for spec in 'zlib:zlib.c' 'stringio:stringio.c' 'strscan:strscan.c'; do dir="${spec%%:*}"; file="${spec#*:}"; obj="$R18OUT/obj/${dir}.o"; "${CC_CMD[@]}" $R18CFLAGS -I"$R18" -I"$R18OUT/include" -DOS_CODE=OS_UNIX -c "$R18/ext/$dir/$file" -o "$obj"; done
"$AR" rcs "$R18OUT/lib/libruby18-ext.a" "$R18OUT/obj/"*.o; "$RANLIB" "$R18OUT/lib/libruby18-static.a" "$R18OUT/lib/libruby18-ext.a"
"$NM" "$R18OUT/lib/libruby18-static.a" | grep -q ' ruby_init$' || die "ruby_init ausente no core legado"
for sym in Init_zlib Init_stringio Init_strscan; do "$NM" "$R18OUT/lib/libruby18-ext.a" | grep -q " $sym$" || die "$sym ausente"; done
[[ "$("$NM" "$R18OUT/lib/libruby18-static.a" 2>/dev/null | grep -c ' T kerberus_onig_compile$')" -ge 1 ]] || die "Oniguruma ausente no core legado"

log "4/8 Sanitizando OpenAL e gerando assets XXD"
OPENAL="$MODERN/lib/libopenal.so"
if [[ -f "$OPENAL" ]]; then
python - "$OPENAL" <<'PY'
from pathlib import Path
import sys
p=Path(sys.argv[1]); b=bytearray(p.read_bytes())
for old,new in [(b'/data/data/com.termux/files/usr/lib/libOpenSLES.so',b'libOpenSLES.so'),(b'/data/data/com.termux/files/usr/lib',b'')]:
    b=b.replace(old,new+b'\0'*(len(old)-len(new)))
p.write_bytes(b)
PY
fi
if [[ -f "$OPENAL" ]] && "$READELF" -d "$OPENAL" 2>/dev/null | grep -E 'NEEDED.*(/data/data/com\.termux|/data/user/[0-9]+/com\.termux)' >/dev/null; then die "OpenAL ainda depende de caminho absoluto do Termux"; fi
(cd "$JNI/mkxp-z" && bash ./make_xxd.sh)
touch "$JNI/mkxp-z/binding/binding-mri.cpp" "$JNI/mkxp-z/binding/binding-util.h"

log "5/8 Preparando Gradle"
cat > "$ROOT/local.properties" <<EOF
sdk.dir=$ANDROID_HOME
ndk.dir=$ANDROID_NDK_HOME
EOF
chmod +x "$ROOT/gradlew"

log "6/8 Compilando APK"
(
 cd "$ROOT"
 export JAVA_HOME ANDROID_HOME ANDROID_SDK_ROOT ANDROID_NDK_HOME NDK_HOME NDK="$ANDROID_NDK_HOME"
 unset CPATH C_INCLUDE_PATH CPLUS_INCLUDE_PATH OBJC_INCLUDE_PATH LIBRARY_PATH SDKROOT 2>/dev/null || true
 ./gradlew assembleDebug --no-daemon --console=plain 2>&1 | tee "$HOME/kerberus-6.3-build.log"
)

log "7/8 Auditando APK"
APK="$(find "$ROOT/app/build/outputs/apk" -type f -iname '*arm64-v8a*debug*.apk' | sort | head -1)"
[[ -n "$APK" ]] || APK="$(find "$ROOT/app/build/outputs/apk" -type f -iname '*debug*.apk' | sort | head -1)"
[[ -f "$APK" ]] || die "APK debug não encontrada"
AUDIT="${TMPDIR:-$PREFIX/tmp}/kerberus63-audit"; rm -rf "$AUDIT"; mkdir -p "$AUDIT"; unzip -qq "$APK" 'lib/arm64-v8a/*.so' -d "$AUDIT"
LIBDIR="$AUDIT/lib/arm64-v8a"
for lib in libmkxp-z18.so libmkxp-z31.so libruby.so libopenal.so; do [[ -s "$LIBDIR/$lib" ]] || die "$lib ausente na APK"; done
if "$READELF" -d "$LIBDIR/libmkxp-z18.so" | grep -q 'libruby.so'; then die "engine legado ficou dependente do Ruby 3.1"; fi
"$READELF" -d "$LIBDIR/libmkxp-z31.so" | grep -q 'libruby.so' || die "engine moderno não referencia libruby.so"
BAD=0; while IFS= read -r so; do if "$READELF" -d "$so" 2>/dev/null | grep -E 'NEEDED.*(/data/data/com\.termux|/data/user/[0-9]+/com\.termux)' >/dev/null; then echo "[ERRO] caminho Termux em $so" >&2; BAD=1; fi; done < <(find "$LIBDIR" -name '*.so'); [[ "$BAD" -eq 0 ]] || die "APK contém dependência absoluta do Termux"

log "8/8 Copiando para Downloads"
mkdir -p "$HOME/KerberusXP/dist"; OUT="$HOME/KerberusXP/dist/$OUT_NAME"; cp -f "$APK" "$OUT"; sha256sum "$OUT" > "$OUT.sha256"
if [[ -d "$HOME/storage/downloads" ]]; then cp -f "$OUT" "$OUT.sha256" "$HOME/storage/downloads/"; fi
cat <<EOF

============================================================
KERBERUS XP 6.3 — BUILD CONCLUÍDA
============================================================
APK: $OUT
Downloads: $HOME/storage/downloads/$OUT_NAME
Log: $HOME/kerberus-6.3-build.log
Runtime modern31: Infinite Fusion / caminho moderno
Runtime legacy18: Uranium, Insurgence, Xenoverse e RGSS1 comum (WinBridge + Kerberus Ports)
============================================================
EOF
