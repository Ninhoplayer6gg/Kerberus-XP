# Kerberus XP — avisos de terceiros

Este arquivo lista o código de terceiros que o Kerberus XP **adicionou** ao
runtime a partir da 6.4.1, com origem, licença e onde ele entra. Os
componentes que já vinham no projeto (mkxp-z, SDL2, Ruby 1.8 do fork
joiplay/ruby, Ruby 3.1 etc.) continuam com as licenças nas próprias pastas.

## Oniguruma 6.9.10

- Origem: https://github.com/kkos/oniguruma, tag `v6.9.10`, commit
  `4ef89209a239c1aea328cf13c05a2807e5c146d1` (fixado em
  `scripts/build-ruby18-android.sh`, `TERMUX-BUILD-KERBERUS-6.3.sh` e
  `scripts/patch-ruby18-oniguruma.py`; o conteúdo é conferido por sha256).
- Licença: BSD 2-Clause, Copyright (c) 2002-2021 K.Kosako. Texto completo
  abaixo e, no APK, em `assets/licenses/oniguruma-COPYING.txt`.
- Onde entra: só no Ruby 1.8 do runtime legacy18 (`libmkxp-z18.so`). O
  código-fonte não é copiado para este repositório: os builds baixam o commit
  fixado e `scripts/patch-ruby18-oniguruma.py` o coloca na árvore do Ruby 1.8
  sem alterações. O runtime moderno (`libmkxp-z31.so`, Infinite Fusion) não
  recebe nada disso.
- Código do Kerberus que o usa: `scripts/ruby18-oniguruma/kerberus_onig.c`
  (chama só a API pública do Oniguruma), `scripts/ruby18-oniguruma/onig-config.h`
  e as mudanças em `regex.c`, `regex.h`, `re.c` e `common.mk` do Ruby 1.8 feitas
  por `scripts/patch-ruby18-oniguruma.py` (código escrito para o Kerberus;
  nenhum trecho copiado de outro projeto).

## WenQuanYi Micro Hei 0.2.0-beta (6.4.3)

- Origem: `app/jni/mkxp-z/assets/wqymicrohei.ttf`, a fonte CJK que o mkxp-z já
  distribui (`MKXPZ_CJK_FONT`); o arquivo não é alterado.
- Licença: Apache License 2.0 (tabela `name` da fonte). Copyright (c) 2007
  Google Corporation (dados digitalizados); Copyright (c) 2008-2009 WenQuanYi
  Board of Trustees and Qianqian Fang. Texto completo no APK em
  `assets/licenses/wqy-microhei-LICENSE.txt`.
- Onde entra: asset da APK `kerberus/fonts/wqymicrohei.ttf` (copiado pelo
  `app/build.gradle`), lido pelos dois motores só quando um texto tem
  caractere chinês/japonês/coreano que a fonte do jogo não tem.

## MGC H-Mode7 v1.2.1 — comportamento reimplementado (6.6)

- O que é: o renderizador 3D "H-Mode7 Engine" de MGC (MGCaladtogel, 2011),
  scripts Ruby + `MGC_Hmode7.dll` (x86, Windows), usado por jogos de RPG Maker
  XP como Pokémon Insurgence.
- O que o Kerberus faz: reimplementa em C++ o comportamento das 8 funções que
  a DLL exporta (`binding/kerberus/hm7-core.h`), escrito a partir de uma
  análise do que cada uma faz e conferido byte a byte contra a DLL que vem com
  o jogo do usuário, executada num emulador x86 (`tools/hm7-reference`, uso
  local). Nenhum código da DLL é copiado nem distribuído; a única informação
  reproduzida literalmente é a tabela de 64 intensidades da iluminação
  (`kRamp`), que é o próprio efeito. A DLL nunca entra no repositório nem no
  APK: os testes guardam só hashes das saídas dela.
- Os scripts do H-Mode7 são do jogo e continuam sendo os do jogo; o Kerberus
  só os ajusta em memória (ports `hm7_surface` e `hm7_rows`), sem alterar
  arquivos.
- Crédito: H-Mode7 Engine por MGC. Onde entra: só no runtime legacy18
  (`libmkxp-z18.so`).

```
Oniguruma LICENSE
-----------------

Copyright (c) 2002-2021  K.Kosako  <kkosako0@gmail.com>
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions
are met:
1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
SUCH DAMAGE.
```
