APP_ABI := arm64-v8a
APP_PLATFORM := android-23
APP_OPTIM := release
APP_STL := c++_shared
APP_CPPFLAGS := -std=c++14 -frtti -fexceptions

# Kerberus: align project shared objects for Android 15+ 16 KB page devices.
APP_LDFLAGS += -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384
