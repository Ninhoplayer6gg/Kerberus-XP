#ifndef KERBERUS_DIAGNOSTICS_H
#define KERBERUS_DIAGNOSTICS_H

#include <cstdio>
#include <SDL_stdinc.h>

// Flush every entry so that the last completed stage survives a native crash.
// The report is local to this imported game and bounded to about 256 KiB.
static void kerberusTrace(const char *stage, const char *detail)
{
    const char *path = SDL_getenv("KERBERUS_LOG_PATH");
    if (!path || !*path) return;
    std::FILE *file = std::fopen(path, "a");
    if (!file) return;
    std::fseek(file, 0, SEEK_END);
    if (std::ftell(file) >= 256 * 1024) {
        std::fclose(file);
        file = std::fopen(path, "w");
        if (!file) return;
        std::fputs("[Relatório anterior atingiu o limite de tamanho]\n", file);
    }
    std::fprintf(file, "[%s] %.4096s\n", stage, detail ? detail : "");
    std::fclose(file);
}

#endif
