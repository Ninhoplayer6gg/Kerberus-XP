# Kerberus XP 6.3 - Legacy18 bootstrap (gerado por tools/gen-legacy18-header.py).
# Nao edite este arquivo: edite app/jni/mkxp-z/binding/kerberus/legacy18/*.rb

# ==== 00_core.rb ====
# Kerberus XP 6.3 - Legacy18 core.
#
# This source is evaluated by the REAL Ruby 1.8 interpreter linked into
# libmkxp-z18.so, after every RGSS section is decoded and before any game
# section runs. Keep it valid on MRI 1.8.7: no refinements, Encoding,
# keyword arguments, prepend, define_singleton_method, caller_locations,
# lambda literals, byte-level String helpers from 1.9 or RubyVM.
#
# Nothing here edits a file of the game. Script replacements (Kerberus Ports)
# happen only in memory, on $RGSS_SCRIPTS, before the section is evaluated.
module KerberusLegacy18
  VERSION = '6.6.1'
  RUNTIME = 'legacy18'

  # Every Kerberus diagnostic raised to game code is a RuntimeError, so
  # scripts that already `rescue` optional features keep working.
  class Error < RuntimeError; end

  @events = {}
  @event_count = 0
  @native = {}
  @config = nil
  @log_writes = 0

  def self.meta(object)
    class << object
      self
    end
  end

  # ---------------------------------------------------------------------
  # Configuration (environment prepared by MainActivity.java)
  # ---------------------------------------------------------------------
  def self.env(name)
    value = ENV[name]
    value.nil? || value.empty? ? nil : value
  end

  def self.config
    return @config if @config
    trace = (env('KERBERUS_WINTRACE') || 'summary').downcase
    trace = 'summary' unless %w(off summary detail).include?(trace)
    compat_log = env('KERBERUS_COMPAT_LOG')
    @config = {
      :trace => trace,
      :compat_log => compat_log,
      :compat_dir => compat_log ? File.dirname(compat_log) : nil,
      :runtime_log => env('KERBERUS_LOG_PATH'),
      :ports => env('KERBERUS_COMPAT_MODE') != 'off',
      :ports_disabled => (env('KERBERUS_PORTS_DISABLE') || '').split(',').map { |x| x.strip }.reject { |x| x.empty? },
      :filesystem => env('KERBERUS_FS_COMPAT') != 'off',
      :dump_scripts => env('KERBERUS_DUMP_SCRIPTS') == '1',
      :frameskip => env('KERBERUS_FRAMESKIP') != 'off',
      :perf_window => [(env('KERBERUS_PERF_WINDOW') || '1200').to_i, 60].max,
      :idle_gc => (env('KERBERUS_IDLE_GC') || '').downcase,
      :exec_name => env('KERBERUS_EXEC_NAME') || 'Game'
    }
  end

  def self.reset_config!
    @config = nil
  end

  def self.trace_level
    config[:trace]
  end

  # Private per-game directory (outside the game folder) used for the
  # virtual registry, virtual Windows folders and WINTRACE reports.
  def self.data_dir(*parts)
    base = config[:compat_dir]
    return nil unless base
    path = File.join(base, 'winbridge', *parts)
    ensure_dir(path)
    path
  end

  def self.ensure_dir(path)
    return path if raw_directory?(path)
    parent = File.dirname(path)
    ensure_dir(parent) unless parent == path || raw_directory?(parent)
    Dir.mkdir(path) unless raw_directory?(path)
    path
  end

  # ---------------------------------------------------------------------
  # Raw file helpers. They never go through the Windows path layer, so
  # diagnostics cannot recurse into the code they are reporting on.
  # ---------------------------------------------------------------------
  def self.raw_directory?(path)
    File.respond_to?(:kerberus_raw_directory?) ? File.kerberus_raw_directory?(path) : File.directory?(path)
  end

  def self.raw_file?(path)
    File.respond_to?(:kerberus_raw_file?) ? File.kerberus_raw_file?(path) : File.file?(path)
  end

  def self.raw_size(path)
    File.respond_to?(:kerberus_raw_size) ? File.kerberus_raw_size(path) : File.size(path)
  end

  def self.raw_write(path, text, mode)
    file = File.respond_to?(:kerberus_raw_open) ? File.kerberus_raw_open(path, mode) : File.open(path, mode)
    begin
      file.write(text)
    ensure
      file.close
    end
  end

  def self.raw_read(path)
    file = File.respond_to?(:kerberus_raw_open) ? File.kerberus_raw_open(path, 'rb') : File.open(path, 'rb')
    begin
      file.read
    ensure
      file.close
    end
  end

  # Append a bounded line to a diagnostic file. A full or read-only
  # partition must never change the game's result, so only IO errors are
  # absorbed here; programming errors still propagate.
  def self.append_bounded(path, line, limit)
    return false unless path
    begin
      if raw_file?(path) && raw_size(path) + line.length > limit
        previous = path + '.previous'
        File.delete(previous) if raw_file?(previous)
        File.rename(path, previous)
      end
      raw_write(path, line, 'ab')
      true
    rescue SystemCallError, IOError
      false
    end
  end

  def self.clean(text, limit)
    value = text.to_s.gsub(/[\r\n\t]/, ' ')
    value.length > limit ? value[0, limit] : value
  end

  # One line per distinct (kind, api). Goes to System.puts (logcat), to the
  # per-game compatibility log shown by the launcher and, when important,
  # to the runtime report.
  def self.event(kind, api, detail, important = false)
    key = kind.to_s + ':' + api.to_s
    return nil if @events[key]
    return nil if @event_count >= 1024
    @events[key] = true
    @event_count += 1
    line = '[' + kind.to_s + '] ' + api.to_s
    detail = detail.to_s
    line << ' ' << detail unless detail.empty?
    line = clean(line, 900)
    System.puts(line) if defined?(System) && System.respond_to?(:puts) && trace_level != 'off'
    append_bounded(config[:compat_log], line + "\n", 65536) unless trace_level == 'off'
    runtime_trace(kind.to_s, api.to_s + (detail.empty? ? '' : ' ' + detail)) if important
    line
  end

  def self.forget_events!
    @events = {}
    @event_count = 0
  end

  # Same format as the native kerberusTrace(), same report file.
  def self.runtime_trace(stage, detail)
    path = config[:runtime_log]
    return false unless path
    return false if raw_file?(path) && raw_size(path) >= 256 * 1024
    begin
      raw_write(path, '[' + stage.to_s + '] ' + clean(detail, 4096) + "\n", 'ab')
      true
    rescue SystemCallError, IOError
      false
    end
  end

  def self.runtime_block(title, fields)
    lines = ['[' + title + ']']
    fields.each { |pair| lines << pair[0].to_s + '=' + clean(pair[1], 400) }
    text = lines.join("\n")
    path = config[:runtime_log]
    if path && !(raw_file?(path) && raw_size(path) >= 256 * 1024)
      begin
        raw_write(path, text + "\n", 'ab')
      rescue SystemCallError, IOError
      end
    end
    System.puts(text) if defined?(System) && System.respond_to?(:puts)
    text
  end

  # ---------------------------------------------------------------------
  # Script location (Ruby 1.8 has only Kernel#caller strings)
  # ---------------------------------------------------------------------
  SECTION_FRAME = /\ASection(\d+):(\d+)/
  NAMED_FRAME = /\A(\d{3,}):(.*):(\d+)(?::in `.*')?\z/

  def self.script_name(index)
    scripts = $RGSS_SCRIPTS
    return nil unless scripts.is_a?(Array)
    entry = scripts[index]
    return nil unless entry.is_a?(Array) && entry[1].is_a?(String)
    clean(entry[1], 80)
  end

  # Returns [script_name, section_label, line] for the first frame that
  # belongs to a game section, or a neutral triple.
  def self.location(stack)
    (stack || []).each do |frame|
      frame = frame.to_s
      if frame =~ SECTION_FRAME
        index = $1.to_i
        line = $2.to_i
        return [script_name(index) || '?', format('Section%03d', index), line]
      elsif frame =~ NAMED_FRAME
        index = $1.to_i
        line = $3.to_i
        return [script_name(index) || $2, format('Section%03d', index), line]
      end
    end
    ['nao identificado', '-', 0]
  end

  def self.here
    location(caller(1))
  end

  # Maps every SectionNNN frame of a backtrace to the RMXP script name.
  def self.readable_backtrace(backtrace, limit)
    result = []
    (backtrace || []).each do |frame|
      break if result.length >= limit
      text = frame.to_s
      if text =~ SECTION_FRAME
        name = script_name($1.to_i)
        text = text + ' [' + name + ']' if name
      end
      result << text
    end
    result
  end

  def self.describe_exception(error)
    where = location(error.backtrace)
    [['script', where[0]], ['section', where[1]], ['line', where[2]],
     ['class', error.class.name], ['message', error.message],
     ['backtrace', readable_backtrace(error.backtrace, 12).join(' <- ')],
     ['runtime', RUNTIME]]
  end

  # ---------------------------------------------------------------------
  # Native mkxp-z methods, captured before game scripts can override them.
  # ---------------------------------------------------------------------
  NATIVE_TABLE = [
    ['Input', [:update, :press?, :trigger?, :repeat?, :release?, :count,
               :pressex?, :triggerex?, :repeatex?, :releaseex?, :repeatcount,
               :mouse_x, :mouse_y, :scroll_v, :gets, :text_input, :text_input=,
               :mouse_in_window?, :clipboard, :clipboard=]],
    ['Audio', [:bgm_play, :bgm_stop, :bgm_fade, :bgm_pos,
               :bgs_play, :bgs_stop, :bgs_fade, :bgs_pos,
               :me_play, :me_stop, :me_fade, :se_play, :se_stop]],
    ['Graphics', [:update, :width, :height, :snap_to_bitmap, :resize_screen,
                  :frame_count, :frame_rate, :play_movie, :fullscreen, :fullscreen=,
                  :frameskip, :frameskip=]],
    ['System', [:puts, :user_language, :power_state, :nproc, :memory,
                :window_title, :set_window_title, :game_title, :reload_cache]]
  ]

  def self.remember_native
    return if @remembered
    @remembered = true
    NATIVE_TABLE.each do |pair|
      name = pair[0]
      next unless Object.const_defined?(name)
      mod = Object.const_get(name)
      pair[1].each do |method_name|
        @native[[name, method_name]] = mod.method(method_name) if mod.respond_to?(method_name)
      end
    end
    if defined?(::Input) && ::Input.const_defined?(:Controller)
      controller = ::Input::Controller
      [:connected?, :raw_button_states, :raw_axes, :power_level, :name].each do |method_name|
        @native[['Input::Controller', method_name]] = controller.method(method_name) if controller.respond_to?(method_name)
      end
    end
    @native[['Kernel', :print]] = Kernel.method(:print) if Kernel.respond_to?(:print)
  end

  # Method object (or nil) for hot paths: no key allocation per call.
  def self.native_method(mod, name)
    @native[[mod, name]]
  end

  def self.native?(mod, name)
    !@native[[mod, name]].nil?
  end

  def self.native(mod, name, *args)
    method = @native[[mod, name]]
    raise Error, 'Kerberus: binding nativo ausente: ' + mod.to_s + '.' + name.to_s unless method
    method.call(*args)
  end

  def self.forget_native!
    @native = {}
    @remembered = false
  end

  # Kernel-level helpers coming from pokemon-native.h. Tests run without
  # them, so each one has a Ruby fallback with the same meaning.
  def self.uptime_ms
    if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:uptime_ms)
      ::KerberusNative.uptime_ms
    else
      (Time.now.to_f * 1000.0).to_i
    end
  end

  def self.monotonic_ns
    if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:monotonic_ns)
      ::KerberusNative.monotonic_ns
    else
      (Time.now.to_f * 1000000000.0).to_i
    end
  end

  def self.focused?
    return ::KerberusNative.focused? if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:focused?)
    true
  end

  def self.thread_id
    return ::KerberusNative.thread_id if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:thread_id)
    Process.pid
  end
end

# ==== 10_signature.rb ====
# Kerberus WinBridge - Win32API signature normalization.
#
# Reference semantics: Ruby 1.8 ext/Win32API and mkxp-z MiniFFI.
#   imports: nil, a String (one type per character) or an Array of Strings
#            (first character of each item). Unknown characters are ignored
#            by Win32API; WinBridge ignores them too but records a warning.
#   exports: nil or a String; only its first character matters.
# Types: P pointer/buffer, S string pointer (= P), I/L/N 32-bit integer,
#        B BOOL (MiniFFI), V or "0" void.
# Extra accepted forms, all normalized before use:
#   "PPI:I"      imports and export joined (only when export is empty)
#   "%w(p i)"    literal percent-array text (never treated as a type)
#   0            legacy "no arguments" / void
module KerberusLegacy18
  module WinBridge
    # Win32API raises TypeError for values it cannot read as a String.
    class SignatureError < TypeError; end

    class Signature
      attr_reader :imports, :export, :raw_imports, :raw_export, :warnings

      def initialize(imports, export, raw_imports, raw_export, warnings)
        @imports = imports
        @export = export
        @raw_imports = raw_imports
        @raw_export = raw_export
        @warnings = warnings
      end

      def arity
        @imports.length
      end

      def imports_text
        @imports.empty? ? 'V' : @imports
      end

      def export_text
        @export.empty? ? 'V' : @export
      end

      def text
        imports_text + ':' + export_text
      end
    end

    module Signatures
      IMPORT_TYPES = { 'P' => 'P', 'S' => 'P', 'I' => 'I', 'L' => 'I', 'N' => 'I', 'B' => 'B' }
      SEPARATORS = " \t\r\n,;"
      PERCENT_ARRAY = /\A%[wWiI]?\s*[\(\[\{<](.*)[\)\]\}>]\z/m

      def self.raw(value)
        text = value.inspect
        text.length > 80 ? text[0, 80] + '...' : text
      end

      def self.parse(imports, export)
        warnings = []
        raw_imports = raw(imports)
        raw_export = raw(export)
        if imports.is_a?(String) && imports.index(':') && export_empty?(export)
          pair = imports.split(':', 2)
          imports = pair[0]
          export = pair[1]
          warnings << 'forma combinada imports:export normalizada'
        end
        Signature.new(parse_imports(imports, warnings), parse_export(export, warnings),
                      raw_imports, raw_export, warnings)
      end

      def self.export_empty?(value)
        value.nil? || value == 0 || (value.is_a?(String) && value.strip.empty?)
      end

      def self.string_value(value, role)
        return value if value.is_a?(String)
        return value.to_str if value.respond_to?(:to_str)
        raise SignatureError, 'assinatura ' + role + ' invalida: ' + raw(value) +
                              ' (esperado String, Array ou nil)'
      end

      def self.parse_imports(value, warnings)
        return '' if value.nil?
        if value == 0
          warnings << 'imports Integer 0 tratado como sem argumentos'
          return ''
        end
        if value.is_a?(Array)
          return items_to_types(value, warnings)
        end
        text = string_value(value, 'de imports')
        raise SignatureError, 'assinatura de imports excede 128 caracteres' if text.length > 128
        stripped = text.strip
        if stripped =~ PERCENT_ARRAY
          warnings << 'texto literal ' + stripped[0, 3] + '...) interpretado como lista de tipos'
          return items_to_types($1.split(/\s+/).reject { |item| item.empty? }, warnings)
        end
        upper = stripped.upcase
        return '' if upper == 'V' || upper == '0' || upper == 'VOID'
        result = ''
        ignored = ''
        upper.each_byte do |byte|
          char = byte.chr
          next if SEPARATORS.index(char)
          type = IMPORT_TYPES[char]
          if type
            result << type
          elsif char == 'V' || char == '0'
            ignored << char
          else
            ignored << char
          end
        end
        unless ignored.empty?
          warnings << 'caracteres ignorados como no Win32API: ' + ignored.inspect
        end
        raise SignatureError, 'mais de 16 parametros na assinatura' if result.length > 16
        result
      end

      def self.items_to_types(items, warnings)
        raise SignatureError, 'mais de 16 parametros na assinatura' if items.length > 16
        result = ''
        items.each do |item|
          text = string_value(item, 'de item')
          text = text.strip
          next if text.empty?
          type = IMPORT_TYPES[text[0, 1].upcase]
          if type
            result << type
            warnings << 'item ' + text.inspect + ': usado o primeiro caractere' if text.length > 1
          elsif text.upcase == 'V' || text == '0'
            next
          else
            warnings << 'item desconhecido ignorado: ' + text.inspect
          end
        end
        result
      end

      def self.parse_export(value, warnings)
        return '' if value.nil? || value == 0
        if value.is_a?(Array)
          warnings << 'export Array: usado o primeiro item'
          value = value.first
          return '' if value.nil?
        end
        text = string_value(value, 'de export').strip
        return '' if text.empty?
        if text =~ PERCENT_ARRAY
          words = $1.split(/\s+/).reject { |item| item.empty? }
          return '' if words.empty?
          text = words.first
        end
        first = text[0, 1].upcase
        return '' if first == 'V' || first == '0'
        type = IMPORT_TYPES[first]
        unless type
          warnings << 'export desconhecido ' + text.inspect + ' tratado como void'
          return ''
        end
        warnings << 'export ' + text.inspect + ': usado o primeiro caractere' if text.length > 1 && text.upcase != 'VOID'
        type
      end
    end
  end
end

# ==== 20_memory.rb ====
# Kerberus WinBridge - buffers, virtual memory and text conversion.
#
# Ruby 1.8 strings are byte arrays, which is exactly what Win32 buffers are.
# Real process addresses never cross this boundary: pointer-returning APIs
# hand out handles from a small virtual heap that only WinBridge providers
# (RtlMoveMemory, lstrlen, CoTaskMemFree...) understand.
module KerberusLegacy18
  module WinBridge
    class InvalidPointer < RuntimeError; end

    module Buffers
      LIMIT = 16 * 1024 * 1024

      def self.null?(value)
        value.nil? || value == 0
      end

      def self.need(value, size, writable, what)
        unless size.is_a?(Integer) && size >= 0 && size <= LIMIT
          raise ArgumentError, what + ': tamanho invalido ' + size.inspect
        end
        unless value.is_a?(String)
          raise InvalidPointer, what + ': esperado buffer String Ruby, recebido ' + value.class.name +
                                ' (enderecos numericos de memoria nao existem no Android)'
        end
        if value.length < size
          raise ArgumentError, what + ': buffer de ' + value.length.to_s + ' bytes; necessario ' + size.to_s
        end
        raise ArgumentError, what + ': buffer congelado' if writable && value.frozen?
        value
      end

      # Writes data at offset without changing the buffer length.
      def self.put(buffer, data, offset)
        offset ||= 0
        need(buffer, offset + data.length, true, 'buffer de saida')
        buffer[offset, data.length] = data unless data.empty?
        data.length
      end

      def self.put_u32(buffer, value, offset)
        put(buffer, [value & 0xffffffff].pack('V'), offset)
      end

      def self.u32(buffer, offset)
        need(buffer, offset + 4, false, 'DWORD')
        buffer[offset, 4].unpack('V')[0]
      end

      def self.pack_u64(value)
        [value & 0xffffffff, (value >> 32) & 0xffffffff].pack('VV')
      end

      # NUL-terminated ANSI/UTF-8 string argument.
      def self.c_string(value)
        return nil if null?(value)
        return Memory.c_string(value) if value.is_a?(Integer)
        text = value.is_a?(String) ? value : value.to_s
        index = text.index("\0")
        index ? text[0, index] : text
      end

      # NUL-terminated UTF-16LE string argument, returned as UTF-8.
      def self.wide_string(value)
        return nil if null?(value)
        return Memory.wide_string(value) if value.is_a?(Integer)
        Text.utf16le_to_utf8(Text.until_wide_nul(value.to_s))
      end

      # Copies text into an output buffer of `capacity` bytes, always NUL
      # terminated like the Win32 *A functions. Returns bytes copied.
      def self.copy_c_string(buffer, capacity, text)
        return 0 if capacity.nil? || capacity <= 0
        bytes = text[0, capacity - 1] || ''
        put(buffer, bytes + "\0", 0)
        bytes.length
      end
    end

    module Memory
      BASE = 0x7E000000
      STEP = 0x10000
      LIMIT = 256
      @blocks = {}
      @next = BASE

      def self.reset!
        @blocks = {}
        @next = BASE
      end

      def self.alloc(bytes)
        raise ArgumentError, 'heap virtual: bloco invalido' unless bytes.is_a?(String)
        raise ArgumentError, 'heap virtual: bloco maior que 64 KiB' if bytes.length > STEP
        raise ArgumentError, 'heap virtual esgotado (' + LIMIT.to_s + ' blocos)' if @blocks.size >= LIMIT
        handle = @next
        @next += STEP
        @next = BASE if @next >= BASE + STEP * 4096
        @next += STEP while @blocks[@next]
        @blocks[handle] = bytes.dup
        handle
      end

      def self.free(handle)
        return true if Buffers.null?(handle)
        !@blocks.delete(handle).nil?
      end

      def self.owns?(pointer)
        !locate(pointer).nil?
      end

      def self.count
        @blocks.size
      end

      # Resolves a pointer that may point inside a block.
      def self.locate(pointer)
        return nil unless pointer.is_a?(Integer)
        base = pointer - ((pointer - BASE) % STEP)
        block = @blocks[base]
        return nil unless block
        offset = pointer - base
        offset <= block.length ? [block, offset] : nil
      end

      def self.fetch(pointer, what)
        found = locate(pointer)
        return found if found
        raise InvalidPointer, what + ': ponteiro 0x' + (pointer.to_i & 0xffffffff).to_s(16) +
                              ' nao pertence ao heap virtual do Kerberus'
      end

      def self.read(pointer, length)
        return '' if length == 0
        if pointer.is_a?(String)
          Buffers.need(pointer, length, false, 'leitura')
          return pointer[0, length]
        end
        block, offset = fetch(pointer, 'leitura')
        if offset + length > block.length
          raise InvalidPointer, 'leitura de ' + length.to_s + ' bytes ultrapassa o bloco virtual'
        end
        block[offset, length]
      end

      def self.write(pointer, data)
        return 0 if data.empty?
        return Buffers.put(pointer, data, 0) if pointer.is_a?(String)
        block, offset = fetch(pointer, 'escrita')
        if offset + data.length > block.length
          raise InvalidPointer, 'escrita de ' + data.length.to_s + ' bytes ultrapassa o bloco virtual'
        end
        block[offset, data.length] = data
        data.length
      end

      def self.c_string(pointer)
        block, offset = fetch(pointer, 'string ANSI')
        tail = block[offset, block.length - offset] || ''
        index = tail.index("\0")
        index ? tail[0, index] : tail
      end

      def self.wide_string(pointer)
        block, offset = fetch(pointer, 'string UTF-16')
        Text.utf16le_to_utf8(Text.until_wide_nul(block[offset, block.length - offset] || ''))
      end

      def self.alloc_wide(text)
        alloc(Text.utf8_to_utf16le(text) + "\0\0")
      end
    end

    # UTF-8 <-> UTF-16LE and Windows-1252 without Encoding (Ruby 1.8).
    module Text
      CP1252 = {
        0x80 => 0x20AC, 0x82 => 0x201A, 0x83 => 0x0192, 0x84 => 0x201E, 0x85 => 0x2026,
        0x86 => 0x2020, 0x87 => 0x2021, 0x88 => 0x02C6, 0x89 => 0x2030, 0x8A => 0x0160,
        0x8B => 0x2039, 0x8C => 0x0152, 0x8E => 0x017D, 0x91 => 0x2018, 0x92 => 0x2019,
        0x93 => 0x201C, 0x94 => 0x201D, 0x95 => 0x2022, 0x96 => 0x2013, 0x97 => 0x2014,
        0x98 => 0x02DC, 0x99 => 0x2122, 0x9A => 0x0161, 0x9B => 0x203A, 0x9C => 0x0153,
        0x9E => 0x017E, 0x9F => 0x0178
      }
      CP1252_REVERSE = {}
      CP1252.each { |byte, code| CP1252_REVERSE[code] = byte }

      def self.until_wide_nul(bytes)
        index = 0
        while index + 1 < bytes.length
          return bytes[0, index] if bytes[index] == 0 && bytes[index + 1] == 0
          index += 2
        end
        bytes[0, bytes.length - (bytes.length % 2)]
      end

      def self.codepoints_utf8(text)
        text.unpack('U*')
      rescue ArgumentError
        # Not valid UTF-8: RGSS1 text files are often Windows-1252.
        codepoints_cp1252(text)
      end

      def self.codepoints_cp1252(bytes)
        result = []
        bytes.each_byte { |byte| result << (CP1252[byte] || byte) }
        result
      end

      def self.utf8_to_utf16le(text)
        units = []
        codepoints_utf8(text.to_s).each do |code|
          if code >= 0x10000
            code -= 0x10000
            units << (0xD800 | (code >> 10)) << (0xDC00 | (code & 0x3FF))
          else
            units << code
          end
        end
        units.pack('v*')
      end

      def self.utf16le_to_utf8(bytes)
        units = bytes.to_s.unpack('v*')
        codes = []
        index = 0
        while index < units.length
          unit = units[index]
          if unit >= 0xD800 && unit <= 0xDBFF && index + 1 < units.length &&
             units[index + 1] >= 0xDC00 && units[index + 1] <= 0xDFFF
            codes << (0x10000 + ((unit - 0xD800) << 10) + (units[index + 1] - 0xDC00))
            index += 2
          else
            codes << (unit >= 0xD800 && unit <= 0xDFFF ? 0xFFFD : unit)
            index += 1
          end
        end
        codes.pack('U*')
      end

      def self.cp1252_to_utf8(bytes)
        codepoints_cp1252(bytes.to_s).pack('U*')
      end

      def self.utf8_to_cp1252(text, default_char)
        used_default = false
        out = ''
        codepoints_utf8(text.to_s).each do |code|
          if code < 0x80 || (code >= 0xA0 && code <= 0xFF)
            out << code.chr
          elsif CP1252_REVERSE[code]
            out << CP1252_REVERSE[code].chr
          else
            out << default_char
            used_default = true
          end
        end
        [out, used_default]
      end
    end
  end
end

# ==== 30_recorder.rb ====
# Kerberus Compatibility Recorder (WINTRACE).
#
# Distinguishes three levels of evidence for every Windows API:
#   DETECTED_STATIC - a literal Win32API.new("dll", "fn") exists in a script
#   DECLARED        - Win32API.new actually ran
#   CALLED_RUNTIME  - the object was called at least once
# Only CALLED_RUNTIME APIs can be blockers; the rest are never reported as
# incompatibilities. Counting is one integer increment per call.
module KerberusLegacy18
  module Recorder
    KIND_LABELS = [
      [:native, 'Native/equivalent'],
      [:port, 'Profile/port'],
      [:limited, 'Limited'],
      [:unavailable, 'Unavailable called']
    ]
    STATIC_CALL = /(?:Win32API|MiniFFI)\s*\.\s*new\s*\(?\s*(['"])([^'"\r\n]{1,120})\1\s*,\s*(['"])([^'"\r\n]{1,120})\3/
    ANY_CALL = /(?:Win32API|MiniFFI)\s*\.\s*new\b/

    @static = {}
    @dynamic = 0
    @bindings = []
    @blockers = {}
    @dirty = false
    @frames = 0

    def self.reset!
      @static = {}
      @dynamic = 0
      @bindings = []
      @blockers = {}
      @dirty = false
      @frames = 0
    end

    def self.bindings
      @bindings
    end

    def self.static
      @static
    end

    def self.scan_static(scripts)
      return unless scripts.is_a?(Array)
      scripts.each_with_index do |entry, index|
        next unless entry.is_a?(Array) && entry[3].is_a?(String)
        source = entry[3]
        next unless source.index('Win32API') || source.index('MiniFFI')
        literals = 0
        source.scan(STATIC_CALL) do
          key = WinBridge.library($2) + '!' + $4
          list = (@static[key] ||= [])
          list << index unless list.include?(index) || list.length >= 8
          literals += 1
        end
        total = source.scan(ANY_CALL).length
        @dynamic += total - literals if total > literals
      end
    end

    def self.declared(binding)
      @bindings << binding
      @dirty = true
      if KerberusLegacy18.trace_level == 'detail'
        where = binding.declared_at || []
        KerberusLegacy18.event('DECLARED', binding.key_text,
                               binding.signature.text + ' ' + binding.kind_label + ' @' + where[1].to_s + ':' + where[2].to_s)
      end
    end

    def self.first_call(binding)
      @dirty = true
      KerberusLegacy18.event('CALLED_RUNTIME', binding.key_text, binding.kind_label + '; ' + binding.note) unless KerberusLegacy18.trace_level == 'off'
    end

    def self.blocker(binding, where)
      key = binding.key_text
      entry = (@blockers[key] ||= [0, where])
      entry[0] += 1
      @dirty = true
      if entry[0] == 1
        KerberusLegacy18.runtime_block('WINBRIDGE', binding.diagnostic(where))
        flush('blocker')
      end
    end

    def self.blockers
      @blockers
    end

    # Called once per frame by the frame hook; cheap unless dirty.
    def self.tick
      @frames += 1
      return unless @dirty && @frames >= 600
      @frames = 0
      flush('periodic')
    end

    def self.summary_lines
      called = @bindings.select { |binding| binding.calls > 0 }
      total = 0
      called.each { |binding| total += binding.calls }
      lines = []
      lines << 'WINTRACE Kerberus ' + VERSION + ' ' + RUNTIME
      lines << 'API calls (distinct): ' + called.length.to_s
      lines << 'Invocations: ' + total.to_s
      KIND_LABELS.each do |pair|
        count = called.select { |binding| binding.kind_bucket == pair[0] }.length
        lines << pair[1] + ': ' + count.to_s
      end
      declared_only = @bindings.select { |binding| binding.calls == 0 }
      static_only = @static.keys.select { |key| !@bindings.any? { |binding| binding.key_text == key } }
      lines << 'Declared, never called: ' + declared_only.length.to_s
      lines << 'DETECTED_STATIC only (never declared): ' + static_only.length.to_s
      lines << 'Dynamic Win32API.new sites: ' + @dynamic.to_s
      lines << ''
      lines << 'Top APIs:'
      called.sort { |a, b| b.calls <=> a.calls }.first(12).each do |binding|
        lines << binding.key_text + ' - ' + binding.calls.to_s + ' calls [' + binding.kind_label + ']'
      end
      lines << ''
      lines << 'BLOCKERS:'
      if @blockers.empty?
        lines << '(nenhum)'
      else
        @blockers.keys.sort.each do |key|
          count, where = @blockers[key]
          lines << key + ' - ' + count.to_s + ' calls @' + where[1].to_s + ':' + where[2].to_s + ' (' + where[0].to_s + ')'
        end
      end
      limited = called.select { |binding| binding.kind_bucket == :limited }
      unless limited.empty?
        lines << ''
        lines << 'LIMITED (called):'
        limited.each { |binding| lines << binding.key_text + ' - ' + binding.note }
      end
      unless declared_only.empty?
        lines << ''
        lines << 'DECLARED (never called):'
        declared_only.first(40).each { |binding| lines << binding.key_text + ' [' + binding.kind_label + ']' }
      end
      unless static_only.empty?
        lines << ''
        lines << 'DETECTED_STATIC (never declared):'
        static_only.sort.first(40).each do |key|
          lines << key + ' sections=' + @static[key].map { |i| format('%03d', i) }.join(',')
        end
      end
      lines
    end

    def self.flush(reason)
      @dirty = false
      return false if KerberusLegacy18.trace_level == 'off'
      directory = KerberusLegacy18.data_dir
      return false unless directory
      text = summary_lines.join("\n") + "\n(" + reason.to_s + ")\n"
      begin
        KerberusLegacy18.raw_write(File.join(directory, 'wintrace.txt'), text, 'wb')
        true
      rescue SystemCallError, IOError
        false
      end
    end
  end

  # Evidence-based milestones. Each one is recorded once per session.
  module Milestones
    ORDER = %w(BOOT TITLE MAP BATTLE SAVE LONG_PLAY)
    @reached = {}
    @polls = 0
    @map_seconds = 0.0
    @last_poll = nil
    @last_position = nil
    @pending_saves = []

    def self.reset!
      @reached = {}
      @polls = 0
      @map_seconds = 0.0
      @last_poll = nil
      @last_position = nil
      @pending_saves = []
    end

    def self.reached
      @reached
    end

    def self.reach(name, detail)
      return false if @reached[name]
      @reached[name] = Time.now.to_i
      line = "MILESTONE\t" + name + "\t" + RUNTIME + "\t" + @reached[name].to_s + "\t" + KerberusLegacy18.clean(detail, 200) + "\n"
      directory = KerberusLegacy18.config[:compat_dir]
      KerberusLegacy18.append_bounded(File.join(directory, 'milestones.log'), line, 65536) if directory
      KerberusLegacy18.runtime_trace('MILESTONE', name + ' ' + detail.to_s)
      true
    end

    def self.save_candidate(path)
      text = path.to_s.tr('\\', '/')
      return unless text =~ /\.rxdata\z/i || text =~ /\.rvdata2?\z/i
      return if text =~ %r{(\A|/)Data/}i
      @pending_saves << text unless @pending_saves.include?(text) || @pending_saves.length >= 8
    end

    def self.scene_name
      scene = $scene
      scene.nil? ? '' : scene.class.name.to_s
    end

    def self.on_map?
      return false unless defined?(::Scene_Map) && $scene.is_a?(::Scene_Map)
      map = $game_map
      map && map.respond_to?(:map_id) && map.map_id.to_i > 0
    end

    def self.poll
      @polls += 1
      now = Time.now.to_f
      elapsed = @last_poll ? now - @last_poll : 0.0
      @last_poll = now
      name = scene_name
      reach('TITLE', name) if name =~ /Title/i
      if on_map?
        @map_seconds += elapsed if elapsed < 5.0
        player = $game_player
        if player && player.respond_to?(:x) && player.respond_to?(:y)
          position = [$game_map.map_id, player.x, player.y]
          reach('MAP', 'map_id=' + position[0].to_s + ' movimento confirmado') if @last_position && @last_position != position
          @last_position = position
        end
        reach('LONG_PLAY', (@map_seconds / 60).to_i.to_s + ' minutos em mapa nesta sessao') if @map_seconds >= 3600
      end
      if !@reached['BATTLE']
        if name =~ /Battle/
          reach('BATTLE', name)
        elsif @polls % 2 == 0 && caller(0).join(' ') =~ /in `(pbStartBattle|pbWildBattle|pbTrainerBattle|pbBattleAnimation|pbSceneStandby|pbDoubleWildBattle)'/
          reach('BATTLE', $1)
        end
      end
      check_saves unless @pending_saves.empty?
    end

    def self.check_saves
      @pending_saves.dup.each do |path|
        next unless KerberusLegacy18.raw_file?(path) && KerberusLegacy18.raw_size(path) > 0
        @pending_saves.delete(path)
        reach('SAVE', File.basename(path))
      end
    end
  end
end

# ==== 40_winbridge.rb ====
# Kerberus WinBridge - Win32API interception with deferred binding.
#
# Resolution chain for Win32API.new(dll, function, imports, exports):
#   1. Kerberus native provider (kernel32/user32/... equivalents)
#   2. Kerberus Port provider (replacement for a known fangame DLL)
#   3. Optional compatibility backend (reserved; nil in normal builds)
#   4. Real shared object (".so" names only) through mkxp-z MiniFFI
#   5. Deferred binding: construction succeeds, a call raises
#      WINBRIDGE_UNAVAILABLE with dll/function/signature/script/line.
#
# The object returned is always a real Win32API (MiniFFI) instance, so
# scripts that reopen Win32API, alias #call or test is_a?(Win32API) keep
# working. Only #initialize and #call are wrapped.
module KerberusLegacy18
  module WinBridge
    class Unavailable < KerberusLegacy18::Error; end

    ERROR_SUCCESS = 0
    ERROR_FILE_NOT_FOUND = 2
    ERROR_PATH_NOT_FOUND = 3
    ERROR_ACCESS_DENIED = 5
    ERROR_INVALID_HANDLE = 6
    ERROR_NOT_ENOUGH_MEMORY = 8
    ERROR_INVALID_PARAMETER = 87
    ERROR_CALL_NOT_IMPLEMENTED = 120
    ERROR_INSUFFICIENT_BUFFER = 122
    ERROR_MOD_NOT_FOUND = 126
    ERROR_PROC_NOT_FOUND = 127
    ERROR_ALREADY_EXISTS = 183
    ERROR_ENVVAR_NOT_FOUND = 203
    ERROR_MORE_DATA = 234
    ERROR_NO_MORE_ITEMS = 259
    ERROR_INVALID_WINDOW_HANDLE = 1400
    ERROR_DEVICE_NOT_CONNECTED = 1167

    DLL_ALIASES = {
      'xinput1_1' => 'xinput', 'xinput1_2' => 'xinput', 'xinput1_3' => 'xinput',
      'xinput1_4' => 'xinput', 'xinput9_1_0' => 'xinput',
      'wsock32' => 'ws2_32', 'kernelbase' => 'kernel32',
      'msvcr70' => 'msvcrt', 'msvcr71' => 'msvcrt', 'msvcr80' => 'msvcrt', 'msvcr90' => 'msvcrt',
      'msvcr100' => 'msvcrt', 'msvcr110' => 'msvcrt', 'msvcr120' => 'msvcrt', 'ucrtbase' => 'msvcrt',
      'rgss fmodex' => 'rgss_fmodex', 'rgss linker' => 'rgss_linker'
    }

    class Provider
      attr_reader :dll, :name, :kind, :note, :params, :impl

      def initialize(dll, name, kind, note, params, impl)
        @dll = dll
        @name = name
        @kind = kind
        @note = note
        @params = params
        @impl = impl
      end
    end

    # Shared by every Win32API object with the same dll/function/signature.
    class Binding
      attr_reader :dll, :function, :signature, :provider, :calls
      attr_accessor :declared_at

      def initialize(dll, function, signature, provider)
        @dll = dll
        @function = function
        @signature = signature
        @provider = provider
        @arity = signature.arity
        @export = signature.export
        @impl = provider.impl
        @calls = 0
        @too_few = provider.params && signature.arity < provider.params
      end

      def kind
        @provider.kind
      end

      def kind_bucket
        kind
      end

      def kind_label
        WinBridge.kind_label(kind)
      end

      def note
        @provider.note
      end

      def key_text
        @dll + '!' + @function
      end

      def invoke(args)
        if args.length != @arity
          raise KerberusLegacy18::Error, 'wrong number of parameters: expected ' + @arity.to_s + ', got ' +
                                         args.length.to_s + ' (' + key_text + ' ' + @signature.text + ')'
        end
        if @too_few
          raise ArgumentError, key_text + ' requer ' + @provider.params.to_s + ' parametros; a assinatura ' +
                               @signature.raw_imports + ' declara ' + @arity.to_s
        end
        @calls += 1
        Recorder.first_call(self) if @calls == 1
        result = @impl.call(args)
        case @export
        when '' then 0
        when 'I' then WinBridge.to_i32(result)
        when 'B' then !(result.nil? || result == false || result == 0)
        else WinBridge.pointer_result(result, self)
        end
      end

      def diagnostic(where)
        WinBridge.diagnostic_fields(self, where, 'provider', kind_label)
      end
    end

    # Declared API without a usable provider. Construction never fails;
    # every call raises a precise, rescuable Unavailable error.
    class Deferred
      attr_reader :dll, :function, :signature, :provider, :calls
      attr_accessor :declared_at

      def initialize(dll, function, signature, provider)
        @dll = dll
        @function = function
        @signature = signature
        @provider = provider
        @calls = 0
      end

      def kind
        :unavailable
      end

      def kind_bucket
        :unavailable
      end

      def kind_label
        @provider ? 'Unavailable (known)' : 'Unavailable (missing)'
      end

      def note
        @provider ? @provider.note : 'nenhum provider, port ou backend para esta API'
      end

      def key_text
        @dll + '!' + @function
      end

      def invoke(args)
        @calls += 1
        where = KerberusLegacy18.location(caller(0))
        Recorder.blocker(self, where)
        raise Unavailable, message(where)
      end

      def message(where)
        lines = ['WINBRIDGE_UNAVAILABLE']
        diagnostic(where).each { |pair| lines << pair[0] + '=' + pair[1].to_s }
        lines.join("\n")
      end

      def diagnostic(where)
        WinBridge.diagnostic_fields(self, where, 'provider', @provider ? 'unavailable' : 'missing')
      end
    end

    @providers = {}
    @bindings = {}
    @recent = {}
    @backend = nil
    @last_error = 0
    @installed = false

    class << self
      attr_accessor :backend
    end

    def self.reset!
      @bindings = {}
      @recent = {}
      @last_error = 0
    end

    def self.kind_label(kind)
      case kind
      when :native then 'Native/equivalent'
      when :port then 'Profile/port'
      when :limited then 'Limited'
      else 'Unavailable'
      end
    end

    def self.diagnostic_fields(binding, where, provider_key, provider_value)
      declared = binding.declared_at || []
      [['dll', binding.dll], ['function', binding.function],
       ['imports', binding.signature.imports_text], ['exports', binding.signature.export_text],
       ['signature', binding.signature.raw_imports + ' / ' + binding.signature.raw_export],
       [provider_key, provider_value], ['reason', binding.note],
       ['script', where[0]], ['section', where[1]], ['line', where[2]],
       ['declared', declared[1].to_s + ':' + declared[2].to_s + ' (' + declared[0].to_s + ')'],
       ['runtime', RUNTIME], ['call_count', binding.calls]]
    end

    # RGSS1 ran on 32-bit Windows: Win32API returned INT2NUM((long)eax).
    def self.to_i32(value)
      value = 1 if value == true
      value = 0 if value.nil? || value == false
      unless value.is_a?(Integer)
        raise TypeError, 'WinBridge: provider retornou ' + value.class.name + ' para export inteiro'
      end
      value &= 0xffffffff
      value >= 0x80000000 ? value - 0x100000000 : value
    end

    def self.pointer_result(value, binding)
      return value if value.is_a?(String)
      return Memory.c_string(value) if value.is_a?(Integer) && value != 0 && Memory.owns?(value)
      raise KerberusLegacy18::Error, binding.key_text + ': ponteiro nulo retornado para export P'
    end

    # ---------------------------------------------------------------------
    # Error state (GetLastError/SetLastError)
    # ---------------------------------------------------------------------
    def self.last_error
      @last_error
    end

    def self.last_error=(value)
      @last_error = value.to_i & 0xffffffff
    end

    # Documented Win32 failure: sets GetLastError and returns the failure
    # value the real API returns. Never reports success.
    def self.failure(error_code, result)
      @last_error = error_code
      result
    end

    def self.success(result)
      @last_error = ERROR_SUCCESS
      result
    end

    # ---------------------------------------------------------------------
    # Provider registry
    # ---------------------------------------------------------------------
    def self.library(value)
      text = value.to_s.tr('\\', '/')
      name = text.split('/').last.to_s.strip.downcase
      name = name[0, name.length - 4] if name.length > 4 && name[-4, 4] == '.dll'
      name = 'rgss1' if name =~ /\Argss1\d\d[a-z]?\z/
      DLL_ALIASES[name] || name
    end

    # kind: :native, :limited, :port or :unavailable. params: minimum
    # argument count the implementation reads (nil = any).
    def self.provide(dll, names, kind, note, params, &impl)
      table = (@providers[dll] ||= {})
      names = [names] unless names.is_a?(Array)
      names.each do |name|
        table[name] = Provider.new(dll, name, kind, note, params, impl)
      end
    end

    # Win32API tries the exact export first, then the ANSI "A" variant.
    def self.lookup(dll, function)
      table = @providers[dll]
      return nil unless table
      table[function] || table[function + 'A']
    end

    def self.provides_library?(dll)
      table = @providers[library(dll)]
      !table.nil? && table.values.any? { |provider| provider.kind != :unavailable }
    end

    def self.providers
      @providers
    end

    def self.native_library?(dll)
      text = dll.to_s.downcase
      text =~ /\.so(\.\d+)*\z/ ? true : false
    end

    # ---------------------------------------------------------------------
    # Binding creation
    # ---------------------------------------------------------------------
    def self.string_arg(value, what)
      return value if value.is_a?(String)
      return value.to_str if value.respond_to?(:to_str)
      raise TypeError, 'Win32API.new: ' + what + ' deve ser String, recebido ' + value.class.name
    end

    def self.attach(object, argv, block)
      unless argv.length >= 2 && argv.length <= 4
        raise ArgumentError, 'wrong number of arguments (' + argv.length.to_s + ' for 2..4)'
      end
      dll = string_arg(argv[0], 'DLL')
      function = string_arg(argv[1], 'funcao')
      binding = recent_binding(dll, function, argv[2], argv[3])
      if binding
        object.instance_variable_set(:@_kerberus_winbridge, binding)
        object.instance_variable_set(:@_funcname, function)
        object.instance_variable_set(:@_libname, dll)
        block.call(object) if block
        return nil
      end
      if native_library?(dll)
        object.send(:kerberus_winbridge_native_initialize, *argv, &block)
        return nil
      end
      imports = argv[2]
      export = argv[3]
      key = dll + "\0" + function + "\0" + key_part(imports) + "\0" + key_part(export)
      binding = @bindings[key] || create(key, dll, function, imports, export)
      remember_binding(dll, function, imports, export, binding)
      object.instance_variable_set(:@_kerberus_winbridge, binding)
      object.instance_variable_set(:@_funcname, function)
      object.instance_variable_set(:@_libname, dll)
      block.call(object) if block
      nil
    end

    # 6.5: Win32API.new of the same API is made many times per frame by
    # Essentials (objects created inside methods called for every key). The
    # binding for a (dll, function, imports, export) never changes, so it is
    # looked up by DLL and function name without building the key string.
    def self.recent_binding(dll, function, imports, export)
      by_function = @recent[dll]
      return nil unless by_function
      entries = by_function[function]
      return nil unless entries
      i = 0
      while i < entries.length
        entry = entries[i]
        return entry[2] if entry[0] == imports && entry[1] == export
        i += 1
      end
      nil
    end

    def self.remember_binding(dll, function, imports, export, binding)
      by_function = (@recent[dll] ||= {})
      entries = (by_function[function] ||= [])
      entries << [copy_part(imports), copy_part(export), binding] if entries.length < 8
    end

    def self.copy_part(value)
      value.is_a?(String) || value.is_a?(Array) ? value.dup.freeze : value
    end

    def self.key_part(value)
      value.is_a?(String) ? value : value.inspect
    end

    def self.create(key, dll, function, imports, export)
      lib = library(dll)
      where = KerberusLegacy18.location(caller(0))
      begin
        signature = Signatures.parse(imports, export)
      rescue SignatureError => error
        fields = [['error', 'SIGNATURE_INVALID'], ['dll', lib], ['function', function],
                  ['imports', Signatures.raw(imports)], ['exports', Signatures.raw(export)],
                  ['reason', error.message], ['script', where[0]], ['section', where[1]],
                  ['line', where[2]], ['runtime', RUNTIME]]
        KerberusLegacy18.runtime_block('WINBRIDGE', fields)
        raise SignatureError, "WINBRIDGE_SIGNATURE\n" + fields.map { |pair| pair[0] + '=' + pair[1].to_s }.join("\n")
      end
      provider = lookup(lib, function)
      provider ||= @backend.resolve(lib, function, signature) if @backend
      binding = if provider && provider.kind != :unavailable
                  Binding.new(lib, function, signature, provider)
                else
                  Deferred.new(lib, function, signature, provider)
                end
      binding.declared_at = where
      signature.warnings.each do |warning|
        KerberusLegacy18.event('SIGNATURE_ADAPTED', binding.key_text,
                               warning + '; recebido ' + signature.raw_imports + ' / ' + signature.raw_export)
      end
      if provider && provider.params && signature.arity < provider.params
        KerberusLegacy18.event('SIGNATURE_ARITY', binding.key_text,
                               'assinatura ' + signature.text + ' tem menos parametros que a API (' + provider.params.to_s + ')', true)
      end
      Recorder.declared(binding)
      @bindings[key] = binding
    end

    # ---------------------------------------------------------------------
    # Installation on the real Win32API (mkxp-z MiniFFI) class
    # ---------------------------------------------------------------------
    def self.install
      return false if @installed
      @installed = true
      unless Object.const_defined?(:Win32API)
        # Builds without MiniFFI: keep the same public surface.
        Object.const_set(:Win32API, Class.new)
        ::Win32API.class_eval do
          def initialize(*argv)
            raise KerberusLegacy18::WinBridge::Unavailable, 'MiniFFI ausente neste build: ' + argv[0].to_s + '!' + argv[1].to_s
          end

          def call(*args)
            raise KerberusLegacy18::WinBridge::Unavailable, 'MiniFFI ausente neste build'
          end
        end
      end
      ::Win32API.class_eval do
        alias_method :kerberus_winbridge_native_initialize, :initialize
        alias_method :kerberus_winbridge_native_call, :call

        def initialize(*argv, &block)
          KerberusLegacy18::WinBridge.attach(self, argv, block)
        end

        def call(*args)
          bridge = @_kerberus_winbridge
          return bridge.invoke(args) if bridge
          kerberus_winbridge_native_call(*args)
        end

        alias_method :Call, :call
      end
      KerberusLegacy18.event('WINBRIDGE', 'Win32API', 'legacy18 WinBridge ativo; deferred binding habilitado')
      true
    end

    def self.installed?
      @installed
    end
  end
end

# ==== 45_ini.rb ====
# Kerberus WinBridge - native INI (GetPrivateProfile*/WritePrivateProfile*).
#
# Windows rules implemented:
#  - a file name without any directory separator lives in the Windows
#    directory (virtual, per game, outside the game folder);
#  - ".\Game.ini" and other relative/absolute paths use the real file;
#  - section and key names are case-insensitive, first match wins;
#  - only ";" starts a comment; values are trimmed and one pair of
#    surrounding quotes is removed;
#  - writes preserve every other line, comment and the line ending style.
module KerberusLegacy18
  module WinBridge
    module Ini
      LIMIT = 1024 * 1024
      @cache = {}

      def self.reset!
        @cache = {}
      end

      def self.windows_dir
        KerberusLegacy18.data_dir('Windows') || '.'
      end

      def self.path_for(filename)
        name = Buffers.null?(filename) ? 'win.ini' : Buffers.c_string(filename).to_s
        name = 'win.ini' if name.empty?
        unix = name.tr('\\', '/')
        return File.join(windows_dir, unix) unless unix.index('/')
        Paths.resolve(unix, true)
      end

      def self.load(path)
        return nil unless KerberusLegacy18.raw_file?(path)
        stat = File.stat(path)
        cached = @cache[path]
        return cached[2] if cached && cached[0] == stat.mtime.to_i && cached[1] == stat.size
        raise ArgumentError, 'INI excede 1 MiB: ' + path if stat.size > LIMIT
        data = parse(KerberusLegacy18.raw_read(path))
        @cache[path] = [stat.mtime.to_i, stat.size, data]
        data
      end

      # => { :newline, :pre => [raw], :sections => [[name, [[key|nil, value|nil, raw]]]] }
      def self.parse(bytes)
        bytes = bytes[3, bytes.length - 3] if bytes[0, 3] == "\xEF\xBB\xBF"
        newline = bytes.index("\r\n") ? "\r\n" : "\n"
        data = { :newline => newline, :pre => [], :sections => [] }
        current = nil
        rows = bytes.split(/\r?\n/, -1)
        rows.pop if rows.last == ''
        rows.each do |raw|
          line = raw.strip
          if line[0, 1] == '['
            close = line.index(']')
            name = close ? line[1, close - 1] : line[1, line.length - 1]
            current = [name.strip, []]
            data[:sections] << current
          elsif current.nil?
            data[:pre] << raw
          elsif line.empty? || line[0, 1] == ';'
            current[1] << [nil, nil, raw]
          elsif (eq = line.index('='))
            current[1] << [line[0, eq].strip, unquote(line[eq + 1, line.length - eq - 1].strip), raw]
          else
            current[1] << [line, '', raw]
          end
        end
        data
      end

      def self.unquote(value)
        if value.length >= 2 && ((value[0, 1] == '"' && value[-1, 1] == '"') ||
                                 (value[0, 1] == "'" && value[-1, 1] == "'"))
          value[1, value.length - 2]
        else
          value
        end
      end

      def self.section(data, name)
        wanted = name.downcase
        data[:sections].each { |entry| return entry if entry[0].downcase == wanted }
        nil
      end

      def self.value(data, section_name, key)
        entry = data && section(data, section_name)
        return nil unless entry
        wanted = key.downcase
        entry[1].each { |item| return item[1] if item[0] && item[0].downcase == wanted }
        nil
      end

      def self.section_names(data)
        data ? data[:sections].map { |entry| entry[0] } : []
      end

      def self.key_names(data, section_name)
        entry = data && section(data, section_name)
        entry ? entry[1].select { |item| item[0] }.map { |item| item[0] } : []
      end

      # GetPrivateProfileStringA(section, key, default, out, size, file)
      def self.read_string(section_arg, key_arg, default_arg, output, capacity, filename)
        capacity = capacity.to_i
        return WinBridge.success(0) if capacity <= 0
        Buffers.need(output, capacity, true, 'GetPrivateProfileString')
        data = load(path_for(filename))
        section_name = Buffers.c_string(section_arg)
        key = Buffers.c_string(key_arg)
        if section_name.nil? || key.nil?
          names = section_name.nil? ? section_names(data) : key_names(data, section_name)
          return write_list(output, capacity, names)
        end
        found = value(data, section_name, key)
        text = found.nil? ? (Buffers.c_string(default_arg) || '').sub(/\s+\z/, '') : found
        if text.length > capacity - 1
          Buffers.put(output, text[0, capacity - 1] + "\0", 0)
          return WinBridge.failure(ERROR_MORE_DATA, capacity - 1)
        end
        Buffers.put(output, text + "\0", 0)
        WinBridge.failure(found.nil? ? ERROR_FILE_NOT_FOUND : ERROR_SUCCESS, text.length)
      end

      # Double NUL terminated list; truncated lists return size - 2.
      def self.write_list(output, capacity, names)
        text = names.map { |name| name + "\0" }.join
        if text.length + 1 <= capacity
          Buffers.put(output, text + "\0", 0)
          return WinBridge.success(text.length)
        end
        if capacity < 2
          Buffers.put(output, "\0" * capacity, 0)
          return WinBridge.failure(ERROR_MORE_DATA, 0)
        end
        Buffers.put(output, text[0, capacity - 2] + "\0\0", 0)
        WinBridge.failure(ERROR_MORE_DATA, capacity - 2)
      end

      # GetPrivateProfileIntA(section, key, default, file)
      def self.read_int(section_arg, key_arg, default, filename)
        found = value(load(path_for(filename)), Buffers.c_string(section_arg).to_s, Buffers.c_string(key_arg).to_s)
        return default.to_i if found.nil?
        text = found.strip
        return 0 unless text =~ /\A(-?)(0[xX][0-9a-fA-F]+|\d+)/
        number = $2.downcase[0, 2] == '0x' ? $2.hex : $2.to_i
        number = -number unless $1.empty?
        number < 0 ? 0 : number
      end

      # GetPrivateProfileSectionA(section, out, size, file) -> "k=v\0k=v\0\0"
      def self.read_section(section_arg, output, capacity, filename)
        data = load(path_for(filename))
        entry = data && section(data, Buffers.c_string(section_arg).to_s)
        pairs = entry ? entry[1].select { |item| item[0] }.map { |item| item[0] + '=' + item[1].to_s } : []
        write_list(output, capacity.to_i, pairs)
      end

      # WritePrivateProfileStringA(section, key, value, file)
      def self.write_string(section_arg, key_arg, value_arg, filename)
        section_name = Buffers.c_string(section_arg)
        return WinBridge.failure(ERROR_INVALID_PARAMETER, 0) if section_name.nil?
        key = Buffers.c_string(key_arg)
        value = Buffers.c_string(value_arg)
        path = path_for(filename)
        directory = File.dirname(path)
        return WinBridge.failure(ERROR_PATH_NOT_FOUND, 0) unless KerberusLegacy18.raw_directory?(directory)
        data = load(path) || { :newline => "\r\n", :pre => [], :sections => [] }
        entry = section(data, section_name)
        if key.nil?
          data[:sections].delete(entry) if entry
        else
          unless entry
            return WinBridge.success(1) if value.nil?
            entry = [section_name, []]
            data[:sections] << entry
          end
          index = nil
          entry[1].each_with_index { |item, i| index = i if index.nil? && item[0] && item[0].downcase == key.downcase }
          if value.nil?
            entry[1].delete_at(index) if index
          elsif index
            entry[1][index] = [entry[1][index][0], value, entry[1][index][0] + '=' + value]
          else
            position = entry[1].length
            position -= 1 while position > 0 && entry[1][position - 1][0].nil? && entry[1][position - 1][2].strip.empty?
            entry[1].insert(position, [key, value, key + '=' + value])
          end
        end
        store(path, data)
        Paths.invalidate(path) if defined?(Paths)
        WinBridge.success(1)
      end

      def self.store(path, data)
        newline = data[:newline]
        lines = data[:pre].dup
        data[:sections].each do |entry|
          lines << '[' + entry[0] + ']'
          entry[1].each { |item| lines << item[2] }
        end
        text = lines.join(newline)
        text << newline unless text.empty?
        KerberusLegacy18.raw_write(path, text, 'wb')
        @cache.delete(path)
      end
    end
  end
end

# ==== 46_registry.rb ====
# Kerberus WinBridge - virtual Windows registry, one per game.
#
# Persisted in the private Kerberus directory of the game, never in the
# game folder and never in any system location. Seeded only with the keys
# that RGSS itself creates (PlayMusic/PlaySound).
module KerberusLegacy18
  module WinBridge
    module Registry
      ROOTS = {
        0x80000000 => 'HKEY_CLASSES_ROOT', 0x80000001 => 'HKEY_CURRENT_USER',
        0x80000002 => 'HKEY_LOCAL_MACHINE', 0x80000003 => 'HKEY_USERS',
        0x80000005 => 'HKEY_CURRENT_CONFIG'
      }
      REG_NONE = 0
      REG_SZ = 1
      REG_EXPAND_SZ = 2
      REG_BINARY = 3
      REG_DWORD = 4
      REG_MULTI_SZ = 7
      REG_QWORD = 11
      REG_CREATED_NEW_KEY = 1
      REG_OPENED_EXISTING_KEY = 2
      HANDLE_BASE = 0x00B00000
      MAX_HANDLES = 256
      SEED = [['HKEY_CURRENT_USER\\Software\\Enterbrain\\RGSS', 'PlayMusic', REG_DWORD, [1].pack('V')],
              ['HKEY_CURRENT_USER\\Software\\Enterbrain\\RGSS', 'PlaySound', REG_DWORD, [1].pack('V')]]

      @keys = nil
      @handles = {}
      @next = HANDLE_BASE

      def self.reset!
        @keys = nil
        @handles = {}
        @next = HANDLE_BASE
      end

      def self.store_path
        directory = KerberusLegacy18.data_dir
        directory ? File.join(directory, 'registry.dat') : nil
      end

      def self.keys
        return @keys if @keys
        @keys = {}
        path = store_path
        if path && KerberusLegacy18.raw_file?(path)
          loaded = Marshal.load(KerberusLegacy18.raw_read(path))
          @keys = loaded if loaded.is_a?(Hash)
        end
        SEED.each do |seed|
          entry = ensure_key(seed[0])
          entry[:values][seed[1].downcase] ||= [seed[1], seed[2], seed[3]]
        end
        @keys
      end

      def self.persist
        path = store_path
        KerberusLegacy18.raw_write(path, Marshal.dump(@keys), 'wb') if path
      end

      def self.normalize(path)
        path.to_s.tr('/', '\\').gsub(/\\+/, '\\').sub(/\A\\/, '').sub(/\\\z/, '')
      end

      def self.ensure_key(full)
        lower = full.downcase
        entry = @keys[lower]
        return entry if entry
        parent = full.rindex('\\')
        ensure_key(full[0, parent]) if parent
        @keys[lower] = { :name => full, :values => {} }
      end

      # Handle -> full key path (roots are valid handles too).
      def self.path_of(handle)
        handle = handle.to_i & 0xffffffff
        ROOTS[handle] || @handles[handle]
      end

      def self.join(base, subkey)
        sub = normalize(Buffers.c_string(subkey).to_s)
        sub.empty? ? base : base + '\\' + sub
      end

      def self.new_handle(full)
        return nil if @handles.size >= MAX_HANDLES
        handle = @next
        @next += 4
        @handles[handle] = full
        handle
      end

      def self.open(root, subkey, output)
        base = path_of(root)
        return ERROR_INVALID_HANDLE unless base
        full = join(base, subkey)
        entry = keys[full.downcase]
        return ERROR_FILE_NOT_FOUND unless entry
        handle = new_handle(entry[:name])
        return ERROR_NOT_ENOUGH_MEMORY unless handle
        Buffers.put_u32(output, handle, 0)
        ERROR_SUCCESS
      end

      def self.create(root, subkey, output, disposition)
        base = path_of(root)
        return ERROR_INVALID_HANDLE unless base
        full = join(base, subkey)
        existed = !keys[full.downcase].nil?
        entry = ensure_key(full)
        persist unless existed
        handle = new_handle(entry[:name])
        return ERROR_NOT_ENOUGH_MEMORY unless handle
        Buffers.put_u32(output, handle, 0)
        Buffers.put_u32(disposition, existed ? REG_OPENED_EXISTING_KEY : REG_CREATED_NEW_KEY, 0) unless Buffers.null?(disposition)
        ERROR_SUCCESS
      end

      # RegEnumKeyExA: index-th direct subkey (sorted by name), then
      # ERROR_NO_MORE_ITEMS; size_io is the buffer size in, name length out.
      def self.enum_key(handle, index, name_out, size_io)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        prefix = base.downcase + '\\'
        children = []
        keys.each_value do |entry|
          lower = entry[:name].downcase
          next unless lower.length > prefix.length && lower[0, prefix.length] == prefix
          rest = entry[:name][prefix.length..-1]
          children << rest unless rest.index('\\')
        end
        children = children.sort_by { |name| name.downcase }
        return ERROR_NO_MORE_ITEMS if index < 0 || index >= children.length
        name = children[index]
        return ERROR_MORE_DATA if Buffers.u32(size_io, 0) <= name.length
        Buffers.put(name_out, name + "\0", 0)
        Buffers.put_u32(size_io, name.length, 0)
        ERROR_SUCCESS
      end

      def self.close(handle)
        @handles.delete(handle.to_i & 0xffffffff) || ROOTS[handle.to_i & 0xffffffff] ? ERROR_SUCCESS : ERROR_INVALID_HANDLE
      end

      # RegQueryValueExA(key, name, reserved, type*, data*, size*)
      def self.query(handle, name, type_out, data_out, size_io)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        entry = keys[base.downcase]
        return ERROR_FILE_NOT_FOUND unless entry
        value = entry[:values][(Buffers.c_string(name) || '').downcase]
        return ERROR_FILE_NOT_FOUND unless value
        bytes = value[2]
        Buffers.put_u32(type_out, value[1], 0) unless Buffers.null?(type_out)
        return (Buffers.null?(data_out) ? ERROR_SUCCESS : ERROR_INVALID_PARAMETER) if Buffers.null?(size_io)
        capacity = Buffers.u32(size_io, 0)
        Buffers.put_u32(size_io, bytes.length, 0)
        return ERROR_SUCCESS if Buffers.null?(data_out)
        return ERROR_MORE_DATA if capacity < bytes.length
        Buffers.put(data_out, bytes, 0)
        ERROR_SUCCESS
      end

      # RegSetValueExA(key, name, reserved, type, data, size)
      def self.set(handle, name, type, data, size)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        entry = ensure_key(keys[base.downcase] ? keys[base.downcase][:name] : base)
        size = size.to_i
        bytes = if data.is_a?(String)
                  Buffers.need(data, size, false, 'RegSetValueEx')
                  data[0, size]
                elsif Buffers.null?(data)
                  ''
                else
                  Memory.read(data, size)
                end
        if (type == REG_SZ || type == REG_EXPAND_SZ) && (bytes.empty? || bytes[-1, 1] != "\0")
          bytes += "\0"
        end
        label = Buffers.c_string(name) || ''
        entry[:values][label.downcase] = [label, type.to_i, bytes]
        persist
        ERROR_SUCCESS
      end

      def self.delete_value(handle, name)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        entry = keys[base.downcase]
        return ERROR_FILE_NOT_FOUND unless entry && entry[:values].delete((Buffers.c_string(name) || '').downcase)
        persist
        ERROR_SUCCESS
      end

      def self.delete_key(handle, subkey)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        full = join(base, subkey).downcase
        return ERROR_FILE_NOT_FOUND unless keys[full]
        return ERROR_ACCESS_DENIED if keys.keys.any? { |key| key.index(full + '\\') == 0 }
        @keys.delete(full)
        persist
        ERROR_SUCCESS
      end
    end
  end
end

# ==== 47_input.rb ====
# Kerberus WinBridge - unified input.
#
# Windows answers GetAsyncKeyState/GetKeyState/GetKeyboardState/
# GetCursorPos from the LIVE keyboard and mouse. mkxp-z's Input.pressex?,
# mouse_x and Input::Controller only read a copy that the native
# Input.update refreshes, and Essentials v15-v17 games (Uranium, Insurgence,
# Xenoverse) replace Input.update with their own polling, so that copy
# never changes. The legacy18 build exposes the SDL event thread's live
# arrays through KerberusNative (binding/kerberus/pokemon-native.h); the
# mkxp-z copy is only a fallback for builds without them.
#
# One state for every device: the on-screen gamepad and Android/physical
# keyboards arrive as SDL keys; a game controller is mapped onto the same
# keys the on-screen gamepad sends for each RGSS button, following
# mkxp-z's default controller bindings.
module KerberusLegacy18
  module WinBridge
    module InputBridge
      VK_SHIFT = 0x10
      VK_CONTROL = 0x11
      VK_MENU = 0x12
      VK_CAPITAL = 0x14
      VK_NUMLOCK = 0x90
      VK_SCROLL = 0x91

      # SDL_GameControllerButton -> key of the on-screen gamepad
      # (app GamepadConfig) for the RGSS button mkxp-z binds it to:
      # A->C (C), B->B (X), X->A (Z), Y->X (A), LS->Y (S), RS->Z (D),
      # LB->L (Q), RB->R (W), D-pad -> arrows.
      PAD_KEYS = [[0, 0x43], [1, 0x58], [2, 0x5A], [3, 0x41], [7, 0x53], [8, 0x44],
                  [9, 0x51], [10, 0x57], [11, 0x26], [12, 0x28], [13, 0x25], [14, 0x27]]
      PAD_MASK = Array.new(256, 0)
      PAD_KEYS.each { |pair| PAD_MASK[pair[1]] |= (1 << pair[0]) }
      # Left stick -> arrows; mkxp-z JAXIS_THRESHOLD (strictly beyond 0x4000).
      PAD_THRESHOLD = 0x4000
      PAD_STICK = Array.new(256)
      PAD_STICK[0x25] = [0, -1]
      PAD_STICK[0x27] = [0, 1]
      PAD_STICK[0x26] = [1, -1]
      PAD_STICK[0x28] = [1, 1]

      # mkxp-z maps two virtual keys onto keys that already have their own:
      # VK_SEPARATOR (0x6C) -> Return and VK_PLAY (0xFA) -> media play. A
      # Windows keyboard never sends either (numpad Enter is VK_RETURN), so
      # answering "down" for them made Essentials' key binding screen record
      # Enter as "Separator" (Pokemon Uranium, Control_Binding).
      NOT_SENT = Array.new(256, false)
      NOT_SENT[0x6C] = true
      NOT_SENT[0xFA] = true

      @async_down = Array.new(256, false)
      @bound = false

      def self.reset!
        @async_down = Array.new(256, false)
        @bound = false
      end

      def self.live_method(name)
        defined?(::KerberusNative) && ::KerberusNative.respond_to?(name) ? ::KerberusNative.method(name) : nil
      end

      # Hot path: GetAsyncKeyState can run thousands of times per second.
      # Method objects are resolved once; no allocation per call.
      def self.bind!
        @live_key = live_method(:key_down?)
        @live_pad = live_method(:pad_buttons)
        @live_axis = live_method(:pad_axis)
        @live_mouse = live_method(:mouse_position)
        @focus = live_method(:focused?)
        @pressex = @live_key ? nil : KerberusLegacy18.native_method('Input', :pressex?)
        @frame_count = KerberusLegacy18.native_method('Graphics', :frame_count)
        @bound = true
      end

      def self.live?
        bind! unless @bound
        !@live_key.nil?
      end

      def self.frame
        bind! unless @bound
        @frame_count ? @frame_count.call : 0
      end

      def self.valid_key?(vk)
        vk.is_a?(Integer) && vk >= 0 && vk <= 255
      end

      def self.focused?
        bind! unless @bound
        @focus.nil? || @focus.call ? true : false
      end

      # Keyboard, on-screen gamepad, mouse buttons and controller.
      def self.down?(vk)
        bind! unless @bound
        return false unless valid_key?(vk)
        return false if NOT_SENT[vk]
        if @live_key
          return true if @live_key.call(vk)
        elsif @pressex
          return true if @pressex.call(vk)
        end
        pad_down?(vk)
      end

      def self.pad_down?(vk)
        return false unless @live_pad
        mask = PAD_MASK[vk]
        stick = PAD_STICK[vk]
        return false if mask == 0 && stick.nil?
        buttons = @live_pad.call
        return false if buttons.nil?
        return true if (buttons & mask) != 0
        return false if stick.nil? || @live_axis.nil?
        value = @live_axis.call(stick[0])
        stick[1] < 0 ? value < -PAD_THRESHOLD : value > PAD_THRESHOLD
      end

      # GetAsyncKeyState returns a SHORT. On 32-bit RGSS1 it reached Ruby
      # sign-extended: -32768 held, -32767 held and pressed since the
      # previous call for this key, 0 up.
      def self.async_key_state(vk)
        bind! unless @bound
        return 0 unless valid_key?(vk)
        return 0 unless focused?
        unless down?(vk)
          @async_down[vk] = false
          return 0
        end
        return -32768 if @async_down[vk]
        @async_down[vk] = true
        -32767
      end

      # GetKeyState: high bit = down (0xFF80 = -128), low bit = toggle.
      # SDL does not expose lock-key toggles to mkxp-z, so toggles are 0.
      def self.key_state(vk)
        focused? && down?(vk) ? -128 : 0
      end

      def self.keyboard_state
        bind! unless @bound
        bytes = "\0" * 256
        return bytes unless focused? && (@live_key || @pressex)
        vk = 1
        while vk < 256
          bytes[vk] = 0x80 if down?(vk)
          vk += 1
        end
        bytes
      end

      def self.mouse
        bind! unless @bound
        return @live_mouse.call if @live_mouse
        x = KerberusLegacy18.native?('Input', :mouse_x) ? KerberusLegacy18.native('Input', :mouse_x).to_i : 0
        y = KerberusLegacy18.native?('Input', :mouse_y) ? KerberusLegacy18.native('Input', :mouse_y).to_i : 0
        [x, y]
      end

      def self.wheel_delta
        KerberusLegacy18.native?('Input', :scroll_v) ? KerberusLegacy18.native('Input', :scroll_v).to_i * 120 : 0
      end

      # ------------------------------------------------------------------
      # US keyboard layout tables (set-1 scan codes)
      # ------------------------------------------------------------------
      SCAN = {}
      [[0x1B, 0x01], [0x08, 0x0E], [0x09, 0x0F], [0x0D, 0x1C], [0x10, 0x2A], [0x11, 0x1D],
       [0x12, 0x38], [0x14, 0x3A], [0x20, 0x39], [0xA0, 0x2A], [0xA1, 0x36], [0xA2, 0x1D],
       [0xA4, 0x38], [0x90, 0x45], [0x91, 0x46], [0x2D, 0x52], [0x2E, 0x53], [0x24, 0x47],
       [0x23, 0x4F], [0x21, 0x49], [0x22, 0x51], [0x26, 0x48], [0x25, 0x4B], [0x27, 0x4D],
       [0x28, 0x50], [0xBA, 0x27], [0xBB, 0x0D], [0xBC, 0x33], [0xBD, 0x0C], [0xBE, 0x34],
       [0xBF, 0x35], [0xC0, 0x29], [0xDB, 0x1A], [0xDC, 0x2B], [0xDD, 0x1B], [0xDE, 0x28],
       [0x6A, 0x37], [0x6B, 0x4E], [0x6D, 0x4A], [0x6E, 0x53], [0x60, 0x52], [0x61, 0x4F],
       [0x62, 0x50], [0x63, 0x51], [0x64, 0x4B], [0x65, 0x4C], [0x66, 0x4D], [0x67, 0x47],
       [0x68, 0x48], [0x69, 0x49], [0x7A, 0x57], [0x7B, 0x58]].each { |pair| SCAN[pair[0]] = pair[1] }
      '1234567890'.split('').each_with_index { |char, index| SCAN[char[0]] = 0x02 + index }
      'QWERTYUIOP'.split('').each_with_index { |char, index| SCAN[char[0]] = 0x10 + index }
      'ASDFGHJKL'.split('').each_with_index { |char, index| SCAN[char[0]] = 0x1E + index }
      'ZXCVBNM'.split('').each_with_index { |char, index| SCAN[char[0]] = 0x2C + index }
      (0...10).each { |index| SCAN[0x70 + index] = 0x3B + index }
      # Scan -> VK prefers the main block (letters, digits, navigation).
      VK_FROM_SCAN = {}
      SCAN.keys.sort.reverse.each { |vk| VK_FROM_SCAN[SCAN[vk]] = vk unless vk >= 0x60 && vk <= 0x6F }
      VK_FROM_SCAN[0x2A] = 0x10
      VK_FROM_SCAN[0x36] = 0x10
      VK_FROM_SCAN[0x1D] = 0x11
      VK_FROM_SCAN[0x38] = 0x12

      UNSHIFTED = { 0x20 => ' ', 0xBA => ';', 0xBB => '=', 0xBC => ',', 0xBD => '-', 0xBE => '.',
                    0xBF => '/', 0xC0 => '`', 0xDB => '[', 0xDC => '\\', 0xDD => ']', 0xDE => "'",
                    0x6A => '*', 0x6B => '+', 0x6D => '-', 0x6E => '.', 0x6F => '/',
                    0x0D => "\r", 0x09 => "\t", 0x08 => "\b", 0x1B => "\e" }
      SHIFTED = { 0xBA => ':', 0xBB => '+', 0xBC => '<', 0xBD => '_', 0xBE => '>', 0xBF => '?',
                  0xC0 => '~', 0xDB => '{', 0xDC => '|', 0xDD => '}', 0xDE => '"' }
      SHIFTED_DIGITS = ')!@#$%^&*('

      def self.map_virtual_key(code, type)
        code = code.to_i
        case type.to_i
        when 0, 4 then SCAN[code] || 0
        when 1, 3 then VK_FROM_SCAN[code & 0xFF] || 0
        when 2
          return code if code >= 0x30 && code <= 0x39
          return code if code >= 0x41 && code <= 0x5A
          return (code - 0x60 + 0x30) if code >= 0x60 && code <= 0x69
          char = UNSHIFTED[code]
          char ? char[0] : 0
        else
          WinBridge.failure(ERROR_INVALID_PARAMETER, 0)
        end
      end

      # Character produced by vk with the given 256-byte keyboard state.
      def self.character(vk, state)
        state = state.is_a?(String) && state.length >= 256 ? state : "\0" * 256
        shift = (state[VK_SHIFT] & 0x80) != 0 || (state[0xA0] & 0x80) != 0 || (state[0xA1] & 0x80) != 0
        ctrl = (state[VK_CONTROL] & 0x80) != 0 || (state[0xA2] & 0x80) != 0 || (state[0xA3] & 0x80) != 0
        alt = (state[VK_MENU] & 0x80) != 0
        caps = (state[VK_CAPITAL] & 0x01) != 0
        numlock = (state[VK_NUMLOCK] & 0x01) != 0
        return nil if alt && !ctrl
        if vk >= 0x41 && vk <= 0x5A
          return (vk - 0x40).chr if ctrl
          upper = shift ^ caps
          return upper ? vk.chr : (vk + 32).chr
        end
        return nil if ctrl && !(vk == 0x0D || vk == 0x08 || vk == 0x1B)
        if vk >= 0x30 && vk <= 0x39
          return shift ? SHIFTED_DIGITS[vk - 0x30, 1] : vk.chr
        end
        if vk >= 0x60 && vk <= 0x69
          return numlock ? (vk - 0x60 + 0x30).chr : nil
        end
        return SHIFTED[vk] if shift && SHIFTED[vk]
        UNSHIFTED[vk]
      end

      # ToUnicode(vk, scan, state[256], buf, cch, flags) -> UTF-16 units written
      def self.to_unicode(vk, state, buffer, capacity)
        char = character(vk.to_i, state)
        return 0 if char.nil? || capacity.to_i < 1
        Buffers.put(buffer, Text.utf8_to_utf16le(char), 0)
        1
      end

      # ToAscii(vk, scan, state[256], WORD* out, flags) -> chars written
      def self.to_ascii(vk, state, buffer)
        char = character(vk.to_i, state)
        return 0 if char.nil?
        Buffers.put(buffer, char + "\0", 0)
        1
      end

      # ------------------------------------------------------------------
      # XInput over the SDL game controller mkxp-z opens (player 0 only)
      # ------------------------------------------------------------------
      # SDL_GameControllerButton index -> XINPUT_GAMEPAD bit
      XINPUT_BUTTONS = [[0, 0x1000], [1, 0x2000], [2, 0x4000], [3, 0x8000], [4, 0x0020],
                        [6, 0x0010], [7, 0x0040], [8, 0x0080], [9, 0x0100], [10, 0x0200],
                        [11, 0x0001], [12, 0x0002], [13, 0x0004], [14, 0x0008]]
      @packet = 0
      @last_pad = nil

      def self.controller_connected?
        bind! unless @bound
        return !@live_pad.call.nil? if @live_pad
        KerberusLegacy18.native?('Input::Controller', :connected?) &&
          KerberusLegacy18.native('Input::Controller', :connected?) ? true : false
      end

      def self.clamp16(number)
        number > 32767 ? 32767 : (number < -32768 ? -32768 : number)
      end

      def self.axis16(value, invert)
        number = (value.to_f * 32767.0).round
        clamp16(invert ? -number : number)
      end

      # Live SDL values: sticks -32768..32767 (Y down), triggers 0..32767.
      def self.xinput_pad_live
        mask = @live_pad.call || 0
        buttons = 0
        XINPUT_BUTTONS.each { |pair| buttons |= pair[1] if (mask >> pair[0]) & 1 == 1 }
        axes = [0, 1, 2, 3, 4, 5].map { |index| @live_axis ? @live_axis.call(index).to_i : 0 }
        trigger = lambda { |value| v = value * 255 / 32767; v < 0 ? 0 : (v > 255 ? 255 : v) }
        [buttons, trigger.call(axes[4]), trigger.call(axes[5]),
         clamp16(axes[0]), clamp16(-axes[1]), clamp16(axes[2]), clamp16(-axes[3])]
      end

      def self.xinput_pad
        bind! unless @bound
        return xinput_pad_live if @live_pad
        buttons = 0
        states = KerberusLegacy18.native('Input::Controller', :raw_button_states)
        XINPUT_BUTTONS.each { |pair| buttons |= pair[1] if states[pair[0]] }
        axes = KerberusLegacy18.native('Input::Controller', :raw_axes)
        trigger = lambda { |value| v = (value.to_f * 255.0).round; v < 0 ? 0 : (v > 255 ? 255 : v) }
        [buttons, trigger.call(axes[4] || 0), trigger.call(axes[5] || 0),
         axis16(axes[0] || 0, false), axis16(axes[1] || 0, true),
         axis16(axes[2] || 0, false), axis16(axes[3] || 0, true)]
      end

      def self.xinput_get_state(index, buffer)
        Buffers.need(buffer, 16, true, 'XInputGetState')
        return ERROR_DEVICE_NOT_CONNECTED unless index.to_i == 0 && controller_connected?
        pad = xinput_pad
        @packet += 1 if pad != @last_pad
        @last_pad = pad
        Buffers.put(buffer, [@packet & 0xffffffff, pad[0], pad[1], pad[2], pad[3], pad[4], pad[5], pad[6]].pack('VvCCssss'), 0)
        ERROR_SUCCESS
      end

      def self.xinput_set_state(index, vibration)
        return ERROR_DEVICE_NOT_CONNECTED unless index.to_i == 0 && controller_connected?
        Buffers.need(vibration, 4, false, 'XInputSetState')
        low, high = vibration[0, 4].unpack('vv')
        if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:controller_rumble)
          ::KerberusNative.controller_rumble(low, high, low == 0 && high == 0 ? 0 : 1000)
          ERROR_SUCCESS
        else
          KerberusLegacy18.event('LIMITED', 'xinput!XInputSetState', 'vibracao do controle nao exposta por este build')
          ERROR_SUCCESS
        end
      end

      def self.xinput_capabilities(index, buffer)
        Buffers.need(buffer, 20, true, 'XInputGetCapabilities')
        return ERROR_DEVICE_NOT_CONNECTED unless index.to_i == 0 && controller_connected?
        # Type GAMEPAD, SubType GAMEPAD, flags 0, all buttons, full ranges, rumble.
        Buffers.put(buffer, [1, 1, 0, 0xF3FF, 255, 255, 32767, 32767, 32767, 32767, 65535, 65535].pack('CCvvCCssssvv'), 0)
        ERROR_SUCCESS
      end

      def self.xinput_battery(index, buffer)
        Buffers.need(buffer, 2, true, 'XInputGetBatteryInformation')
        return ERROR_DEVICE_NOT_CONNECTED unless index.to_i == 0 && controller_connected?
        level = KerberusLegacy18.native?('Input::Controller', :power_level) ? KerberusLegacy18.native('Input::Controller', :power_level).to_s : 'UNKNOWN'
        pair = case level
               when 'WIRED' then [1, 3]
               when 'FULL', 'MAX' then [2, 3]
               when 'MEDIUM' then [2, 2]
               when 'LOW' then [2, 1]
               when 'EMPTY' then [2, 0]
               else [0xFF, 0]
               end
        Buffers.put(buffer, pair.pack('CC'), 0)
        ERROR_SUCCESS
      end
    end
  end
end

# ==== 48_audio.rb ====
# Kerberus WinBridge - single audio strategy.
#
# Every Windows audio path (FMOD through RGSS Linker, Essentials audio.dll
# AudioContext*, MCI, PlaySound) ends here and here only calls the native
# mkxp-z Audio methods captured at boot. One owner per channel means two
# backends can never play the same music at once.
module KerberusLegacy18
  module WinBridge
    module AudioBridge
      CHANNELS = [:bgm, :bgs, :me, :se]
      SEEKABLE = [:bgm, :bgs]
      @state = {}
      @fade_in = nil
      @profile_volume = false

      def self.reset!
        @state = {}
        @fade_in = nil
        @profile_volume = false
      end

      # Uranium/Essentials option menus store BGM/SE volume in $PokemonSystem.
      def self.use_profile_volume!
        @profile_volume = true
      end

      def self.scaled(channel, volume)
        value = volume.to_f
        value = 0.0 if value < 0
        value = 100.0 if value > 100
        if @profile_volume && defined?($PokemonSystem) && $PokemonSystem
          name = (channel == :bgm || channel == :me) ? :bgmvolume : :sevolume
          if $PokemonSystem.respond_to?(name)
            level = ($PokemonSystem.send(name) || 100).to_f
            level = 0.0 if level < 0
            level = 100.0 if level > 100
            value = value * level / 100.0
          end
        end
        value.round
      end

      def self.check_channel(channel)
        raise ArgumentError, 'canal de audio invalido: ' + channel.inspect unless CHANNELS.include?(channel)
      end

      def self.play(channel, name, volume, pitch, position)
        check_channel(channel)
        raise ArgumentError, 'nome de audio deve ser String' unless name.is_a?(String)
        return stop(channel) if name.empty?
        volume = 100 if volume.nil?
        pitch = 100 if pitch.nil?
        position = 0 if position.nil?
        actual = scaled(channel, volume)
        if SEEKABLE.include?(channel)
          KerberusLegacy18.native('Audio', (channel.to_s + '_play').to_sym, name, actual, pitch.to_i, position.to_f)
        else
          if position.to_f != 0
            KerberusLegacy18.event('LIMITED', 'Audio.' + channel.to_s + '_play(position)', 'canal nativo sem seek; tocando do inicio')
          end
          KerberusLegacy18.native('Audio', (channel.to_s + '_play').to_sym, name, actual, pitch.to_i)
        end
        @state[channel] = [name, volume.to_i, pitch.to_i]
        @fade_in = nil if channel == :bgm
        nil
      end

      def self.stop(channel)
        check_channel(channel)
        KerberusLegacy18.native('Audio', (channel.to_s + '_stop').to_sym)
        @state.delete(channel)
        @fade_in = nil if channel == :bgm
        nil
      end

      def self.fade(channel, ms)
        check_channel(channel)
        raise ArgumentError, 'fade invalido: ' + ms.inspect unless ms.is_a?(Numeric) && ms >= 0
        return stop(channel) if channel == :se
        KerberusLegacy18.native('Audio', (channel.to_s + '_fade').to_sym, ms.to_i)
        @state.delete(channel)
        @fade_in = nil if channel == :bgm
        nil
      end

      def self.position(channel)
        channel = :bgm if channel.nil?
        name = (channel.to_s + '_pos').to_sym
        KerberusLegacy18.native?('Audio', name) ? KerberusLegacy18.native('Audio', name) : 0
      end

      def self.info(channel)
        @state[channel]
      end

      def self.playing?(channel)
        !@state[channel].nil?
      end

      # mkxp AudioStream#play with the same file only changes the volume.
      def self.set_volume(channel, value)
        entry = @state[channel]
        return value unless entry
        level = value.to_f
        level = 0 if level < 0
        level = 100 if level > 100
        args = [entry[0], scaled(channel, level), entry[2]]
        args << position(channel).to_f if SEEKABLE.include?(channel)
        KerberusLegacy18.native('Audio', (channel.to_s + '_play').to_sym, *args)
        entry[1] = level.to_i
        value
      end

      def self.fade_in(ms)
        raise ArgumentError, 'fade invalido: ' + ms.inspect unless ms.is_a?(Numeric) && ms >= 0
        entry = @state[:bgm]
        return nil unless entry
        target = entry[1]
        return set_volume(:bgm, target) if ms == 0
        set_volume(:bgm, 0)
        entry[1] = target
        @fade_in = [KerberusLegacy18.uptime_ms, ms.to_f, target]
        nil
      end

      def self.fading_in?
        !@fade_in.nil?
      end

      # Called by the frame hook.
      def self.tick
        return unless @fade_in
        start, duration, target = @fade_in
        entry = @state[:bgm]
        if entry.nil?
          @fade_in = nil
          return
        end
        progress = (KerberusLegacy18.uptime_ms - start) / duration
        progress = 1.0 if progress > 1.0
        set_volume(:bgm, (target * progress).round)
        entry[1] = target
        @fade_in = nil if progress >= 1.0
      end

      # ------------------------------------------------------------------
      # winmm!PlaySoundA(sound, module, flags)
      # ------------------------------------------------------------------
      SND_ASYNC = 0x0001
      SND_LOOP = 0x0008
      SND_PURGE = 0x0040
      SND_ALIAS = 0x00010000
      SND_FILENAME = 0x00020000
      SND_RESOURCE = 0x00040004

      def self.play_sound(sound, flags)
        flags = flags.to_i
        name = Buffers.c_string(sound)
        if name.nil? || (flags & SND_PURGE) != 0
          stop(:se)
          stop(:bgs) if playing?(:bgs) && @state[:bgs][3] == :play_sound
          return 1
        end
        if (flags & SND_RESOURCE) == SND_RESOURCE || ((flags & SND_ALIAS) != 0 && (flags & SND_FILENAME) == 0)
          return WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
        end
        path = Paths.resolve(name.tr('\\', '/'), false)
        if (flags & SND_LOOP) != 0
          play(:bgs, path, 100, 100, 0)
          @state[:bgs][3] = :play_sound
        else
          play(:se, path, 100, 100, 0)
        end
        1
      end

      # ------------------------------------------------------------------
      # winmm!mciSendStringA - audio subset mapped to native channels
      # ------------------------------------------------------------------
      module MCI
        MCIERR_INVALID_DEVICE_ID = 257
        MCIERR_UNRECOGNIZED_COMMAND = 261
        MCIERR_UNSUPPORTED_FUNCTION = 274
        MCIERR_INVALID_DEVICE_NAME = 263
        MCIERR_FILE_NOT_FOUND = 275
        MESSAGES = {
          0 => 'The specified command was carried out.',
          257 => 'Invalid device ID.', 261 => 'Unknown command.',
          263 => 'The specified device is not open or is not recognized by MCI.',
          274 => 'The MCI device the system is using does not support the specified command.',
          275 => 'Cannot find the specified file.'
        }
        # "mpegvideo" is also the usual MCI device for MP3/OGG music, so the
        # file extension decides; only "avivideo" is always a video device.
        VIDEO_EXTENSIONS = /\.(avi|wmv|mpg|mpeg|mp4|mov|mkv)\z/i
        @devices = {}

        def self.reset!
          @devices = {}
        end

        def self.tokens(command)
          command.to_s.scan(/"[^"]*"|\S+/).map { |token| token[0, 1] == '"' ? token[1, token.length - 2] : token }
        end

        def self.reply(buffer, capacity, text)
          return if Buffers.null?(buffer) || capacity.to_i <= 0
          Buffers.copy_c_string(buffer, capacity.to_i, text)
        end

        def self.send_string(command, buffer, capacity)
          words = tokens(command)
          return MCIERR_UNRECOGNIZED_COMMAND if words.empty?
          verb = words.shift.downcase
          case verb
          when 'open' then open(words)
          when 'play' then play(words)
          when 'stop', 'pause' then stop(words)
          when 'resume' then resume(words)
          when 'close' then close(words)
          when 'setaudio' then set_audio(words)
          when 'status' then status(words, buffer, capacity)
          when 'seek' then seek(words)
          else
            KerberusLegacy18.event('LIMITED', 'winmm!mciSendString', 'comando MCI nao suportado: ' + verb)
            MCIERR_UNSUPPORTED_FUNCTION
          end
        end

        def self.open(words)
          file = words.shift
          return MCIERR_UNRECOGNIZED_COMMAND unless file
          type = nil
          alias_name = file
          while (word = words.shift)
            case word.downcase
            when 'type' then type = (words.shift || '').downcase
            when 'alias' then alias_name = words.shift || alias_name
            end
          end
          if type == 'avivideo' || file =~ VIDEO_EXTENSIONS
            KerberusLegacy18.event('LIMITED', 'winmm!mciSendString', 'video MCI (' + file.to_s + ') indisponivel; use Graphics.play_movie com OGV')
            return MCIERR_UNSUPPORTED_FUNCTION
          end
          path = Paths.resolve(file.tr('\\', '/'), false)
          return MCIERR_FILE_NOT_FOUND unless KerberusLegacy18.raw_file?(path)
          @devices[alias_name.downcase] = { :path => path, :channel => nil, :volume => 100, :mode => 'stopped' }
          0
        end

        def self.device(words)
          name = words.shift
          name && @devices[name.downcase]
        end

        def self.play(words)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          repeat = words.map { |word| word.downcase }.include?('repeat')
          # Looping MCI music is background music; one-shots are ME.
          channel = repeat ? :bgm : :me
          AudioBridge.play(channel, entry[:path], entry[:volume], 100, 0)
          entry[:channel] = channel
          entry[:mode] = 'playing'
          0
        end

        def self.stop(words)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          owned = entry[:channel] && AudioBridge.info(entry[:channel]) &&
                  AudioBridge.info(entry[:channel])[0] == entry[:path]
          AudioBridge.stop(entry[:channel]) if owned
          entry[:mode] = 'stopped'
          0
        end

        def self.resume(words)
          entry = device(words.dup)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          return 0 if entry[:mode] == 'playing'
          play(words + (entry[:channel] == :bgm ? ['repeat'] : []))
        end

        def self.close(words)
          name = words.first
          if name && name.downcase == 'all'
            @devices.keys.each { |key| stop([key]) }
            @devices.clear
            return 0
          end
          result = stop(words.dup)
          @devices.delete(name.downcase) if name
          result
        end

        def self.set_audio(words)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          index = words.map { |word| word.downcase }.index('volume')
          return MCIERR_UNSUPPORTED_FUNCTION unless index
          value = words[index + 1].to_s.downcase == 'to' ? words[index + 2] : words[index + 1]
          entry[:volume] = (value.to_i / 10.0).round
          AudioBridge.set_volume(entry[:channel], entry[:volume]) if entry[:channel] && AudioBridge.playing?(entry[:channel])
          0
        end

        def self.status(words, buffer, capacity)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          case (words.first || '').downcase
          when 'mode'
            playing = entry[:channel] && AudioBridge.playing?(entry[:channel])
            reply(buffer, capacity, playing && entry[:mode] == 'playing' ? 'playing' : 'stopped')
          when 'position'
            reply(buffer, capacity, entry[:channel] ? (AudioBridge.position(entry[:channel]).to_f * 1000).to_i.to_s : '0')
          else
            return MCIERR_UNSUPPORTED_FUNCTION
          end
          0
        end

        def self.seek(words)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          MCIERR_UNSUPPORTED_FUNCTION
        end

        def self.error_string(code, buffer, capacity)
          text = MESSAGES[code.to_i] || ('MCI error ' + code.to_i.to_s)
          return 0 if capacity.to_i <= 0
          Buffers.copy_c_string(buffer, capacity.to_i, text)
          1
        end
      end
    end
  end
end

# ==== 49_system.rb ====
# Kerberus WinBridge - virtual window, locale and handle tables shared by
# several providers. Only locale/region, never personal data, is exposed.
module KerberusLegacy18
  module WinBridge
    module Window
      HWND = 1
      DESKTOP = 0x00010010
      DC = 0x0DC00001
      WS_POPUP_VISIBLE = 0x90000000
      @capture = 0
      @cursor = 0
      @styles = {}

      def self.reset!
        @capture = 0
        @cursor = 0
        @styles = {}
      end

      def self.handle?(value)
        value.to_i == HWND
      end

      def self.width
        KerberusLegacy18.native?('Graphics', :width) ? KerberusLegacy18.native('Graphics', :width) : 640
      end

      def self.height
        KerberusLegacy18.native?('Graphics', :height) ? KerberusLegacy18.native('Graphics', :height) : 480
      end

      def self.rect_bytes
        [0, 0, width, height].pack('l4')
      end

      def self.title
        if KerberusLegacy18.native?('System', :window_title)
          text = KerberusLegacy18.native('System', :window_title).to_s
          return text unless text.empty?
        end
        KerberusLegacy18.native?('System', :game_title) ? KerberusLegacy18.native('System', :game_title).to_s : ''
      end

      def self.captured
        @capture
      end

      def self.capture(value)
        previous = @capture
        @capture = value
        previous
      end

      def self.show_cursor(show)
        @cursor += (show.nil? || show == 0 || show == false) ? -1 : 1
        @cursor
      end

      def self.style(index)
        @styles[index.to_i] || (index.to_i == -16 ? WS_POPUP_VISIBLE : 0)
      end

      def self.set_style(index, value)
        previous = style(index)
        @styles[index.to_i] = value.to_i & 0xffffffff
        previous
      end

      def self.metric(index)
        case index.to_i
        when 0, 16, 61, 78 then width
        when 1, 17, 62, 79 then height
        when 19 then 1          # SM_MOUSEPRESENT (touch acts as mouse)
        when 43 then 3          # SM_CMOUSEBUTTONS
        when 80 then 1          # SM_CMONITORS
        when 4, 5, 6, 7, 8, 15, 23, 32, 33, 45, 46, 76, 77, 0x1000 then 0
        else
          KerberusLegacy18.event('LIMITED', 'user32!GetSystemMetrics(' + index.to_i.to_s + ')', 'metrica sem equivalente; 0 como no Windows para indice desconhecido')
          0
        end
      end
    end

    module Locale
      PRIMARY = { 'ar' => 0x01, 'bg' => 0x02, 'ca' => 0x03, 'zh' => 0x04, 'cs' => 0x05, 'da' => 0x06,
                  'de' => 0x07, 'el' => 0x08, 'en' => 0x09, 'es' => 0x0A, 'fi' => 0x0B, 'fr' => 0x0C,
                  'he' => 0x0D, 'hu' => 0x0E, 'is' => 0x0F, 'it' => 0x10, 'ja' => 0x11, 'ko' => 0x12,
                  'nl' => 0x13, 'nb' => 0x14, 'no' => 0x14, 'pl' => 0x15, 'pt' => 0x16, 'ro' => 0x18,
                  'ru' => 0x19, 'hr' => 0x1A, 'sk' => 0x1B, 'sv' => 0x1D, 'th' => 0x1E, 'tr' => 0x1F,
                  'id' => 0x21, 'uk' => 0x22, 'vi' => 0x2A }
      SPECIFIC = { 'en_US' => 0x0409, 'en_GB' => 0x0809, 'en_AU' => 0x0C09, 'en_CA' => 0x1009,
                   'pt_BR' => 0x0416, 'pt_PT' => 0x0816, 'es_ES' => 0x0C0A, 'es_MX' => 0x080A,
                   'es_AR' => 0x2C0A, 'es_US' => 0x540A, 'es_CL' => 0x340A, 'es_CO' => 0x240A,
                   'fr_FR' => 0x040C, 'fr_CA' => 0x0C0C, 'de_DE' => 0x0407, 'de_AT' => 0x0C07,
                   'de_CH' => 0x0807, 'it_IT' => 0x0410, 'ja_JP' => 0x0411, 'ko_KR' => 0x0412,
                   'zh_CN' => 0x0804, 'zh_TW' => 0x0404, 'zh_HK' => 0x0C04, 'ru_RU' => 0x0419,
                   'nl_NL' => 0x0413, 'pl_PL' => 0x0415, 'tr_TR' => 0x041F }
      GEO = { 'US' => 244, 'GB' => 242, 'BR' => 32, 'PT' => 193, 'ES' => 217, 'MX' => 166,
              'AR' => 11, 'FR' => 84, 'DE' => 94, 'IT' => 118, 'JP' => 122, 'KR' => 134,
              'CN' => 45, 'TW' => 237, 'RU' => 203, 'CA' => 39, 'AU' => 12, 'NL' => 176,
              'PL' => 191, 'TR' => 235, 'CL' => 46, 'CO' => 51, 'PE' => 187 }
      ANSI = { 'ja' => 932, 'ko' => 949, 'ru' => 1251, 'uk' => 1251, 'bg' => 1251,
               'pl' => 1250, 'cs' => 1250, 'hu' => 1250, 'sk' => 1250, 'hr' => 1250, 'ro' => 1250,
               'el' => 1253, 'tr' => 1254, 'he' => 1255, 'ar' => 1256, 'vi' => 1258, 'th' => 874 }

      def self.tag
        raw = KerberusLegacy18.native?('System', :user_language) ? KerberusLegacy18.native('System', :user_language).to_s : ''
        raw = 'en_US' if raw.empty?
        parts = raw.tr('-', '_').split(/[_.@]/)
        language = parts[0].to_s.downcase
        region = parts[1].to_s.upcase
        region.empty? ? language : language + '_' + region
      end

      def self.language
        tag.split('_')[0].to_s
      end

      def self.region
        tag.split('_')[1].to_s
      end

      def self.langid
        SPECIFIC[tag] || (PRIMARY[language] ? (0x0400 | PRIMARY[language]) : 0x0409)
      end

      def self.geoid
        GEO[region]
      end

      def self.ansi_codepage
        return 936 if tag == 'zh_CN'
        return 950 if language == 'zh'
        ANSI[language] || 1252
      end
    end

    # Virtual process environment: no Android variable (paths, user data)
    # is exposed. SetEnvironmentVariable changes only this table.
    module Env
      DEFAULTS = { 'USERNAME' => 'Player', 'COMPUTERNAME' => 'KERBERUS', 'OS' => 'Windows_NT' }
      @table = DEFAULTS.dup

      def self.reset!
        @table = DEFAULTS.dup
      end

      def self.get(name)
        @table[name.to_s.upcase]
      end

      def self.set(name, value)
        key = name.to_s.upcase
        value.nil? ? @table.delete(key) : @table[key] = value.to_s
      end
    end

    # Virtual kernel handles (files, find handles, console, modules).
    module Handles
      BASE = 0x00C00000
      @table = {}
      @next = BASE

      def self.reset!
        @table.values.each { |entry| entry[1].close if entry[0] == :file && !entry[1].closed? }
        @table = {}
        @next = BASE
      end

      def self.add(kind, object, writable = false)
        raise KerberusLegacy18::Error, 'tabela de handles virtuais cheia' if @table.size >= 512
        handle = @next
        @next += 4
        @table[handle] = [kind, object, writable]
        handle
      end

      def self.writable?(handle)
        entry = @table[handle.to_i & 0xffffffff]
        entry ? entry[2] : false
      end

      def self.get(handle, kind)
        entry = @table[handle.to_i & 0xffffffff]
        entry && (kind.nil? || entry[0] == kind) ? entry[1] : nil
      end

      def self.kind(handle)
        entry = @table[handle.to_i & 0xffffffff]
        entry ? entry[0] : nil
      end

      def self.close(handle)
        entry = @table.delete(handle.to_i & 0xffffffff)
        return false unless entry
        entry[1].close if entry[0] == :file && !entry[1].closed?
        true
      end
    end

    # Console APIs write to the Kerberus log instead of a Windows console.
    module Console
      STD_INPUT = 0x00C0FF10
      STD_OUTPUT = 0x00C0FF14
      STD_ERROR = 0x00C0FF18
      @allocated = false

      def self.reset!
        @allocated = false
      end

      def self.handle?(value)
        [STD_INPUT, STD_OUTPUT, STD_ERROR].include?(value.to_i & 0xffffffff) || Handles.kind(value) == :console
      end

      def self.alloc
        return WinBridge.failure(ERROR_ACCESS_DENIED, 0) if @allocated
        @allocated = true
        WinBridge.success(1)
      end

      def self.free
        @allocated = false
        1
      end

      def self.write(text)
        text.to_s.split(/\r?\n/).each do |line|
          System.puts('[console] ' + line) if defined?(System) && System.respond_to?(:puts)
        end
        text.to_s.length
      end
    end

    # Windows path argument -> Android path through the Windows-like layer.
    def self.native_path(value, create)
      text = Buffers.c_string(value)
      return nil if text.nil? || text.empty?
      unix = text.tr('\\', '/')
      return nil if unix =~ /\A[A-Za-z]:/
      Paths.resolve(unix, create)
    end

    def self.windows_path(path)
      File.expand_path(path.to_s).tr('/', '\\')
    end
  end
end

# ==== 50_kernel32.rb ====
# Kerberus WinBridge providers - kernel32 (and ntdll memory helpers).
module KerberusLegacy18
  module WinBridge
    SYSTEM_MESSAGES = {
      0 => 'The operation completed successfully.', 2 => 'The system cannot find the file specified.',
      3 => 'The system cannot find the path specified.', 5 => 'Access is denied.',
      6 => 'The handle is invalid.', 8 => 'Not enough memory resources are available to process this command.',
      87 => 'The parameter is incorrect.', 120 => 'This function is not supported on this system.',
      122 => 'The data area passed to a system call is too small.',
      126 => 'The specified module could not be found.', 127 => 'The specified procedure could not be found.',
      183 => 'Cannot create a file when that file already exists.', 234 => 'More data is available.',
      1167 => 'The device is not connected.'
    }
    INVALID_HANDLE = 0xffffffff
    VIRTUAL_MODULE_BASE = 0x10000000
    GAME_MODULE = 0x00400000

    def self.module_handle(name)
      return GAME_MODULE if name.nil?
      lib = library(name)
      return GAME_MODULE if lib == KerberusLegacy18.config[:exec_name].downcase || lib == 'game' || lib =~ /\.exe\z/
      return nil unless provides_library?(lib)
      VIRTUAL_MODULE_BASE + (lib.hash & 0x0FFF) * 0x10000
    end

    def self.filetime(time)
      value = (time.to_i + 11644473600) * 10000000
      Buffers.pack_u64(value)
    end

    def self.file_attributes(path)
      return nil unless path && File.exist?(path)
      File.directory?(path) ? 0x10 : 0x20
    end

    k = 'kernel32'

    # --- clocks -----------------------------------------------------------
    provide(k, 'GetTickCount', :native, 'CLOCK_BOOTTIME em ms (32 bits, reinicia como no Windows)', 0) { |a| KerberusLegacy18.uptime_ms & 0xffffffff }
    provide(k, 'GetTickCount64', :native, 'CLOCK_BOOTTIME em ms', 0) { |a| KerberusLegacy18.uptime_ms }
    provide(k, 'QueryPerformanceCounter', :native, 'CLOCK_BOOTTIME em ns', 1) do |a|
      Buffers.put(a[0], Buffers.pack_u64(KerberusLegacy18.monotonic_ns), 0)
      1
    end
    provide(k, 'QueryPerformanceFrequency', :native, '1 GHz (contador em ns)', 1) do |a|
      Buffers.put(a[0], Buffers.pack_u64(1000000000), 0)
      1
    end
    provide(k, 'Sleep', :native, 'suspende a thread Ruby como o Sleep do Windows', 1) do |a|
      ms = a[0].to_i & 0xffffffff
      if ms == 0xffffffff
        raise Unavailable, 'kernel32!Sleep(INFINITE) bloquearia o jogo para sempre'
      end
      ms == 0 ? Thread.pass : sleep(ms / 1000.0)
      0
    end

    # --- process / thread / errors ----------------------------------------
    provide(k, 'GetCurrentThreadId', :native, 'gettid do Android', 0) { |a| KerberusLegacy18.thread_id }
    provide(k, 'GetCurrentProcessId', :native, 'getpid do Android', 0) { |a| Process.pid }
    provide(k, 'GetCurrentProcess', :native, 'pseudo-handle -1 documentado', 0) { |a| -1 }
    provide(k, 'GetCurrentThread', :native, 'pseudo-handle -2 documentado', 0) { |a| -2 }
    provide(k, 'GetLastError', :native, 'ultimo erro definido pelos providers', 0) { |a| WinBridge.last_error }
    provide(k, 'SetLastError', :native, 'define o ultimo erro', 1) { |a| WinBridge.last_error = a[0]; 0 }
    provide(k, 'IsDebuggerPresent', :native, 'sem depurador', 0) { |a| 0 }
    provide(k, 'OutputDebugStringA', :native, 'texto enviado ao log do Kerberus', 1) do |a|
      KerberusLegacy18.event('DEBUG_STRING', Buffers.c_string(a[0]).to_s[0, 120], '')
      0
    end
    provide(k, 'FormatMessageA', :native, 'tabela de mensagens de sistema comuns; demais codigos falham como no Windows', 5) do |a|
      flags = a[0].to_i
      code = a[2].to_i & 0xffffffff
      text = (flags & 0x1000) != 0 ? SYSTEM_MESSAGES[code] : nil
      if text.nil?
        WinBridge.failure(317, 0)
      else
        text += "\r\n"
        if (flags & 0x100) != 0
          Buffers.put_u32(a[4], Memory.alloc(text + "\0"), 0)
        else
          capacity = a[5].to_i
          next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if capacity <= text.length
          Buffers.put(a[4], text + "\0", 0)
        end
        WinBridge.success(text.length)
      end
    end

    # --- INI ----------------------------------------------------------------
    provide(k, 'GetPrivateProfileStringA', :native, 'parser INI nativo (regras do Windows)', 6) { |a| Ini.read_string(a[0], a[1], a[2], a[3], a[4], a[5]) }
    provide(k, 'GetPrivateProfileIntA', :native, 'parser INI nativo', 4) { |a| Ini.read_int(a[0], a[1], a[2], a[3]) }
    provide(k, 'GetPrivateProfileSectionA', :native, 'parser INI nativo', 4) { |a| Ini.read_section(a[0], a[1], a[2], a[3]) }
    provide(k, 'GetPrivateProfileSectionNamesA', :native, 'parser INI nativo', 3) do |a|
      Ini.write_list(a[0], a[1].to_i, Ini.section_names(Ini.load(Ini.path_for(a[2]))))
    end
    provide(k, 'WritePrivateProfileStringA', :native, 'escrita INI preservando o arquivo', 4) { |a| Ini.write_string(a[0], a[1], a[2], a[3]) }
    provide(k, 'GetProfileStringA', :native, 'win.ini virtual do jogo', 5) { |a| Ini.read_string(a[0], a[1], a[2], a[3], a[4], 'win.ini') }
    provide(k, 'GetProfileIntA', :native, 'win.ini virtual do jogo', 3) { |a| Ini.read_int(a[0], a[1], a[2], 'win.ini') }
    provide(k, 'WriteProfileStringA', :native, 'win.ini virtual do jogo', 3) { |a| Ini.write_string(a[0], a[1], a[2], 'win.ini') }

    # --- memory (Ruby buffers and the virtual heap only) --------------------
    move = lambda do |a|
      length = a[2].to_i
      next 0 if length == 0
      Memory.write(a[0], Memory.read(a[1], length))
      0
    end
    provide(k, 'RtlMoveMemory', :native, 'copia entre buffers Ruby/heap virtual; enderecos reais rejeitados', 3, &move)
    provide('ntdll', 'RtlMoveMemory', :native, 'copia entre buffers Ruby/heap virtual; enderecos reais rejeitados', 3, &move)
    provide(k, 'RtlZeroMemory', :native, 'zera buffer Ruby/heap virtual', 2) { |a| Memory.write(a[0], "\0" * a[1].to_i); 0 }
    provide(k, 'RtlFillMemory', :native, 'preenche buffer Ruby/heap virtual', 3) { |a| Memory.write(a[0], (a[2].to_i & 0xff).chr * a[1].to_i); 0 }
    provide(k, 'lstrlenA', :native, 'strlen em buffer Ruby/heap virtual', 1) { |a| (Buffers.c_string(a[0]) || '').length }
    provide(k, 'lstrlenW', :native, 'wcslen em buffer Ruby/heap virtual', 1) do |a|
      next 0 if Buffers.null?(a[0])
      if a[0].is_a?(Integer)
        block, offset = Memory.fetch(a[0], 'lstrlenW')
        Text.until_wide_nul(block[offset, block.length - offset] || '').length / 2
      else
        Text.until_wide_nul(a[0].to_s).length / 2
      end
    end
    alloc = lambda do |a|
      size = a[1].to_i
      next WinBridge.failure(ERROR_NOT_ENOUGH_MEMORY, 0) if size < 0 || size > Memory::STEP
      WinBridge.success(Memory.alloc("\0" * size))
    end
    free = lambda { |a| Memory.free(a[0]) ? WinBridge.success(0) : WinBridge.failure(ERROR_INVALID_HANDLE, a[0]) }
    provide(k, 'GlobalAlloc', :native, 'heap virtual (ate 64 KiB por bloco)', 2, &alloc)
    provide(k, 'LocalAlloc', :native, 'heap virtual (ate 64 KiB por bloco)', 2, &alloc)
    provide(k, 'GlobalFree', :native, 'heap virtual', 1, &free)
    provide(k, 'LocalFree', :native, 'heap virtual', 1, &free)
    provide(k, 'GlobalLock', :native, 'bloco fixo do heap virtual', 1) { |a| Memory.owns?(a[0]) ? a[0] : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'GlobalUnlock', :native, 'bloco fixo do heap virtual', 1) { |a| WinBridge.success(0) }
    provide(k, 'GetProcessHeap', :native, 'heap virtual unico', 0) { |a| 0x00150000 }
    provide(k, 'HeapAlloc', :native, 'heap virtual', 3) { |a| alloc.call([0, a[2]]) }
    provide(k, 'HeapFree', :native, 'heap virtual', 3) { |a| Memory.free(a[2]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }

    # --- text conversion ------------------------------------------------------
    provide(k, 'MultiByteToWideChar', :native, 'UTF-8 (65001) e Windows-1252 (ACP) sem Encoding', 6) do |a|
      codepage = a[0].to_i
      length = a[3].to_i
      source = length < 0 ? Buffers.c_string(a[2]).to_s + "\0" : Memory.read(a[2], length)
      text = codepage == 65001 ? source : Text.cp1252_to_utf8(source)
      wide = Text.utf8_to_utf16le(text)
      units = wide.length / 2
      next WinBridge.success(units) if a[5].to_i == 0
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if a[5].to_i < units
      Memory.write(a[4], wide)
      WinBridge.success(units)
    end
    provide(k, 'WideCharToMultiByte', :native, 'UTF-16LE para UTF-8 (65001) ou Windows-1252', 6) do |a|
      codepage = a[0].to_i
      units = a[3].to_i
      bytes = units < 0 ? Text.utf8_to_utf16le(Buffers.wide_string(a[2]).to_s) + "\0\0" : Memory.read(a[2], units * 2)
      text = Text.utf16le_to_utf8(bytes)
      used = false
      if codepage != 65001
        default_char = Buffers.null?(a[6]) ? '?' : Buffers.c_string(a[6]).to_s[0, 1]
        text, used = Text.utf8_to_cp1252(text, default_char.empty? ? '?' : default_char)
      end
      Buffers.put_u32(a[7], used ? 1 : 0, 0) if a.length > 7 && !Buffers.null?(a[7])
      next WinBridge.success(text.length) if a[5].to_i == 0
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if a[5].to_i < text.length
      Memory.write(a[4], text)
      WinBridge.success(text.length)
    end

    # --- modules --------------------------------------------------------------
    provide(k, 'GetModuleHandleA', :native, 'modulo do jogo e DLLs com provider Kerberus', 1) do |a|
      handle = WinBridge.module_handle(Buffers.c_string(a[0]))
      handle ? WinBridge.success(handle) : WinBridge.failure(ERROR_MOD_NOT_FOUND, 0)
    end
    load_library = lambda do |a|
      name = Buffers.c_string(a[0]).to_s
      handle = WinBridge.module_handle(name)
      if handle
        WinBridge.success(handle)
      else
        KerberusLegacy18.event('LOADLIBRARY_MISSING', WinBridge.library(name), 'DLL sem provider/port; retornando NULL como um Windows sem a DLL')
        WinBridge.failure(ERROR_MOD_NOT_FOUND, 0)
      end
    end
    provide(k, 'LoadLibraryA', :native, 'sucesso apenas para DLLs com provider/port; demais = ERROR_MOD_NOT_FOUND', 1, &load_library)
    provide(k, 'LoadLibraryExA', :native, 'sucesso apenas para DLLs com provider/port', 1, &load_library)
    provide(k, 'FreeLibrary', :native, 'modulos virtuais', 1) { |a| a[0].to_i != 0 ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'GetProcAddress', :native, 'endereco virtual somente para funcoes com provider', 2) do |a|
      name = Buffers.c_string(a[1]).to_s
      found = WinBridge.providers.values.any? { |table| (table[name] || table[name + 'A']) && (table[name] || table[name + 'A']).kind != :unavailable }
      found ? WinBridge.success(0x20000000 + (name.hash & 0xFFFFFF)) : WinBridge.failure(ERROR_PROC_NOT_FOUND, 0)
    end
    provide(k, 'GetModuleFileNameA', :native, 'caminho real do jogo com separadores Windows', 3) do |a|
      path = WinBridge.windows_path(File.join(Dir.pwd, KerberusLegacy18.config[:exec_name] + '.exe'))
      capacity = a[2].to_i
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if capacity <= 0
      copied = Buffers.copy_c_string(a[1], capacity, path)
      copied < path.length ? WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, capacity) : WinBridge.success(copied)
    end

    # --- locale -----------------------------------------------------------------
    [['GetUserDefaultLangID', 0], ['GetSystemDefaultLangID', 0], ['GetUserDefaultUILanguage', 0],
     ['GetSystemDefaultUILanguage', 0], ['GetUserDefaultLCID', 0], ['GetSystemDefaultLCID', 0],
     ['GetThreadLocale', 0]].each do |pair|
      provide(k, pair[0], :native, 'idioma do Android convertido para LANGID', pair[1]) { |a| Locale.langid }
    end
    provide(k, 'GetUserGeoID', :native, 'regiao do Android convertida para GEOID', 1) do |a|
      geo = Locale.geoid
      if geo
        geo
      else
        KerberusLegacy18.event('LIMITED', 'kernel32!GetUserGeoID', 'regiao ' + Locale.region.inspect + ' sem tabela; GEOID_NOT_AVAILABLE')
        -1
      end
    end
    provide(k, 'GetACP', :native, 'code page ANSI do idioma do Android', 0) { |a| Locale.ansi_codepage }
    provide(k, 'GetOEMCP', :native, 'code page OEM', 0) { |a| Locale.language == 'ja' ? 932 : 437 }
    provide(k, 'GetLocaleInfoA', :limited, 'somente LOCALE_SISO639LANGNAME/SISO3166CTRYNAME/IDEFAULTANSICODEPAGE', 4) do |a|
      text = case a[1].to_i & 0xffff
             when 0x59 then Locale.language
             when 0x5A then Locale.region
             when 0x1004 then Locale.ansi_codepage.to_s
             end
      if text.nil?
        WinBridge.failure(1004, 0)
      elsif a[3].to_i == 0
        WinBridge.success(text.length + 1)
      elsif a[3].to_i <= text.length
        WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0)
      else
        Buffers.put(a[2], text + "\0", 0)
        WinBridge.success(text.length + 1)
      end
    end

    # --- system information -------------------------------------------------------
    provide(k, 'GetSystemPowerStatus', :native, 'bateria via SDL_GetPowerInfo', 1) do |a|
      Buffers.need(a[0], 12, true, 'SYSTEM_POWER_STATUS')
      state = KerberusLegacy18.native?('System', :power_state) ? KerberusLegacy18.native('System', :power_state) : {}
      percent = state[:percent]
      discharging = state[:discharging] ? true : false
      seconds = state[:seconds]
      ac = discharging ? 0 : (percent.nil? ? 255 : 1)
      flag = if percent.nil? then 128
             elsif percent > 66 then 1
             elsif percent < 5 then 4
             elsif percent < 33 then 2
             else 0
             end
      flag |= 8 if !discharging && !percent.nil? && percent < 100
      Buffers.put(a[0], [ac, flag, percent.nil? ? 255 : percent, 0, seconds.nil? ? 0xffffffff : seconds, 0xffffffff].pack('CCCCVV'), 0)
      1
    end
    memory_status = lambda do
      total = KerberusLegacy18.native?('System', :memory) ? KerberusLegacy18.native('System', :memory).to_i * 1024 * 1024 : 0
      available = total
      begin
        text = KerberusLegacy18.raw_read('/proc/meminfo')
        available = $1.to_i * 1024 if text =~ /^MemAvailable:\s+(\d+)/
      rescue SystemCallError, IOError
      end
      [total, available]
    end
    provide(k, 'GlobalMemoryStatusEx', :native, 'memoria total do SDL e MemAvailable do Linux', 1) do |a|
      Buffers.need(a[0], 64, true, 'MEMORYSTATUSEX')
      total, available = memory_status.call
      load = total > 0 ? 100 - (available * 100 / total) : 0
      virtual = 0x7FFE0000
      Buffers.put(a[0], [64, load].pack('VV') + Buffers.pack_u64(total) + Buffers.pack_u64(available) +
                        Buffers.pack_u64(total) + Buffers.pack_u64(available) + Buffers.pack_u64(virtual) +
                        Buffers.pack_u64(virtual) + Buffers.pack_u64(0), 0)
      1
    end
    provide(k, 'GlobalMemoryStatus', :native, 'memoria total do SDL e MemAvailable do Linux (limitada a 4 GiB)', 1) do |a|
      Buffers.need(a[0], 32, true, 'MEMORYSTATUS')
      total, available = memory_status.call
      cap = lambda { |value| value > 0xffffffff ? 0xffffffff : value }
      load = total > 0 ? 100 - (available * 100 / total) : 0
      Buffers.put(a[0], [32, load, cap.call(total), cap.call(available), cap.call(total), cap.call(available), 0x7FFE0000, 0x7FFE0000].pack('V8'), 0)
      0
    end
    system_info = lambda do |a|
      Buffers.need(a[0], 36, true, 'SYSTEM_INFO')
      cpus = KerberusLegacy18.native?('System', :nproc) ? KerberusLegacy18.native('System', :nproc).to_i : 1
      mask = cpus >= 32 ? 0xffffffff : (1 << cpus) - 1
      # A 32-bit RGSS player sees an x86 machine (PROCESSOR_ARCHITECTURE_INTEL).
      Buffers.put(a[0], [0, 0, 4096, 0x10000, 0x7FFEFFFF, mask, cpus, 586, 0x10000, 6, 0].pack('vvVVVVVVVvv'), 0)
      0
    end
    provide(k, 'GetSystemInfo', :limited, 'CPUs reais; arquitetura x86 como um RGSS 32 bits', 1, &system_info)
    provide(k, 'GetNativeSystemInfo', :limited, 'CPUs reais; arquitetura x86 como um RGSS 32 bits', 1, &system_info)
    provide(k, 'GetVersion', :limited, 'Windows 8 (6.2.9200), como o Windows 10 reporta a um jogo sem manifesto', 0) { |a| (9200 << 16) | (2 << 8) | 6 }
    provide(k, 'GetVersionExA', :limited, 'Windows 8 (6.2.9200), como o Windows 10 reporta a um jogo sem manifesto', 1) do |a|
      size = Buffers.u32(a[0], 0)
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) unless size == 148 || size == 156
      Buffers.need(a[0], size, true, 'OSVERSIONINFO')
      data = [size, 6, 2, 9200, 2].pack('V5') + "\0" * 128
      data += [0, 0, 0, 1, 0].pack('vvvCC') if size == 156
      Buffers.put(a[0], data, 0)
      1
    end
    provide(k, 'GetComputerNameA', :native, 'nome virtual KERBERUS (nenhum dado pessoal)', 2) do |a|
      name = 'KERBERUS'
      capacity = Buffers.u32(a[1], 0)
      if capacity <= name.length
        Buffers.put_u32(a[1], name.length + 1, 0)
        next WinBridge.failure(111, 0)
      end
      Buffers.put(a[0], name + "\0", 0)
      Buffers.put_u32(a[1], name.length, 0)
      1
    end
    provide(k, 'GetEnvironmentVariableA', :limited, 'ambiente virtual minimo; demais variaveis ausentes', 3) do |a|
      value = Env.get(Buffers.c_string(a[0]).to_s)
      if value.nil?
        WinBridge.failure(ERROR_ENVVAR_NOT_FOUND, 0)
      elsif a[2].to_i <= value.length
        WinBridge.success(value.length + 1)
      else
        Buffers.put(a[1], value + "\0", 0)
        WinBridge.success(value.length)
      end
    end

    # --- directories ---------------------------------------------------------------
    provide(k, 'GetCurrentDirectoryA', :native, 'Dir.pwd com separadores Windows', 2) do |a|
      path = WinBridge.windows_path(Dir.pwd)
      next WinBridge.success(path.length + 1) if a[0].to_i <= path.length
      Buffers.put(a[1], path + "\0", 0)
      WinBridge.success(path.length)
    end
    provide(k, 'SetCurrentDirectoryA', :native, 'Dir.chdir com resolucao estilo Windows', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      if path && File.directory?(path)
        Dir.chdir(path)
        WinBridge.success(1)
      else
        WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      end
    end
    directory_provider = lambda do |subdir|
      lambda do |a|
        path = WinBridge.windows_path(KerberusLegacy18.data_dir(subdir) || Dir.pwd)
        next WinBridge.success(path.length + 1) if a[1].to_i <= path.length
        Buffers.put(a[0], path + "\0", 0)
        WinBridge.success(path.length)
      end
    end
    provide(k, 'GetWindowsDirectoryA', :native, 'pasta Windows virtual por jogo (fora da pasta do jogo)', 2, &directory_provider.call('Windows'))
    provide(k, 'GetSystemDirectoryA', :native, 'pasta System32 virtual por jogo', 2, &directory_provider.call('Windows'))
    provide(k, 'GetTempPathA', :native, 'pasta temporaria virtual por jogo', 2) do |a|
      path = WinBridge.windows_path(KerberusLegacy18.data_dir('Temp') || Dir.pwd) + '\\'
      next WinBridge.success(path.length + 1) if a[0].to_i <= path.length
      Buffers.put(a[1], path + "\0", 0)
      WinBridge.success(path.length)
    end

    # --- files -------------------------------------------------------------------------
    provide(k, 'GetFileAttributesA', :native, 'atributos a partir do sistema de arquivos Android', 1) do |a|
      attributes = WinBridge.file_attributes(WinBridge.native_path(a[0], false))
      attributes ? WinBridge.success(attributes) : WinBridge.failure(ERROR_FILE_NOT_FOUND, -1)
    end
    provide(k, 'SetFileAttributesA', :limited, 'atributos Windows nao existem no Android; arquivo verificado', 2) do |a|
      WinBridge.file_attributes(WinBridge.native_path(a[0], false)) ? 1 : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(k, 'CreateDirectoryA', :native, 'Dir.mkdir com resolucao estilo Windows', 2) do |a|
      path = WinBridge.native_path(a[0], true)
      if path.nil? || !File.directory?(File.dirname(path))
        WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      elsif File.exist?(path)
        WinBridge.failure(ERROR_ALREADY_EXISTS, 0)
      else
        Dir.mkdir(path)
        WinBridge.success(1)
      end
    end
    provide(k, 'RemoveDirectoryA', :native, 'Dir.rmdir', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      begin
        path && File.directory?(path) ? (Dir.rmdir(path); WinBridge.success(1)) : WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      rescue SystemCallError
        WinBridge.failure(145, 0)
      end
    end
    provide(k, 'DeleteFileA', :native, 'File.delete', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      path && File.file?(path) ? (File.delete(path); WinBridge.success(1)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(k, 'CopyFileA', :native, 'copia binaria', 3) do |a|
      source = WinBridge.native_path(a[0], false)
      target = WinBridge.native_path(a[1], true)
      if source.nil? || !File.file?(source)
        WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
      elsif target.nil? || !File.directory?(File.dirname(target))
        WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      elsif a[2].to_i != 0 && File.exist?(target)
        WinBridge.failure(80, 0)
      else
        data = File.open(source, 'rb') { |file| file.read }
        File.open(target, 'wb') { |file| file.write(data) }
        WinBridge.success(1)
      end
    end
    move_file = lambda do |a|
      source = WinBridge.native_path(a[0], false)
      target = WinBridge.native_path(a[1], true)
      replace = a.length > 2 && (a[2].to_i & 1) != 0
      if source.nil? || !File.exist?(source)
        WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
      elsif target.nil?
        WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      elsif File.exist?(target) && !replace
        WinBridge.failure(ERROR_ALREADY_EXISTS, 0)
      else
        File.rename(source, target)
        WinBridge.success(1)
      end
    end
    provide(k, 'MoveFileA', :native, 'File.rename', 2, &move_file)
    provide(k, 'MoveFileExA', :native, 'File.rename (MOVEFILE_REPLACE_EXISTING suportado)', 3, &move_file)

    provide(k, 'CreateFileA', :native, 'arquivos do jogo via File; console via log', 7) do |a|
      name = Buffers.c_string(a[0]).to_s
      if %w(con conout$ conin$).include?(name.downcase)
        next WinBridge.success(Handles.add(:console, name))
      end
      access = a[1].to_i & 0xffffffff
      disposition = a[4].to_i
      path = WinBridge.native_path(a[0], true)
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, INVALID_HANDLE) if path.nil? || !File.directory?(File.dirname(path))
      exists = File.file?(path)
      write = (access & 0x40000000) != 0 || (access & 0x10000000) != 0
      mode = nil
      case disposition
      when 1 then next WinBridge.failure(80, INVALID_HANDLE) if exists
                  mode = 'w+b'
      when 2 then mode = 'w+b'
      when 3 then next WinBridge.failure(ERROR_FILE_NOT_FOUND, INVALID_HANDLE) unless exists
                  mode = write ? 'r+b' : 'rb'
      when 4 then mode = exists ? (write ? 'r+b' : 'rb') : 'w+b'
      when 5 then next WinBridge.failure(ERROR_FILE_NOT_FOUND, INVALID_HANDLE) unless exists
                  mode = 'w+b'
      else next WinBridge.failure(ERROR_INVALID_PARAMETER, INVALID_HANDLE)
      end
      file = File.open(path, mode)
      Milestones.save_candidate(path) if mode != 'rb'
      WinBridge.failure(exists && (disposition == 2 || disposition == 4) ? ERROR_ALREADY_EXISTS : ERROR_SUCCESS,
                        Handles.add(:file, file, mode != 'rb'))
    end
    provide(k, 'ReadFile', :native, 'leitura binaria', 5) do |a|
      file = Handles.get(a[0], :file)
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless file
      data = file.read(a[2].to_i) || ''
      Buffers.put(a[1], data, 0) unless data.empty?
      Buffers.put_u32(a[3], data.length, 0) unless Buffers.null?(a[3])
      WinBridge.success(1)
    end
    provide(k, 'WriteFile', :native, 'escrita binaria; console vai para o log', 5) do |a|
      length = a[2].to_i
      data = Memory.read(a[1], length)
      if Console.handle?(a[0])
        Console.write(data)
      else
        file = Handles.get(a[0], :file)
        next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless file
        file.write(data)
      end
      Buffers.put_u32(a[3], length, 0) unless Buffers.null?(a[3])
      WinBridge.success(1)
    end
    provide(k, 'FlushFileBuffers', :native, 'IO#flush', 1) do |a|
      file = Handles.get(a[0], :file)
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless file
      next WinBridge.failure(ERROR_ACCESS_DENIED, 0) unless Handles.writable?(a[0])
      file.flush
      1
    end
    provide(k, 'GetFileSize', :native, 'tamanho do arquivo', 2) do |a|
      file = Handles.get(a[0], :file)
      next WinBridge.failure(ERROR_INVALID_HANDLE, -1) unless file
      file.flush if Handles.writable?(a[0])
      size = file.stat.size
      Buffers.put_u32(a[1], size >> 32, 0) unless Buffers.null?(a[1])
      size & 0xffffffff
    end
    provide(k, 'SetFilePointer', :native, 'seek (FILE_BEGIN/CURRENT/END)', 4) do |a|
      file = Handles.get(a[0], :file)
      next WinBridge.failure(ERROR_INVALID_HANDLE, -1) unless file
      distance = a[1].to_i & 0xffffffff
      distance -= 0x100000000 if distance >= 0x80000000
      whence = [IO::SEEK_SET, IO::SEEK_CUR, IO::SEEK_END][a[3].to_i]
      next WinBridge.failure(ERROR_INVALID_PARAMETER, -1) unless whence
      file.seek(distance, whence)
      file.pos & 0xffffffff
    end
    provide(k, 'CloseHandle', :native, 'handles virtuais', 1) do |a|
      Handles.close(a[0]) || Console.handle?(a[0]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_HANDLE, 0)
    end

    find_data = lambda do |directory, name|
      path = File.join(directory, name)
      stat = File.exist?(path) ? File.stat(path) : nil
      size = stat && stat.file? ? stat.size : 0
      time = stat ? WinBridge.filetime(stat.mtime) : "\0" * 8
      [stat && stat.directory? ? 0x10 : 0x20].pack('V') + time + time + time +
        [size >> 32, size & 0xffffffff, 0, 0].pack('V4') + (name[0, 259] + "\0").ljust(260, "\0") + "\0" * 16
    end
    provide(k, 'FindFirstFileA', :native, 'Dir com curinga sem diferenciar maiusculas', 2) do |a|
      pattern = Buffers.c_string(a[0]).to_s.tr('\\', '/')
      slash = pattern.rindex('/')
      directory = slash ? Paths.resolve(pattern[0, slash], false) : '.'
      mask = slash ? pattern[slash + 1, pattern.length] : pattern
      mask = '*' if mask == '*.*'
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, INVALID_HANDLE) unless File.directory?(directory)
      names = Dir.entries(directory).select { |entry| File.fnmatch(mask, entry, File::FNM_CASEFOLD | File::FNM_DOTMATCH) }
      next WinBridge.failure(ERROR_FILE_NOT_FOUND, INVALID_HANDLE) if names.empty?
      Buffers.put(a[1], find_data.call(directory, names.shift), 0)
      WinBridge.success(Handles.add(:find, [directory, names]))
    end
    provide(k, 'FindNextFileA', :native, 'Dir com curinga', 2) do |a|
      state = Handles.get(a[0], :find)
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless state
      next WinBridge.failure(18, 0) if state[1].empty?
      Buffers.put(a[1], find_data.call(state[0], state[1].shift), 0)
      WinBridge.success(1)
    end
    provide(k, 'FindClose', :native, 'handle de busca virtual', 1) { |a| Handles.close(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }

    # --- console ------------------------------------------------------------------------
    provide(k, 'AllocConsole', :native, 'console virtual escrito no log do Kerberus', 0) { |a| Console.alloc }
    provide(k, 'FreeConsole', :native, 'console virtual', 0) { |a| Console.free }
    provide(k, 'AttachConsole', :limited, 'sem console de processo pai no Android', 1) { |a| WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'GetConsoleWindow', :native, 'console virtual sem janela', 0) { |a| 0 }
    provide(k, 'GetStdHandle', :native, 'handles do console virtual', 1) do |a|
      case a[0].to_i & 0xffffffff
      when 0xFFFFFFF6 then Console::STD_INPUT
      when 0xFFFFFFF5 then Console::STD_OUTPUT
      when 0xFFFFFFF4 then Console::STD_ERROR
      else WinBridge.failure(ERROR_INVALID_HANDLE, -1)
      end
    end
    write_console = lambda do |wide|
      lambda do |a|
        next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless Console.handle?(a[0])
        count = a[2].to_i
        text = wide ? Text.utf16le_to_utf8(Memory.read(a[1], count * 2)) : Memory.read(a[1], count)
        Console.write(text)
        Buffers.put_u32(a[3], count, 0) unless Buffers.null?(a[3])
        WinBridge.success(1)
      end
    end
    provide(k, 'WriteConsoleA', :native, 'texto do console vai para o log', 4, &write_console.call(false))
    provide(k, 'WriteConsoleW', :native, 'texto do console vai para o log', 4, &write_console.call(true))
    provide(k, 'ReadConsoleA', :limited, 'sem entrada de console no Android', 4) { |a| WinBridge.failure(ERROR_CALL_NOT_IMPLEMENTED, 0) }
    provide(k, 'SetConsoleTitleA', :native, 'titulo registrado no log', 1) { |a| KerberusLegacy18.event('CONSOLE', 'title', Buffers.c_string(a[0]).to_s); 1 }
    provide(k, 'SetConsoleTextAttribute', :native, 'cores sem efeito em log de texto', 2) { |a| Console.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'CreateConsoleScreenBuffer', :native, 'buffer de console virtual', 5) { |a| WinBridge.success(Handles.add(:console, 'buffer')) }
    provide(k, 'SetConsoleActiveScreenBuffer', :native, 'buffer de console virtual', 1) { |a| Console.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'SetConsoleScreenBufferSize', :native, 'buffer de console virtual', 2) { |a| Console.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
  end
end

# ==== 51_user32.rb ====
# Kerberus WinBridge providers - user32 over SDL/mkxp-z.
#
# There is one logical top-level window (HWND 1) whose client area is the
# RGSS resolution. Screen, window and client coordinates are the same space,
# which is exactly what an undecorated fullscreen RGSS window reports.
module KerberusLegacy18
  module WinBridge
    u = 'user32'

    provide(u, 'GetAsyncKeyState', :native, 'estado SDL ao vivo (toque/teclado/controle/mouse); SHORT com sinal como no RGSS1', 1) { |a| InputBridge.async_key_state(a[0].to_i) }
    provide(u, 'GetKeyState', :native, 'estado SDL ao vivo; bits de toggle nao expostos pelo SDL', 1) { |a| InputBridge.key_state(a[0].to_i) }
    provide(u, 'GetKeyboardState', :native, '256 estados SDL ao vivo; bits de toggle 0', 1) do |a|
      Buffers.put(a[0], InputBridge.keyboard_state, 0)
      1
    end
    provide(u, 'MapVirtualKeyA', :native, 'tabela de scan codes US', 2) { |a| InputBridge.map_virtual_key(a[0], a[1]) }
    provide(u, 'MapVirtualKeyExA', :native, 'tabela de scan codes US', 2) { |a| InputBridge.map_virtual_key(a[0], a[1]) }
    provide(u, 'ToUnicode', :native, 'layout US com Shift/Ctrl/CapsLock do estado informado', 5) { |a| InputBridge.to_unicode(a[0], a[2], a[3], a[4]) }
    provide(u, 'ToUnicodeEx', :native, 'layout US com Shift/Ctrl/CapsLock do estado informado', 5) { |a| InputBridge.to_unicode(a[0], a[2], a[3], a[4]) }
    provide(u, 'ToAscii', :native, 'layout US com Shift/Ctrl/CapsLock do estado informado', 4) { |a| InputBridge.to_ascii(a[0], a[2], a[3]) }
    provide(u, 'ToAsciiEx', :native, 'layout US com Shift/Ctrl/CapsLock do estado informado', 4) { |a| InputBridge.to_ascii(a[0], a[2], a[3]) }
    provide(u, 'GetKeyboardLayout', :native, 'HKL US, coerente com ToUnicode', 1) { |a| 0x04090409 }
    provide(u, 'keybd_event', :limited, 'teclas sinteticas nao sao injetadas; Alt+Enter/fullscreen ja e gerenciado pelo Android', 4) do |a|
      KerberusLegacy18.event('LIMITED', 'user32!keybd_event', 'vk=' + a[0].to_i.to_s + ' ignorado (sem retorno no Windows)')
      0
    end
    provide(u, 'SendInput', :limited, 'eventos sinteticos nao sao injetados', 3) { |a| WinBridge.failure(ERROR_ACCESS_DENIED, 0) }

    provide(u, 'GetCursorPos', :native, 'mouse/toque SDL ao vivo em coordenadas do jogo', 1) do |a|
      Buffers.put(a[0], InputBridge.mouse.pack('l2'), 0)
      1
    end
    provide(u, 'SetCursorPos', :limited, 'Android nao permite mover o ponteiro de toque', 2) { |a| WinBridge.failure(ERROR_CALL_NOT_IMPLEMENTED, 0) }
    point_identity = lambda do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0]) || a[0].to_i == Window::DESKTOP || a[0].to_i == 0
      Buffers.need(a[1], 8, true, 'POINT')
      1
    end
    provide(u, 'ScreenToClient', :native, 'tela e cliente coincidem na janela logica', 2, &point_identity)
    provide(u, 'ClientToScreen', :native, 'tela e cliente coincidem na janela logica', 2, &point_identity)
    provide(u, 'ShowCursor', :native, 'contador de exibicao do cursor', 1) { |a| Window.show_cursor(a[0]) }
    provide(u, 'ClipCursor', :limited, 'sem cursor de hardware no Android; confinamento vazio', 1) { |a| 1 }
    provide(u, 'SetCapture', :native, 'captura logica da janela', 1) { |a| Window.handle?(a[0]) ? Window.capture(Window::HWND) : 0 }
    provide(u, 'ReleaseCapture', :native, 'captura logica da janela', 0) { |a| Window.capture(0); 1 }
    provide(u, 'GetCapture', :native, 'captura logica da janela', 0) { |a| Window.captured }
    provide(u, 'GetDoubleClickTime', :native, '500 ms, padrao do Windows', 0) { |a| 500 }

    rect = lambda do |a|
      Buffers.need(a[1], 16, true, 'RECT')
      if Window.handle?(a[0]) || a[0].to_i == Window::DESKTOP
        Buffers.put(a[1], Window.rect_bytes, 0)
        1
      else
        WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0)
      end
    end
    provide(u, 'GetClientRect', :native, 'resolucao logica do RGSS', 2, &rect)
    provide(u, 'GetWindowRect', :native, 'janela logica sem bordas', 2, &rect)
    provide(u, 'GetSystemMetrics', :native, 'desktop virtual = resolucao do jogo; bordas 0', 1) { |a| Window.metric(a[0]) }
    provide(u, 'AdjustWindowRect', :native, 'janela sem bordas: retangulo inalterado', 3) { |a| Buffers.need(a[0], 16, true, 'RECT'); 1 }
    provide(u, 'AdjustWindowRectEx', :native, 'janela sem bordas: retangulo inalterado', 4) { |a| Buffers.need(a[0], 16, true, 'RECT'); 1 }

    find_window = lambda do |klass, title|
      klass = Buffers.c_string(klass)
      title = Buffers.c_string(title)
      class_ok = klass.nil? || klass.empty? || klass == 'RGSS Player'
      title_ok = title.nil? || title.empty? || title == Window.title
      class_ok && title_ok ? WinBridge.success(Window::HWND) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(u, 'FindWindowA', :native, 'janela logica "RGSS Player"', 2) { |a| find_window.call(a[0], a[1]) }
    provide(u, 'FindWindowExA', :native, 'janela logica "RGSS Player"', 4) do |a|
      Buffers.null?(a[0]) && Buffers.null?(a[1]) ? find_window.call(a[2], a[3]) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    focus_window = lambda { |a| KerberusLegacy18.focused? ? Window::HWND : 0 }
    provide(u, 'GetActiveWindow', :native, 'janela logica quando o app tem foco', 0, &focus_window)
    provide(u, 'GetForegroundWindow', :native, 'janela logica quando o app tem foco', 0, &focus_window)
    provide(u, 'GetFocus', :native, 'janela logica quando o app tem foco', 0, &focus_window)
    provide(u, 'GetDesktopWindow', :native, 'desktop virtual', 0) { |a| Window::DESKTOP }
    provide(u, 'GetWindowThreadProcessId', :native, 'thread dona da janela e pid Android', 2) do |a|
      next 0 unless Window.handle?(a[0])
      Buffers.put_u32(a[1], Process.pid, 0) unless Buffers.null?(a[1])
      KerberusLegacy18.thread_id
    end
    provide(u, 'IsWindow', :native, 'janela logica', 1) { |a| Window.handle?(a[0]) || a[0].to_i == Window::DESKTOP ? 1 : 0 }
    provide(u, 'IsWindowVisible', :native, 'janela logica sempre visivel', 1) { |a| Window.handle?(a[0]) ? 1 : 0 }
    provide(u, 'IsIconic', :native, 'janela logica nunca minimizada', 1) { |a| 0 }
    provide(u, 'IsZoomed', :native, 'janela logica em tela cheia', 1) { |a| Window.handle?(a[0]) ? 1 : 0 }
    provide(u, 'SetWindowTextA', :native, 'titulo da janela SDL', 2) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      KerberusLegacy18.native('System', :set_window_title, Buffers.c_string(a[1]).to_s) if KerberusLegacy18.native?('System', :set_window_title)
      1
    end
    provide(u, 'GetWindowTextA', :native, 'titulo da janela SDL', 3) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      Buffers.copy_c_string(a[1], a[2].to_i, Window.title)
    end
    provide(u, 'GetWindowTextLengthA', :native, 'titulo da janela SDL', 1) { |a| Window.handle?(a[0]) ? Window.title.length : 0 }
    provide(u, 'GetClassNameA', :native, 'classe RGSS Player', 3) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      Buffers.copy_c_string(a[1], a[2].to_i, 'RGSS Player')
    end
    provide(u, 'GetWindowLongA', :native, 'estilos da janela logica', 2) { |a| Window.handle?(a[0]) ? Window.style(a[1]) : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) }
    geometry = 'superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada'
    provide(u, 'SetWindowLongA', :limited, geometry, 3) { |a| Window.handle?(a[0]) ? Window.set_style(a[1], a[2]) : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) }
    [['SetWindowPos', 7], ['MoveWindow', 6], ['ShowWindow', 2], ['SetForegroundWindow', 1],
     ['BringWindowToTop', 1], ['UpdateWindow', 1], ['InvalidateRect', 3], ['SetActiveWindow', 1],
     ['SetFocus', 1]].each do |pair|
      provide(u, pair[0], :limited, geometry, pair[1]) do |a|
        Window.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0)
      end
    end
    provide(u, 'GetDC', :native, 'DC virtual do jogo', 1) { |a| Window::DC }
    provide(u, 'GetWindowDC', :native, 'DC virtual do jogo', 1) { |a| Window::DC }
    provide(u, 'ReleaseDC', :native, 'DC virtual do jogo', 2) { |a| a[1].to_i == Window::DC ? 1 : 0 }

    provide(u, 'PeekMessageA', :native, 'fila Win32 vazia: eventos pertencem ao SDL', 5) { |a| 0 }
    provide(u, 'GetMessageA', :unavailable, 'bloquearia o jogo: a fila Win32 nao recebe eventos no Android', 4)
    message = lambda do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      msg = a[1].to_i
      if msg == 0x10 || (msg == 0x112 && (a[2].to_i & 0xFFF0) == 0xF060)
        KerberusLegacy18.event('WINDOW_CLOSE', 'user32 message', 'WM_CLOSE/SC_CLOSE para a janela do jogo: encerrando como no Windows', true)
        exit
      end
      KerberusLegacy18.event('LIMITED', 'user32 message 0x' + msg.to_s(16), 'mensagem Win32 sem efeito no Android')
      0
    end
    provide(u, 'SendMessageA', :limited, 'WM_CLOSE encerra o jogo; demais mensagens sem efeito', 4, &message)
    provide(u, 'PostMessageA', :limited, 'WM_CLOSE encerra o jogo; demais mensagens sem efeito', 4, &message)
    provide(u, 'RegisterHotKey', :limited, 'atalhos globais indisponiveis no Android', 4) { |a| WinBridge.failure(1409, 0) }
    provide(u, 'UnregisterHotKey', :limited, 'atalhos globais indisponiveis no Android', 2) { |a| WinBridge.failure(1419, 0) }
    provide(u, 'SystemParametersInfoA', :limited, 'parametros de desktop nao expostos', 4) { |a| WinBridge.failure(ERROR_CALL_NOT_IMPLEMENTED, 0) }
    provide(u, 'MessageBoxA', :limited, 'mensagem RGSS nativa; botoes Sim/Nao retornam a opcao segura', 4) do |a|
      text = Buffers.c_string(a[1]).to_s
      caption = Buffers.c_string(a[2]).to_s
      type = a[3].to_i & 0x0F
      KerberusLegacy18.native('Kernel', :print, caption.empty? ? text : caption + "\n\n" + text) if KerberusLegacy18.native?('Kernel', :print)
      answer = { 0 => 1, 1 => 2, 2 => 5, 3 => 2, 4 => 7, 5 => 2, 6 => 2 }[type] || 1
      KerberusLegacy18.event('LIMITED', 'user32!MessageBoxA', 'tipo ' + type.to_s + ' respondido com ' + answer.to_s) if type != 0
      answer
    end
  end
end

# ==== 52_advapi32_shell32.rb ====
# Kerberus WinBridge providers - advapi32 (virtual registry) and shell32.
module KerberusLegacy18
  module WinBridge
    r = 'advapi32'
    provide(r, 'RegOpenKeyExA', :native, 'registro virtual persistente por jogo', 5) { |a| Registry.open(a[0], a[1], a[4]) }
    provide(r, 'RegOpenKeyA', :native, 'registro virtual persistente por jogo', 3) { |a| Registry.open(a[0], a[1], a[2]) }
    provide(r, 'RegCreateKeyExA', :native, 'registro virtual persistente por jogo', 9) { |a| Registry.create(a[0], a[1], a[7], a[8]) }
    provide(r, 'RegCreateKeyA', :native, 'registro virtual persistente por jogo', 3) { |a| Registry.create(a[0], a[1], a[2], 0) }
    provide(r, 'RegQueryValueExA', :native, 'registro virtual persistente por jogo', 6) { |a| Registry.query(a[0], a[1], a[3], a[4], a[5]) }
    provide(r, 'RegSetValueExA', :native, 'registro virtual persistente por jogo', 6) { |a| Registry.set(a[0], a[1], a[3].to_i, a[4], a[5]) }
    provide(r, 'RegDeleteValueA', :native, 'registro virtual persistente por jogo', 2) { |a| Registry.delete_value(a[0], a[1]) }
    provide(r, 'RegDeleteKeyA', :native, 'registro virtual persistente por jogo', 2) { |a| Registry.delete_key(a[0], a[1]) }
    provide(r, 'RegCloseKey', :native, 'registro virtual persistente por jogo', 1) { |a| Registry.close(a[0]) }
    provide(r, 'RegFlushKey', :native, 'registro virtual persistido a cada escrita', 1) { |a| Registry.path_of(a[0]) ? 0 : ERROR_INVALID_HANDLE }
    provide(r, 'GetUserNameA', :native, 'nome virtual Player; nenhum dado pessoal do aparelho', 2) do |a|
      name = 'Player'
      capacity = Buffers.u32(a[1], 0)
      Buffers.put_u32(a[1], name.length + 1, 0)
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if capacity <= name.length
      Buffers.put(a[0], name + "\0", 0)
      1
    end

    s = 'shell32'
    # Known folders deliberately fail like on a system without that folder:
    # Essentials then keeps using its existing fallback (the game folder),
    # so saves made by earlier Kerberus versions stay where they are.
    saves = 'pasta especial indisponivel; o jogo usa o proprio fallback e os saves existentes continuam no mesmo lugar'
    provide(s, 'SHGetKnownFolderPath', :limited, saves, 4) do |a|
      Buffers.put_u32(a[3], 0, 0) unless Buffers.null?(a[3])
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0x80070002)
    end
    provide(s, 'SHGetSpecialFolderLocation', :limited, saves, 3) do |a|
      Buffers.put_u32(a[2], 0, 0) unless Buffers.null?(a[2])
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0x80004005)
    end
    provide(s, 'SHGetFolderPathA', :limited, saves, 5) do |a|
      Buffers.put(a[4], "\0", 0) unless Buffers.null?(a[4])
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0x80004005)
    end
    provide(s, 'SHGetSpecialFolderPathA', :limited, saves, 4) do |a|
      Buffers.put(a[1], "\0", 0) unless Buffers.null?(a[1])
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(s, 'SHGetPathFromIDListA', :native, 'nenhum PIDL e emitido; PIDL nulo falha como no Windows', 2) do |a|
      Buffers.put(a[1], "\0", 0) unless Buffers.null?(a[1])
      WinBridge.failure(ERROR_INVALID_PARAMETER, 0)
    end
    provide(s, 'ShellExecuteA', :limited, 'abrir programas/URLs externos indisponivel', 6) do |a|
      KerberusLegacy18.event('LIMITED', 'shell32!ShellExecuteA', Buffers.c_string(a[2]).to_s[0, 120])
      2
    end
    provide('ole32', 'CoTaskMemFree', :native, 'libera bloco do heap virtual', 1) { |a| Memory.free(a[0]); 0 }
    provide('ole32', 'CoTaskMemAlloc', :native, 'heap virtual', 1) do |a|
      size = a[0].to_i
      size < 0 || size > Memory::STEP ? 0 : Memory.alloc("\0" * size)
    end
    @com_initialized = false
    co_init = lambda do |a|
      result = @com_initialized ? 1 : 0
      @com_initialized = true
      result
    end
    provide('ole32', 'CoInitialize', :native, 'apartamento COM logico (S_OK/S_FALSE)', 1, &co_init)
    provide('ole32', 'CoInitializeEx', :native, 'apartamento COM logico (S_OK/S_FALSE)', 2, &co_init)
    provide('ole32', 'CoUninitialize', :native, 'apartamento COM logico', 0) { |a| @com_initialized = false; 0 }
    provide('ole32', 'CoCreateGuid', :native, 'GUID aleatorio versao 4', 1) do |a|
      bytes = Array.new(16) { rand(256) }
      bytes[7] = (bytes[7] & 0x0F) | 0x40
      bytes[8] = (bytes[8] & 0x3F) | 0x80
      Buffers.put(a[0], bytes.pack('C*'), 0)
      0
    end
    provide('ole32', 'CoCreateInstance', :unavailable, 'objetos COM do Windows nao existem no Android', 5)
  end
end

# ==== 53_media_misc.rb ====
# Kerberus WinBridge providers - winmm, gdi32, msvcrt, xinput, ws2_32 and
# fangame DLLs. Network and DLLs without a port report documented failures
# or precise WINBRIDGE_UNAVAILABLE errors, never fake success.
module KerberusLegacy18
  module WinBridge
    m = 'winmm'
    provide(m, 'timeGetTime', :native, 'CLOCK_BOOTTIME em ms (32 bits)', 0) { |a| KerberusLegacy18.uptime_ms & 0xffffffff }
    provide(m, 'timeBeginPeriod', :native, 'timers do Android ja tem resolucao de 1 ms (TIMERR_NOERROR)', 1) { |a| 0 }
    provide(m, 'timeEndPeriod', :native, 'timers do Android ja tem resolucao de 1 ms (TIMERR_NOERROR)', 1) { |a| 0 }
    provide(m, 'timeGetDevCaps', :native, 'periodo minimo 1 ms', 2) { |a| Buffers.put(a[0], [1, 1000000].pack('VV'), 0); 0 }
    provide(m, 'PlaySoundA', :native, 'arquivos via Audio nativo (SE ou BGS em loop)', 3) { |a| AudioBridge.play_sound(a[0], a[2]) }
    provide(m, 'sndPlaySoundA', :native, 'arquivos via Audio nativo', 2) { |a| AudioBridge.play_sound(a[0], (a[1].to_i & 0x0009) | AudioBridge::SND_FILENAME) }
    provide(m, 'mciSendStringA', :limited, 'open/play/stop/pause/resume/close/setaudio/status sobre canais nativos; video indisponivel', 4) do |a|
      AudioBridge::MCI.send_string(Buffers.c_string(a[0]), a[1], a[2])
    end
    provide(m, 'mciGetErrorStringA', :native, 'tabela de mensagens MCI', 3) { |a| AudioBridge::MCI.error_string(a[0], a[1], a[2]) }
    provide(m, 'waveOutGetNumDevs', :limited, 'nenhum dispositivo waveOut: o jogo deve usar o Audio nativo', 0) { |a| 0 }
    %w(waveOutOpen waveOutClose waveOutPrepareHeader waveOutUnprepareHeader waveOutWrite
       waveOutSetVolume waveOutGetVolume waveOutReset waveOutPause waveOutRestart
       midiOutOpen midiOutClose midiOutShortMsg midiOutGetNumDevs auxSetVolume auxGetVolume).each do |name|
      provide(m, name, :limited, 'saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED)', nil) do |a|
        name == 'midiOutGetNumDevs' ? 0 : 8
      end
    end

    g = 'gdi32'
    provide(g, 'AddFontResourceA', :native, 'fontes em Fonts/ ja sao carregadas pelo mkxp-z; outras pastas nao', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      if path.nil? || !File.file?(path)
        WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
      elsif File.expand_path(path).index(File.expand_path('Fonts') + '/') == 0
        1
      else
        KerberusLegacy18.event('LIMITED', 'gdi32!AddFontResourceA', File.basename(path) + ' fora de Fonts/ nao e registrada no mkxp-z')
        0
      end
    end
    provide(g, 'AddFontResourceExA', :native, 'fontes em Fonts/ ja sao carregadas pelo mkxp-z', 3) do |a|
      WinBridge.lookup('gdi32', 'AddFontResourceA').impl.call([a[0]])
    end
    provide(g, 'RemoveFontResourceA', :native, 'fonte continua indexada pelo mkxp-z', 1) { |a| WinBridge.native_path(a[0], false) ? 1 : 0 }
    provide(g, 'GetDeviceCaps', :native, 'DC virtual: 96 DPI, 32 bpp, resolucao do jogo', 2) do |a|
      case a[1].to_i
      when 8 then Window.width
      when 10 then Window.height
      when 12 then 32
      when 14 then 1
      when 88, 90 then 96
      when 116 then 60
      else 0
      end
    end
    provide(g, 'DeleteObject', :native, 'objetos GDI virtuais', 1) { |a| a[0].to_i != 0 ? 1 : 0 }
    %w(CreateFontA CreateFontIndirectA SelectObject GetTextExtentPoint32A TextOutA BitBlt
       StretchBlt CreateCompatibleDC CreateCompatibleBitmap GetDIBits SetDIBitsToDevice).each do |name|
      provide(g, name, :unavailable, 'desenho GDI sem superficie: use Bitmap do RGSS', nil)
    end

    c = 'msvcrt'
    provide(c, '_write', :native, 'stdout/stderr para o log do Kerberus', 3) do |a|
      descriptor = a[0].to_i
      next -1 unless descriptor == 1 || descriptor == 2
      Console.write(Memory.read(a[1], a[2].to_i))
      a[2].to_i
    end
    provide(c, '_read', :limited, 'sem stdin no Android (EBADF)', 3) { |a| -1 }

    x = 'xinput'
    provide(x, 'XInputGetState', :native, 'controle SDL ao vivo (jogador 0)', 2) { |a| InputBridge.xinput_get_state(a[0], a[1]) }
    provide(x, 'XInputSetState', :native, 'vibracao via SDL_GameControllerRumble', 2) { |a| InputBridge.xinput_set_state(a[0], a[1]) }
    provide(x, 'XInputGetCapabilities', :native, 'controle SDL como gamepad padrao', 3) { |a| InputBridge.xinput_capabilities(a[0], a[2]) }
    provide(x, 'XInputGetBatteryInformation', :native, 'nivel de energia SDL', 3) { |a| InputBridge.xinput_battery(a[0], a[2]) }
    provide(x, 'XInputEnable', :native, 'sem efeito colateral', 1) { |a| 0 }
    provide(x, 'XInputGetKeystroke', :limited, 'fila de teclas do XInput nao existe no SDL (ERROR_EMPTY)', 3) do |a|
      index = a[0].to_i
      index == 0 && InputBridge.controller_connected? ? 4306 : ERROR_DEVICE_NOT_CONNECTED
    end

    # Winsock: a machine without network. Documented error codes let games
    # disable online features instead of crashing.
    net = 'ws2_32'
    @wsa_error = 0
    net_down = lambda do |value, code|
      lambda do |a|
        @wsa_error = code
        value
      end
    end
    provide(net, 'WSAStartup', :limited, 'rede indisponivel: WSASYSNOTREADY', 2) { |a| @wsa_error = 10091; 10091 }
    provide(net, 'WSACleanup', :limited, 'rede indisponivel', 0) { |a| @wsa_error = 10093; -1 }
    provide(net, 'WSAGetLastError', :native, 'ultimo erro Winsock', 0) { |a| @wsa_error }
    provide(net, 'socket', :limited, 'rede indisponivel: INVALID_SOCKET/WSAENETDOWN', 3, &net_down.call(-1, 10050))
    %w(connect bind listen accept send recv sendto recvfrom select setsockopt getsockopt
       shutdown closesocket ioctlsocket).each do |name|
      provide(net, name, :limited, 'rede indisponivel: SOCKET_ERROR/WSAENOTSOCK', nil, &net_down.call(-1, 10038))
    end
    provide(net, 'gethostbyname', :limited, 'rede indisponivel: WSAHOST_NOT_FOUND', 1, &net_down.call(0, 11001))
    provide(net, 'gethostbyaddr', :limited, 'rede indisponivel: WSAHOST_NOT_FOUND', 3, &net_down.call(0, 11001))
    provide(net, 'getservbyname', :limited, 'rede indisponivel: WSANO_DATA', 2, &net_down.call(0, 11004))
    provide(net, 'gethostname', :native, 'nome virtual kerberus', 2) { |a| Buffers.copy_c_string(a[0], a[1].to_i, 'kerberus'); 0 }
    provide(net, 'htons', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffff].pack('n').unpack('v')[0] }
    provide(net, 'ntohs', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffff].pack('n').unpack('v')[0] }
    provide(net, 'htonl', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffffffff].pack('N').unpack('V')[0] }
    provide(net, 'ntohl', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffffffff].pack('N').unpack('V')[0] }
    provide(net, 'inet_addr', :native, 'conversao pura', 1) do |a|
      parts = Buffers.c_string(a[0]).to_s.split('.')
      if parts.length == 4 && parts.all? { |part| part =~ /\A\d{1,3}\z/ && part.to_i <= 255 }
        parts.map { |part| part.to_i }.pack('C4').unpack('V')[0]
      else
        0xffffffff
      end
    end
    provide(net, 'inet_ntoa', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffffffff].pack('V').unpack('C4').join('.') }

    provide('rpg.net', 'InputGetWheelDelta', :native, 'roda do mouse via Input.scroll_v', 0) { |a| InputBridge.wheel_delta }

    # RGSS1 player DLL (RGSS102E.dll and friends).
    provide('rgss1', 'RGSSGetRTPPath', :native, 'sem RTP instalado: caminho vazio', 1) { |a| 0 }
    provide('rgss1', 'RGSSGetPathWithRTP', :native, 'sem RTP: caminho original', 1) { |a| Buffers.c_string(a[0]).to_s }

    # Fangame DLLs replaced by Kerberus Ports. Direct calls mean the port did
    # not recognise the script, so the diagnostic names what to port.
    [['kleinbitmap', 'KleinBitmap: o script original nao foi reconhecido pelo port klein_bitmap',
      %w(add_outline compare_bitmap modify_color modify_pallete save_pallete scroll_up scroll_down
         scroll_left scroll_right set_pattern to_negative to_retro version)],
     ['gif', 'gif.dll: o script GifBitmap nao foi reconhecido pelo port gif_dll',
      %w(GifToPngFiles GifToPngFilesInMemory CopyDataString FreeDataString)],
     ['audio', 'audio.dll: o script AudioContext nao foi reconhecido pelo port audio_dll',
      %w(AudioContextInitialize AudioContextFree AudioContextPlay AudioContextSEPlay AudioContextStop
         AudioContextFadeIn AudioContextFadeOut AudioContextGetPosition AudioContextIsActive AudioContextSetVolume)],
     ['rgss_fmodex', 'FMOD: carregado apenas via RGSS Linker pelo port uranium.rgss_linker', %w(Init_FmodEx)]].each do |entry|
      entry[2].each { |name| provide(entry[0], name, :unavailable, entry[1], nil) }
    end

    # MGC_Hmode7.dll (H-Mode7 v1.2.1, Pokemon Insurgence): the eight exports
    # run natively (binding/kerberus/hm7-core.h, checked byte for byte
    # against the DLL). The game passes its objects by __id__.
    module HM7Bridge
      def self.object(id, what)
        ObjectSpace._id2ref(id.to_i)
      rescue RangeError
        raise ArgumentError, 'MGC_Hmode7: ' + what + ' nao existe mais (__id__ ' + id.to_s + ')'
      end

      def self.call(name, *args)
        unless defined?(::KerberusNative) && ::KerberusNative.respond_to?(name)
          raise WinBridge::Unavailable, "WINBRIDGE_UNAVAILABLE\nMGC_Hmode7: renderizador nativo ausente neste build (KerberusNative." + name.to_s + ')'
        end
        ::KerberusNative.send(name, *args)
      end
    end

    h = 'mgc_hmode7'
    native = 'H-Mode7 nativo (kerberus/hm7-core.h), identico a DLL'
    provide(h, 'renderHM7', :port, native + '; devolve a altura alvo da camera', 3) do |a|
      HM7Bridge.call(:hm7_render, HM7Bridge.object(a[0], 'params'), HM7Bridge.object(a[1], 'vars'),
                     HM7Bridge.object(a[2], 'render_surfaces'))
    end
    provide(h, 'computeM7', :port, native, 3) do |a|
      HM7Bridge.call(:hm7_compute_m7, HM7Bridge.object(a[0], 'computetable'), HM7Bridge.object(a[1], 'rowsdata'),
                     HM7Bridge.object(a[2], 'parameters'))
    end
    provide(h, 'drawMapTileset', :port, native, 5) do |a|
      HM7Bridge.call(:hm7_draw_map_tileset, HM7Bridge.object(a[0], 'map_tileset'), HM7Bridge.object(a[1], 'tileset'),
                     HM7Bridge.object(a[2], 'heightset'), HM7Bridge.object(a[3], 'tilemap_hash'),
                     HM7Bridge.object(a[4], 'auto_tilesets'))
    end
    provide(h, 'refreshMapTileset', :port, native, 4) do |a|
      HM7Bridge.call(:hm7_refresh_map_tileset, HM7Bridge.object(a[0], 'map_tileset'), HM7Bridge.object(a[1], 'tileset'),
                     HM7Bridge.object(a[2], 'tilemap_hash'), HM7Bridge.object(a[3], 'auto_tilesets'))
    end
    provide(h, 'drawTextureset', :port, native, 3) do |a|
      HM7Bridge.call(:hm7_draw_textureset, HM7Bridge.object(a[0], 'textures'), HM7Bridge.object(a[1], 'textureset'),
                     HM7Bridge.object(a[2], 'texture_auto'))
    end
    provide(h, 'drawHeightmap', :port, native, 4) do |a|
      HM7Bridge.call(:hm7_draw_heightmap, HM7Bridge.object(a[0], 'heightmap'), HM7Bridge.object(a[1], 'heightpattern'),
                     HM7Bridge.object(a[2], 'map_tileset'), HM7Bridge.object(a[3], 'tiletable'))
    end
    provide(h, 'applyLighting', :port, native, 1) { |a| HM7Bridge.call(:hm7_apply_lighting, HM7Bridge.object(a[0], 'heightmap')) }
    provide(h, 'applyOpacity', :port, native, 2) { |a| HM7Bridge.call(:hm7_apply_opacity, HM7Bridge.object(a[0], 'bitmap'), a[1].to_i) }

    provide('rubyscreen', 'TakeScreenshot', :port, 'Graphics.snap_to_bitmap + Bitmap#to_file (PNG, JPG ou BMP pela extensao)', 1) do |a|
      path = WinBridge.native_path(a[0], true)
      next 0 if path.nil?
      bitmap = KerberusLegacy18.native('Graphics', :snap_to_bitmap)
      begin
        bitmap.to_file(path)
      ensure
        bitmap.dispose if bitmap && !bitmap.disposed?
      end
      1
    end
    provide('rubyscreen', 'SwapRgb', :port, 'troca R/B em buffer BGRA Ruby', 2) do |a|
      size = a[1].to_i
      Buffers.need(a[0], size, true, 'SwapRgb')
      raise ArgumentError, 'SwapRgb: tamanho deve ser multiplo de 4' unless size % 4 == 0
      data = a[0]
      index = 0
      while index < size
        red = data[index]
        data[index] = data[index + 2]
        data[index + 2] = red
        index += 4
      end
      0
    end
  end
end

# ==== 54_extended.rb ====
# Kerberus WinBridge 6.4 - Win32 functions common in RPG Maker XP scripts
# that 6.3 did not answer. A game that called one of them stopped with
# WINBRIDGE_UNAVAILABLE. Each provider below either does the real thing on
# Android (time, strings, memory, clipboard, controller, registry...) or
# returns the documented Windows failure for something Android does not
# allow (process priority, network, external programs). No false success.
module KerberusLegacy18
  module WinBridge
    ERROR_NOT_SUPPORTED = 50 unless const_defined?(:ERROR_NOT_SUPPORTED)
    ERROR_INVALID_ADDRESS = 487 unless const_defined?(:ERROR_INVALID_ADDRESS)
    ERROR_INVALID_MENU_HANDLE = 1401 unless const_defined?(:ERROR_INVALID_MENU_HANDLE)
    ERROR_CLIPBOARD_NOT_OPEN = 1418 unless const_defined?(:ERROR_CLIPBOARD_NOT_OPEN)
    ERROR_INTERNET_NAME_NOT_RESOLVED = 12007 unless const_defined?(:ERROR_INTERNET_NAME_NOT_RESOLVED)
    STILL_ACTIVE = 259 unless const_defined?(:STILL_ACTIVE)

    # Pointer-returning string functions return their destination. A Ruby
    # String buffer has no address, so a non-NULL token marks success there.
    def self.destination(value)
      value.is_a?(Integer) ? value : 1
    end

    # Named kernel objects of this process (single-instance checks).
    module Named
      @objects = {}

      def self.reset!
        @objects = {}
      end

      def self.handle_for(kind, name, create)
        key = name.nil? ? nil : kind.to_s + ':' + name.to_s.downcase
        if key && @objects[key] && Handles.get(@objects[key], kind)
          WinBridge.last_error = ERROR_ALREADY_EXISTS
          return Handles.add(kind, key)
        end
        return WinBridge.failure(ERROR_FILE_NOT_FOUND, 0) unless create
        handle = Handles.add(kind, key)
        @objects[key] = handle if key
        WinBridge.success(handle)
      end
    end

    # C runtime rand/srand: the exact MSVCRT generator.
    module CRand
      @state = 1
      def self.srand(seed)
        @state = seed.to_i & 0xffffffff
      end
      def self.rand
        @state = (@state * 214013 + 2531011) & 0xffffffff
        (@state >> 16) & 0x7fff
      end
    end

    module Format
      DAYS = { 'pt' => %w(domingo segunda-feira terca-feira quarta-feira quinta-feira sexta-feira sabado),
               'es' => %w(domingo lunes martes miercoles jueves viernes sabado),
               'en' => %w(Sunday Monday Tuesday Wednesday Thursday Friday Saturday) }
      MONTHS = { 'pt' => %w(janeiro fevereiro marco abril maio junho julho agosto setembro outubro novembro dezembro),
                 'es' => %w(enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre),
                 'en' => %w(January February March April May June July August September October November December) }
      SHORT_DATE = { 'en' => 'M/d/yyyy' }
      LONG_DATE = { 'pt' => "dddd, d' de 'MMMM' de 'yyyy", 'es' => "dddd, d' de 'MMMM' de 'yyyy", 'en' => 'dddd, MMMM d, yyyy' }
      TIME = { 'en' => 'h:mm:ss tt' }

      def self.language
        lang = Locale.language
        DAYS[lang] ? lang : 'en'
      end

      # SYSTEMTIME (16 bytes) or the current local time.
      def self.time_from(value)
        return Time.now if Buffers.null?(value)
        fields = Memory.read(value, 16).unpack('v8')
        Time.local(fields[0], fields[1], fields[3], fields[4], fields[5], fields[6])
      end

      def self.systemtime(time)
        [time.year, time.month, time.wday, time.day, time.hour, time.min, time.sec, (time.usec / 1000)].pack('v8')
      end

      # Windows date/time pictures; text between single quotes is literal.
      def self.render(picture, time, flags)
        lang = language
        out = ''
        i = 0
        while i < picture.length
          c = picture[i, 1]
          if c == "'"
            close = picture.index("'", i + 1) || picture.length
            out << picture[i + 1...close]
            i = close + 1
            next
          end
          run = 1
          run += 1 while picture[i + run, 1] == c
          token = c * run
          out << case c
                 when 'd'
                   case run
                   when 1 then time.day.to_s
                   when 2 then format('%02d', time.day)
                   when 3 then DAYS[lang][time.wday][0, 3]
                   else DAYS[lang][time.wday]
                   end
                 when 'M'
                   case run
                   when 1 then time.month.to_s
                   when 2 then format('%02d', time.month)
                   when 3 then MONTHS[lang][time.month - 1][0, 3]
                   else MONTHS[lang][time.month - 1]
                   end
                 when 'y'
                   run <= 2 ? format('%02d', time.year % 100) : time.year.to_s
                 when 'h'
                   hour = time.hour % 12
                   hour = 12 if hour == 0
                   run == 1 ? hour.to_s : format('%02d', hour)
                 when 'H'
                   run == 1 ? time.hour.to_s : format('%02d', time.hour)
                 when 'm'
                   run == 1 ? time.min.to_s : format('%02d', time.min)
                 when 's'
                   (flags & 2) != 0 ? '' : (run == 1 ? time.sec.to_s : format('%02d', time.sec))
                 when 't'
                   (flags & 4) != 0 ? '' : (time.hour < 12 ? 'AM' : 'PM')[0, run]
                 else token
                 end
          i += run
        end
        out
      end

      def self.date(value, flags, picture)
        lang = language
        picture ||= (flags & 2) != 0 ? LONG_DATE[lang] : (SHORT_DATE[lang] || 'dd/MM/yyyy')
        render(picture, time_from(value), 0)
      end

      def self.clock(value, flags, picture)
        picture ||= (flags & 8) != 0 ? 'HH:mm:ss' : (TIME[language] || 'HH:mm:ss')
        picture = picture.sub(/[:.]?s+/, '') if (flags & 2) != 0
        render(picture, time_from(value), flags).strip
      end

      # C printf / wsprintf format with the Win32API argument list.
      def self.printf(fmt, args)
        index = 0
        fmt.gsub(/%([-+ #0]*)(\d*|\*)(?:\.(\d+))?(?:hh|h|ll|l|I64|I32)?([diouxXcsSfFeEgGp%])/) do
          flags = $1
          width = $2
          precision = $3
          type = $4
          next '%' if type == '%'
          if width == '*'
            width = args[index].to_i.to_s
            index += 1
          end
          value = args[index]
          index += 1
          spec = '%' + flags + width.to_s + (precision ? '.' + precision : '')
          case type
          when 's', 'S' then format(spec + 's', Buffers.c_string(value).to_s)
          when 'c' then format(spec + 'c', value.to_i & 0xff)
          when 'u' then format(spec + 'd', value.to_i & 0xffffffff)
          when 'i' then format(spec + 'd', WinBridge.to_i32(value.to_i))
          when 'p' then format('%08X', value.to_i & 0xffffffff)
          when 'f', 'F', 'e', 'E', 'g', 'G' then format(spec + type.downcase, value.to_f)
          else format(spec + type, value.to_i)
          end
        end
      end
    end

    module Clipboard
      @open = false
      def self.reset!
        @open = false
      end
      def self.open?
        @open
      end
      def self.open!(value)
        @open = value
      end
      def self.text
        KerberusLegacy18.native?('Input', :clipboard) ? KerberusLegacy18.native('Input', :clipboard).to_s : ''
      end
      def self.text=(value)
        KerberusLegacy18.native('Input', :clipboard=, value.to_s) if KerberusLegacy18.native?('Input', :clipboard=)
      end
    end

    k = 'kernel32'
    priority = 'prioridade gerida pelo Android; pedido recusado com ERROR_ACCESS_DENIED'
    provide(k, 'SetPriorityClass', :limited, priority, 2) { |a| WinBridge.failure(ERROR_ACCESS_DENIED, 0) }
    provide(k, 'SetThreadPriority', :limited, priority, 2) { |a| WinBridge.failure(ERROR_ACCESS_DENIED, 0) }
    provide(k, 'GetPriorityClass', :native, 'NORMAL_PRIORITY_CLASS', 1) { |a| WinBridge.success(0x20) }
    provide(k, 'GetThreadPriority', :native, 'THREAD_PRIORITY_NORMAL', 1) { |a| WinBridge.success(0) }
    @command_line = nil
    provide(k, 'GetCommandLineA', :native, 'linha de comando do executavel do jogo, sem argumentos', 0) do |a|
      @command_line ||= Memory.alloc('"' + KerberusLegacy18.config[:exec_name].to_s + '.exe"' + "\0")
    end
    @command_line_w = nil
    provide(k, 'GetCommandLineW', :native, 'linha de comando do executavel do jogo, sem argumentos', 0) do |a|
      @command_line_w ||= Memory.alloc_wide('"' + KerberusLegacy18.config[:exec_name].to_s + '.exe"')
    end
    provide(k, 'SetEnvironmentVariableA', :native, 'ambiente virtual do jogo (lido por GetEnvironmentVariable)', 2) do |a|
      name = Buffers.c_string(a[0]).to_s
      next WinBridge.failure(ERROR_INVALID_PARAMETER, 0) if name.empty? || name.index('=')
      Env.set(name, Buffers.null?(a[1]) ? nil : Buffers.c_string(a[1]))
      WinBridge.success(1)
    end
    provide(k, 'CreateMutexA', :native, 'objetos nomeados deste processo; ERROR_ALREADY_EXISTS na segunda criacao', 3) do |a|
      Named.handle_for(:mutex, Buffers.c_string(a[2]), true)
    end
    provide(k, 'OpenMutexA', :native, 'objetos nomeados deste processo', 3) { |a| Named.handle_for(:mutex, Buffers.c_string(a[2]), false) }
    provide(k, 'ReleaseMutex', :native, 'objetos nomeados deste processo', 1) do |a|
      Handles.kind(a[0]) == :mutex ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_HANDLE, 0)
    end
    provide(k, 'GetDiskFreeSpaceExA', :native, 'statvfs da pasta pedida (ou da pasta do jogo)', 4) do |a|
      path = Buffers.null?(a[0]) ? Dir.pwd : WinBridge.native_path(a[0], false)
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, 0) if path.nil? || !File.directory?(path)
      next WinBridge.failure(ERROR_NOT_SUPPORTED, 0) unless defined?(::KerberusNative) && ::KerberusNative.respond_to?(:disk_space)
      space = ::KerberusNative.disk_space(path)
      next WinBridge.failure(ERROR_NOT_SUPPORTED, 0) unless space
      Buffers.put(a[1], Buffers.pack_u64(space[0]), 0) unless Buffers.null?(a[1])
      Buffers.put(a[2], Buffers.pack_u64(space[1]), 0) unless Buffers.null?(a[2])
      Buffers.put(a[3], Buffers.pack_u64(space[2]), 0) unless Buffers.null?(a[3])
      WinBridge.success(1)
    end
    provide(k, 'lstrcpyA', :native, 'copia em buffer Ruby/heap virtual', 2) do |a|
      Memory.write(a[0], Buffers.c_string(a[1]).to_s + "\0")
      WinBridge.destination(a[0])
    end
    provide(k, 'lstrcpynA', :native, 'copia limitada em buffer Ruby/heap virtual', 3) do |a|
      count = a[2].to_i
      next WinBridge.destination(a[0]) if count <= 0
      Memory.write(a[0], Buffers.c_string(a[1]).to_s[0, count - 1] + "\0")
      WinBridge.destination(a[0])
    end
    provide(k, 'lstrcatA', :native, 'concatena em buffer Ruby/heap virtual', 2) do |a|
      Memory.write(a[0], Buffers.c_string(a[0]).to_s + Buffers.c_string(a[1]).to_s + "\0")
      WinBridge.destination(a[0])
    end
    compare = lambda do |left, right|
      left = left.to_s
      right = right.to_s
      left < right ? -1 : (left > right ? 1 : 0)
    end
    provide(k, 'lstrcmpA', :native, 'comparacao de bytes', 2) { |a| compare.call(Buffers.c_string(a[0]), Buffers.c_string(a[1])) }
    provide(k, 'lstrcmpiA', :native, 'comparacao sem diferenciar maiusculas (ASCII)', 2) do |a|
      compare.call(Buffers.c_string(a[0]).to_s.downcase, Buffers.c_string(a[1]).to_s.downcase)
    end
    provide(k, 'lstrcmpW', :native, 'comparacao de texto UTF-16', 2) { |a| compare.call(Buffers.wide_string(a[0]), Buffers.wide_string(a[1])) }
    provide(k, 'lstrcmpiW', :native, 'comparacao sem diferenciar maiusculas (ASCII)', 2) do |a|
      compare.call(Buffers.wide_string(a[0]).to_s.downcase, Buffers.wide_string(a[1]).to_s.downcase)
    end
    copy_path = lambda do |buffer, capacity, text|
      next WinBridge.success(text.length + 1) if capacity.to_i <= text.length
      Buffers.put(buffer, text + "\0", 0)
      WinBridge.success(text.length)
    end
    provide(k, 'GetShortPathNameA', :native, 'sem nomes 8.3: o caminho curto e o proprio caminho', 3) do |a|
      text = Buffers.c_string(a[0]).to_s
      path = WinBridge.native_path(a[0], false)
      next WinBridge.failure(ERROR_FILE_NOT_FOUND, 0) if path.nil? || !File.exist?(path)
      copy_path.call(a[1], a[2], text)
    end
    provide(k, 'GetFullPathNameA', :native, 'caminho absoluto a partir da pasta atual, separadores Windows', 4) do |a|
      text = Buffers.c_string(a[0]).to_s
      next WinBridge.failure(ERROR_INVALID_PARAMETER, 0) if text.empty?
      full = text =~ /\A[A-Za-z]:/ ? text.tr('/', '\\') : WinBridge.windows_path(File.expand_path(text.tr('\\', '/')))
      result = copy_path.call(a[2], a[1], full)
      unless Buffers.null?(a[3]) || result > full.length
        Buffers.put_u32(a[3], 0, 0)
      end
      result
    end
    provide(k, 'GetTempFileNameA', :native, 'arquivo temporario unico na pasta pedida', 4) do |a|
      directory = WinBridge.native_path(a[0], false)
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, 0) if directory.nil? || !File.directory?(directory)
      prefix = Buffers.c_string(a[1]).to_s[0, 3]
      unique = a[2].to_i & 0xffff
      number = unique == 0 ? (Time.now.to_i & 0xffff) : unique
      name = nil
      65536.times do
        number = 1 if number == 0
        name = File.join(directory, prefix + format('%X', number) + '.tmp')
        break unless unique == 0 && File.exist?(name)
        number = (number + 1) & 0xffff
      end
      File.open(name, 'wb') { |file| file.write('') } if unique == 0
      Buffers.put(a[3], WinBridge.windows_path(name) + "\0", 0)
      WinBridge.success(number)
    end
    provide(k, 'Beep', :limited, 'sem alto-falante de sistema; falha documentada', 2) { |a| WinBridge.failure(ERROR_NOT_SUPPORTED, 0) }
    provide(k, 'GetLocalTime', :native, 'hora local do aparelho', 1) { |a| Buffers.put(a[0], Format.systemtime(Time.now), 0); 0 }
    provide(k, 'GetSystemTime', :native, 'hora UTC do aparelho', 1) { |a| Buffers.put(a[0], Format.systemtime(Time.now.utc), 0); 0 }
    provide(k, 'GetTimeZoneInformation', :native, 'fuso do aparelho (Bias); horario de verao nao informado', 1) do |a|
      bias = -(Time.now.utc_offset / 60)
      name = Text.utf8_to_utf16le(Time.now.zone.to_s)[0, 62]
      name += "\0" * (64 - name.length)
      data = [bias].pack('l') + name + "\0" * 16 + [0].pack('l') + name + "\0" * 16 + [0].pack('l')
      Buffers.put(a[0], data, 0)
      WinBridge.success(0)
    end
    provide(k, 'GetLogicalDrives', :native, 'unidade virtual C:', 0) { |a| WinBridge.success(0x4) }
    provide(k, 'GetDriveTypeA', :native, 'C: fixa; demais letras inexistentes', 1) do |a|
      root = Buffers.c_string(a[0]).to_s
      root.empty? || root =~ /\A[Cc]:/ || root !~ /\A[A-Za-z]:/ ? 3 : 1
    end
    provide(k, 'GetVolumeInformationA', :native, 'volume virtual KERBERUS em C:', 8) do |a|
      root = Buffers.c_string(a[0]).to_s
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, 0) unless root.empty? || root =~ /\A[Cc]:/
      Buffers.copy_c_string(a[1], a[2].to_i, 'KERBERUS') unless Buffers.null?(a[1])
      Buffers.put_u32(a[3], 0x4B45524B, 0) unless Buffers.null?(a[3])
      Buffers.put_u32(a[4], 255, 0) unless Buffers.null?(a[4])
      Buffers.put_u32(a[5], 0x6, 0) unless Buffers.null?(a[5])
      Buffers.copy_c_string(a[6], a[7].to_i, 'NTFS') unless Buffers.null?(a[6])
      WinBridge.success(1)
    end
    provide(k, 'VirtualAlloc', :native, 'heap virtual (ate 64 KiB); endereco fixo pedido e recusado', 4) do |a|
      size = a[1].to_i
      next WinBridge.failure(ERROR_INVALID_ADDRESS, 0) unless Buffers.null?(a[0])
      next WinBridge.failure(ERROR_NOT_ENOUGH_MEMORY, 0) if size <= 0 || size > Memory::STEP
      WinBridge.success(Memory.alloc("\0" * size))
    end
    provide(k, 'VirtualFree', :native, 'heap virtual', 3) { |a| Memory.free(a[0]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_ADDRESS, 0) }
    provide(k, 'ExitProcess', :native, 'encerra o jogo', 1) do |a|
      KerberusLegacy18.event('EXIT', 'kernel32!ExitProcess', 'codigo ' + a[0].to_i.to_s, true)
      exit(a[0].to_i)
    end
    provide(k, 'TerminateProcess', :native, 'somente o proprio processo (pseudo-handle -1)', 2) do |a|
      next WinBridge.failure(ERROR_ACCESS_DENIED, 0) unless WinBridge.to_i32(a[0].to_i) == -1
      KerberusLegacy18.event('EXIT', 'kernel32!TerminateProcess', 'codigo ' + a[1].to_i.to_s, true)
      exit(a[1].to_i)
    end
    provide(k, 'GetExitCodeProcess', :native, 'proprio processo: STILL_ACTIVE', 2) do |a|
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless WinBridge.to_i32(a[0].to_i) == -1
      Buffers.put_u32(a[1], STILL_ACTIVE, 0)
      WinBridge.success(1)
    end
    date_or_time = lambda do |a, text|
      capacity = a[5].to_i
      next WinBridge.success(text.length + 1) if capacity == 0
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if capacity <= text.length
      Buffers.put(a[4], text + "\0", 0)
      WinBridge.success(text.length + 1)
    end
    provide(k, 'GetDateFormatA', :native, 'formatos de data do Windows no idioma do aparelho (pt/es/en)', 6) do |a|
      picture = Buffers.null?(a[3]) ? nil : Buffers.c_string(a[3])
      date_or_time.call(a, Format.date(a[2], a[1].to_i, picture))
    end
    provide(k, 'GetTimeFormatA', :native, 'formatos de hora do Windows no idioma do aparelho', 6) do |a|
      picture = Buffers.null?(a[3]) ? nil : Buffers.c_string(a[3])
      date_or_time.call(a, Format.clock(a[2], a[1].to_i, picture))
    end

    c = 'msvcrt'
    provide(c, 'memcpy', :native, 'copia entre buffers Ruby/heap virtual', 3) do |a|
      Memory.write(a[0], Memory.read(a[1], a[2].to_i))
      WinBridge.destination(a[0])
    end
    provide(c, 'memmove', :native, 'copia entre buffers Ruby/heap virtual', 3) do |a|
      Memory.write(a[0], Memory.read(a[1], a[2].to_i))
      WinBridge.destination(a[0])
    end
    provide(c, 'memset', :native, 'preenche buffer Ruby/heap virtual', 3) do |a|
      Memory.write(a[0], (a[1].to_i & 0xff).chr * a[2].to_i)
      WinBridge.destination(a[0])
    end
    provide(c, 'strlen', :native, 'strlen em buffer Ruby/heap virtual', 1) { |a| (Buffers.c_string(a[0]) || '').length }
    provide(c, 'sprintf', :native, 'formato C (d i u x X o c s f e g p)', 2) do |a|
      text = Format.printf(Buffers.c_string(a[1]).to_s, a[2..-1] || [])
      Memory.write(a[0], text + "\0")
      text.length
    end
    provide(c, 'rand', :native, 'gerador exato do MSVCRT', 0) { |a| CRand.rand }
    provide(c, 'srand', :native, 'gerador exato do MSVCRT', 1) { |a| CRand.srand(a[0]); 0 }
    provide(c, 'system', :limited, 'sem interpretador de comandos no Android', 1) { |a| Buffers.null?(a[0]) ? 0 : -1 }

    s = 'shell32'
    provide(s, 'ShellExecuteExA', :limited, 'abrir programas/URLs externos indisponivel', 1) do |a|
      Buffers.put_u32(a[0], 2, 32) if a[0].is_a?(String) && a[0].length >= 36
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(s, 'SHFileOperationA', :limited, 'estrutura com ponteiros reais; operacao recusada (DE_INVALIDFILES)', 1) { |a| 0x7C }
    provide(s, 'SHBrowseForFolderA', :limited, 'sem seletor de pastas: nenhuma pasta escolhida', 1) { |a| 0 }
    provide(s, 'DragAcceptFiles', :native, 'arrastar arquivos nao existe no Android', 2) { |a| 0 }
    provide(s, 'ExtractIconA', :limited, 'icones de executaveis nao sao extraidos', 3) { |a| 0 }

    u = 'user32'
    provide(u, 'MessageBoxW', :limited, 'mensagem RGSS nativa; botoes Sim/Nao retornam a opcao segura', 4) do |a|
      WinBridge.lookup('user32', 'MessageBoxA').impl.call([a[0], Buffers.wide_string(a[1]).to_s, Buffers.wide_string(a[2]).to_s, a[3]])
    end
    provide(u, 'EnumDisplaySettingsA', :native, 'um modo: resolucao do jogo, 32 bpp, 60 Hz', 3) do |a|
      mode = a[1].to_i & 0xffffffff
      next WinBridge.failure(ERROR_INVALID_PARAMETER, 0) unless mode == 0 || mode == 0xffffffff || mode == 0xfffffffe
      Buffers.need(a[2], 124, true, 'DEVMODE')
      Buffers.put(a[2], [156].pack('v'), 36)
      Buffers.put(a[2], [0x40000 | 0x80000 | 0x100000 | 0x400000].pack('V'), 40)
      Buffers.put(a[2], [32, Window.width, Window.height, 0, 60].pack('V5'), 104)
      WinBridge.success(1)
    end
    provide(u, 'ChangeDisplaySettingsA', :limited, 'apenas o modo atual (resolucao do jogo) e aceito', 2) do |a|
      next 0 if Buffers.null?(a[0])
      fields = Buffers.u32(a[0], 40)
      width = (fields & 0x80000) != 0 ? Buffers.u32(a[0], 108) : Window.width
      height = (fields & 0x100000) != 0 ? Buffers.u32(a[0], 112) : Window.height
      width == Window.width && height == Window.height ? 0 : -2
    end
    cursor = { :current => 0x00C1C000 }
    provide(u, 'LoadCursorA', :native, 'cursores do sistema como handles virtuais', 2) do |a|
      Buffers.null?(a[0]) && a[1].is_a?(Integer) ? WinBridge.success(0x00C1C000 + (a[1].to_i & 0xffff)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(u, 'LoadCursorFromFileA', :native, 'arquivo de cursor existente vira handle virtual', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      path && File.file?(path) ? WinBridge.success(0x00C1D000 + (path.hash & 0xfff)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(u, 'SetCursor', :limited, 'sem cursor visivel no Android; handle anterior devolvido', 1) do |a|
      previous = cursor[:current]
      cursor[:current] = a[0].to_i
      previous
    end
    provide(u, 'DestroyIcon', :native, 'handles virtuais', 1) { |a| WinBridge.success(1) }
    provide(u, 'LoadImageA', :native, 'arquivo existente ou recurso do sistema vira handle virtual', 6) do |a|
      if (a[5].to_i & 0x10) != 0
        path = WinBridge.native_path(a[1], false)
        next path && File.file?(path) ? WinBridge.success(0x00C1E000 + (path.hash & 0xfff)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
      end
      Buffers.null?(a[0]) && a[1].is_a?(Integer) ? WinBridge.success(0x00C1F000 + (a[1].to_i & 0xfff)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    key_names = { 0x08 => 'Backspace', 0x09 => 'Tab', 0x0D => 'Enter', 0x10 => 'Shift', 0x11 => 'Ctrl', 0x12 => 'Alt',
                  0x14 => 'Caps Lock', 0x1B => 'Esc', 0x20 => 'Space', 0x21 => 'Page Up', 0x22 => 'Page Down',
                  0x23 => 'End', 0x24 => 'Home', 0x25 => 'Left', 0x26 => 'Up', 0x27 => 'Right', 0x28 => 'Down',
                  0x2D => 'Insert', 0x2E => 'Delete', 0x90 => 'Num Lock', 0x91 => 'Scroll Lock' }
    provide(u, 'GetKeyNameTextA', :native, 'nomes de teclas do layout US', 3) do |a|
      scan = (a[0].to_i >> 16) & 0xff
      vk = InputBridge::VK_FROM_SCAN[scan]
      name = vk.nil? ? '' : (key_names[vk] || (vk >= 0x70 && vk <= 0x7B ? 'F' + (vk - 0x6F).to_s : (vk >= 0x30 && vk <= 0x5A ? vk.chr : '')))
      name.empty? ? WinBridge.failure(ERROR_INVALID_PARAMETER, 0) : WinBridge.success(Buffers.copy_c_string(a[1], a[2].to_i, name))
    end
    provide(u, ['DefWindowProcA', 'CallWindowProcA'], :limited, 'sem procedimento de janela Win32', 4) { |a| 0 }
    provide(u, 'GetMenu', :native, 'a janela do jogo nao tem menu', 1) { |a| WinBridge.success(0) }
    provide(u, 'SetMenu', :native, 'a janela do jogo nao tem menu', 2) { |a| Buffers.null?(a[1]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_MENU_HANDLE, 0) }
    provide(u, 'DrawMenuBar', :native, 'a janela do jogo nao tem menu', 1) { |a| Window.handle?(a[0]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) }
    provide(u, 'GetSystemMenu', :native, 'a janela do jogo nao tem menu de sistema', 2) { |a| WinBridge.success(0) }
    provide(u, 'GetParent', :native, 'janela de nivel superior', 1) { |a| WinBridge.success(0) }
    provide(u, 'GetWindowPlacement', :native, 'janela logica normal na resolucao do jogo', 2) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      Buffers.put(a[1], [44, 0, 1, -1, -1, -1, -1, 0, 0, Window.width, Window.height].pack('V3l8'), 0)
      WinBridge.success(1)
    end
    provide(u, 'SetWindowPlacement', :limited, 'superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada', 2) do |a|
      Window.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0)
    end
    sys_colors = [0xC8C8C8, 0x000000, 0xD1B499, 0xDBCDBF, 0xF0F0F0, 0xFFFFFF, 0x646464, 0x000000, 0x000000, 0x000000,
                  0xB4B4B4, 0xFCF7F4, 0xABABAB, 0xD77800, 0xFFFFFF, 0xF0F0F0, 0xA0A0A0, 0x6D6D6D, 0x000000, 0x000000,
                  0xFFFFFF, 0x696969, 0xE3E3E3, 0x000000, 0xE1FFFF, 0x000000, 0xCC6600, 0xEAD1B9, 0xF2E4D7, 0xFF9933, 0xF0F0F0]
    provide(u, 'GetSysColor', :native, 'cores padrao do Windows 10', 1) { |a| sys_colors[a[0].to_i] || 0 }
    provide(u, 'WindowFromPoint', :native, 'janela logica dentro da resolucao do jogo', 2) do |a|
      x = WinBridge.to_i32(a[0].to_i)
      y = WinBridge.to_i32(a[1].to_i)
      x >= 0 && y >= 0 && x < Window.width && y < Window.height ? Window::HWND : Window::DESKTOP
    end
    provide(u, ['TranslateMessage', 'DispatchMessageA'], :native, 'fila Win32 sempre vazia no Android', 1) { |a| 0 }
    enabled = { :value => true }
    provide(u, 'EnableWindow', :native, 'estado habilitado da janela logica', 2) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      was_disabled = !enabled[:value]
      enabled[:value] = !(a[1].nil? || a[1] == 0 || a[1] == false)
      was_disabled ? 1 : 0
    end
    provide(u, 'IsWindowEnabled', :native, 'estado habilitado da janela logica', 1) { |a| Window.handle?(a[0]) && enabled[:value] ? 1 : 0 }
    case_map = lambda do |a, method|
      value = a[0]
      if value.is_a?(Integer) && (value & 0xffff0000) == 0
        char = (value & 0xff).chr
        mapped = method == :upcase ? char.upcase : char.downcase
        next mapped[0]
      end
      text = Buffers.c_string(value).to_s
      Memory.write(value, (method == :upcase ? text.upcase : text.downcase))
      WinBridge.destination(value)
    end
    provide(u, 'CharUpperA', :native, 'maiusculas ASCII no buffer ou caractere', 1) { |a| case_map.call(a, :upcase) }
    provide(u, 'CharLowerA', :native, 'minusculas ASCII no buffer ou caractere', 1) { |a| case_map.call(a, :downcase) }
    provide(u, 'wsprintfA', :native, 'formato C (d i u x X c s p)', 2) do |a|
      text = Format.printf(Buffers.c_string(a[1]).to_s, a[2..-1] || [])[0, 1023]
      Memory.write(a[0], text + "\0")
      text.length
    end
    class_longs = { -12 => 0x00C1C000 + 32512 }
    provide(u, 'GetClassLongA', :native, 'dados de classe da janela logica', 2) do |a|
      Window.handle?(a[0]) ? (class_longs[WinBridge.to_i32(a[1].to_i)] || 0) : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0)
    end
    provide(u, 'SetClassLongA', :native, 'dados de classe da janela logica', 3) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      index = WinBridge.to_i32(a[1].to_i)
      previous = class_longs[index] || 0
      class_longs[index] = a[2].to_i
      previous
    end
    provide(u, 'SetKeyboardState', :limited, 'o estado das teclas vem do SDL e nao pode ser escrito', 1) { |a| WinBridge.failure(ERROR_NOT_SUPPORTED, 0) }
    provide(u, 'OpenClipboard', :native, 'area de transferencia do Android', 1) { |a| Clipboard.open!(true); WinBridge.success(1) }
    provide(u, 'CloseClipboard', :native, 'area de transferencia do Android', 0) do |a|
      next WinBridge.failure(ERROR_CLIPBOARD_NOT_OPEN, 0) unless Clipboard.open?
      Clipboard.open!(false)
      WinBridge.success(1)
    end
    provide(u, 'EmptyClipboard', :native, 'area de transferencia do Android', 0) do |a|
      next WinBridge.failure(ERROR_CLIPBOARD_NOT_OPEN, 0) unless Clipboard.open?
      Clipboard.text = ''
      WinBridge.success(1)
    end
    provide(u, 'IsClipboardFormatAvailable', :native, 'texto da area de transferencia do Android', 1) do |a|
      [1, 7, 13].include?(a[0].to_i) && !Clipboard.text.empty? ? 1 : 0
    end
    provide(u, 'GetClipboardData', :native, 'CF_TEXT/CF_UNICODETEXT em bloco do heap virtual', 1) do |a|
      next WinBridge.failure(ERROR_CLIPBOARD_NOT_OPEN, 0) unless Clipboard.open?
      text = Clipboard.text
      case a[0].to_i
      when 1, 7 then WinBridge.success(Memory.alloc(Text.utf8_to_cp1252(text, '?')[0][0, Memory::STEP - 1] + "\0"))
      when 13 then WinBridge.success(Memory.alloc_wide(text[0, Memory::STEP / 2 - 1]))
      else WinBridge.failure(ERROR_NOT_SUPPORTED, 0)
      end
    end
    provide(u, 'SetClipboardData', :native, 'CF_TEXT/CF_UNICODETEXT de bloco do heap virtual', 2) do |a|
      next WinBridge.failure(ERROR_CLIPBOARD_NOT_OPEN, 0) unless Clipboard.open?
      case a[0].to_i
      when 1, 7 then Clipboard.text = Text.cp1252_to_utf8(Buffers.c_string(a[1]).to_s)
      when 13 then Clipboard.text = Buffers.wide_string(a[1]).to_s
      else next WinBridge.failure(ERROR_NOT_SUPPORTED, 0)
      end
      WinBridge.success(a[1])
    end
    provide(u, 'SetTimer', :limited, 'timers Win32 dependem de fila de mensagens; recusado', 4) { |a| WinBridge.failure(ERROR_NOT_SUPPORTED, 0) }
    provide(u, 'KillTimer', :limited, 'nenhum timer Win32 e criado', 2) { |a| WinBridge.failure(ERROR_INVALID_PARAMETER, 0) }
    provide(u, 'FlashWindow', :limited, 'a janela do jogo ja esta ativa; sem piscar', 2) { |a| Window.handle?(a[0]) ? 1 : 0 }
    provide(u, 'MessageBeep', :limited, 'sem sons de sistema; falha documentada', 1) { |a| WinBridge.failure(ERROR_NOT_SUPPORTED, 0) }

    g = 'gdi32'
    provide(g, 'GetStockObject', :native, 'objetos de estoque como handles virtuais', 1) do |a|
      index = a[0].to_i
      index >= 0 && index <= 19 ? WinBridge.success(0x01900000 + index) : WinBridge.failure(ERROR_INVALID_PARAMETER, 0)
    end
    provide(g, 'DeleteDC', :native, 'DCs virtuais', 1) { |a| Buffers.null?(a[0]) ? WinBridge.failure(ERROR_INVALID_HANDLE, 0) : WinBridge.success(1) }
    snapshot = { :frame => nil, :bitmap => nil }
    provide(g, 'GetPixel', :native, 'pixel da tela do jogo (Graphics.snap_to_bitmap, uma captura por quadro)', 3) do |a|
      x = WinBridge.to_i32(a[1].to_i)
      y = WinBridge.to_i32(a[2].to_i)
      next 0xffffffff unless a[0].to_i == Window::DC && x >= 0 && y >= 0 && x < Window.width && y < Window.height
      next 0xffffffff unless KerberusLegacy18.native?('Graphics', :snap_to_bitmap)
      frame = InputBridge.frame
      if snapshot[:frame] != frame || snapshot[:bitmap].nil? || snapshot[:bitmap].disposed?
        snapshot[:bitmap].dispose if snapshot[:bitmap] && !snapshot[:bitmap].disposed?
        snapshot[:bitmap] = KerberusLegacy18.native('Graphics', :snap_to_bitmap)
        snapshot[:frame] = frame
      end
      color = snapshot[:bitmap].get_pixel(x, y)
      color.red.to_i | (color.green.to_i << 8) | (color.blue.to_i << 16)
    end
    provide(g, 'SetPixel', :limited, 'a tela do jogo nao aceita desenho GDI; CLR_INVALID', 4) { |a| 0xffffffff }

    w = 'winmm'
    # JOYINFOEX from the SDL game controller mkxp-z opened (player 0).
    joy_buttons = [[0, 0x1], [1, 0x2], [2, 0x4], [3, 0x8], [9, 0x10], [10, 0x20], [4, 0x40], [6, 0x80], [7, 0x100], [8, 0x200]]
    joy_state = lambda do
      next nil unless InputBridge.controller_connected?
      pad = InputBridge.xinput_pad
      mask = 0
      bits = pad[0]
      xmap = { 0x1000 => 0, 0x2000 => 1, 0x4000 => 2, 0x8000 => 3, 0x0100 => 9, 0x0200 => 10, 0x0020 => 4, 0x0010 => 6, 0x0040 => 7, 0x0080 => 8 }
      xmap.each { |bit, sdl| mask |= (joy_buttons.assoc(sdl) || [0, 0])[1] if (bits & bit) != 0 }
      pov = 0xffff
      pov = 0 if (bits & 0x1) != 0
      pov = 9000 if (bits & 0x8) != 0
      pov = 18000 if (bits & 0x2) != 0
      pov = 27000 if (bits & 0x4) != 0
      axis = lambda { |value, invert| v = invert ? -value : value; ((v + 32768) & 0xffff) }
      [axis.call(pad[3], false), axis.call(pad[4], true), (pad[1] * 257) & 0xffff, axis.call(pad[5], false), axis.call(pad[6], true), (pad[2] * 257) & 0xffff, mask, pov]
    end
    provide(w, 'joyGetNumDevs', :native, '16 posicoes de joystick, como o driver do Windows', 0) { |a| 16 }
    provide(w, 'joyGetPosEx', :native, 'controle SDL do jogador 0', 2) do |a|
      next 165 unless a[0].to_i == 0
      state = joy_state.call
      next 167 if state.nil?
      Buffers.need(a[1], 52, true, 'JOYINFOEX')
      count = 0
      10.times { |bit| count += 1 if (state[6] >> bit) & 1 == 1 }
      Buffers.put(a[1], [state[0], state[1], state[2], state[3], state[4], state[5], state[6], count, state[7]].pack('V9'), 8)
      0
    end
    provide(w, 'joyGetPos', :native, 'controle SDL do jogador 0', 2) do |a|
      next 165 unless a[0].to_i == 0
      state = joy_state.call
      next 167 if state.nil?
      Buffers.put(a[1], [state[0], state[1], state[2], state[6] & 0xf].pack('V4'), 0)
      0
    end
    provide(w, 'joyGetDevCapsA', :native, 'controle SDL como gamepad de 10 botoes e 6 eixos', 3) do |a|
      next 165 unless a[0].to_i == 0
      next 167 unless InputBridge.controller_connected?
      name = 'Kerberus Gamepad'
      caps = [0x045E, 0x028E].pack('vv') + name + "\0" * (32 - name.length) +
             [0, 65535, 0, 65535, 0, 65535, 10, 10, 1000, 0, 65535, 0, 65535, 0, 65535, 0x1F, 6, 6, 10].pack('V19') + "\0" * 292
      Buffers.put(a[1], caps[0, [a[2].to_i, caps.length].min], 0)
      0
    end

    n = 'wininet'
    offline = 'rede desativada no Kerberus (mesma politica do Winsock): sem conexao'
    provide(n, 'InternetGetConnectedState', :limited, offline, 2) do |a|
      Buffers.put_u32(a[0], 0x20, 0) unless Buffers.null?(a[0])
      0
    end
    provide(n, 'InternetOpenA', :limited, offline, 5) { |a| WinBridge.success(Handles.add(:internet, nil)) }
    provide(n, 'InternetOpenUrlA', :limited, offline, 6) { |a| WinBridge.failure(ERROR_INTERNET_NAME_NOT_RESOLVED, 0) }
    provide(n, 'InternetReadFile', :limited, offline, 4) { |a| WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(n, 'InternetCloseHandle', :limited, offline, 1) do |a|
      Handles.kind(a[0]) == :internet && Handles.close(a[0]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_HANDLE, 0)
    end
    provide('urlmon', 'URLDownloadToFileA', :limited, offline, 5) { |a| WinBridge.to_i32(0x800C0005) }

    provide('ntdll', 'RtlZeroMemory', :native, 'zera buffer Ruby/heap virtual', 2) { |a| Memory.write(a[0], "\0" * a[1].to_i); 0 }
    provide('psapi', 'GetProcessMemoryInfo', :native, 'memoria real do processo (/proc/self/status)', 3) do |a|
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless WinBridge.to_i32(a[0].to_i) == -1
      status = KerberusLegacy18.raw_file?('/proc/self/status') ? KerberusLegacy18.raw_read('/proc/self/status') : ''
      field = lambda { |key| status =~ /^#{key}:\s+(\d+)\s+kB/ ? [$1.to_i * 1024, 0xffffffff].min : 0 }
      data = [40, 0, field.call('VmHWM'), field.call('VmRSS'), 0, 0, 0, 0, field.call('VmSize'), field.call('VmPeak')].pack('V10')
      Buffers.put(a[1], data[0, [a[2].to_i, 40].min], 0)
      WinBridge.success(1)
    end
    provide('advapi32', 'RegEnumKeyExA', :native, 'subchaves do registro virtual', 8) { |a| Registry.enum_key(a[0], a[1].to_i, a[2], a[3]) }
  end
end

# ==== 80_filesystem.rb ====
# Kerberus Paths - Windows-like path semantics for Ruby-level file APIs.
#
# mkxp-z already resolves RGSS loads (Bitmap, Audio, load_data, RGSSAD)
# through PhysFS. Scripts that use File/Dir/IO directly hit the Android
# filesystem, which is case-sensitive and does not know "\". Here:
#   * the exact path is always tried first (one stat on the fast path);
#   * only on a miss, "\" becomes "/" and every component is matched
#     case-insensitively against a cached directory index;
#   * writes to a name that exists with another case reuse that file,
#     like NTFS, instead of creating a duplicate.
# Game files are never renamed or copied.
module KerberusLegacy18
  module Paths
    MISS_LIMIT = 2048
    @dirs = {}
    @miss = {}
    @installed = false

    def self.reset!
      @dirs = {}
      @miss = {}
    end

    def self.installed?
      @installed
    end

    def self.raw_exist?(path)
      @installed ? File.kerberus_raw_exist?(path) : File.exist?(path)
    end

    def self.raw_directory?(path)
      @installed ? File.kerberus_raw_directory?(path) : File.directory?(path)
    end

    def self.raw_entries(path)
      @installed ? Dir.kerberus_raw_entries(path) : Dir.entries(path)
    end

    def self.invalidate(path)
      @miss.clear unless @miss.empty?
      return unless path.is_a?(String)
      directory = File.dirname(path.tr('\\', '/'))
      @dirs.delete(directory)
      @dirs.delete('.') if directory == '.'
    end

    def self.clear_misses
      @miss.clear unless @miss.empty?
    end

    def self.resolve(path, create)
      return path unless path.is_a?(String) && !path.empty?
      text = path.index('\\') ? path.tr('\\', '/') : path
      return text if raw_exist?(text)
      return text if !create && @miss[text]
      found = walk(text, create)
      return found if found
      @miss.clear if @miss.size >= MISS_LIMIT
      @miss[text] = true unless create
      text
    end

    def self.join(base, part)
      return part if base == '.'
      return '/' + part if base == '/'
      base + '/' + part
    end

    def self.walk(text, create)
      absolute = text[0, 1] == '/'
      parts = text.split('/').reject { |part| part.empty? }
      return nil if parts.empty?
      base = absolute ? '/' : '.'
      parts.each_with_index do |part, index|
        candidate = join(base, part)
        if part == '.' || part == '..' || raw_exist?(candidate)
          base = candidate
          next
        end
        actual = lookup(base, part)
        if actual
          base = join(base, actual)
        elsif create && index == parts.length - 1
          base = candidate
        else
          return nil
        end
      end
      base
    end

    def self.lookup(directory, name)
      index = directory_index(directory)
      index ? index[name.downcase] : nil
    end

    def self.directory_index(directory)
      return nil unless raw_directory?(directory)
      stamp = File.mtime(directory).to_i
      cached = @dirs[directory]
      return cached[1] if cached && cached[0] == stamp
      index = {}
      raw_entries(directory).sort.each do |entry|
        next if entry == '.' || entry == '..'
        key = entry.downcase
        index[key] = entry unless index.has_key?(key)
      end
      @dirs.clear if @dirs.size >= 256
      @dirs[directory] = [stamp, index]
      index
    end

    def self.write_mode?(mode)
      if mode.is_a?(String)
        mode.index('w') || mode.index('a') || mode.index('+') ? true : false
      elsif mode.is_a?(Integer)
        (mode & (File::WRONLY | File::RDWR | File::CREAT | File::APPEND)) != 0
      else
        false
      end
    end

    # A write to a save-like file is evidence for the SAVE milestone.
    def self.written(path)
      invalidate(path)
      Milestones.save_candidate(path) if defined?(Milestones)
    end

    # ------------------------------------------------------------------
    # Wrappers. Predicates retry only when the raw answer is negative;
    # raising methods retry only on ENOENT/ENOTDIR.
    # ------------------------------------------------------------------
    PREDICATES = %w(exist? exists? file? directory? readable? writable? executable? size? zero?)
    RAISING = %w(size mtime atime ctime stat lstat ftype readlines read foreach)
    MUTATING = %w(delete unlink)

    def self.raw_name(name)
      'kerberus_paths_' + name.sub('?', '').sub('[]', 'index') + (name[-1, 1] == '?' ? '?' : '')
    end

    def self.wrap_predicate(owner, name)
      raw = raw_name(name)
      return if owner.method_defined?(raw) || !owner.method_defined?(name)
      owner.send(:alias_method, raw, name)
      owner.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        def #{name}(path, *rest)
          value = #{raw}(path, *rest)
          return value if value || !path.is_a?(String)
          fixed = KerberusLegacy18::Paths.resolve(path, false)
          fixed == path ? value : #{raw}(fixed, *rest)
        end
      RUBY
    end

    def self.wrap_raising(owner, name, mutating)
      raw = raw_name(name)
      return if owner.method_defined?(raw) || !owner.method_defined?(name)
      owner.send(:alias_method, raw, name)
      after = mutating ? 'KerberusLegacy18::Paths.invalidate(path)' : ''
      owner.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        def #{name}(path, *rest, &block)
          begin
            result = #{raw}(path, *rest, &block)
            #{after}
            result
          rescue Errno::ENOENT, Errno::ENOTDIR
            raise unless path.is_a?(String)
            fixed = KerberusLegacy18::Paths.resolve(path, false)
            raise if fixed == path
            result = #{raw}(fixed, *rest, &block)
            #{mutating ? 'KerberusLegacy18::Paths.invalidate(fixed)' : ''}
            result
          end
        end
      RUBY
    end

    def self.install
      return false if @installed
      file_meta = KerberusLegacy18.meta(File)
      filetest_meta = KerberusLegacy18.meta(FileTest)
      io_meta = KerberusLegacy18.meta(IO)
      dir_meta = KerberusLegacy18.meta(Dir)

      # Raw helpers used by Kerberus itself (never resolved, never logged).
      file_meta.send(:alias_method, :kerberus_raw_exist?, :exist?)
      file_meta.send(:alias_method, :kerberus_raw_file?, :file?)
      file_meta.send(:alias_method, :kerberus_raw_directory?, :directory?)
      file_meta.send(:alias_method, :kerberus_raw_size, :size)
      dir_meta.send(:alias_method, :kerberus_raw_entries, :entries)

      PREDICATES.each do |name|
        wrap_predicate(file_meta, name)
        wrap_predicate(filetest_meta, name)
      end
      %w(size mtime atime ctime stat lstat ftype).each { |name| wrap_raising(file_meta, name, false) }
      wrap_raising(filetest_meta, 'size', false)
      %w(read readlines foreach).each { |name| wrap_raising(io_meta, name, false) }
      MUTATING.each { |name| wrap_raising(file_meta, name, true) }
      %w(entries foreach rmdir delete unlink).each { |name| wrap_raising(dir_meta, name, %w(rmdir delete unlink).include?(name)) }

      File.class_eval(<<-RUBY, 'Kerberus Paths', 1)
        alias_method :kerberus_raw_initialize, :initialize
        def initialize(path, *rest, &block)
          if path.is_a?(String)
            if KerberusLegacy18::Paths.write_mode?(rest[0])
              path = KerberusLegacy18::Paths.resolve(path, true)
              kerberus_raw_initialize(path, *rest, &block)
              KerberusLegacy18::Paths.written(path)
              return
            end
            # Ruby 1.8 cannot re-run File#initialize after a failed open
            # ("reinitializing File"), so resolve before opening.
            path = KerberusLegacy18::Paths.resolve(path, false) unless File.kerberus_raw_exist?(path)
          end
          kerberus_raw_initialize(path, *rest, &block)
        end
      RUBY
      file_meta.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        def kerberus_raw_open(path, mode)
          file = allocate
          file.send(:kerberus_raw_initialize, path, mode)
          file
        end

        alias_method :kerberus_raw_rename, :rename
        def rename(from, to)
          source = from.is_a?(String) ? KerberusLegacy18::Paths.resolve(from, false) : from
          target = to.is_a?(String) ? KerberusLegacy18::Paths.resolve(to, true) : to
          result = kerberus_raw_rename(source, target)
          KerberusLegacy18::Paths.invalidate(source)
          KerberusLegacy18::Paths.written(target)
          result
        end
      RUBY
      Dir.class_eval(<<-RUBY, 'Kerberus Paths', 1)
        alias_method :kerberus_raw_initialize, :initialize
        def initialize(path, *rest)
          path = KerberusLegacy18::Paths.resolve(path, false) if path.is_a?(String) && !File.kerberus_raw_directory?(path)
          kerberus_raw_initialize(path, *rest)
        end
      RUBY
      dir_meta.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        alias_method :kerberus_raw_mkdir, :mkdir
        def mkdir(path, *rest)
          target = path.is_a?(String) ? KerberusLegacy18::Paths.resolve(path, true) : path
          result = kerberus_raw_mkdir(target, *rest)
          KerberusLegacy18::Paths.invalidate(target)
          result
        end

        alias_method :kerberus_raw_chdir, :chdir
        def chdir(*args, &block)
          if args[0].is_a?(String) && !kerberus_raw_exist_dir?(args[0])
            args[0] = KerberusLegacy18::Paths.resolve(args[0], false)
          end
          # Caches hold relative paths: they belong to one working directory.
          KerberusLegacy18::Paths.reset!
          return kerberus_raw_chdir(*args) unless block
          begin
            kerberus_raw_chdir(*args) do |path|
              KerberusLegacy18::Paths.reset!
              block.call(path)
            end
          ensure
            KerberusLegacy18::Paths.reset!
          end
        end

        def kerberus_raw_exist_dir?(path)
          File.kerberus_raw_directory?(path)
        end

        alias_method :kerberus_raw_glob, :glob
        def glob(pattern, *rest, &block)
          result = kerberus_raw_glob(pattern, *rest)
          if result.empty? && pattern.is_a?(String)
            fixed = KerberusLegacy18::Paths.glob_pattern(pattern)
            flags = (rest[0] || 0) | File::FNM_CASEFOLD
            result = kerberus_raw_glob(fixed, flags) if fixed
          end
          return result unless block
          result.each { |item| block.call(item) }
          nil
        end

        alias_method :kerberus_raw_index, :[]
        def [](*patterns)
          result = []
          patterns.each { |pattern| result.concat(glob(pattern)) }
          result
        end
      RUBY
      Kernel.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        alias_method :kerberus_raw_load, :load
        def load(path, *rest)
          begin
            kerberus_raw_load(path, *rest)
          rescue LoadError
            raise unless path.is_a?(String)
            fixed = KerberusLegacy18::Paths.resolve(path, false)
            raise if fixed == path
            kerberus_raw_load(fixed, *rest)
          end
        end
        module_function :load
      RUBY
      if Kernel.private_method_defined?(:save_data) || Kernel.method_defined?(:save_data)
        Kernel.module_eval(<<-RUBY, 'Kerberus Paths', 1)
          alias_method :kerberus_raw_save_data, :save_data
          def save_data(object, path)
            target = path.is_a?(String) ? KerberusLegacy18::Paths.resolve(path, true) : path
            result = kerberus_raw_save_data(object, target)
            KerberusLegacy18::Paths.written(target)
            result
          end
          module_function :save_data
        RUBY
      end
      @installed = true
      KerberusLegacy18.event('FILESYSTEM', 'Paths', 'caminhos estilo Windows (\\ e maiusculas/minusculas) para File/Dir/IO')
      true
    end

    # Resolves the literal directory prefix of a glob pattern.
    def self.glob_pattern(pattern)
      text = pattern.tr('\\', '/')
      wild = text.index(/[\*\?\[\{]/)
      return (text == pattern ? nil : text) unless wild
      slash = text.rindex('/', wild)
      return text == pattern ? nil : text unless slash
      prefix = resolve(text[0, slash], false)
      prefix + text[slash, text.length - slash]
    end
  end
end

# ==== 83_winenv.rb ====
# Kerberus - Windows process environment and files created while the game
# runs (6.4.2).
#
# RGSS1 games run as Windows processes: ENV["TEMP"], ENV["APPDATA"] ... exist,
# and a file the game writes can be opened with Bitmap.new at once. On Android
# neither holds:
#  * ENV has no Windows variables. Pokemon Essentials v16/v17 builds paths
#    with ENV["TEMP"]+"\\tempscreen.bmp" (Sprite_Resizer, audio recording,
#    GIF frames), which stops the game with NoMethodError on nil (Pokemon
#    Uranium, title screen).
#  * mkxp-z resolves Bitmap.new through a path cache built when the game
#    starts; a file created later is "No such file or directory".
# WinEnv.install gives the process the Windows variables it lacks, pointing
# at real writable folders inside the game (.kerberus/...); a variable that
# already exists is never changed. Bitmap.new retries once, after reloading
# the engine's path cache, only when the file really exists on disk; a path
# inside the game folder given as absolute is retried as relative. A missing
# file still raises the original error.
module KerberusLegacy18
  module WinEnv
    # HOME is not a Windows variable, but the Ruby 1.8 of RGSS1 falls back to
    # USERPROFILE for File.expand_path("~"); Linux Ruby reads only HOME.
    FOLDERS = [['TEMP', 'temp'], ['TMP', 'temp'], ['APPDATA', 'appdata/Roaming'],
               ['LOCALAPPDATA', 'appdata/Local'], ['USERPROFILE', 'profile'], ['HOME', 'profile']]
    VALUES = [['USERNAME', 'Player'], ['COMPUTERNAME', 'KERBERUS'], ['OS', 'Windows_NT']]
    IMAGE_EXTENSIONS = ['', '.png', '.jpg', '.jpeg', '.bmp', '.gif']

    @installed = []
    @reloaded = {}
    class << self
      attr_reader :installed
    end

    def self.root
      File.join(Dir.pwd, '.kerberus')
    end

    def self.install
      return @installed unless @installed.empty?
      FOLDERS.each do |name, folder|
        next if present?(name)
        path = File.join(root, folder)
        begin
          KerberusLegacy18.ensure_dir(path)
        rescue SystemCallError => error
          KerberusLegacy18.event('WINENV_FAILED', name, path + ': ' + error.message, true)
          next
        end
        ENV[name] = path
        @installed << name
      end
      VALUES.each do |name, value|
        next if present?(name)
        ENV[name] = value
        @installed << name
      end
      @installed.each { |name| WinBridge::Env.set(name, ENV[name]) } if defined?(WinBridge::Env)
      unless @installed.empty?
        KerberusLegacy18.event('WINENV', 'ENV', 'variaveis do Windows criadas: ' + @installed.join(', ') +
                               ' (pastas reais em .kerberus/ dentro do jogo)', true)
      end
      install_bitmap_retry
      @installed
    end

    def self.present?(name)
      value = ENV[name]
      !value.nil? && !value.empty?
    end

    def self.install_bitmap_retry
      return false unless defined?(::Bitmap) && KerberusLegacy18.native?('System', :reload_cache)
      return false if ::Bitmap.method_defined?(:kerberus_env_initialize)
      ::Bitmap.class_eval(<<-RUBY, 'Kerberus WinEnv', 1)
        alias_method :kerberus_env_initialize, :initialize
        def initialize(*args)
          kerberus_env_initialize(*args)
        rescue Errno::ENOENT
          path = KerberusLegacy18::WinEnv.retry_path(args[0])
          raise unless path
          args[0] = path
          kerberus_env_initialize(*args)
        end
      RUBY
      true
    end

    # Path to retry with, or nil (then the original error stands).
    def self.retry_path(path)
      return nil unless path.is_a?(String) && !path.empty?
      text = path.tr('\\', '/')
      base = Dir.pwd + '/'
      relative = text.index(base) == 0 ? text[base.length..-1] : text
      return nil if relative =~ /\A\// || relative =~ /\A[A-Za-z]:/
      found = IMAGE_EXTENSIONS.find { |ext| Paths.raw_exist?(relative + ext) && !Paths.raw_directory?(relative + ext) }
      found ||= IMAGE_EXTENSIONS.find do |ext|
        resolved = Paths.resolve(relative + ext, false)
        Paths.raw_exist?(resolved) && !Paths.raw_directory?(resolved)
      end
      return nil unless found
      # The cache is reloaded once per file; the retry with the game-relative
      # path happens every time (Essentials rewrites the same temp file, as
      # ENV['TEMP'] + '\\tempscreen.bmp', before every battle transition).
      key = relative.downcase
      unless @reloaded[key]
        @reloaded[key] = true
        KerberusLegacy18.native('System', :reload_cache)
        KerberusLegacy18.event('RUNTIME_FILE', 'Bitmap.new', 'arquivo criado durante o jogo (' + relative +
                               '); cache de caminhos do mkxp-z recarregado', true)
      end
      relative
    end

    def self.forget_reloads!
      @reloaded = {}
    end
  end
end

# ==== 84_io_eof.rb ====
# Kerberus - IO#eof? of the Ruby 1.8 on Android (6.4.3).
#
# Bionic hides the stdio FILE, so Ruby 1.8's IO#eof? could not see the
# buffer and trusted the EOF flag, which a seek clears: at the end of a file
# eof? answered false and the next read returned nil (Pokemon Uranium, OGG
# length at the title screen). The APK's interpreter carries the fix
# (scripts/patch-ruby18-io.py, IO.kerberus_eof_probe). An interpreter without
# it (an older Termux build) is checked once with a real file and, only when
# it gives the wrong answer, gets IO#eof? here: read one character and push it
# back, what the interpreter itself does after its buffer shortcut.
module KerberusLegacy18
  module IoEof
    @mode = nil
    class << self
      attr_reader :mode
    end

    def self.install
      return @mode if @mode
      if ::IO.respond_to?(:kerberus_eof_probe)
        @mode = :interpreter
        KerberusLegacy18.event('RUBY18_IO', 'IO#eof?', ::IO.kerberus_eof_probe ?
                               'interpretador le o arquivo (stdio do Android)' : 'interpretador le o buffer do stdio', true)
      elsif wrong_at_end?
        install_override
        @mode = :bootstrap
        KerberusLegacy18.event('RUBY18_IO', 'IO#eof?', 'interpretador sem o patch de IO: eof? por leitura no bootstrap', true)
      else
        @mode = :native
      end
      @mode
    end

    # Does eof? answer false at the end of a file after a seek?
    def self.wrong_at_end?
      path = File.join(Dir.pwd, '.kerberus', 'temp', 'kerberus-eof-check.bin')
      begin
        KerberusLegacy18.ensure_dir(File.dirname(path))
        File.open(path, 'wb') { |file| file.write('OggS') }
        File.open(path, 'rb') do |file|
          file.pos = 4
          return !file.eof?
        end
      rescue SystemCallError, IOError => error
        KerberusLegacy18.event('RUBY18_IO', 'IO#eof?', 'verificacao impossivel: ' + error.message, true)
        false
      ensure
        begin
          File.delete(path) if File.exist?(path)
        rescue SystemCallError
        end
      end
    end

    def self.install_override
      return false if ::IO.method_defined?(:kerberus_stdio_eof?)
      ::IO.class_eval(<<-RUBY, 'Kerberus IoEof', 1)
        alias_method :kerberus_stdio_eof?, :eof?
        def eof?
          byte = getc
          return true if byte.nil?
          ungetc(byte)
          false
        end
        alias_method :eof, :eof?
      RUBY
      true
    end
  end
end

# ==== 85_ruby181.rb ====
# Kerberus - RGSS1 class semantics (Ruby 1.8.1).
#
# RPG Maker XP runs game scripts on Ruby 1.8.1. When a script reopened a
# class with a DIFFERENT superclass, 1.8.1 defined a new class under that
# name (eval.c, NODE_CLASS, "goto override_class"). Ruby 1.8.2 and later
# raise "superclass mismatch for class X" instead, so games written against
# RGSS1 stop while loading (Pokemon Uranium: Window_PokemonBag).
#
# Since 6.3.3 the Kerberus Ruby 1.8 interpreter carries the 1.8.1 rule
# itself (scripts/patch-ruby18-rgss1.py). The bootstrap detects it with a
# probe and only installs the reporting hook. An interpreter without the
# patch (older build, stock 1.8.7) gets the previous fallback: every
# "class Name < ConstantPath" statement of the game scripts gets, on its
# own line (line numbers unchanged), a guard that removes Name first when
# its superclass differs. KERBERUS_RUBY181=transform forces the fallback.
#
# Regular expressions (6.4.1): RGSS1 compiled them with Oniguruma, so game
# scripts use look-behind (?<=..) (?<!..) and named groups that Ruby 1.8.7's
# GNU engine rejects while parsing ("undefined (?...) sequence", Pokemon
# Uranium Section253). The Kerberus interpreter hands exactly those patterns
# to Oniguruma (scripts/patch-ruby18-oniguruma.py); the bootstrap probes and
# reports it. There is no text fallback: rewriting a look-behind would
# change what the pattern matches.
module KerberusLegacy18
  module Ruby181
    PATH = '(?:::)?[A-Z][A-Za-z0-9_]*(?:::[A-Z][A-Za-z0-9_]*)*'
    CLASS_LINE = /\A([ \t]*)class[ \t]+(#{PATH})[ \t]*<[ \t]*(#{PATH})[ \t]*(?:;|#|\r?\z)/
    ANY_CLASS = /^[ \t]*class[ \t]+#{PATH}[ \t]*<[ \t]*#{PATH}/

    @overrides = []
    class << self
      attr_reader :overrides
    end

    # Runs in the game's scope right before its class statement (fallback).
    def self.reopen(scope, name, superclass, section, line)
      cbase = scope.is_a?(Module) ? scope : Object
      return nil unless superclass.is_a?(Class) && cbase.const_defined?(name)
      klass = cbase.const_get(name)
      return nil unless klass.is_a?(Class)
      previous = klass.superclass
      return nil if previous == superclass
      cbase.send(:remove_const, name)
      record(cbase, name, previous, superclass, format('Section%03d:%d', section, line))
      nil
    end

    def self.record(cbase, name, previous, superclass, where)
      prefix = cbase == Object || cbase.name.to_s.empty? ? '' : cbase.name.to_s + '::'
      label = prefix + name.to_s
      @overrides << [where, label, previous, superclass]
      KerberusLegacy18.event('RUBY181_CLASS_OVERRIDE', where,
                             label + ': superclasse ' + previous.to_s + ' -> ' + superclass.to_s +
                             ' (classe nova, como no Ruby 1.8.1 do RGSS1)', true)
      nil
    end

    def self.where(frames)
      frames.each { |frame| return $1 + ':' + $2 if frame =~ /\A(Section\d+):(\d+)/ }
      '?'
    end

    # Called by the patched eval.c (cbase, name, old and new superclass).
    HOOK = lambda do |cbase, name, previous, superclass|
      KerberusLegacy18::Ruby181.record(cbase, name, previous, superclass,
                                       KerberusLegacy18::Ruby181.where(caller(0)))
    end

    # True when the interpreter itself applies the 1.8.1 rule.
    def self.interpreter_rule?
      return @interpreter unless @interpreter.nil?
      probe = Module.new
      begin
        probe.module_eval("class ProbeBase; end\nclass Probe < ProbeBase; end\nclass Probe < Object; end\n",
                          'Kerberus RGSS1 probe', 1)
        @interpreter = probe.const_get(:Probe).superclass == Object
      rescue TypeError
        @interpreter = false
      end
      @interpreter
    end

    # True when the interpreter compiles RGSS1 regex syntax that the GNU
    # engine rejects (probe: the look-behind of Uranium's Section253).
    def self.regex_rule?
      return @regex unless @regex.nil?
      begin
        @regex = (Regexp.new('(?<!\\\\)"') =~ 'x\\"y"') == 4
      rescue RegexpError
        @regex = false
      end
      @regex
    end

    def self.report_regex
      if regex_rule?
        engine = Regexp.respond_to?(:kerberus_oniguruma) ? 'Oniguruma ' + Regexp.kerberus_oniguruma[0].to_s : 'Oniguruma'
        KerberusLegacy18.event('RUBY181_REGEX', 'RGSS1',
                               'regex do RGSS1 que o motor GNU do Ruby 1.8 rejeita (look-behind, grupos nomeados) ' \
                               'compiladas pelo ' + engine + ' do interpretador', true)
      else
        KerberusLegacy18.event('RUBY181_REGEX', 'AVISO',
                               'interpretador sem o Oniguruma: secoes com look-behind ou grupos nomeados ' \
                               'falham ao compilar (undefined (?...) sequence)', true)
      end
    end

    # [text, guarded statements]; the line count never changes.
    def self.transform(text, section)
      return [text, 0] unless text =~ ANY_CLASS
      lines = text.split("\n", -1)
      comment = false
      count = 0
      lines.each_with_index do |line, index|
        if comment
          comment = false if line =~ /\A=end(?:\s|\z)/
          next
        end
        if line =~ /\A=begin(?:\s|\z)/
          comment = true
          next
        end
        match = CLASS_LINE.match(line)
        next unless match
        path = match[2]
        cut = path.rindex('::')
        if cut
          scope = cut == 0 ? 'Object' : path[0, cut]
          name = path[cut + 2..-1]
        else
          scope = 'self'
          name = path
        end
        guard = 'KerberusLegacy18::Ruby181.reopen(' + scope + ', ' + name.inspect + ', ' + match[3] + ', ' +
                section.to_s + ', ' + (index + 1).to_s + ');'
        lines[index] = match[1] + guard + line[match[1].length..-1]
        count += 1
      end
      [lines.join("\n"), count]
    end

    def self.apply_all(scripts)
      return 0 unless scripts.is_a?(Array)
      report_regex
      if interpreter_rule? && ENV['KERBERUS_RUBY181'] != 'transform'
        $__kerberus_rgss1_class_override = HOOK
        KerberusLegacy18.event('RUBY181_CLASSES', 'RGSS1',
                               'regra de superclasse do Ruby 1.8.1 aplicada pelo interpretador (eval.c)', true)
        return 0
      end
      total = 0
      sections = 0
      scripts.each_with_index do |entry, index|
        next unless entry.is_a?(Array) && entry[3].is_a?(String)
        result, count = transform(entry[3], index)
        next if count == 0
        entry[3] = result
        total += count
        sections += 1
      end
      KerberusLegacy18.event('RUBY181_CLASSES', 'RGSS1',
                             total.to_s + " declaracoes 'class X < Y' em " + sections.to_s +
                             ' secoes seguem a regra de superclasse do Ruby 1.8.1 (bootstrap; interpretador sem o patch)', true)
      total
    end
  end
end

# ==== 86_zlib.rb ====
# Kerberus - Zlib::Inflate.inflate on Android (6.6.1).
#
# On a phone, Pokemon Insurgence stopped at boot with Zlib::DataError
# ("invalid distance too far back") while inflating Data/Constants.rxdata.
# The same data inflates in the desktop build of this engine and under arm64
# emulation, and the Scripts.rxdata loader, which inflates with one zlib call
# in C, works on that phone. When the extension raises Zlib::DataError, the
# input is inflated again by KerberusNative.inflate on a private copy:
# - in 1024-byte steps, the extension's own calling pattern (diagnosis only);
# - in a single call, like the Scripts.rxdata loader.
# The single-call result is returned only when zlib reached the end of the
# stream, which includes zlib's Adler-32 check of the output. Each recovery or
# failure goes to the runtime report with the input's size and CRC-32. When
# the native inflate fails too, the original exception is raised unchanged.
module KerberusLegacy18
  module ZlibGuard
    REPORT_LIMIT = 8
    @installed = false
    @reports = 0
    @recovered = 0
    class << self
      attr_reader :installed, :recovered
    end

    def self.available?
      defined?(::Zlib::Inflate) && defined?(::Zlib::DataError) &&
        defined?(::KerberusNative) && ::KerberusNative.respond_to?(:inflate)
    end

    def self.install
      return true if @installed
      return false unless available?
      singleton = class << ::Zlib::Inflate; self; end
      unless singleton.method_defined?(:kerberus_extension_inflate)
        singleton.class_eval(<<-RUBY, 'Kerberus ZlibGuard', 1)
          alias_method :kerberus_extension_inflate, :inflate
          def inflate(source)
            kerberus_extension_inflate(source)
          rescue ::Zlib::DataError => error
            KerberusLegacy18::ZlibGuard.recover(source, error)
          end
        RUBY
      end
      @installed = true
    end

    def self.recover(source, error)
      data = source.to_str
      stepped = ::KerberusNative.inflate(data, 1024)
      single = ::KerberusNative.inflate(data, 0)
      recovered = single.is_a?(::String)
      @recovered += 1 if recovered
      report(data, error, stepped, single, recovered)
      raise error unless recovered
      single
    end

    def self.describe_input(data)
      head = data[0, 8].to_s.unpack('H*')[0]
      tail = data.length > 8 ? data[data.length - 8, 8].unpack('H*')[0] : head
      data.length.to_s + ' bytes crc32=' + format('%08x', ::Zlib.crc32(data)) +
        ' inicio=' + head + ' fim=' + tail
    end

    def self.describe_result(result)
      if result.is_a?(::String)
        'ok ' + result.length.to_s + ' bytes crc32=' + format('%08x', ::Zlib.crc32(result))
      else
        'falhou codigo=' + result[0].to_s + ' ' + result[1].to_s
      end
    end

    def self.report(data, error, stepped, single, recovered)
      @reports += 1
      return nil if @reports > REPORT_LIMIT
      where = KerberusLegacy18.location(caller(0))
      outcome = recovered ? 'dados entregues pelo inflate nativo de chamada unica (Adler-32 conferido pelo zlib)' :
                            'inflate nativo tambem falhou: erro original mantido'
      KerberusLegacy18.event('ZLIB_INFLATE', 'Zlib::Inflate.inflate',
                             (recovered ? 'recuperado' : 'falhou') + ' em ' + where[1] + ':' + where[2].to_s, true)
      KerberusLegacy18.runtime_block('ZLIB_INFLATE', [
        ['script', where[0]], ['section', where[1]], ['line', where[2]],
        ['erro', error.class.name + ': ' + error.message],
        ['entrada', describe_input(data)],
        ['zlib', 'biblioteca=' + ::Zlib.zlib_version.to_s + ' cabecalho=' + ::Zlib::ZLIB_VERSION.to_s],
        ['nativo_1024', describe_result(stepped)],
        ['nativo_unico', describe_result(single)],
        ['resultado', outcome]])
    end
  end
end

# ==== 90_ports.rb ====
# Kerberus Ports - in-memory replacement of Windows-only script systems.
#
# A port is declared with markers (every string must appear in the section),
# an optional whole-game condition and a transformation. Game files are
# never touched: only $RGSS_SCRIPTS[i][3], already decoded in memory, is
# replaced before the section runs. Ports that replace a section declare
# the names they provide; missing top-level names are reported (and block
# the port when it is strict) so an incomplete replacement never hides a
# NameError behind a successful boot.
module KerberusLegacy18
  module Ports
    class Port
      attr_reader :id, :title, :markers, :condition, :strict, :provides, :transform

      def initialize(id, title, markers, options, transform)
        @id = id
        @title = title
        @markers = markers
        @condition = options[:condition]
        @strict = options[:strict] ? true : false
        @provides = options[:provides] || []
        @transform = transform
      end

      def matches?(source)
        @markers.all? { |marker| source.index(marker) }
      end
    end

    @registry = []
    @applied = []

    def self.reset!
      @applied = []
    end

    def self.registry
      @registry
    end

    def self.applied
      @applied
    end

    def self.register(id, title, markers, options, &transform)
      @registry.delete_if { |port| port.id == id }
      @registry << Port.new(id, title, markers, options, transform)
    end

    def self.find(id)
      @registry.find { |port| port.id == id }
    end

    # ------------------------------------------------------------------
    # Source helpers (line-count preserving where it matters)
    # ------------------------------------------------------------------
    module Source
      TOP_DEF = /^def\s+(?:self\.)?([A-Za-z_]\w*[?!=]?)/
      TOP_TYPE = /^(?:class|module)\s+([A-Z]\w*(?:::[A-Z]\w*)*)/

      def self.definitions(text)
        names = []
        text.each_line do |line|
          names << $1 if line =~ TOP_DEF || line =~ TOP_TYPE
        end
        names.uniq
      end

      def self.lines(text)
        text.count("\n")
      end

      # Pads replacement with blank lines so later line numbers stay valid.
      def self.pad(original, replacement)
        missing = lines(original) - lines(replacement)
        missing > 0 ? replacement + "\n" * missing : replacement
      end

      def self.method_body(source, name, body)
        expression = /^([ \t]*)def #{Regexp.escape(name)}(?=[ \t(\n;])(?:\([^\n]*\)|[^\n]*)\n.*?^\1end\b/m
        matches = []
        source.scan(expression) { matches << $1 }
        raise ArgumentError, 'metodo ambiguo ou ausente: ' + name unless matches.length == 1
        source.sub(expression) do |old|
          indent = matches[0]
          head = old.split("\n")[0] + "\n"
          inner = body.split("\n").map { |line| indent + '  ' + line + "\n" }.join
          pad(old, head + inner + indent + 'end')
        end
      end
    end

    def self.disabled?(port)
      KerberusLegacy18.config[:ports_disabled].include?(port.id)
    end

    def self.apply_all(scripts)
      return 0 unless scripts.is_a?(Array)
      unless KerberusLegacy18.config[:ports]
        KerberusLegacy18.event('PORTS_DISABLED', 'Kerberus Ports', 'desativado pelo usuario (KERBERUS_COMPAT_MODE=off)', true)
        return 0
      end
      count = 0
      scripts.each_with_index do |entry, index|
        next unless entry.is_a?(Array) && entry[3].is_a?(String)
        @registry.each do |port|
          source = entry[3]
          next unless port.matches?(source)
          next if port.condition && !port.condition.call(scripts)
          label = format('Section%03d', index) + ' (' + (KerberusLegacy18.script_name(index) || '?') + ')'
          if disabled?(port)
            KerberusLegacy18.event('PORT_DISABLED', port.id, label, true)
            next
          end
          begin
            result = port.transform.call(source, index, scripts)
          rescue StandardError => error
            # A port that cannot parse this variant leaves the original
            # section untouched; the WinBridge still reports any API call.
            KerberusLegacy18.event('PORT_FAILED', port.id, label + ' ' + error.class.name + ': ' + error.message, true)
            next
          end
          next if result.nil? || result == source
          unless port.provides.empty? && !(result.length < source.length / 2)
            missing = Source.definitions(source) - Source.definitions(result) - port.provides
            unless missing.empty?
              text = 'nomes do script original sem equivalente: ' + missing.first(12).join(', ')
              if port.strict
                KerberusLegacy18.event('PORT_SKIPPED', port.id, label + ' ' + text, true)
                next
              end
              KerberusLegacy18.event('PORT_COVERAGE', port.id, label + ' ' + text, true)
            end
          end
          entry[3] = result
          @applied << [port.id, index]
          count += 1
          KerberusLegacy18.event('PORT_APPLIED', port.id + ' ' + label, port.title, true)
        end
      end
      count
    end

    # ==================================================================
    # Port implementations (installed when the replaced section runs)
    # ==================================================================
    module Linker
      def self.install
        Kernel.module_eval(<<-RUBY, 'Kerberus Ports', 1)
          def load_module(library, symbol)
            KerberusLegacy18::Ports::Linker.load(library, symbol)
          end
          module_function :load_module
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'rgss_linker', 'load_module nativo: RGSS FmodEx -> Audio nativo')
      end

      def self.load(library, symbol)
        name = KerberusLegacy18::WinBridge.library(library.to_s)
        if (name == 'rgss_fmodex' || name == 'fmodex' || name == 'rgss fmodex') && symbol.to_s == 'Init_FmodEx'
          EssentialsAudio.install(:fmod)
          return true
        end
        where = KerberusLegacy18.here
        KerberusLegacy18.runtime_block('WINBRIDGE', [['error', 'RGSS_LINKER_EXTENSION'], ['library', library.to_s],
                                                     ['symbol', symbol.to_s], ['script', where[0]],
                                                     ['section', where[1]], ['line', where[2]], ['runtime', RUNTIME]])
        raise KerberusLegacy18::WinBridge::Unavailable,
              "WINBRIDGE_UNAVAILABLE\nRGSS Linker: extensao x86 sem port: " + library.to_s + '!' + symbol.to_s
      end
    end

    # Essentials audio API over the single AudioBridge.
    module EssentialsAudio
      BRIDGE = KerberusLegacy18::WinBridge::AudioBridge
      @installed = {}

      def self.installed?(flavor)
        @installed[flavor] ? true : false
      end

      def self.install(flavor)
        return true if @installed[flavor]
        first = @installed.empty?
        @installed[flavor] = true
        BRIDGE.use_profile_volume! if flavor == :fmod
        if first
          Kernel.module_eval(<<-RUBY, 'Kerberus Ports', 1)
            def Audio_bgm_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:bgm, name, volume, pitch, position)
            end
            def Audio_bgm_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:bgm); end
            def Audio_bgm_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:bgm, ms); end
            def Audio_bgm_fadein(ms); KerberusLegacy18::WinBridge::AudioBridge.fade_in(ms); end
            def Audio_bgm_get_position; KerberusLegacy18::WinBridge::AudioBridge.position(:bgm); end
            def Audio_bgm_get_volume
              info = KerberusLegacy18::WinBridge::AudioBridge.info(:bgm)
              info ? info[1] : 0
            end
            def Audio_bgm_set_volume(volume); KerberusLegacy18::WinBridge::AudioBridge.set_volume(:bgm, volume); end
            def Audio_bgm_name
              info = KerberusLegacy18::WinBridge::AudioBridge.info(:bgm)
              info ? info[0] : ''
            end
            def Audio_bgm_pitch
              info = KerberusLegacy18::WinBridge::AudioBridge.info(:bgm)
              info ? info[2] : 100
            end
            def Audio_bgm_playing?; KerberusLegacy18::WinBridge::AudioBridge.playing?(:bgm); end
            def Audio_bgs_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:bgs, name, volume, pitch, position)
            end
            def Audio_bgs_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:bgs); end
            def Audio_bgs_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:bgs, ms); end
            def Audio_me_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:me, name, volume, pitch, position)
            end
            def Audio_me_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:me); end
            def Audio_me_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:me, ms); end
            def Audio_se_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:se, name, volume, pitch, position)
            end
            def Audio_se_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:se); end
            def audio_control_volume(volume); KerberusLegacy18::WinBridge::AudioBridge.set_volume(:bgm, volume); end
            def getPlayMusic; true; end
            def getPlaySound; true; end
            module_function :Audio_bgm_play, :Audio_bgm_stop, :Audio_bgm_fade, :Audio_bgm_fadein,
                            :Audio_bgm_get_position, :Audio_bgm_get_volume, :Audio_bgm_set_volume,
                            :Audio_bgm_name, :Audio_bgm_pitch, :Audio_bgm_playing?,
                            :Audio_bgs_play, :Audio_bgs_stop, :Audio_bgs_fade,
                            :Audio_me_play, :Audio_me_stop, :Audio_me_fade,
                            :Audio_se_play, :Audio_se_stop, :audio_control_volume,
                            :getPlayMusic, :getPlaySound
          RUBY
          # RGSS event commands call Audio.* directly; route them through the
          # same bridge so its state (name, volume, playing?) is always right.
          KerberusLegacy18.meta(::Audio).module_eval(<<-RUBY, 'Kerberus Ports', 1)
            def bgm_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:bgm, name, volume, pitch, position)
            end
            def bgm_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:bgm); end
            def bgm_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:bgm, ms); end
            def bgs_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:bgs, name, volume, pitch, position)
            end
            def bgs_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:bgs); end
            def bgs_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:bgs, ms); end
            def me_play(name, volume = 100, pitch = 100)
              KerberusLegacy18::WinBridge::AudioBridge.play(:me, name, volume, pitch, 0)
            end
            def me_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:me); end
            def me_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:me, ms); end
            def se_play(name, volume = 100, pitch = 100)
              KerberusLegacy18::WinBridge::AudioBridge.play(:se, name, volume, pitch, 0)
            end
            def se_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:se); end
            def bgm_position; KerberusLegacy18::WinBridge::AudioBridge.position(:bgm); end
          RUBY
        end
        if flavor == :fmod
          # The Uranium FMOD section also defined this Essentials helper.
          Kernel.module_eval(<<-RUBY, 'Kerberus Ports', 1)
            def safeExists?(file); File.file?(file); end
            module_function :safeExists?
          RUBY
        end
        if flavor == :audio_dll && !Object.const_defined?(:AudioState)
          Object.const_set(:AudioState, Module.new)
          KerberusLegacy18.meta(::AudioState).module_eval(<<-RUBY, 'Kerberus Ports', 1)
            def update; KerberusLegacy18::WinBridge::AudioBridge.tick; end
            def bgmActive?; KerberusLegacy18::WinBridge::AudioBridge.playing?(:bgm); end
            def meActive?; KerberusLegacy18::WinBridge::AudioBridge.playing?(:me); end
            def method_missing(name, *args)
              raise KerberusLegacy18::WinBridge::Unavailable,
                    "WINBRIDGE_UNAVAILABLE\\nport audio_dll: AudioState." + name.to_s + ' ainda sem equivalente'
            end
          RUBY
        end
        KerberusLegacy18.event('PORT_INSTALLED', 'audio.' + flavor.to_s,
                               'BGM/BGS/ME/SE, volume, pitch, fade e fade-in via Audio nativo (canal unico)')
        true
      end
    end

    # KleinBitmap functions over Bitmap#raw_data (RGBA bytes).
    module Klein
      LIMIT = 16 * 1024 * 1024

      def self.bytes(bitmap)
        unless bitmap.is_a?(::Bitmap) && !bitmap.disposed?
          raise ArgumentError, 'KleinBitmap: Bitmap invalido ou descartado'
        end
        if bitmap.width * bitmap.height * 4 > LIMIT
          raise KerberusLegacy18::WinBridge::Unavailable, 'KleinBitmap: bitmap excede 16 MiB'
        end
        if bitmap.respond_to?(:animated?) && bitmap.animated?
          frame = bitmap.snap_to_bitmap
          begin
            return frame.raw_data
          ensure
            frame.dispose
          end
        end
        bitmap.raw_data
      end

      def self.channel(color, name)
        color.respond_to?(name) ? color.send(name).to_i : 0
      end

      def self.scroll(bitmap, dx, dy)
        return bitmap if bitmap.width == 0 || bitmap.height == 0
        dx %= bitmap.width
        dy %= bitmap.height
        temp = bitmap.clone
        begin
          bitmap.clear
          [dx, dx - bitmap.width].each do |x|
            [dy, dy - bitmap.height].each { |y| bitmap.blt(x, y, temp, temp.rect) }
          end
        ensure
          temp.dispose
        end
        bitmap
      end

      def self.negative(bitmap)
        data = bytes(bitmap)
        index = 0
        while index < data.length
          data[index] = 255 - data[index]
          data[index + 1] = 255 - data[index + 1]
          data[index + 2] = 255 - data[index + 2]
          index += 4
        end
        bitmap.raw_data = data
        bitmap
      end

      def self.modify_color(bitmap, from, to)
        data = bytes(bitmap)
        old = [channel(from, :red), channel(from, :green), channel(from, :blue)]
        replacement = [channel(to, :red), channel(to, :green), channel(to, :blue)]
        index = 0
        while index < data.length
          if data[index] == old[0] && data[index + 1] == old[1] && data[index + 2] == old[2]
            data[index] = replacement[0]
            data[index + 1] = replacement[1]
            data[index + 2] = replacement[2]
          end
          index += 4
        end
        bitmap.raw_data = data
        bitmap
      end

      # Documented: repaint using a 4-color palette, c1 darkest .. c4 brightest.
      def self.retro(bitmap, colors)
        raise ArgumentError, 'to_retro requer 4 cores' unless colors.length == 4
        palette = colors.map { |color| [channel(color, :red), channel(color, :green), channel(color, :blue)] }
        data = bytes(bitmap)
        index = 0
        while index < data.length
          if data[index + 3] > 0
            luma = (data[index] * 299 + data[index + 1] * 587 + data[index + 2] * 114) / 1000
            shade = palette[luma * 4 / 256]
            data[index] = shade[0]
            data[index + 1] = shade[1]
            data[index + 2] = shade[2]
          end
          index += 4
        end
        bitmap.raw_data = data
        bitmap
      end

      # Documented: add_outline(color, pixelsize) - colored outline around
      # opaque pixels (8-neighbour dilation, pixelsize times).
      def self.outline(bitmap, color, size)
        size = size.to_i
        return bitmap if size <= 0
        width = bitmap.width
        height = bitmap.height
        data = bytes(bitmap)
        rgba = [channel(color, :red), channel(color, :green), channel(color, :blue), color.respond_to?(:alpha) ? color.alpha.to_i : 255]
        solid = Array.new(width * height, false)
        (0...(width * height)).each { |pixel| solid[pixel] = data[pixel * 4 + 3] > 0 }
        size.times do
          grown = solid.dup
          (0...height).each do |y|
            (0...width).each do |x|
              pixel = y * width + x
              next if solid[pixel]
              hit = false
              (-1..1).each do |oy|
                (-1..1).each do |ox|
                  nx = x + ox
                  ny = y + oy
                  hit = true if !hit && nx >= 0 && ny >= 0 && nx < width && ny < height && solid[ny * width + nx]
                end
              end
              next unless hit
              grown[pixel] = true
              offset = pixel * 4
              data[offset] = rgba[0]
              data[offset + 1] = rgba[1]
              data[offset + 2] = rgba[2]
              data[offset + 3] = rgba[3]
            end
          end
          solid = grown
        end
        bitmap.raw_data = data
        bitmap
      end

      def self.unavailable(name)
        raise KerberusLegacy18::WinBridge::Unavailable,
              "WINBRIDGE_UNAVAILABLE\nKleinBitmap." + name + ': formato de paleta proprietario sem documentacao publica'
      end

      def self.install
        ::Bitmap.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          def scroll_up(speed = 1); KerberusLegacy18::Ports::Klein.scroll(self, 0, -Integer(speed)); end
          def scroll_down(speed = 1); KerberusLegacy18::Ports::Klein.scroll(self, 0, Integer(speed)); end
          def scroll_left(speed = 1); KerberusLegacy18::Ports::Klein.scroll(self, -Integer(speed), 0); end
          def scroll_right(speed = 1); KerberusLegacy18::Ports::Klein.scroll(self, Integer(speed), 0); end
          def to_negative; KerberusLegacy18::Ports::Klein.negative(self); end
          def modify_color(from, to); KerberusLegacy18::Ports::Klein.modify_color(self, from, to); end
          def to_retro(c1, c2, c3, c4); KerberusLegacy18::Ports::Klein.retro(self, [c1, c2, c3, c4]); end
          def add_outline(color, pixelsize = 1); KerberusLegacy18::Ports::Klein.outline(self, color, pixelsize); end
          def save_pallete(*args); KerberusLegacy18::Ports::Klein.unavailable('save_pallete'); end
          def modify_pallete(*args); KerberusLegacy18::Ports::Klein.unavailable('modify_pallete'); end
        RUBY
        ::Sprite.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          attr_accessor :kleinPatternBitmap
          def set_pattern(pattern, alpha, everyframe = false)
            KerberusLegacy18::Ports::Klein.set_pattern(self, pattern, alpha, everyframe)
          end
          def delete_pattern
            KerberusLegacy18::Ports::Klein.delete_pattern(self)
          end
          alias_method :kerberus_klein_dispose, :dispose unless method_defined?(:kerberus_klein_dispose)
          def dispose
            KerberusLegacy18::Ports::Klein.release_pattern(self)
            kerberus_klein_dispose
          end
        RUBY
        Object.const_set(:KLEIN_BFUNCS_WORKING, true) unless Object.const_defined?(:KLEIN_BFUNCS_WORKING)
        Kernel.module_eval(<<-RUBY, 'Kerberus Ports', 1)
          def compare_klein_bitmaps(a, b)
            a.width == b.width && a.height == b.height &&
              KerberusLegacy18::Ports::Klein.bytes(a) == KerberusLegacy18::Ports::Klein.bytes(b)
          end
          def klein_bitmap_version; 1; end
          def klein_dll(*args)
            raise KerberusLegacy18::WinBridge::Unavailable,
                  "WINBRIDGE_UNAVAILABLE\\nKleinBitmap: chamada direta a DLL (" + args.inspect + '); use os metodos Bitmap/Sprite do port'
          end
          module_function :compare_klein_bitmaps, :klein_bitmap_version, :klein_dll
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'klein_bitmap',
                               'scroll, negativo, modify_color, to_retro, add_outline, pattern e comparacao; paletas indisponiveis')
      end

      def self.set_pattern(sprite, pattern, alpha, everyframe)
        raise ArgumentError, 'set_pattern: alpha invalido' unless alpha.is_a?(Numeric)
        bitmap = sprite.bitmap
        source = sprite.instance_variable_get(:@kerberus_pattern_source)
        output = sprite.instance_variable_get(:@kerberus_pattern_output)
        if everyframe || !(output && bitmap.equal?(output))
          next_source = bitmap.respond_to?(:animated?) && bitmap.animated? ? bitmap.snap_to_bitmap : bitmap.clone
          next_output = next_source.clone
          source.dispose if source && !source.disposed?
          output.dispose if output && !output.disposed?
          source = next_source
          output = next_output
          sprite.instance_variable_set(:@kerberus_pattern_source, source)
          sprite.instance_variable_set(:@kerberus_pattern_output, output)
        end
        raise ArgumentError, 'set_pattern: pattern vazio' if pattern.width == 0 || pattern.height == 0
        target = bytes(source)
        pixels = bytes(pattern)
        opacity = alpha.to_f
        opacity = 0.0 if opacity < 0
        opacity = 255.0 if opacity > 255
        opacity /= 255.0
        width = source.width
        count = target.length / 4
        pixel = 0
        while pixel < count
          index = pixel * 4
          if target[index + 3] != 0
            offset = (((pixel / width) % pattern.height) * pattern.width + (pixel % width) % pattern.width) * 4
            mix = opacity * pixels[offset + 3] / 255.0
            3.times do |j|
              target[index + j] = (target[index + j] * (1 - mix) + pixels[offset + j] * mix).round
            end
          end
          pixel += 1
        end
        output.raw_data = target
        sprite.bitmap = output
      end

      def self.delete_pattern(sprite)
        source = sprite.instance_variable_get(:@kerberus_pattern_source)
        output = sprite.instance_variable_get(:@kerberus_pattern_output)
        return nil unless source
        if sprite.bitmap.equal?(output)
          sprite.bitmap = source
        elsif !source.disposed?
          source.dispose
        end
        output.dispose if output && !output.disposed?
        sprite.instance_variable_set(:@kerberus_pattern_source, nil)
        sprite.instance_variable_set(:@kerberus_pattern_output, nil)
        nil
      end

      def self.release_pattern(sprite)
        [:@kerberus_pattern_source, :@kerberus_pattern_output].each do |name|
          item = sprite.instance_variable_get(name)
          item.dispose if item && !item.disposed?
          sprite.instance_variable_set(name, nil)
        end
      end
    end

    # Essentials GifBitmap over mkxp-z animated Bitmap (libnsgif).
    module Gif
      def self.install
        return false unless Object.const_defined?(:GifBitmap)
        ::GifBitmap.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          def initialize(*args)
            file, hue = KerberusLegacy18::Ports::Gif.arguments(args)
            @kerberus_frames = {}
            if file.to_s.tr('\\\\', '/').sub(/\\/+\\z/, '') =~ /\\AGraphics\\/Autotiles\\z/i
              @kerberus_bitmap = Bitmap.new(32, 32)
              return
            end
            path = defined?(RTP) && RTP.respond_to?(:getImagePath) ? (RTP.getImagePath(file) || file) : file
            @kerberus_bitmap = KerberusLegacy18::Ports::Gif.load(path, hue)
          end
          def bitmap; @kerberus_bitmap; end
          def width; bitmap.width; end
          def height; bitmap.height; end
          def length; KerberusLegacy18::Ports::Gif.animated?(bitmap) ? bitmap.frame_count : 1; end
          def currentIndex; KerberusLegacy18::Ports::Gif.animated?(bitmap) ? bitmap.current_frame : 0; end
          def disposed?; bitmap.nil? || bitmap.disposed?; end
          def update; nil; end
          def totalFrames; length * frameDelay; end
          def frameDelay(index = nil)
            KerberusLegacy18::Ports::Gif.animated?(bitmap) && bitmap.frame_rate.to_f > 0 ? (40.0 / bitmap.frame_rate).round : 1
          end
          def deanimate
            if KerberusLegacy18::Ports::Gif.animated?(bitmap)
              original = bitmap
              original.goto_and_stop(0)
              @kerberus_bitmap = original.snap_to_bitmap
              original.dispose
              @kerberus_frames.each_value { |frame| frame.dispose unless frame.disposed? }
              @kerberus_frames.clear
            end
            bitmap
          end
          def [](index)
            KerberusLegacy18::Ports::Gif.frame(self, bitmap, @kerberus_frames, index)
          end
          def each
            length.times { |index| yield self[index] }
          end
          def dispose
            @kerberus_frames.each_value { |frame| frame.dispose unless frame.disposed? }
            @kerberus_frames.clear
            bitmap.dispose if bitmap && !bitmap.disposed?
          end
          def copy
            duplicate = clone
            duplicate.instance_variable_set(:@kerberus_bitmap, bitmap.clone)
            duplicate.instance_variable_set(:@kerberus_frames, {})
            duplicate
          end
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'gif_dll', 'GifBitmap via Bitmap animado nativo do mkxp-z')
        true
      end

      def self.arguments(args)
        if args.length >= 2 && args[1].is_a?(String)
          [File.join(args[0].to_s, args[1]), args[2] || 0]
        else
          [args[0], args[1] || 0]
        end
      end

      def self.animated?(bitmap)
        bitmap.respond_to?(:animated?) && bitmap.animated?
      end

      # Essentials' GifBitmap never fails on a missing picture: an empty name
      # (a folder path such as "Graphics/Characters/", used by events without
      # a graphic) or an absent file gives a blank 32x32 BitmapWrapper, so the
      # game shows nothing there, as on Windows. The absent file is reported.
      def self.blank
        (Object.const_defined?(:BitmapWrapper) ? ::BitmapWrapper : ::Bitmap).new(32, 32)
      end

      def self.load(path, hue)
        text = path.to_s
        return blank if text.empty? || text =~ /[\/\\]\z/
        begin
          bitmap = ::Bitmap.new(path)
        rescue Errno::ENOENT
          KerberusLegacy18.event('GIF_MISSING', text, 'arquivo ausente: bitmap vazio 32x32, como o GifBitmap do Essentials', true)
          return blank
        end
        return bitmap if hue.to_i == 0
        unless animated?(bitmap)
          bitmap.hue_change(hue)
          return bitmap
        end
        colored = nil
        begin
          bitmap.frame_count.times do |index|
            bitmap.goto_and_stop(index)
            frame = bitmap.snap_to_bitmap
            frame.hue_change(hue)
            if colored
              colored.add_frame(frame)
              frame.dispose
            else
              colored = frame
            end
          end
          colored.frame_rate = bitmap.frame_rate
          colored.looping = bitmap.looping
          colored.play
          colored
        ensure
          bitmap.dispose unless bitmap.disposed?
        end
      end

      def self.frame(owner, bitmap, cache, index)
        return nil unless index.is_a?(Integer) && index >= 0 && index < owner.length
        return bitmap if owner.length == 1
        return cache[index] if cache.has_key?(index)
        current = bitmap.current_frame
        playing = bitmap.playing
        begin
          bitmap.goto_and_stop(index)
          cache[index] = bitmap.snap_to_bitmap
        ensure
          bitmap.goto_and_stop(current)
          bitmap.play if playing
        end
        cache[index]
      end
    end

    # Bitmap memory helpers of old Essentials (RtlMoveMemory_pi on addresses).
    module BitmapMemory
      def self.swap(data)
        result = data.dup
        index = 0
        while index < result.length
          red = result[index]
          result[index] = result[index + 2]
          result[index + 2] = red
          index += 4
        end
        result
      end

      def self.install
        ::Bitmap.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          def getData
            KerberusLegacy18::Ports::BitmapMemory.swap(KerberusLegacy18::Ports::Klein.bytes(self))
          end
          def setData(data)
            size = width * height * 4
            KerberusLegacy18::WinBridge::Buffers.need(data, size, false, 'Bitmap#setData')
            self.raw_data = KerberusLegacy18::Ports::BitmapMemory.swap(data[0, size])
          end
          def asOpaque
            data = KerberusLegacy18::Ports::Klein.bytes(self)
            index = 3
            while index < data.length
              data[index] = 255
              index += 4
            end
            self.raw_data = data
            self
          end
          def saveToPng(file)
            to_file(KerberusLegacy18::Paths.resolve(file.to_s, true))
          end
          def address
            raise KerberusLegacy18::WinBridge::Unavailable,
                  "WINBRIDGE_UNAVAILABLE\\nBitmap#address: enderecos de objetos RGSS1 nao existem no mkxp-z; use raw_data"
          end
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'bitmap_memory', 'getData/setData/asOpaque/saveToPng via raw_data')
      end
    end

    module TextEntry
      def self.install
        return false unless Object.const_defined?(:Window_TextEntry_Keyboard)
        ::Window_TextEntry_Keyboard.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          alias_method :kerberus_text_update, :update unless method_defined?(:kerberus_text_update)
          alias_method :kerberus_text_dispose, :dispose unless method_defined?(:kerberus_text_dispose)
          def update
            active_now = respond_to?(:active) ? (active ? true : false) : true
            if active_now != @kerberus_text_active
              @kerberus_text_active = active_now
              KerberusLegacy18.native('Input', :text_input=, active_now) if KerberusLegacy18.native?('Input', :text_input=)
            end
            kerberus_text_update
          end
          def dispose
            if @kerberus_text_active && KerberusLegacy18.native?('Input', :text_input=)
              KerberusLegacy18.native('Input', :text_input=, false)
            end
            @kerberus_text_active = false
            kerberus_text_dispose
          end
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'text_entry', 'teclado Android/IME via Input.gets')
        true
      end

      def self.incoming
        return '' unless KerberusLegacy18.native?('Input', :gets)
        text = KerberusLegacy18.native('Input', :gets).to_s
        result = []
        text.each_char { |char| result << char unless char =~ /\A[\x00-\x1f\x7f]\z/ }
        result
      end
    end

    module Movies
      def self.install
        native = KerberusLegacy18.native?('Graphics', :play_movie)
        KerberusLegacy18.meta(::Graphics).module_eval(<<-RUBY, 'Kerberus Ports', 1)
          def play_movie(filename, cancellable = true, fit = true)
            KerberusLegacy18::Ports::Movies.play(filename, cancellable)
          end
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'zeus_video', native ? 'Graphics.play_movie nativo (OGV/Theora)' : 'sem binding de video')
      end

      def self.play(filename, cancellable)
        base = filename.to_s.tr('\\', '/').sub(/\.[^.\/]+\z/, '')
        candidates = [filename.to_s.tr('\\', '/'), base + '.ogv', base + '.ogg']
        found = candidates.map { |path| KerberusLegacy18::Paths.resolve(path, false) }.find { |path| File.file?(path) && path =~ /\.og[gv]\z/i }
        unless found && KerberusLegacy18.native?('Graphics', :play_movie)
          KerberusLegacy18.event('LIMITED', 'Graphics.play_movie', filename.to_s + ': sem versao OGV/Theora; video pulado', true)
          return nil
        end
        KerberusLegacy18.native('Graphics', :play_movie, found, 100, cancellable ? true : false)
      end
    end

    # ==================================================================
    # Registry
    # ==================================================================
    register('rgss_linker', 'RGSS Linker: load_module nativo (FMOD -> Audio mkxp-z)',
             ['RGSSLinker_Initialize', 'def load_module'], :provides => %w(load_module RGSSLinker_Initialize)) do |source, index, scripts|
      Source.pad(source, "# Kerberus Ports: RGSS Linker substituido por adaptador nativo\nKerberusLegacy18::Ports::Linker.install\n")
    end

    register('fmodex_audio', 'FMOD Ex (RGSS Linker) -> Audio nativo do mkxp-z',
             ['Init_FmodEx', 'LOOP_TABLE', 'bgmvolume'],
             :provides => %w(Audio_bgm_play Audio_bgm_stop Audio_bgm_fade Audio_bgm_fadein Audio_bgm_get_position
                             Audio_bgm_get_volume Audio_bgm_set_volume Audio_bgm_name Audio_bgm_pitch Audio_bgm_playing?
                             Audio_bgs_play Audio_bgs_stop Audio_bgs_fade Audio_me_play Audio_me_stop Audio_me_fade
                             Audio_se_play Audio_se_stop audio_control_volume safeExists? getPlayMusic getPlaySound Audio)) do |source, index, scripts|
      table = source[/LOOP_TABLE\s*=\s*\[(.*?)\]/m, 1]
      entries = table ? table.split("\n").reject { |line| line.strip.empty? || line.strip[0, 1] == '#' }.length : 0
      if entries > 0
        KerberusLegacy18.event('LIMITED', 'FMOD LOOP_TABLE', entries.to_s + ' pontos de loop customizados; use tags LOOPSTART/LOOPLENGTH no OGG', true)
      end
      Source.pad(source, "# Kerberus Ports: FMOD substituido pelo Audio nativo\nKerberusLegacy18::Ports::EssentialsAudio.install(:fmod)\n")
    end

    register('audio_dll', 'Essentials audio.dll (AudioContext) -> Audio nativo',
             ['class AudioContext', 'AudioContextInitialize', 'module AudioState'],
             :provides => %w(AudioContext AudioState Audio Audio_bgm_play Audio_bgm_stop Audio_bgm_fade Audio_bgm_fadein
                             Audio_bgm_get_position Audio_bgm_get_volume Audio_bgm_set_volume Audio_bgm_name Audio_bgm_pitch
                             Audio_bgm_playing? Audio_bgs_play Audio_bgs_stop Audio_bgs_fade Audio_me_play Audio_me_stop
                             Audio_me_fade Audio_se_play Audio_se_stop audio_control_volume getPlayMusic getPlaySound)) do |source, index, scripts|
      Source.pad(source, "# Kerberus Ports: audio.dll substituida pelo Audio nativo\nKerberusLegacy18::Ports::EssentialsAudio.install(:audio_dll)\n")
    end

    register('gif_dll', 'Essentials gif.dll -> Bitmap animado nativo',
             ['module GifLibrary', 'class GifBitmap', 'GifToPngFilesInMemory'], {}) do |source, index, scripts|
      source.gsub(/safeExists\?\(\s*["']gif\.dll["']\s*\)/, 'false') + "\nKerberusLegacy18::Ports::Gif.install\n"
    end

    register('klein_bitmap', 'KleinBitmap.dll -> operacoes Bitmap/Sprite nativas',
             ['KLEIN_BFUNCS_DLL', 'def klein_dll', 'compare_klein_bitmaps'],
             :provides => %w(klein_dll compare_klein_bitmaps klein_bitmap_version Bitmap Sprite)) do |source, index, scripts|
      Source.pad(source, "# Kerberus Ports: KleinBitmap substituida\nKerberusLegacy18::Ports::Klein.install\n")
    end

    register('bitmap_memory', 'Bitmap via RtlMoveMemory -> raw_data; escala de janela gerenciada pelo Android',
             ['def pbSetResizeFactor2', 'RtlMoveMemory_pi', 'def saveToPng'], {}) do |source, index, scripts|
      text = source.sub(/^([ \t]*def pbSetResizeFactor2\(\s*factor\b[^\n)]*\))/) { $1 + '; factor = 1.0 # Kerberus: superficie Android' }
      text = KerberusLegacy18::Ports.native_snapshot(text)
      text + "\nKerberusLegacy18::Ports::BitmapMemory.install\n"
    end

    # Essentials v16/v17 Graphics.snap_to_bitmap: rubyscreen.dll writes a BMP
    # to %TEMP% and the game loads it back. mkxp-z captures the screen itself;
    # the file round trip (and its path-cache miss) is replaced by the native
    # capture, the game's own post-processing (opaque, offset, resize) stays.
    SNAPSHOT_FILE = /^([ \t]*)tempPath=ENV\["TEMP"\][^\n]*\n.*?(?=^[ \t]*if bm && bm\.get_pixel\(0,0\)\.alpha==0)/m

    def self.native_snapshot(source)
      return source unless source =~ /def self\.snap_to_bitmap/ && source =~ SNAPSHOT_FILE
      source.sub(SNAPSHOT_FILE) do |old|
        indent = $1
        Source.pad(old, indent + 'bm=KerberusLegacy18::Ports.snapshot # Kerberus: captura nativa do mkxp-z, sem arquivo temporario')
      end
    end

    def self.snapshot
      KerberusLegacy18.native('Graphics', :snap_to_bitmap)
    end

    # Uranium's first section relaunches the executable on a reset (F12):
    # "if $game_exists; Thread.new {system('Uranium')}; exit; end". mkxp-z
    # resets by running the sections again in the same process, so on
    # Android that code only closed the game. The reset proceeds in place.
    RELAUNCH = /^([ \t]*)Thread\.new\s*\{\s*system\(\s*['"][^'"]+['"]\s*\)\s*\}[ \t\r]*\n[ \t]*exit(?=[ \t\r]*$)/

    register('hard_reset', 'Reset (F12) sem relancar o executavel: o mkxp-z reinicia os scripts no mesmo processo',
             ['$game_exists', 'Thread.new', 'system('], {}) do |source, index, scripts|
      next nil unless source =~ RELAUNCH
      source.gsub(RELAUNCH) { $1 + "KerberusLegacy18.event('RESET', 'F12', 'reset no mesmo processo (sem relancar o executavel)', true)\n" }
    end

    # Essentials v15-v17 CustomTilemap (MAPVIEWMODE 1, the default) shows each
    # priority tile as a Sprite whose bitmap is the WHOLE tileset. RGSS1 on
    # Windows draws bitmaps of any height; the GPU does not: a tileset taller
    # than GL_MAX_TEXTURE_SIZE (4096-16384 on phones; Uranium has tilesets up
    # to 21256 px) is a CPU "mega surface" in mkxp-z and cannot be a Sprite
    # bitmap. For such a tileset the tilemap takes its own per-tile path (the
    # one it uses for resized tiles): each tile is copied once to a 32x32
    # bitmap, and blt from a mega surface is supported. Other tilesets keep
    # the original path.
    MEGA_TILE = /^([ \t]*def getRegularTile\(sprite,\s*id\)[ \t\r]*\n[ \t]*if !@diffsizes)(?=[ \t\r]*$)/

    register('mega_tileset', 'Tileset maior que a textura da GPU: tiles de prioridade copiados para bitmaps 32x32',
             ['class CustomTilemap', 'def getRegularTile', '@regularTileInfo'], {}) do |source, index, scripts|
      next nil unless source =~ MEGA_TILE
      source.sub(MEGA_TILE) { $1 + ' && !KerberusLegacy18::Ports.mega?(@tileset)' }
    end

    def self.mega?(bitmap)
      return false unless bitmap && bitmap.respond_to?(:mega?) && !bitmap.disposed?
      return false unless bitmap.mega?
      unless @mega_reported
        @mega_reported = true
        KerberusLegacy18.event('MEGA_TILESET', 'CustomTilemap', 'tileset ' + bitmap.width.to_s + 'x' + bitmap.height.to_s +
                               ' maior que a textura da GPU: tiles copiados um a um', true)
      end
      true
    end

    # 6.5: Essentials v15-v17 Input calls pbSameThread(GetForegroundWindow)
    # for every key it reads (about 30 times per frame), and each call creates
    # two Win32API objects and makes three Win32 calls. With the Kerberus
    # window (GetForegroundWindow gives it or 0; GetWindowThreadProcessId
    # gives the current thread only for it) the answer is "is this handle the
    # game window", so the body becomes that test. Same line count.
    SAME_THREAD = /^([ \t]*)def pbSameThread\(wnd\)[ \t]*(\r?\n)[ \t]*return false if wnd==0[ \t\r]*\n[ \t]*processid=\[0\]\.pack\('l'\)[ \t\r]*\n[ \t]*getCurrentThreadId=Win32API\.new\('kernel32',[ \t]*'GetCurrentThreadId',[ \t]*'%w\(\)',[ \t]*'l'\)[ \t\r]*\n[ \t]*getWindowThreadProcessId=Win32API\.new\('user32',[ \t]*'GetWindowThreadProcessId',[ \t]*'%w\(l p\)',[ \t]*'l'\)[ \t\r]*\n[ \t]*threadid=getCurrentThreadId\.call[ \t\r]*\n[ \t]*wndthreadid=getWindowThreadProcessId\.call\(wnd,processid\)[ \t\r]*\n[ \t]*return \(wndthreadid==threadid\)[ \t]*\r?\n/

    register('essentials_focus', 'Essentials pbSameThread: foco da janela sem criar Win32API a cada tecla',
             ['def pbSameThread(wnd)', 'GetWindowThreadProcessId', 'GetCurrentThreadId'], {}) do |source, index, scripts|
      next nil unless source =~ SAME_THREAD
      source.sub(SAME_THREAD) do
        indent = $1
        nl = $2
        indent + 'def pbSameThread(wnd)' + nl +
          indent + '  return false if wnd==0' + nl +
          indent + '  return KerberusLegacy18::WinBridge::Window.handle?(wnd)' + nl + nl * 5
      end
    end

    # 6.5: Essentials v16/v17 ReflectedSprite (reflections on still water)
    # updates every character of the map every frame, reading terrain tags
    # under each one, while Spriteset_Map updates only the characters near
    # the screen (in_range?, 6 tiles of border). A reflection of a character
    # outside that area cannot be seen: it is skipped, and its sprite is
    # disposed as the original does when a reflection must not show (it is
    # created again when the character comes near). Same line count.
    REFLECTION = /^([ \t]*return if disposed\?)(?=[ \t\r]*\n[ \t]*currentY=@event\.real_y)/

    register('essentials_reflections', 'Essentials ReflectedSprite: reflexos so de personagens perto da tela',
             ['class ReflectedSprite', 'currentY=@event.real_y', 'shouldShow'], {}) do |source, index, scripts|
      next nil unless source =~ REFLECTION
      source.sub(REFLECTION) { $1 + ' || KerberusLegacy18::Ports.reflection_far?(self, @event)' }
    end

    REFLECTION_BORDER = 192 * 4

    # Same area as Spriteset_Map#in_range? (6 tiles around the screen); the
    # usual case (near) costs a few integer comparisons.
    def self.reflection_far?(reflection, event)
      map = event.map
      return false unless map
      x = event.real_x - map.display_x
      return false if x > -REFLECTION_BORDER && x < Graphics.width * 4 + REFLECTION_BORDER &&
                      (y = event.real_y - map.display_y) > -REFLECTION_BORDER &&
                      y < Graphics.height * 4 + REFLECTION_BORDER
      # Perspective view (tilemap 2) draws every character: nothing is skipped.
      return false if defined?($PokemonSystem) && $PokemonSystem &&
                      $PokemonSystem.respond_to?(:tilemap) && $PokemonSystem.tilemap == 2
      sprite = reflection.instance_variable_get(:@sprite)
      if sprite
        sprite.dispose
        reflection.instance_variable_set(:@sprite, nil)
      end
      true
    end

    # 6.6: H-Mode7 (MGC_Hmode7.dll -> kerberus/hm7-core.h) draws characters
    # from CPU copies of their bitmaps. HM7::Surface#update redraws a
    # character's bitmap on the GPU (clear + blt) whenever its pose changes,
    # so the next frame had to read it back (one GPU sync per changed
    # character). The same copy is made on the CPU from the character sheet,
    # which is read once; the original lines stay as the fallback. Same pixels,
    # same line count.
    HM7_SURFACE = /^([ \t]*)bitmap\.clear([ \t]*\r?\n)([ \t]*)bitmap\.blt\(0, 0, bitmap_set, Rect\.new\(@sx, @sy, @cw, @ch - @offset_height\)\)([ \t]*\r?\n(?:[ \t]*#[^\n]*\n)*)([ \t]*)HM7\.apply_opacity\(bitmap, character\.opacity\)/

    register('hm7_surface', 'H-Mode7: poses dos personagens copiadas na CPU (sem ler a GPU a cada mudanca)',
             ['module HM7', 'class Surface', 'HM7.apply_opacity(bitmap, character.opacity)'], {}) do |source, index, scripts|
      next nil unless source =~ HM7_SURFACE
      source.sub(HM7_SURFACE) do
        $1 + 'unless KerberusLegacy18::Ports.hm7_surface(bitmap, bitmap_set, @sx, @sy, @cw, @ch - @offset_height, character.opacity)' +
          $2 + $3 + '  bitmap.clear; bitmap.blt(0, 0, bitmap_set, Rect.new(@sx, @sy, @cw, @ch - @offset_height))' +
          $4 + $5 + '  HM7.apply_opacity(bitmap, character.opacity); end'
      end
    end

    # 6.6: the HM7 scripts set the fading colour in pixel (0, 0) of the rows
    # bitmap before every computeM7; the native set_pixel keeps the renderer's
    # CPU copy valid instead of reading the bitmap back from the GPU.
    HM7_ROWS = /@rowsdata\.set_pixel\(0, 0, /

    register('hm7_rows', 'H-Mode7: cor de fade aplicada tambem na copia da CPU (sem ler a GPU a cada giro de camera)',
             ['module HM7', 'HM7.compute_m7(@computetable, @rowsdata, @parameters)', '@rowsdata.set_pixel(0, 0, '], {}) do |source, index, scripts|
      source.gsub(HM7_ROWS) { 'KerberusLegacy18::Ports.hm7_set_pixel(@rowsdata, 0, 0, ' }
    end

    # Essentials' Sockets script (and the online scripts copied from it)
    # turns WSAGetLastError into an Errno class by comparing
    # Errno::X.new.errno with the Winsock code. Ruby on Windows numbers the
    # socket errors with the Winsock codes (ECONNREFUSED is 10061 there); Ruby
    # 1.8 on Android has the Linux numbers, so nothing matched and
    # const_get(nil) raised a TypeError instead of the network error. The
    # lookup now uses the Windows numbering; a code Windows Ruby has no class
    # for fails the same way it does there.
    WSA_ERRNO = /Errno\.const_get\(\s*Errno\.constants\.detect\s*\{\s*\|\s*(\w+)\s*\|\s*Errno\.const_get\(\s*\1\s*\)\.new\.errno\s*==\s*(\w+)\s*\}\s*\)/m
    # Ruby 1.8 win32/win32.h: errno names defined as Winsock codes.
    WSA_ERRNO_NAMES = {
      10035 => 'EWOULDBLOCK', 10036 => 'EINPROGRESS', 10037 => 'EALREADY', 10038 => 'ENOTSOCK',
      10039 => 'EDESTADDRREQ', 10040 => 'EMSGSIZE', 10041 => 'EPROTOTYPE', 10042 => 'ENOPROTOOPT',
      10043 => 'EPROTONOSUPPORT', 10044 => 'ESOCKTNOSUPPORT', 10045 => 'EOPNOTSUPP',
      10046 => 'EPFNOSUPPORT', 10047 => 'EAFNOSUPPORT', 10048 => 'EADDRINUSE', 10049 => 'EADDRNOTAVAIL',
      10050 => 'ENETDOWN', 10051 => 'ENETUNREACH', 10052 => 'ENETRESET', 10053 => 'ECONNABORTED',
      10054 => 'ECONNRESET', 10055 => 'ENOBUFS', 10056 => 'EISCONN', 10057 => 'ENOTCONN',
      10058 => 'ESHUTDOWN', 10059 => 'ETOOMANYREFS', 10060 => 'ETIMEDOUT', 10061 => 'ECONNREFUSED',
      10062 => 'ELOOP', 10064 => 'EHOSTDOWN', 10065 => 'EHOSTUNREACH', 10067 => 'EPROCLIM',
      10068 => 'EUSERS', 10069 => 'EDQUOT', 10070 => 'ESTALE', 10071 => 'EREMOTE'
    }

    register('winsock_errno', 'Erro Winsock -> classe Errno com a numeracao do Ruby do Windows',
             ['WSAGetLastError', 'Errno.constants.detect'], {}) do |source, index, scripts|
      source.gsub(WSA_ERRNO) do
        text, code = $&, $2
        'Errno.const_get(KerberusLegacy18::Ports.wsa_errno_name(' + code + '))' + "\n" * text.count("\n")
      end
    end

    # Name of the Errno class Ruby on Windows has for a Winsock code, or nil.
    def self.wsa_errno_name(code)
      name = WSA_ERRNO_NAMES[code.to_i]
      name && ::Errno.const_defined?(name) ? name : nil
    end

    def self.hm7_set_pixel(bitmap, x, y, color)
      return bitmap.set_pixel(x, y, color) unless defined?(::KerberusNative) && ::KerberusNative.respond_to?(:hm7_set_pixel)
      ::KerberusNative.hm7_set_pixel(bitmap, x, y, color)
    end

    def self.hm7_surface(bitmap, sheet, x, y, w, h, opacity)
      return false unless defined?(::KerberusNative) && ::KerberusNative.respond_to?(:hm7_surface)
      ::KerberusNative.hm7_surface(bitmap, sheet, x, y, w, h, opacity)
    end

    register('font_installer', 'FontInstaller: fontes de Fonts/ ja indexadas pelo mkxp-z',
             ['FontInstaller', 'AddFontResource', 'WriteProfileString'], {}) do |source, index, scripts|
      source.gsub(/^([ \t]*)FontInstaller\.install\s*$/) { $1 + "KerberusLegacy18.event('PORT_INSTALLED', 'font_installer', 'instalacao no sistema ignorada; Fonts/ indexado pelo mkxp-z')" }
    end

    register('text_entry', 'Entrada de texto por teclado -> Input.gets (teclado Android/IME)',
             ['class Window_TextEntry_Keyboard', '@toUnicode', 'GetKeyboardState'], {}) do |source, index, scripts|
      # Scripts.rxdata keeps the RMXP editor's CRLF line ends.
      start = source.index('    if !@toUnicode')
      finish = start && source.index(/\r?\n  end\r?\nend/, start)
      if start && finish
        replacement = "    KerberusLegacy18::Ports::TextEntry.incoming.each { |character| insert(character) }\n"
        source[0, start] + Source.pad(source[start, finish - start] + "\n", replacement).chomp + source[finish, source.length - finish] +
          "\nKerberusLegacy18::Ports::TextEntry.install\n"
      else
        KerberusLegacy18.event('PORT_SKIPPED', 'text_entry', 'estrutura do editor diferente; ToUnicode/GetKeyboardState genericos continuam ativos', true)
        nil
      end
    end

    register('unicode_pointer', 'Strings de ponteiro -> buffers Ruby/heap virtual',
             ['def getUnicodeStringFromAnsi(addr)', 'def getUnicodeString(addr)'], {}) do |source, index, scripts|
      text = Source.method_body(source, 'getUnicodeStringFromAnsi',
                                "return KerberusLegacy18::Ports.ansi_string(addr)")
      Source.method_body(text, 'getUnicodeString', "return KerberusLegacy18::Ports.wide_string(addr)")
    end

    register('zeus_video', 'Zeus Video Player (MCI/AVI) -> Graphics.play_movie',
             [':Zeus_Video_Player', 'MciSendString', 'ZVP_OldAviMode'], :provides => %w(Graphics)) do |source, index, scripts|
      Source.pad(source, "# Kerberus Ports: Zeus Video Player\nKerberusLegacy18::Ports::Movies.install\n")
    end

    def self.ansi_string(value)
      return '' if KerberusLegacy18::WinBridge::Buffers.null?(value)
      bytes = KerberusLegacy18::WinBridge::Buffers.c_string(value).to_s
      begin
        bytes.unpack('U*')
        bytes
      rescue ArgumentError
        KerberusLegacy18::WinBridge::Text.cp1252_to_utf8(bytes)
      end
    end

    def self.wide_string(value)
      KerberusLegacy18::WinBridge::Buffers.wide_string(value) || ''
    end
  end
end

# ==== 93_session.rb ====
# Kerberus - "Salvar agora" from the Kerberus in-game menu (6.5).
#
# The request comes from Java through the engine (kerberus-session.h) and is
# served here, inside Graphics.update, by the game's own save routine: the
# same pbSave(), same file, same backups, as the Save option of the game's
# menu. Nothing is saved unless the game is at a safe point, where saving
# from the game's own menu would give the same result:
#   * the field (Scene_Map), with Graphics.update called straight from the
#     map loop (Scene_Map#main) - no menu, message, battle or other screen
#     running inside Scene_Map#update;
#   * the player standing still, no map event running, no transfer or
#     transition pending;
#   * not a new game started in this session: the game's menu confirms the
#     replacement of an existing save there, so the first save stays with it.
# Otherwise the reply names the reason (the launcher words it for the
# player) and nothing is written. Games without Pokemon Essentials' pbSave
# are told to save from their own menu.
# Replies: save:ok, save:fail, save:busy:<reason>, save:unsupported:<reason>.
module KerberusLegacy18
  module Session
    OWN_FILE = /\A(?:Kerberus|kerberus)/
    OWN_METHODS = %w(save_now serve)

    # Engine entry point (binding-mri.cpp): code 1 = save now.
    def self.serve(code, arg)
      return 'request:' + code.to_s + ':unsupported' unless code == 1
      save_now
    end

    def self.save_now
      reason = unsupported_reason
      return 'save:unsupported:' + reason if reason
      reason = busy_reason(caller(0))
      return 'save:busy:' + reason if reason
      ok = Object.new.send(:pbSave)
      KerberusLegacy18.runtime_trace('SESSAO', 'salvar agora (menu Kerberus): ' + (ok ? 'salvo pelo pbSave do jogo' : 'pbSave do jogo informou falha'))
      ok ? 'save:ok' : 'save:fail'
    end

    def self.unsupported_reason
      return 'no_pbsave' unless Object.private_method_defined?(:pbSave) || Object.method_defined?(:pbSave)
      return 'not_loaded' unless defined?(::Scene_Map) && $game_player && $game_map && $game_temp
      nil
    end

    def self.busy_reason(frames)
      return 'scene' unless $scene.is_a?(::Scene_Map)
      temp = $game_temp
      return 'battle' if flag?(temp, :in_battle)
      return 'message' if flag?(temp, :message_window_showing)
      return 'transfer' if flag?(temp, :player_transferring) || flag?(temp, :transition_processing)
      return 'menu' if flag?(temp, :menu_calling) || flag?(temp, :in_menu)
      return 'moving' if $game_player.respond_to?(:moving?) && $game_player.moving?
      return 'event' if interpreter_running?
      if defined?($PokemonTemp) && $PokemonTemp && $PokemonTemp.respond_to?(:begunNewGame) && $PokemonTemp.begunNewGame
        return 'newgame'
      end
      return 'screen' unless map_loop?(frames)
      nil
    end

    def self.flag?(object, name)
      object.respond_to?(name) && object.send(name) ? true : false
    end

    def self.interpreter_running?
      interpreter = if $game_map.respond_to?(:interpreter) then $game_map.interpreter
                    elsif $game_system && $game_system.respond_to?(:map_interpreter) then $game_system.map_interpreter
                    end
      interpreter && interpreter.respond_to?(:running?) && interpreter.running? ? true : false
    end

    # frames: caller(0) from save_now. Above the game's call are this module
    # and Graphics.update with its wrappers (Kerberus Frame, or a game's own
    # alias such as Uranium's update_KGC_SpecialTransition); the first frame
    # below them must be Scene_Map#main, and no method with update in its
    # name may be further down (menus, messages and battles run inside
    # Scene_Map#update). An unusual stack is refused, never guessed.
    def self.map_loop?(frames)
      names = frames.map { |frame| frame.to_s[/in `([^']*)'\z/, 1].to_s }
      index = 0
      index += 1 while index < names.length &&
                       (OWN_FILE =~ frames[index].to_s || OWN_METHODS.include?(names[index]) || names[index] =~ /update/i)
      return false unless index < names.length && names[index] =~ /main/
      names[(index + 1)..-1].each { |name| return false if name =~ /update/i }
      true
    end
  end
end

# ==== 94_idle_gc.rb ====
# Kerberus - Ruby collections at idle moments (6.4.3).
#
# Ruby 1.8 collects with a full mark and sweep of every live object; a
# Pokemon Essentials game keeps over a million, so a collection while the
# player walks or battles is a visible hitch. Two moments hide it:
#  * scene transitions: RGSS games freeze the screen (Graphics.freeze ...
#    Graphics.transition) and a collection right before the transition is
#    not seen;
#  * a message on screen ($game_temp.message_window_showing, RMXP and
#    Essentials) for MESSAGE_FRAMES frames: the player is reading.
# There, when the process has already gone past a threshold of the way to
# its next collection (GC.kerberus_pressure, patched Ruby 1.8), the
# collection runs now instead of later during play. It changes when a
# collection happens, never what it frees.
#   KERBERUS_IDLE_GC=off        disabled
#   KERBERUS_IDLE_GC=<1..100>   threshold in percent (default 50)
module KerberusLegacy18
  module IdleGc
    DEFAULT_THRESHOLD = 50
    MESSAGE_FRAMES = 20
    @count = 0
    @total_ns = 0
    @frozen = false
    @message_frames = 0
    @installed = false
    @threshold = DEFAULT_THRESHOLD
    class << self
      attr_reader :count, :total_ns, :threshold
    end

    def self.installed?
      @installed
    end

    def self.install
      return false if @installed || !defined?(::Graphics)
      setting = KerberusLegacy18.config[:idle_gc]
      return false if setting == 'off'
      unless ::GC.respond_to?(:kerberus_pressure)
        KerberusLegacy18.event('IDLE_GC', 'GC', 'interpretador sem GC.kerberus_pressure: coleta em momentos ociosos desligada', true)
        return false
      end
      @threshold = setting.to_i.between?(1, 100) ? setting.to_i : DEFAULT_THRESHOLD
      @installed = true
      KerberusLegacy18.meta(::Graphics).module_eval(<<-RUBY, 'Kerberus IdleGc', 1)
        alias_method :kerberus_idle_gc_freeze, :freeze
        alias_method :kerberus_idle_gc_transition, :transition
        def freeze(*args)
          result = kerberus_idle_gc_freeze(*args)
          KerberusLegacy18::IdleGc.frozen!
          result
        end
        def transition(*args)
          KerberusLegacy18::IdleGc.transition!
          kerberus_idle_gc_transition(*args)
        end
      RUBY
      true
    end

    def self.frozen!
      @frozen = true
    end

    # Only while the screen is frozen: Graphics.transition without a
    # freeze returns at once and a collection there would be seen.
    def self.transition!
      frozen = @frozen
      @frozen = false
      frozen ? collect : false
    end

    # Once per message, after it has been on screen for MESSAGE_FRAMES.
    def self.tick
      return unless @installed
      temp = $game_temp
      if temp && temp.respond_to?(:message_window_showing) && temp.message_window_showing
        @message_frames += 1
        collect if @message_frames == MESSAGE_FRAMES
      else
        @message_frames = 0
      end
    end

    def self.collect
      return false if ::GC.kerberus_pressure < @threshold
      spent = ::GC.kerberus_stats[1]
      ::GC.start
      @total_ns += ::GC.kerberus_stats[1] - spent
      @count += 1
      true
    end
  end
end

# ==== 95_frame.rb ====
# Kerberus frame hook: one cheap call per Graphics.update.
# Audio fade-in is game behaviour and propagates its errors normally.
# Recorder/milestone polling and the performance report are diagnostics
# only: if they ever fail they are disabled and the failure is written to
# the runtime report.
#
# Performance report (6.4): wall time between Graphics.update calls, so it
# includes the engine's own frame pacing. Every perf_window frames one
# [PERF] line goes to the runtime log: frames per second, mean and worst
# frame, an upper bound for the 95th percentile, frames slower than 50 ms,
# and the Ruby collections of the window (GC.kerberus_stats, patched
# Ruby 1.8; those run at idle moments by 94_idle_gc.rb counted apart).
# No allocation per frame beyond the integer arithmetic.
module KerberusLegacy18
  module Frame
    @count = 0
    @diagnostics = true
    @installed = false

    # Upper bounds (ms) of the frame-time histogram used for the p95 bound.
    BUCKETS = [17, 25, 34, 50, 67, 100, 200, 500]

    def self.reset!
      @count = 0
      @diagnostics = true
      reset_window!
      @last_ns = nil
    end

    def self.reset_window!
      @window_frames = 0
      @window_start = nil
      @window_max = 0
      @window_slow = 0
      @histogram = Array.new(BUCKETS.length + 1, 0)
      @gc_start = gc_stats
      @idle_start = [IdleGc.count, IdleGc.total_ns]
    end

    def self.gc_stats
      defined?(::GC) && ::GC.respond_to?(:kerberus_stats) ? ::GC.kerberus_stats : nil
    end

    # RGSS1 skipped drawing frames when a game fell behind, so the game
    # kept its speed on slow machines; mkxp-z ships with this off.
    def self.enable_frameskip
      return false unless KerberusLegacy18.config[:frameskip]
      return false unless KerberusLegacy18.native?('Graphics', :frameskip=)
      KerberusLegacy18.native('Graphics', :frameskip=, true)
      KerberusLegacy18.event('FRAMESKIP', 'Graphics', 'pulo de quadros do RGSS1 ativo: o jogo mantem a velocidade quando o aparelho atrasa', true)
      true
    end

    def self.measure(now)
      if @last_ns
        ms = (now - @last_ns) / 1000000
        @window_frames += 1
        @window_max = ms if ms > @window_max
        @window_slow += 1 if ms > 50
        index = 0
        index += 1 while index < BUCKETS.length && ms > BUCKETS[index]
        @histogram[index] += 1
      else
        @window_start = now
      end
      @last_ns = now
      report(now) if @window_frames >= KerberusLegacy18.config[:perf_window]
    end

    def self.report(now)
      elapsed_ms = (now - @window_start) / 1000000.0
      fps = elapsed_ms > 0 ? @window_frames * 1000.0 / elapsed_ms : 0.0
      target = (@window_frames * 95 + 99) / 100
      seen = 0
      p95 = nil
      @histogram.each_with_index do |count, index|
        seen += count
        if seen >= target
          p95 = index < BUCKETS.length ? '<=' + BUCKETS[index].to_s : '>' + BUCKETS[-1].to_s
          break
        end
      end
      line = format('quadros=%d fps=%.1f quadro_medio=%.1fms p95%sms pior=%dms lentos(>50ms)=%d',
                    @window_frames, fps, elapsed_ms / @window_frames, p95.to_s, @window_max, @window_slow)
      now_gc = gc_stats
      if now_gc && @gc_start
        count = now_gc[0] - @gc_start[0]
        total = (now_gc[1] - @gc_start[1]) / 1000000.0
        line << format(' gc=%d (%.0fms no total, pior %.0fms, heap %d objetos; %d em momentos ociosos, %.0fms)', count, total,
                       now_gc[2] / 1000000.0, now_gc[3], IdleGc.count - @idle_start[0],
                       (IdleGc.total_ns - @idle_start[1]) / 1000000.0)
      end
      line << ' frameskip=' + (KerberusLegacy18.native?('Graphics', :frameskip) && KerberusLegacy18.native('Graphics', :frameskip) ? 'on' : 'off')
      KerberusLegacy18.runtime_trace('PERF', line)
      reset_window!
      @window_start = now
    end

    def self.install
      return false if @installed || !defined?(::Graphics)
      @installed = true
      KerberusLegacy18.meta(::Graphics).module_eval(<<-RUBY, 'Kerberus Frame', 1)
        alias_method :kerberus_frame_update, :update
        def update(*args)
          result = kerberus_frame_update(*args)
          KerberusLegacy18::Frame.tick
          result
        end
      RUBY
      true
    end

    def self.tick
      @count += 1
      WinBridge::AudioBridge.tick if WinBridge::AudioBridge.fading_in?
      IdleGc.tick
      return unless @diagnostics
      begin
        measure(KerberusLegacy18.monotonic_ns)
        Recorder.tick
        Paths.clear_misses if @count % 60 == 0
        Milestones.poll if @count % 30 == 0
      rescue StandardError => error
        @diagnostics = false
        KerberusLegacy18.runtime_block('KERBERUS_DIAGNOSTICS_DISABLED', KerberusLegacy18.describe_exception(error))
      end
    end

    @last_ns = nil
    reset_window!
  end
end

# ==== 97_profiles.rb ====
# Evidence-based profile detection. Profiles only label the game and add
# diagnostics; behaviour comes from generic WinBridge providers and Ports
# selected by script content, never by the game's name.
module KerberusLegacy18
  module Profiles
    RULES = [
      ['Pokemon Uranium', [['RGSSLinker_Initialize', 'Uranium.ini']]],
      ['Pokemon Insurgence', [['MGC_Hmode7', 'renderHM7'], ['Insurgence']]],
      ['Pokemon Xenoverse', [['Xenoverse']]],
      ['Pokemon Infinite Fusion', [['Infinite Fusion']]]
    ]

    def self.sources(scripts)
      (scripts || []).map { |entry| entry.is_a?(Array) ? entry[3].to_s : '' }
    end

    def self.detect(scripts)
      texts = sources(scripts)
      found = []
      RULES.each do |rule|
        ok = rule[1].all? { |markers| texts.any? { |text| markers.all? { |marker| text.index(marker) } } }
        found << rule[0] if ok
      end
      found
    end

    # "# Pokemon Essentials / # Version X" header, or an ESSENTIALS_VERSION constant.
    def self.essentials_version(scripts)
      sources(scripts).each do |text|
        return $1 if text =~ /^\s*#\s*Pok.mon Essentials\s*#?\s*\r?\n\s*#\s*Version\s+([0-9]+(?:\.[0-9]+){0,3})/i
        return $1 if text =~ /^\s*ESSENTIALS_VERSION\s*=\s*["']([^"']+)["']/
        return $1 if text =~ /^\s*ESSENTIALSVERSION\s*=\s*["']([^"']+)["']/
      end
      nil
    end

    def self.report(scripts)
      names = detect(scripts)
      version = essentials_version(scripts)
      detail = 'perfis=' + (names.empty? ? 'nenhum' : names.join(',')) +
               ' essentials=' + (version || 'nao identificado') +
               ' secoes=' + (scripts ? scripts.length : 0).to_s
      KerberusLegacy18.event('PROFILE', 'legacy18', detail, true)
      if names.include?('Pokemon Infinite Fusion')
        KerberusLegacy18.event('PROFILE_WARNING', 'Pokemon Infinite Fusion',
                               'o runtime validado para este jogo e modern31; verifique .kerberus-runtime', true)
      end
      names
    end
  end
end

# ==== 99_activate.rb ====
# Activation: runs once, after $RGSS_SCRIPTS is decoded, before Section000.
module KerberusLegacy18
  @activated = false

  def self.activated?
    @activated
  end

  def self.dump_scripts(scripts)
    directory = data_dir('scripts')
    return unless directory
    scripts.each_with_index do |entry, index|
      next unless entry.is_a?(Array) && entry[3].is_a?(String)
      name = format('%03d', index) + '-' + entry[1].to_s.gsub(/[^A-Za-z0-9_.-]+/, '_')[0, 40] + '.rb'
      raw_write(File.join(directory, name), entry[3], 'wb')
    end
  end

  def self.activate(scripts)
    return false if @activated
    @activated = true
    remember_native
    uranium = Profiles.sources(scripts).any? { |text| text.index('RGSSLinker_Initialize') && text.index('Uranium.ini') }
    Paths.install if config[:filesystem]
    WinBridge.install
    WinEnv.install
    IoEof.install
    ZlibGuard.install
    Recorder.scan_static(scripts)
    Profiles.report(scripts)
    applied = Ports.apply_all(scripts)
    Ruby181.apply_all(scripts)
    $KERBERUS_URANIUM_COMPAT_ACTIVE = true if uranium
    Frame.install
    Frame.enable_frameskip
    IdleGc.install
    dump_scripts(scripts) if config[:dump_scripts]
    at_exit { KerberusLegacy18::Recorder.flush('exit') }
    event('LEGACY18_READY', 'Kerberus ' + VERSION,
          'WinBridge ativo; ports aplicados=' + applied.to_s + '; filesystem=' + (config[:filesystem] ? 'windows' : 'nativo') +
          '; wintrace=' + trace_level, true)
    true
  end
end

KerberusLegacy18.activate($RGSS_SCRIPTS) if defined?($RGSS_SCRIPTS) && $RGSS_SCRIPTS
