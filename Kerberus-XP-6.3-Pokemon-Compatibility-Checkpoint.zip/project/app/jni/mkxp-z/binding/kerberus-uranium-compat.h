#pragma once
static const char *KERBERUS_URANIUM_COMPAT_RUBY = R"KUC(
# Kerberus Shared Compatibility. No game file is edited by these modules.
module Kerberus
  module Compatibility
    VERSION = '5.2.0'
    class Unavailable < StandardError; end
    class InvalidParameter < ArgumentError; end
    @seen = {}
    @events = []
    @native = {}
    class << self
      attr_reader :events, :profile, :native
      def event(state, api, detail = '')
        key = [state, api]
        return if @seen[key] || @seen.length >= 512
        @seen[key] = true
        origin = caller_locations(1, 12).find { |f| f.path.to_s.match?(/Section\d+|\.rxdata/) }
        location = origin ? "#{File.basename(origin.path)}:#{origin.lineno}" : 'compatibility'
        if origin && (section = origin.path.match(/Section(\d+)/)) && defined?($RGSS_SCRIPTS) && $RGSS_SCRIPTS
          entry = $RGSS_SCRIPTS[section[1].to_i]
          location = "#{entry[1].to_s[0,120]}:#{origin.lineno}" if entry.is_a?(Array)
        end
        line = "[#{state}] #{api} #{location} #{detail}".gsub(/[\r\n\t]/, ' ')[0, 512]
        @events << line
        @events.shift if @events.length > 128
        System.puts(line) if defined?(System) && System.respond_to?(:puts)
        path = ENV['KERBERUS_COMPAT_LOG']
        if path && !path.empty?
          begin
            File.rename(path, path + '.previous') if File.file?(path) && File.size(path) >= 65536
            File.open(path, 'ab') { |file| file.write(line + "\n") }
          rescue SystemCallError, IOError
            # A full diagnostic partition must not change the game's result.
          end
        end
      end
      def unavailable(api, reason = 'Recurso ainda sem equivalente seguro no Android')
        event('API_MISSING', api, reason)
        raise Unavailable, "Kerberus: #{api}: #{reason}"
      end
      def remember_native
        {Input => [:update, :press?, :trigger?, :repeat?, :release?, :count,
                   :pressex?, :triggerex?, :repeatex?, :releaseex?, :repeatcount,
                   :mouse_x, :mouse_y, :scroll_v, :gets, :text_input=],
         Audio => [:bgm_play, :bgm_stop, :bgm_fade, :bgm_pos, :bgs_play, :bgs_stop,
                   :bgs_fade, :bgs_pos, :me_play, :me_stop, :me_fade, :se_play, :se_stop],
         Graphics => [:width, :height, :snap_to_bitmap, :resize_screen]}.each do |mod, names|
          names.each { |name| @native[[mod.name, name]] ||= mod.method(name) if mod.respond_to?(name) }
        end
      end
      def call_native(mod, name, *args)
        method = @native[[mod, name]]
        unavailable("#{mod}.#{name}", 'Binding nativo ausente') unless method
        method.call(*args)
      end
      def buffer(value, size, writable = true)
        unless size.is_a?(Integer) && size.between?(0, 16 * 1024 * 1024) &&
               value.is_a?(String) && value.bytesize >= size && (!writable || !value.frozen?)
          raise InvalidParameter, "Buffer Ruby #{writable ? 'gravavel' : 'legivel'} de #{size} bytes necessario; ponteiros numericos rejeitados"
        end
        value
      end
      def put(buffer, data)
        self.buffer(buffer, data.bytesize)
        original_encoding = buffer.encoding
        buffer.force_encoding('ASCII-8BIT')
        buffer[0, data.bytesize] = data.b
        buffer.force_encoding(original_encoding)
        data.bytesize
      end
      def null?(value); value.nil? || value == 0; end
      def string(value)
        raise InvalidParameter, 'String necessaria' unless value.is_a?(String)
        value.split("\0", 2).first.to_s
      end
      def relative_file(path)
        value = string(path).tr('\\', '/')
        full = File.expand_path(value, Dir.pwd)
        base = File.realpath(Dir.pwd) + '/'
        raise InvalidParameter, 'Caminho fora do jogo' unless full.start_with?(base)
        parent = full
        parent = File.dirname(parent) until File.exist?(parent) || File.symlink?(parent)
        resolved = File.realpath(parent)
        raise InvalidParameter, 'Link fora do jogo' unless resolved == base.delete_suffix('/') || resolved.start_with?(base)
        full
      end
    end
  end
end

Kerberus::Compatibility::API_CATALOG = {["advapi32","GetUserName"]=>[["PP:I"],"fallback","Nome virtual Player, sem ler nome pessoal do aparelho; buffer e tamanho Win32 validados."],
["advapi32","RegCloseKey"]=>[["I:I"],"fallback","Libera somente handles virtuais emitidos pelo provider; handle desconhecido retorna erro 6."],
["advapi32","RegOpenKeyExA"]=>[["IPIIP:I"],"fallback","Registro virtual somente leitura HKCU/Software/Enterbrain/RGSS. Nenhuma chave Windows real; chave ausente retorna erro 2."],
["advapi32","RegQueryValueExA"]=>[["IPIPPP:I"],"fallback","Somente PlayMusic/PlaySound DWORD. Consultas de tamanho, buffer curto e chave ausente retornam status Win32 explicitos."],
["audio","AudioContextFadeIn"]=>[["II:V"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["audio","AudioContextFadeOut"]=>[["II:V"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["audio","AudioContextFree"]=>[["I:V"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["audio","AudioContextGetPosition"]=>[["I:I"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["audio","AudioContextInitialize"]=>[[":I"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["audio","AudioContextIsActive"]=>[["I:I"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["audio","AudioContextPlay"]=>[["IPIIII:V"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["audio","AudioContextSEPlay"]=>[["IPIII:V"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["audio","AudioContextSetVolume"]=>[["II:V"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["audio","AudioContextStop"]=>[["I:V"],"profile","Substituicao por Audio nativo antes de construir estas APIs; ponteiros DLL nunca usados."],
["gdi32","AddFontResource"]=>[["P:I"],"fallback","Fontes locais indexadas pelo mkxp; instalacao no sistema Windows indisponivel."],
["gif","CopyDataString"]=>[["IPI:I"],"profile","Substituicao por Bitmap GIF animado nativo, sem arquivos PNG temporarios."],
["gif","FreeDataString"]=>[["I:V"],"profile","Substituicao por Bitmap GIF animado nativo, sem arquivos PNG temporarios."],
["gif","GifToPngFiles"]=>[["PP:I"],"profile","Substituicao por Bitmap GIF animado nativo, sem arquivos PNG temporarios."],
["gif","GifToPngFilesInMemory"]=>[["PIP:I"],"profile","Substituicao por Bitmap GIF animado nativo, sem arquivos PNG temporarios."],
["kernel32","AllocConsole"]=>[[":I"],"unavailable","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","CreateConsoleScreenBuffer"]=>[["IIPIP:I"],"unavailable","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","FormatMessageA"]=>[["IPIIPIP:I"],"fallback","Mensagem local com codigo numerico; nao reproduz tabelas nem FORMAT_MESSAGE_ALLOCATE_BUFFER do Windows."],
["kernel32","FreeLibrary"]=>[["P:I"],"fallback","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","GetCurrentProcess"]=>[[":I"],"equivalent","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","GetCurrentThreadId"]=>[[":I"],"equivalent","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","GetLastError"]=>[[":I"],"equivalent","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","GetPrivateProfileString"]=>[["PPPPIP:I"],"equivalent","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","GetSystemPowerStatus"]=>[["P:I"],"fallback","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","GetTickCount"]=>[[":I"],"equivalent","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","GetTickCount64"]=>[[":I"],"equivalent","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","GetUserDefaultLangID"]=>[[":I"],"fallback","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","GetUserGeoID"]=>[["I:I"],"fallback","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","LoadLibrary"]=>[["P:I","P:V"],"fallback","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","QueryPerformanceCounter"]=>[["P:I"],"equivalent","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","QueryPerformanceFrequency"]=>[["P:I"],"equivalent","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","ReadConsole"]=>[["IPIII:I"],"unavailable","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","RtlMoveMemory"]=>[["IPI:I","PII:I","PPI:V"],"fallback","Copia limitada a dois buffers Ruby com limites validados. Enderecos numericos RGSS1 sao rejeitados; Bitmap usa raw_data pelo perfil."],
["kernel32","SetConsoleActiveScreenBuffer"]=>[["I:I"],"unavailable","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","SetConsoleScreenBufferSize"]=>[["IP:I"],"unavailable","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","SetConsoleTitle"]=>[["P:I"],"unavailable","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","SetPriorityClass"]=>[["II:V"],"fallback","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","WriteConsole"]=>[["IPIII:I"],"unavailable","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kernel32","WriteProfileString"]=>[["PPP:I"],"fallback","Processo/relogio Android ou buffer Ruby; acesso a ponteiros reais proibido."],
["kleinbitmap","add_outline"]=>[["IIIII:V"],"unavailable","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","compare_bitmap"]=>[["II:I"],"profile","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","modify_color"]=>[["IIIIIII:V"],"profile","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","modify_pallete"]=>[["IP:V"],"unavailable","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","save_pallete"]=>[["IP:V"],"unavailable","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","scroll_down"]=>[["II:V"],"profile","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","scroll_left"]=>[["II:V"],"profile","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","scroll_right"]=>[["II:V"],"profile","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","scroll_up"]=>[["II:V"],"profile","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","set_pattern"]=>[["III:V"],"profile","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","to_negative"]=>[["I:V"],"profile","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","to_retro"]=>[["IIIIIIIIIIIII:V"],"unavailable","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["kleinbitmap","version"]=>[[":I"],"unavailable","Operacoes Bitmap/Sprite em Ruby/mkxp; paletas proprietarias e retro/outline pendentes."],
["mgc_hmode7","applyLighting"]=>[["I:I"],"unavailable","HMode7 usa ponteiros RGSS1. Construcao permitida; execucao rejeitada explicitamente. Mapas HM7 precisam de backend."],
["mgc_hmode7","applyOpacity"]=>[["II:I"],"unavailable","HMode7 usa ponteiros RGSS1. Construcao permitida; execucao rejeitada explicitamente. Mapas HM7 precisam de backend."],
["mgc_hmode7","computeM7"]=>[["III:I"],"unavailable","HMode7 usa ponteiros RGSS1. Construcao permitida; execucao rejeitada explicitamente. Mapas HM7 precisam de backend."],
["mgc_hmode7","drawHeightmap"]=>[["IIII:I"],"unavailable","HMode7 usa ponteiros RGSS1. Construcao permitida; execucao rejeitada explicitamente. Mapas HM7 precisam de backend."],
["mgc_hmode7","drawMapTileset"]=>[["IIIII:I"],"unavailable","HMode7 usa ponteiros RGSS1. Construcao permitida; execucao rejeitada explicitamente. Mapas HM7 precisam de backend."],
["mgc_hmode7","drawTextureset"]=>[["III:I"],"unavailable","HMode7 usa ponteiros RGSS1. Construcao permitida; execucao rejeitada explicitamente. Mapas HM7 precisam de backend."],
["mgc_hmode7","refreshMapTileset"]=>[["IIII:I"],"unavailable","HMode7 usa ponteiros RGSS1. Construcao permitida; execucao rejeitada explicitamente. Mapas HM7 precisam de backend."],
["mgc_hmode7","renderHM7"]=>[["III:I"],"unavailable","HMode7 usa ponteiros RGSS1. Construcao permitida; execucao rejeitada explicitamente. Mapas HM7 precisam de backend."],
["msvcrt","_read"]=>[["IPI:I"],"unavailable","Console Windows sem backend; operacao rejeitada na chamada."],
["msvcrt","_write"]=>[["IPI:I"],"unavailable","Console Windows sem backend; operacao rejeitada na chamada."],
["ole32","CoTaskMemFree"]=>[["I:V"],"fallback","Nenhuma alocacao COM; apenas ponteiro nulo aceito."],
["rgss fmodex","Init_FmodEx"]=>[[":V"],"profile","BGM/BGS/ME/SE via mkxp Audio. LOOP_TABLE nao vazia necessita suporte a loop customizado."],
["rgss linker","RGSSLinker_Initialize"]=>[["P:I"],"profile","Loader Ruby 1.8 substituido por adaptador Audio; extensoes desconhecidas rejeitadas."],
["rpg.net","InputGetWheelDelta"]=>[[":I"],"equivalent","Roda do mouse via SDL Input.scroll_v."],
["rubyscreen","SwapRgb"]=>[["PI:V"],"equivalent","Screenshot e pixels via Graphics/Bitmap nativos; sem enderecos de objetos."],
["rubyscreen","TakeScreenshot"]=>[["P:I"],"profile","Screenshot e pixels via Graphics/Bitmap nativos; sem enderecos de objetos."],
["shell32","SHGetKnownFolderPath"]=>[["PIIP:I"],"fallback","Pastas Windows indisponiveis: falha documentada aciona pasta de saves local existente."],
["shell32","SHGetPathFromIDList"]=>[["IP:I"],"fallback","Pastas Windows indisponiveis: falha documentada aciona pasta de saves local existente."],
["shell32","SHGetSpecialFolderLocation"]=>[["IIP:I"],"fallback","Pastas Windows indisponiveis: falha documentada aciona pasta de saves local existente."],
["user32","FindWindowEx"]=>[["IIPP:I"],"equivalent","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","GetAsyncKeyState"]=>[["I:I"],"fallback","Estado pressionado via SDL; nao reproduz o bit de pressionamento desde a ultima consulta Win32."],
["user32","GetClientRect"]=>[["IP:I"],"equivalent","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","GetCursorPos"]=>[["P:I"],"equivalent","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","GetForegroundWindow"]=>[[":I"],"equivalent","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","GetKeyState"]=>[["I:I"],"fallback","Estado pressionado via SDL; nao reproduz bits de toggle do teclado Windows."],
["user32","GetKeyboardState"]=>[["P:I","P:V"],"fallback","256 bytes de estados SDL, sem bits de toggle. Editor de texto substituido por Input.gets/IME."],
["user32","GetSystemMetrics"]=>[["I:I"],"fallback","Somente dimensoes do viewport; outras metricas de desktop retornam indisponivel."],
["user32","GetWindowRect"]=>[["IP:I"],"equivalent","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","GetWindowThreadProcessId"]=>[["IP:I"],"equivalent","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","MapVirtualKey"]=>[["II:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","PeekMessage"]=>[["PIIII:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","PostMessage"]=>[["IIII:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","RegisterHotKey"]=>[["IIII:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","ReleaseCapture"]=>[[":I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","ScreenToClient"]=>[["IP:I"],"equivalent","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","SendMessage"]=>[["IIII:V"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","SetCapture"]=>[["P:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","SetWindowLong"]=>[["III:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","SetWindowPos"]=>[["IIIIIII:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","SetWindowTextA"]=>[["IP:I"],"equivalent","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","ShowCursor"]=>[["I:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","ShowWindow"]=>[["II:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["user32","ToUnicode"]=>[["IIPPII:I"],"fallback","Janela logica do runtime e SDL Input; sem HWND nativo de Windows."],
["winmm","mciGetErrorString"]=>[["IPI:I"],"fallback","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["winmm","mciSendString"]=>[["PPII:I","PPII:V"],"fallback","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["winmm","timeGetTime"]=>[[":I"],"equivalent","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["winmm","waveOutClose"]=>[["I:I"],"fallback","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["winmm","waveOutGetNumDevs"]=>[[":I"],"fallback","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["winmm","waveOutOpen"]=>[["PIPIII:I"],"fallback","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["winmm","waveOutPrepareHeader"]=>[["IPI:I"],"fallback","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["winmm","waveOutSetVolume"]=>[["II:I"],"fallback","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["winmm","waveOutUnprepareHeader"]=>[["IPI:I"],"fallback","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["winmm","waveOutWrite"]=>[["IPI:I"],"fallback","Timers suportados; waveOut/MCI sem backend retornam erro documentado e geram UNAVAILABLE."],
["ws2_32","WSAGetLastError"]=>[[":I"],"fallback","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","accept"]=>[["PPI:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","bind"]=>[["PPI:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","closesocket"]=>[["P:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","connect"]=>[["PPI:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","gethostbyaddr"]=>[["PII:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","gethostbyname"]=>[["P:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","gethostname"]=>[["PI:V"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","getservbyname"]=>[["PP:P"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","htonl"]=>[["I:I"],"equivalent","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","htons"]=>[["I:I"],"equivalent","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","inet_addr"]=>[["P:I"],"equivalent","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","inet_ntoa"]=>[["I:P"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","listen"]=>[["PI:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","recv"]=>[["PPII:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","select"]=>[["IPPPP:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","send"]=>[["PPII:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","setsockopt"]=>[["PIIPI:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","shutdown"]=>[["PI:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."],
["ws2_32","socket"]=>[["III:I"],"unavailable","Online indisponivel; construcao adiada e chamada rejeitada. Conversoes puras sao locais."]}.freeze

module Kerberus::Compatibility
  # Pure syntax transformations are staged and all sections are compiled before
  # any section is committed. Names in the RPG Maker editor are never selectors.
  module Source
    def self.method_body(source, name, body)
      expression = /^([ \t]*)def #{Regexp.escape(name)}(?=[ \t(\n;])(?:\([^\n]*\)|[^\n]*)\n.*?^\1end\b/m
      matches = source.scan(expression)
      raise ArgumentError, "Metodo ambiguo/ausente: #{name}" unless matches.length == 1
      source.sub(expression) { |old| old.lines.first + body.lines.map { |l| matches[0][0] + '  ' + l }.join + matches[0][0] + 'end' }
    end
    def self.signature(source, *markers); markers.all? { |marker| source.include?(marker) }; end

    def self.normalize_cjk_wordregexp(text)
      return [text, false] unless text.include?('module WordRegexp') &&
                                  text.include?('WesternLatinWord') &&
                                  text.include?('def self.requireCJKFont?')

      lines = text.lines
      start_index = nil
      indent = nil

      lines.each_with_index do |line, index|
        match = line.match(/^([ \t]*)module WordRegexp\s*$/)
        next unless match
        start_index = index
        indent = match[1]
        break
      end
      return [text, false] unless start_index

      end_index = nil
      ((start_index + 1)...lines.length).each do |index|
        if lines[index].match?(/^#{Regexp.escape(indent)}end\s*$/)
          tail = lines[(index + 1)..-1].to_a
          next_code = tail.find { |candidate| !candidate.strip.empty? }
          if next_code && next_code.match?(/^#{Regexp.escape(indent)}def self\.requireCJKFont\?/)
            end_index = index
            break
          end
        end
      end
      return [text, false] unless end_index

      inner = indent + '  '
      replacement = [
        "#{indent}module WordRegexp\n",
        "#{inner}HanZi = /[\\u3400-\\u4DBF\\u4E00-\\u9FFF]/u\n",
        "#{inner}Kana = /[\\u3041-\\u309F\\u30A1-\\u30FA\\u30FC]/u\n",
        "#{inner}CJ = /(?:#{'#{'}HanZi}|#{'#{'}Kana})/u\n",
        "#{inner}LatinCharSet = /\\p{Latin}/u\n",
        "#{inner}FullWidthLatin = /[\\uFF21-\\uFF3A\\uFF41-\\uFF5A]/u\n",
        "#{inner}FullWidthNumber = /[\\uFF10-\\uFF19]/u\n",
        "#{inner}GreekCharSet = /\\p{Greek}/u\n",
        "#{inner}WesternLatinWord = /(?:#{'#{'}LatinCharSet}|#{'#{'}GreekCharSet}|#{'#{'}FullWidthLatin}|[0-9]|#{'#{'}FullWidthNumber})+\\-?/u\n",
        "#{inner}NotAllowedAtStartSet = /[\\)\\]\\}>\\.,\\!?;:\\-~\\\"\\'%]/u\n",
        "#{inner}NotAllowedAtStartFullWidth = /[\\u2019\\u201D\\u2026\\u203A\\u3001\\u3002\\u3009\\u300B\\u300D\\u300F\\u3011\\u3015\\u3017\\uFE5E\\uFF01\\uFF09\\uFF0C\\uFF0D\\uFF1A\\uFF1B\\uFF1E\\uFF1F\\uFF3D\\uFF5E]/u\n",
        "#{inner}NotAllowedAtStart = /(?:#{'#{'}NotAllowedAtStartSet}|#{'#{'}NotAllowedAtStartFullWidth})/u\n",
        "#{inner}NotAllowedAtEndSet = /[\\(\\[\\{<\\$@]/u\n",
        "#{inner}NotAllowedAtEndFullWidth = /[\\uFE64\\uFE5D\\uFF08\\uFF1C\\u3010\\u300A\\u3016\\u3008\\u3014\\u300C\\u300E\\u201C\\u2018\\u2039]/u\n",
        "#{inner}NotAllowedAtEnd = /(?:#{'#{'}NotAllowedAtEndSet}|#{'#{'}NotAllowedAtEndFullWidth})/u\n",
        "#{inner}WordRegexp = /#{'#{'}NotAllowedAtEnd}*(#{'#{'}HanZi}|#{'#{'}Kana}|#{'#{'}WesternLatinWord}|\\S)#{'#{'}NotAllowedAtStart}*/u\n",
        "#{indent}end\n"
      ]

      lines[start_index..end_index] = replacement
      [lines.join, true]
    end

    def self.syntax(source)
      # Scripts.rxdata commonly yields ASCII-8BIT strings even when their bytes
      # are valid UTF-8. Ruby 3 then creates binary regexes from literal CJK/
      # Latin text while \u escapes create UTF-8 regexes, and interpolation
      # raises RegexpError. Promote only byte sequences that are valid UTF-8.
      bytes = source.b
      utf8 = bytes.dup.force_encoding(Encoding::UTF_8)
      source = utf8.valid_encoding? ? utf8 : bytes
      text = source.gsub("\r\n", "\n").gsub("\r", "\n")
      text, cjk_module_replaced = normalize_cjk_wordregexp(text)
      if cjk_module_replaced
        Kerberus::Compatibility.event(
          'RUBY3_PATCH',
          'CJK WordRegexp',
          'legacy byte-regexp module replaced by UTF-8-safe implementation'
        )
      else
        # Fallback for a repack that keeps the constants but changes the module
        # structure. These replacements are intentionally unconditional by
        # constant name; they do not rely on a minimum marker count.
        values = {
          'HanZi' => '[\u3400-\u4DBF\u4E00-\u9FFF]',
          'Kana' => '[\u3041-\u309F\u30A1-\u30FA\u30FC]',
          'FullWidthLatin' => '[\uFF21-\uFF3A\uFF41-\uFF5A]',
          'FullWidthNumber' => '[\uFF10-\uFF19]',
          'NotAllowedAtStartFullWidth' => '[\u2019\u201D\u2026\u203A\u3001\u3002\u3009\u300B\u300D\u300F\u3011\u3015\u3017\uFE5E\uFF01\uFF09\uFF0C\uFF0D\uFF1A\uFF1B\uFF1E\uFF1F\uFF3D\uFF5E]',
          'NotAllowedAtEndFullWidth' => '[\uFE64\uFE5D\uFF08\uFF1C\u3010\u300A\u3016\u3008\u3014\u300C\u300E\u201C\u2018\u2039]'
        }
        changed = []
        lines = text.lines.map do |line|
          key = values.keys.find { |name| line.match?(/^\s*#{Regexp.escape(name)}\s*=/) }
          if key
            indent = line[/^\s*/].to_s
            changed << key
            "#{indent}#{key} = /#{values[key]}/u\n"
          elsif line.match?(/^\s*(?:CJ|WordRegexp)\s*=.*\/n\s*(?:#.*)?$/)
            changed << 'dynamic'
            line.sub(/\/n(\s*(?:#.*)?)$/, '/u\1')
          else
            line
          end
        end
        text = lines.join
        unless changed.empty?
          Kerberus::Compatibility.event(
            'RUBY3_PATCH',
            'CJK WordRegexp fallback',
            "regex encoding normalized: #{changed.uniq.join(',')}"
          )
        end
      end
      # KERBERUS_CJK_DRAWTEXT_ENCODING_FIX_5203
      if text.include?('def getLineBrokenChunks') &&
         text.include?('CJKUtils::WordRegexp::WordRegexp')
        old_cjk_drawtext = 'textmsg.slice!(/(?:\\n|[ \\r\\t\\f]+|#{CJKUtils::WordRegexp::WordRegexp}[ \\r\\t\\f]*)/n)'
        new_cjk_drawtext = 'textmsg.slice!(/(?:\\n|[ \\r\\t\\f]+|#{CJKUtils::WordRegexp::WordRegexp}[ \\r\\t\\f]*)/u)'
        if text.include?(old_cjk_drawtext)
          text = text.sub(old_cjk_drawtext, new_cjk_drawtext)
          Kerberus::Compatibility.event('RUBY3_PATCH','CJK DrawText','outer regexp /n -> /u')
        end
      end

      # JSON grammar's C1 exclusion is Unicode, not an incomplete UTF-8 byte.
      if signature(text, 'stringLiterals', '\\x7f-\\x9f')
        text = text.lines.map { |line| line.include?('stringLiterals=') ? line.gsub('\\x7f-\\x9f', '\\u007f-\\u009f') : line }.join
      end
      # Ruby 1.8's obsolete numeric case delimiter. Only a numeric when clause.
      text = text.gsub(/^(\s*when\s+[+-]?\d+)\s*:(?=\s|$)/, '\\1 then')
      text
    end
  end
  module Ruby18
    ORIGINAL_STRING_INDEX = String.instance_method(:index)
    # Capture Ruby 3 byte primitives before any RGSS1 script can alias or
    # redefine them. All Kerberus byte adapters call these UnboundMethods
    # directly, so game monkey patches cannot change their return types.
    ORIGINAL_STRING_GETBYTE = String.instance_method(:getbyte)
    ORIGINAL_STRING_SETBYTE = String.instance_method(:setbyte)
    ORIGINAL_STRING_BYTESLICE = String.instance_method(:byteslice)
    ORIGINAL_STRING_BYTESIZE = String.instance_method(:bytesize)

    # KERBERUS_COMPAT_INDEX_NATIVE_510
    # ORIGINAL_STRING_INDEX foi capturado antes de qualquer String.prepend.
    # Chamar o UnboundMethod diretamente evita redispatch para GlobalStringBytes
    # e elimina a recursao infinita.
    def self.compat_index(string, needle, offset = 0)
      offset = Integer(offset)

      case needle
      when Integer
        byte = [needle & 255].pack('C')
        binary = string.b
        ORIGINAL_STRING_INDEX.bind(binary).call(byte, offset)

      when String
        binary = string.b
        target = needle.b
        ORIGINAL_STRING_INDEX.bind(binary).call(target, offset)

      else
        # Regexp e outros tipos usam diretamente o String#index original.
        ORIGINAL_STRING_INDEX.bind(string).call(needle, offset)
      end
    end

    def self.byte_at(string, index)
      raise TypeError, 'String necessaria para leitura de byte' unless string.is_a?(String)
      ORIGINAL_STRING_GETBYTE.bind(string).call(Integer(index))
    end

    def self.byte_slice(string, *args)
      raise TypeError, 'String necessaria para byteslice' unless string.is_a?(String)
      ORIGINAL_STRING_BYTESLICE.bind(string).call(*args)
    end

    def self.byte_size(string)
      raise TypeError, 'String necessaria para bytesize' unless string.is_a?(String)
      ORIGINAL_STRING_BYTESIZE.bind(string).call
    end

    def self.set_byte(string, index, value)
      raise TypeError, 'String necessaria para setbyte' unless string.is_a?(String)
      ORIGINAL_STRING_SETBYTE.bind(string).call(Integer(index), Integer(value) & 255)
    end

    # Ruby 1.8 treats String offsets as bytes. These adapters deliberately avoid
    # calling String#index, String#[]= or String#slice! internally after
    # String.prepend, because Ruby 3.1 can redispatch them through this module
    # and recurse indefinitely.
    def self.byte_index(string, needle, offset = 0)
      needle = [needle & 255].pack('C') if needle.is_a?(Integer)
      return nil unless needle.is_a?(String)

      hay_size = string.bytesize
      sub = needle.b
      sub_size = sub.bytesize
      start = Integer(offset)
      start += hay_size if start < 0
      return nil if start < 0 || start > hay_size
      return start if sub_size == 0
      return nil if sub_size > hay_size || start > hay_size - sub_size

      first = byte_at(sub, 0)
      limit = hay_size - sub_size
      i = start
      while i <= limit
        if byte_at(string, i) == first
          same = true
          j = 1
          while j < sub_size
            if byte_at(string, i + j) != byte_at(sub, j)
              same = false
              break
            end
            j += 1
          end
          return i if same
        end
        i += 1
      end
      nil
    end

    def self.replacement_bytes(value)
      return [value & 255] if value.is_a?(Integer)
      value = value.to_str unless value.is_a?(String)
      value.b.bytes
    end

    def self.byte_assign(string, *args)
      encoding = string.encoding
      bytes = string.b.bytes

      case args.length
      when 2
        selector, value = args
        if selector.is_a?(Integer) && value.is_a?(Integer)
          set_byte(string, selector, value & 255)
          return value
        end

        replacement = replacement_bytes(value)
        if selector.is_a?(Integer)
          bytes[selector, 1] = replacement
        elsif selector.is_a?(Range)
          bytes[selector] = replacement
        else
          return :kerberus_super
        end

        string.replace(bytes.pack('C*').force_encoding(encoding))
        value
      when 3
        first, length, value = args
        return :kerberus_super unless first.is_a?(Integer) && length.is_a?(Integer)
        bytes[first, length] = replacement_bytes(value)
        string.replace(bytes.pack('C*').force_encoding(encoding))
        value
      else
        :kerberus_super
      end
    end

    def self.byte_slice_bang(string, *args)
      encoding = string.encoding
      bytes = string.b.bytes

      removed =
        if args.length == 1 && (args[0].is_a?(Integer) || args[0].is_a?(Range))
          bytes.slice!(args[0])
        elsif args.length == 2 && args.all? { |value| value.is_a?(Integer) }
          bytes.slice!(args[0], args[1])
        else
          return :kerberus_super
        end

      return nil if removed.nil?
      removed = [removed] if removed.is_a?(Integer)
      string.replace(bytes.pack('C*').force_encoding(encoding))

      # The old adapter operated on String#b, so slice! returned an
      # ASCII-8BIT byte string. Preserve that behavior for legacy scripts.
      removed.pack('C*')
    end

    module StringBytes
      refine Array do
        def nitems; count { |item| !item.nil? }; end
      end

      refine String do
        def [](*args)
          if args.length == 1 && args[0].is_a?(Integer)
            Ruby18.byte_at(self, args[0])
          elsif (args.length == 2 && args.all? { |v| v.is_a?(Integer) }) ||
                (args.length == 1 && args[0].is_a?(Range))
            byteslice(*args)
          else
            super
          end
        end

        def []=(*args)
          value = Ruby18.byte_assign(self, *args)
          value == :kerberus_super ? super : value
        end

        def slice(*args); self[*args]; end

        def slice!(*args)
          value = Ruby18.byte_slice_bang(self, *args)
          value == :kerberus_super ? super : value
        end

        def length; bytesize; end
        def size; bytesize; end

        def index(needle, offset = 0)
          Ruby18.compat_index(self, needle, offset)
        end
      end
    end

    module GlobalHashIndex
      # Ruby 1.8 Hash#index(value) returned the matching key. Ruby 3 removed it.
      def index(value)
        key(value)
      end
    end

    module GlobalArrayNitems
      def nitems; count { |item| !item.nil? }; end
    end

    module GlobalStringBytes
      def [](*args)
        if args.length == 1 && args[0].is_a?(Integer)
          getbyte(args[0])
        elsif (args.length == 2 && args.all? { |v| v.is_a?(Integer) }) ||
              (args.length == 1 && args[0].is_a?(Range))
          byteslice(*args)
        else
          super
        end
      end

      def []=(*args)
        value = Ruby18.byte_assign(self, *args)
        value == :kerberus_super ? super : value
      end

      def slice(*args); self[*args]; end

      def slice!(*args)
        value = Ruby18.byte_slice_bang(self, *args)
        value == :kerberus_super ? super : value
      end

      def length; bytesize; end
      def size; bytesize; end

      # KERBERUS_DISABLE_GLOBAL_STRING_INDEX_510
      # String#index permanece nativo no Ruby 3.
      # O antigo override causava redispatch/recursao infinita.
    end

    @mutex = Mutex.new
    @global_bytes_installed = false

    def self.exclusive
      return yield if @mutex.owned?
      @mutex.synchronize { yield }
    end

    def self.install(global_bytes = false)
      if global_bytes && !@global_bytes_installed
        Array.prepend(GlobalArrayNitems) unless Array.ancestors.include?(GlobalArrayNitems)
        Hash.prepend(GlobalHashIndex) unless Hash.ancestors.include?(GlobalHashIndex)
        # KERBERUS_DISABLE_GLOBAL_STRING_BYTES_510
        # Global String monkeypatch desativado no Ruby 3.
        # Refinements/profile-specific transforms continuam ativos.
        # String.prepend(GlobalStringBytes) intentionally disabled.
        @global_bytes_installed = true
      end

      Thread.define_singleton_method(:exclusive) { |&block| Ruby18.exclusive(&block) }

      mutex = @mutex
      Thread.define_singleton_method(:critical) { mutex.owned? }
      Thread.define_singleton_method(:critical=) do |value|
        if value
          mutex.lock unless mutex.owned?
        elsif mutex.owned?
          mutex.unlock
        end
        value
      end

      unless String.method_defined?(:each)
        String.class_eval { alias_method :each, :each_line }
      end
    end
  end
end

module Kerberus::Compatibility
  module Registry
    @handles = {}
    @next_handle = 0x10000
    # Read-only virtual values actually referenced by Essentials. Missing RTPs
    # are not fabricated. Games keep their existing local save-folder fallback.
    VALUES = { [0x80000001, 'software\\enterbrain\\rgss'] =>
               {'playmusic' => [4, [1].pack('V')], 'playsound' => [4, [1].pack('V')]} }.freeze
    def self.open(root, subkey, reserved, access, output)
      Kerberus::Compatibility.buffer(output, 4)
      return 87 unless reserved == 0 && access.is_a?(Integer)
      key = [root & 0xffffffff, Kerberus::Compatibility.string(subkey).tr('/', '\\').downcase]
      return 2 unless VALUES.key?(key)
      return 8 if @handles.size >= 64
      handle = @next_handle
      @next_handle += 1
      @handles[handle] = key
      Kerberus::Compatibility.put(output, [handle].pack('V'))
      0
    end
    def self.close(handle); @handles.delete(handle) ? 0 : 6; end
    def self.query(handle, name, reserved, type, data, size)
      Kerberus::Compatibility.buffer(size, 4)
      Kerberus::Compatibility.buffer(type, 4) unless Kerberus::Compatibility.null?(type)
      return 87 unless Kerberus::Compatibility.null?(reserved)
      key = @handles[handle]
      return 6 unless key
      value = VALUES[key][Kerberus::Compatibility.string(name).downcase]
      return 2 unless value
      kind, bytes = value
      capacity = size.unpack('V')[0]
      unless Kerberus::Compatibility.null?(data)
        Kerberus::Compatibility.buffer(data, capacity)
      end
      Kerberus::Compatibility.put(size, [bytes.bytesize].pack('V'))
      Kerberus::Compatibility.put(type, [kind].pack('V')) unless Kerberus::Compatibility.null?(type)
      return 0 if Kerberus::Compatibility.null?(data)
      return 234 if capacity < bytes.bytesize
      Kerberus::Compatibility.put(data, bytes)
      0
    end
  end
  module Ini
    def self.read(section, key, default, output, capacity, filename)
      Kerberus::Compatibility.buffer(output, capacity)
      return 0 if capacity == 0
      path = Kerberus::Compatibility.relative_file(filename)
      values = {}
      if File.file?(path)
        raise InvalidParameter, 'INI excede 64 KiB' if File.size(path) > 65536
        current = ''
        File.binread(path).force_encoding('UTF-8').scrub.each_line do |line|
          line = line.strip
          if line.match?(/\A\[[^\]]+\]\z/)
            current = line[1...-1].downcase
            values[current] ||= {}
          elsif !line.start_with?(';', '#') && line.include?('=')
            k, v = line.split('=', 2)
            (values[current] ||= {})[k.strip.downcase] = v.strip
          end
        end
      end
      list = Kerberus::Compatibility.null?(section) || Kerberus::Compatibility.null?(key)
      value = if Kerberus::Compatibility.null?(section)
        values.keys.join("\0") + "\0"
      elsif Kerberus::Compatibility.null?(key)
        (values[Kerberus::Compatibility.string(section).downcase] || {}).keys.join("\0") + "\0"
      else
        fallback = Kerberus::Compatibility.null?(default) ? '' : Kerberus::Compatibility.string(default)
        (values[Kerberus::Compatibility.string(section).downcase] || {}).fetch(Kerberus::Compatibility.string(key).downcase, fallback)
      end
      suffix = list && capacity >= 2 ? "\0\0" : "\0"
      bytes = value.b.byteslice(0, [capacity - suffix.bytesize, 0].max)
      Kerberus::Compatibility.put(output, bytes + suffix)
      bytes.bytesize
    end
  end
end

module Kerberus::Compatibility
  module Win32
    # The only HWND is a managed token. It is never passed to FFI/dereferenced.
    WINDOW = 1
    @capture = 0
    @cursor = 0
    class << self
      def normalize(value)
        value = value.join if value.is_a?(Array) && value.all? { |x| x.is_a?(String) && x.length == 1 }
        return '' if value.nil? || value == 0
        raise InvalidParameter, 'Assinatura deve ser String/Array' unless value.is_a?(String) && value.bytesize <= 128
        text = value.upcase.strip
        text = text[3...-1] if text.start_with?('%W(') && text.end_with?(')')
        text = text.gsub(/[\s,]/, '')
        return '' if text.empty? || text == 'V'
        raise InvalidParameter, 'Tipo de assinatura desconhecido' unless text.match?(/\A[PLINS]+\z/)
        text.tr('LNS', 'III')
      end
      def library(value)
        raise InvalidParameter, 'DLL deve ser String' unless value.is_a?(String) && value.bytesize <= 256
        value.tr('\\', '/').split('/').last.to_s.downcase.sub(/\.dll\z/, '')
      end
      def install
        return if @installed
        @installed = true
        @owner_thread = thread_id
        original = ::Win32API.method(:new)
        ::Win32API.define_singleton_method(:new) do |dll, function, imports = '', exports = '', *extra, &constructor_block|
          key = [Win32.library(dll), function]
          descriptor = API_CATALOG[key]
          if descriptor
            begin
              input, output = Win32.normalize(imports), Win32.normalize(exports)
              signature = input + ':' + (output.empty? ? 'V' : output)
              raise InvalidParameter, 'Convencao adicional nao suportada' unless extra.empty?
              unless descriptor[0].include?(signature)
              # Kerberus 5.1: RGSS1/Win32API antigo usa variantes P/I para o
              # mesmo ABI. Como este provider executa uma funcao Ruby pelo
              # nome da API (nao chama a DLL Windows), uma variante pode ser
              # aceita com seguranca quando preserva aridade e retorno.
              requested_in, requested_out = signature.split(':', 2)

              compatible_signature = descriptor[0].find do |known_signature|
                known_in, known_out = known_signature.split(':', 2)

                known_in.to_s.length == requested_in.to_s.length &&
                  known_out.to_s == requested_out.to_s
              end

              if compatible_signature
                Kerberus::Compatibility.event(
                  'SIGNATURE_ADAPTED',
                  key.join('!'),
                  "#{signature} -> #{compatible_signature}; Ruby provider"
                )
              else
                raise InvalidParameter,
                  "#{key.join('!')} assinatura nao classificada: #{signature}; "                   "aceitas=#{descriptor[0].join(',')}"
              end
            end
              call = Call.new(key, input, output, descriptor)
              Kerberus::Compatibility.event('BOUND', key.join('!'), "#{signature}; #{descriptor[1]}")
              constructor_block.call(call) if constructor_block
              call
            rescue ArgumentError => error
              Kerberus::Compatibility.event('SIGNATURE_REJECTED', key.join('!'), error.message)
              raise
            end
          elsif dll.to_s.downcase.end_with?('.so')
            original.call(dll, function, imports, exports, *extra, &constructor_block)
          else
            Kerberus::Compatibility.unavailable(key.join('!'), 'API Windows nao classificada; MiniFFI nao sera chamado')
          end
        end
      end
      def thread_id
        return KerberusNative.thread_id if defined?(KerberusNative)
        Thread.current.native_thread_id
      end
      def focused?
        defined?(KerberusNative) ? KerberusNative.focused? : true
      end
      def key_pressed?(key)
        raise InvalidParameter, 'Virtual key fora de 0..255' unless key.between?(0, 255)
        Kerberus::Compatibility.call_native('Input', :pressex?, key)
      end
      def tick
        clock = Process.const_defined?(:CLOCK_BOOTTIME) ? Process::CLOCK_BOOTTIME : Process::CLOCK_MONOTONIC
        Process.clock_gettime(clock, :millisecond)
      end
      def fallback(function, result, reason)
        Thread.current[:kerberus_win32_error] = 120 # ERROR_CALL_NOT_IMPLEMENTED, never fake success.
        Kerberus::Compatibility.event('UNAVAILABLE', function, reason)
        result
      end
      def dispatch(dll, fn, a)
        case fn
        when 'GetCurrentThreadId' then thread_id
        when 'GetWindowThreadProcessId'
          Kerberus::Compatibility.buffer(a[1], 4) unless Kerberus::Compatibility.null?(a[1])
          return 0 unless a[0] == WINDOW
          Kerberus::Compatibility.put(a[1], [Process.pid].pack('V')) unless Kerberus::Compatibility.null?(a[1])
          @owner_thread
        when 'GetCurrentProcess' then -1 # documented pseudo handle, never dereferenced
        when 'FindWindowEx'
          return 0 unless Kerberus::Compatibility.null?(a[1])
          klass = Kerberus::Compatibility.null?(a[2]) ? '' : Kerberus::Compatibility.string(a[2])
          title = Kerberus::Compatibility.null?(a[3]) ? '' : Kerberus::Compatibility.string(a[3])
          return 0 unless klass.empty? || %w[RGSS Player].include?(klass) || klass == 'RGSS Player'
          return 0 if !title.empty? && defined?(System) && System.respond_to?(:window_title) && title != System.window_title
          WINDOW
        when 'GetForegroundWindow' then focused? ? WINDOW : 0
        when 'GetClientRect', 'GetWindowRect'
          Kerberus::Compatibility.buffer(a[1], 16)
          return 0 unless a[0] == WINDOW
          Kerberus::Compatibility.put(a[1], [0, 0, Graphics.width, Graphics.height].pack('l<4')); 1
        when 'GetSystemMetrics'
          return Graphics.width if [0, 16, 78].include?(a[0])
          return Graphics.height if [1, 17, 79].include?(a[0])
          fallback(fn, 0, 'Metrica de desktop indisponivel')
        when 'GetCursorPos'
          Kerberus::Compatibility.put(a[0], [Kerberus::Compatibility.call_native('Input', :mouse_x), Kerberus::Compatibility.call_native('Input', :mouse_y)].pack('l<2')); 1
        when 'ScreenToClient'
          Kerberus::Compatibility.buffer(a[1], 8)
          a[0] == WINDOW ? 1 : 0 # both coordinates are in the logical game viewport
        when 'GetAsyncKeyState', 'GetKeyState' then focused? && key_pressed?(a[0]) ? 0x8000 : 0
        when 'GetKeyboardState'
          Kerberus::Compatibility.buffer(a[0], 256)
          256.times { |i| a[0].setbyte(i, focused? && key_pressed?(i) ? 0x80 : 0) }
          1
        when 'SetWindowTextA'
          return 0 unless a[0] == WINDOW
          System.set_window_title(Kerberus::Compatibility.string(a[1])); 1
        when 'SetCapture'
          return 0 unless a[0] == WINDOW
          previous = @capture; @capture = WINDOW; previous
        when 'ReleaseCapture' then previous = @capture; @capture = 0; previous == 0 ? 0 : 1
        when 'ShowCursor'
          @cursor += a[0] == 0 ? -1 : 1
          if defined?(Input) && Input.respond_to?(:mouse_visible=)
            Input.mouse_visible = @cursor >= 0
          else
            Kerberus::Compatibility.event('UNAVAILABLE', fn, 'Cursor de hardware nao exposto pelo binding')
          end
          @cursor
        when 'GetTickCount', 'timeGetTime' then tick & 0xffffffff
        when 'GetTickCount64' then tick
        when 'QueryPerformanceCounter'
          Kerberus::Compatibility.put(a[0], [Process.clock_gettime(Process::CLOCK_MONOTONIC, :nanosecond)].pack('Q<')); 1
        when 'QueryPerformanceFrequency' then Kerberus::Compatibility.put(a[0], [1_000_000_000].pack('Q<')); 1
        when 'RegOpenKeyExA' then Registry.open(*a)
        when 'RegQueryValueExA' then Registry.query(*a)
        when 'RegCloseKey' then Registry.close(*a)
        when 'GetPrivateProfileString' then Ini.read(*a)
        when 'RtlMoveMemory'
          Kerberus::Compatibility.buffer(a[0], a[2]); Kerberus::Compatibility.buffer(a[1], a[2], false)
          Kerberus::Compatibility.put(a[0], a[1].byteslice(0, a[2])); 0
        when 'SwapRgb'
          Kerberus::Compatibility.buffer(a[0], a[1])
          raise InvalidParameter, 'Pixels BGRA incompletos' unless a[1] % 4 == 0
          (0...a[1]).step(4) do |i|
            red = a[0].getbyte(i); a[0].setbyte(i, a[0].getbyte(i + 2)); a[0].setbyte(i + 2, red)
          end
          0
        when 'GetLastError' then Thread.current[:kerberus_win32_error] || 0
        when 'FormatMessageA'
          Kerberus::Compatibility.buffer(a[4], a[5])
          message = "Kerberus: erro #{a[2]}".b.byteslice(0, [a[5] - 1, 0].max)
          return 0 if a[5] <= 0
          Kerberus::Compatibility.put(a[4], message + "\0"); message.bytesize
        when 'GetUserName'
          Kerberus::Compatibility.buffer(a[1], 4)
          capacity = a[1].unpack('V')[0]; Kerberus::Compatibility.buffer(a[0], capacity)
          Kerberus::Compatibility.put(a[1], [7].pack('V'))
          return 0 if capacity < 7
          Kerberus::Compatibility.put(a[0], "Player\0"); 1
        when 'GetUserDefaultLangID' then fallback(fn, 0x0409, 'Idioma neutro en-US; Android nao expoe LANGID Win32')
        when 'GetUserGeoID' then fallback(fn, -1, 'GEOID_NOT_AVAILABLE')
        when 'GetSystemPowerStatus'
          Kerberus::Compatibility.buffer(a[0], 12)
          fallback(fn, 0, 'Status de bateria indisponivel por este provider')
        when 'SHGetKnownFolderPath'
          Kerberus::Compatibility.buffer(a[3], 4)
          Kerberus::Compatibility.put(a[3], [0].pack('V'))
          fallback(fn, 0x80004001, 'E_NOTIMPL: use a pasta de saves local existente')
        when 'SHGetSpecialFolderLocation'
          Kerberus::Compatibility.put(a[2], [0].pack('V'))
          fallback(fn, 0x80004001, 'E_NOTIMPL')
        when 'SHGetPathFromIDList' then fallback(fn, 0, 'Nenhum PIDL Windows foi alocado')
        when 'CoTaskMemFree'
          raise InvalidParameter, 'Ponteiro COM nao pertence ao Kerberus' unless Kerberus::Compatibility.null?(a[0])
          0
        when 'InputGetWheelDelta' then Kerberus::Compatibility.call_native('Input', :scroll_v).to_i * 120
        when 'waveOutGetNumDevs' then fallback(fn, 0, 'waveOut sem backend; Audio nativo continua disponivel')
        when /^waveOut/ then fallback(fn, 8, 'MMSYSERR_NOTSUPPORTED: PCM direto nao implementado')
        when 'mciSendString' then fallback(fn, 274, 'MCIERR_UNSUPPORTED_FUNCTION: gravacao/video MCI indisponivel')
        when 'mciGetErrorString'
          Kerberus::Compatibility.buffer(a[1], a[2]); return 0 if a[2] == 0
          bytes = 'MCI indisponivel no Android'.b.byteslice(0, a[2] - 1)
          Kerberus::Compatibility.put(a[1], bytes + "\0"); 1
        when 'PeekMessage' then fallback(fn, 0, 'Sem fila Win32; texto vem de SDL Input.gets')
        when 'MapVirtualKey', 'ToUnicode' then fallback(fn, 0, 'Conversao Win32 indisponivel; editor usa SDL Input.gets')
        when 'WSAGetLastError' then 10045 # WSAEOPNOTSUPP; network provider is disabled
        when 'htons' then [a[0] & 0xffff].pack('n').unpack('v')[0]
        when 'htonl' then [a[0] & 0xffffffff].pack('N').unpack('V')[0]
        when 'inet_addr'
          parts = Kerberus::Compatibility.string(a[0]).split('.')
          return 0xffffffff unless parts.size == 4 && parts.all? { |p| p.match?(/\A\d{1,3}\z/) && p.to_i <= 255 }
          parts.map(&:to_i).pack('C4').unpack('V')[0]
        when 'TakeScreenshot'
          path = Kerberus::Compatibility.relative_file(a[0])
          Kerberus::Compatibility.unavailable(fn, 'Use PNG para exportar captura') unless path.downcase.end_with?('.png')
          bitmap = Kerberus::Compatibility.call_native('Graphics', :snap_to_bitmap)
          begin; bitmap.to_file(path); ensure; bitmap.dispose; end
          1
        when 'LoadLibrary', 'FreeLibrary', 'RegisterHotKey', 'SetPriorityClass', 'SetWindowPos',
             'SetWindowLong', 'ShowWindow', 'PostMessage', 'SendMessage', 'AddFontResource', 'WriteProfileString'
          fallback(fn, 0, 'Operacao de desktop indisponivel; falha explicita')
        else Kerberus::Compatibility.unavailable("#{dll}!#{fn}", API_CATALOG[[dll, fn]][2])
        end
      end
    end
    class Call
      def initialize(key, imports, exports, descriptor)
        @key, @imports, @exports, @descriptor = key, imports, exports, descriptor
        @applied = false
      end
      def call(*args)
        raise InvalidParameter, "#{@key.join('!')} espera #{@imports.length} argumentos; recebeu #{args.length}" unless args.length == @imports.length
        @imports.chars.each_with_index do |type, i|
          arg = args[i]
          if type == 'I'
            raise InvalidParameter, "Argumento #{i}: inteiro necessario" unless arg.is_a?(Integer)
          elsif !arg.is_a?(String) && !arg.is_a?(Integer) && !arg.nil?
            raise InvalidParameter, "Argumento #{i}: buffer/handle necessario"
          end
        end
        result = Win32.dispatch(*@key, args)
        unless @applied
          parameters = args.map { |value| value.is_a?(String) ? "buffer(#{value.bytesize})" : value.nil? ? 'NULL' : value.to_s }.join(',')
          Kerberus::Compatibility.event('APPLIED', @key.join('!'), "args=[#{parameters}]; #{@descriptor[1]}; retorno=#{result.is_a?(Numeric) ? result : result.class}")
          @applied = true
        end
        @exports.empty? ? nil : result
      rescue ArgumentError => error
        Kerberus::Compatibility.event('PARAMETER_REJECTED', @key.join('!'), error.message)
        raise
      end
      alias Call call
    end
  end
end

module Kerberus::Compatibility
  module AudioAdapter
    @channels = {}
    @profile_volume = false
    class << self
      def volume_for(channel, value)
        volume = [[value.to_f, 0].max, 100].min
        if @profile_volume && defined?($PokemonSystem) && $PokemonSystem
          method = [:bgm, :me].include?(channel) ? :bgmvolume : :sevolume
          volume *= [[($PokemonSystem.public_send(method) || 100).to_f, 0].max, 100].min / 100.0 if $PokemonSystem.respond_to?(method)
        end
        volume.to_i
      end
      def play(channel, name, volume = 100, pitch = 100, position = 0)
        raise ArgumentError, 'Nome de audio deve ser String' unless name.is_a?(String)
        return stop(channel) if name.empty?
        raise ArgumentError, 'Posicao de audio invalida' unless position.nil? || (position.is_a?(Numeric) && position.finite? && position >= 0)
        position ||= 0
        if [:me, :se].include?(channel) && position != 0
          Kerberus::Compatibility.unavailable("Audio.#{channel}_play(position)", 'Este canal nativo nao oferece seek')
        end
        actual_volume = volume_for(channel, volume)
        args = [name, actual_volume, pitch]
        args << position.to_f if [:bgm, :bgs].include?(channel)
        Kerberus::Compatibility.call_native('Audio', "#{channel}_play".to_sym, *args)
        @channels[channel] = [name, actual_volume, pitch]
        @fade_in = nil if channel == :bgm
        nil
      end
      def stop(channel)
        Kerberus::Compatibility.call_native('Audio', "#{channel}_stop".to_sym)
        @channels.delete(channel)
        @fade_in = nil if channel == :bgm
        nil
      end
      def fade(channel, ms)
        raise ArgumentError, 'Duracao de fade invalida' unless ms.is_a?(Numeric) && ms.finite? && ms >= 0
        Kerberus::Compatibility.call_native('Audio', "#{channel}_fade".to_sym, ms.to_i)
        @fade_in = nil if channel == :bgm
      end
      def position(channel = :bgm)
        Kerberus::Compatibility.call_native('Audio', "#{channel}_pos".to_sym)
      end
      def info(channel = :bgm); @channels[channel]; end
      def volume=(value)
        return unless @channels[:bgm]
        state = @channels[:bgm]
        level = [[value.to_f, 0].max, 100].min.to_i
        # mkxp AudioStream::play changes volume without restarting this file.
        Kerberus::Compatibility.call_native('Audio', :bgm_play, state[0], level, state[2], position)
        state[1] = level
      end
      def fade_in(ms)
        raise ArgumentError, 'Duracao de fade invalida' unless ms.is_a?(Numeric) && ms.finite? && ms >= 0
        return unless @channels[:bgm]
        target = @channels[:bgm][1]
        return self.volume = target if ms == 0
        self.volume = 0
        @fade_in = [Process.clock_gettime(Process::CLOCK_MONOTONIC), ms / 1000.0, target]
      end
      def tick
        return unless @fade_in
        start, duration, target = @fade_in
        progress = [(Process.clock_gettime(Process::CLOCK_MONOTONIC) - start) / duration, 1.0].min
        value = (target * progress).round
        self.volume = value if @channels[:bgm] && value != @channels[:bgm][1]
        @fade_in = nil if progress >= 1
      end
      def install(profile_volume = false)
        @profile_volume ||= profile_volume
        return if @installed
        @installed = true
        [:bgm, :bgs, :me, :se].each do |channel|
          Audio.define_singleton_method("#{channel}_play") { |name, vol = 100, pitch = 100, pos = 0| AudioAdapter.play(channel, name, vol, pitch, pos) }
          Audio.define_singleton_method("#{channel}_stop") { AudioAdapter.stop(channel) }
          Audio.define_singleton_method("#{channel}_fade") { |ms| AudioAdapter.fade(channel, ms) } unless channel == :se
          Kernel.send(:define_method, "Audio_#{channel}_play") { |name, vol = 100, pitch = 100, pos = 0| AudioAdapter.play(channel, name, vol, pitch, pos) }
          Kernel.send(:define_method, "Audio_#{channel}_stop") { AudioAdapter.stop(channel) }
          Kernel.send(:module_function, "Audio_#{channel}_play", "Audio_#{channel}_stop")
          unless channel == :se
            Kernel.send(:define_method, "Audio_#{channel}_fade") { |ms| AudioAdapter.fade(channel, ms) }
            Kernel.send(:module_function, "Audio_#{channel}_fade")
          end
        end
        helpers = {
          Audio_bgm_get_position: proc { AudioAdapter.position },
          Audio_bgm_get_volume: proc { AudioAdapter.info ? AudioAdapter.info[1] : 0 },
          Audio_bgm_set_volume: proc { |v| AudioAdapter.volume = v },
          Audio_bgm_name: proc { AudioAdapter.info ? AudioAdapter.info[0] : '' },
          Audio_bgm_pitch: proc { AudioAdapter.info ? AudioAdapter.info[2] : 100 },
          Audio_bgm_playing?: proc { !AudioAdapter.info.nil? },
          Audio_bgm_fadein: proc { |ms| AudioAdapter.fade_in(ms) },
          audio_control_volume: proc { |v| AudioAdapter.volume = v },
          safeExists?: proc { |file| File.file?(file) },
          getPlayMusic: proc { true }, getPlaySound: proc { true }
        }
        helpers.each { |name, body| Kernel.send(:define_method, name, &body); Kernel.send(:module_function, name) }
        Audio.define_singleton_method(:bgm_position) { AudioAdapter.position }
        Audio.define_singleton_method(:update) { AudioAdapter.tick }
        Kerberus::Compatibility.event('APPLIED', 'AUDIO_NATIVE', 'BGM/BGS/ME/SE, volume, pitch, fade, posicao em segundos; loop pelo mkxp')
      end
    end
  end
end

module Kerberus::Compatibility
  module InputAdapter
    def self.install
      # Retain the game's buttonToKey and later remapping screens. Native logical
      # input is ORed with these bindings, so touch and controllers remain usable.
      [:pressex?, :triggerex?, :repeatex?, :releaseex?, :repeatcount].each do |name|
        Input.define_singleton_method(name) { |key| Kerberus::Compatibility.call_native('Input', name, key) }
      end
      [:press?, :trigger?, :repeat?, :release?].each do |name|
        extended = "#{name.to_s.delete_suffix('?')}ex?".to_sym
        Input.define_singleton_method(name) do |button|
          Kerberus::Compatibility.call_native('Input', name, button) ||
            buttonToKey(button).any? { |key| Kerberus::Compatibility.call_native('Input', extended, key) }
        end
      end
      Input.define_singleton_method(:count) do |button|
        native = Kerberus::Compatibility.call_native('Input', :count, button)
        buttonToKey(button).inject(native) { |value, key| [value, Kerberus::Compatibility.call_native('Input', :repeatcount, key)].max }
      end
      Input.define_singleton_method(:update) do
        Kerberus::Compatibility.call_native('Input', :update)
        AudioAdapter.tick
      end
      if defined?(::Mouse)
        ::Mouse.define_singleton_method(:getMouseGlobalPos) { [Input.mouse_x, Input.mouse_y] }
        ::Mouse.define_singleton_method(:getMousePos) do |anywhere = false|
          x, y = Input.mouse_x, Input.mouse_y
          anywhere || (x >= 0 && y >= 0 && x < Graphics.width && y < Graphics.height) ? [x, y] : nil
        end
      end
      Kerberus::Compatibility.event('APPLIED', 'INPUT_NATIVE', 'SDL teclado/touch/gamepad; mapeamento do jogo preservado')
    end
    def self.install_keys
      # The Insurgence Keys module still exports all constants, without allocating
      # or scanning 256 Win32 key states on every update.
      ::Keys.define_singleton_method(:update) { nil }
      {press?: :pressex?, trigger?: :triggerex?, repeat?: :repeatex?, release?: :releaseex?}.each do |name, native|
        ::Keys.define_singleton_method(name) { |key| Kerberus::Compatibility.call_native('Input', native, key) }
      end
    end
    module TextEntry
      def update
        # The surrounding scene already owns Enter/Esc, cursor and deletion.
        was_active = @kerberus_text_active
        @kerberus_text_active = !!active
        if @kerberus_text_active != was_active
          Kerberus::Compatibility.call_native('Input', :text_input=, @kerberus_text_active)
        end
        super
      end
      def dispose
        Kerberus::Compatibility.call_native('Input', :text_input=, false) if @kerberus_text_active
        super
      end
    end
    def self.install_text
      return unless defined?(::Window_TextEntry_Keyboard)
      ::Window_TextEntry_Keyboard.prepend(TextEntry) unless ::Window_TextEntry_Keyboard.ancestors.include?(TextEntry)
    end
  end
end

module Kerberus::Compatibility
  module BitmapAdapter
    LIMIT = 16 * 1024 * 1024
    def self.bytes(bitmap)
      raise InvalidParameter, 'Bitmap invalido/descartado' unless bitmap.is_a?(Bitmap) && !bitmap.disposed?
      Kerberus::Compatibility.unavailable('Bitmap.raw_data', 'Efeito excede limite de 16 MiB') if bitmap.width * bitmap.height * 4 > LIMIT
      if bitmap.animated?
        frame = bitmap.snap_to_bitmap
        begin; return frame.raw_data.b; ensure; frame.dispose; end
      end
      bitmap.raw_data.b
    end
    def self.swap(data)
      result = data.dup
      (0...result.bytesize).step(4) do |i|
        red = result.getbyte(i); result.setbyte(i, result.getbyte(i + 2)); result.setbyte(i + 2, red)
      end
      result
    end
    def self.install_legacy
      Bitmap.class_eval do
        define_method(:getData) { BitmapAdapter.swap(BitmapAdapter.bytes(self)) }
        define_method(:setData) do |data|
          Kerberus::Compatibility.buffer(data, width * height * 4, false)
          self.raw_data = BitmapAdapter.swap(data.byteslice(0, width * height * 4))
        end
        define_method(:asOpaque) do
          data = BitmapAdapter.bytes(self)
          (3...data.bytesize).step(4) { |i| data.setbyte(i, 255) }
          self.raw_data = data
          self
        end
        define_method(:saveToPng) { |file| to_file(Kerberus::Compatibility.relative_file(file)) }
        define_method(:address) { Kerberus::Compatibility.unavailable('Bitmap.address', 'Endereco RGSS1 nao existe no mkxp-z; use raw_data') }
      end
      Graphics.define_singleton_method(:snap_to_bitmap) { Kerberus::Compatibility.call_native('Graphics', :snap_to_bitmap) }
    end
    module KleinBitmap
      def kerberus_scroll(dx, dy)
        return self if width == 0 || height == 0
        dx %= width; dy %= height
        temp = clone
        begin
          clear
          [dx, dx - width].each { |x| [dy, dy - height].each { |y| blt(x, y, temp, temp.rect) } }
        ensure
          temp.dispose
        end
        self
      end
      def scroll_up(speed = 1); kerberus_scroll(0, -Integer(speed)); end
      def scroll_down(speed = 1); kerberus_scroll(0, Integer(speed)); end
      def scroll_left(speed = 1); kerberus_scroll(-Integer(speed), 0); end
      def scroll_right(speed = 1); kerberus_scroll(Integer(speed), 0); end
      def to_negative
        data = BitmapAdapter.bytes(self)
        (0...data.bytesize).step(4) { |i| 3.times { |j| data.setbyte(i + j, 255 - data.getbyte(i + j)) } }
        self.raw_data = data
        self
      end
      def modify_color(from, to)
        data = BitmapAdapter.bytes(self)
        old = [from.red, from.green, from.blue].map(&:to_i)
        replacement = [to.red, to.green, to.blue].map(&:to_i)
        (0...data.bytesize).step(4) do |i|
          next unless 3.times.all? { |j| data.getbyte(i + j) == old[j] }
          3.times { |j| data.setbyte(i + j, replacement[j]) }
        end
        self.raw_data = data
        self
      end
      [:save_pallete, :modify_pallete, :to_retro, :add_outline].each do |name|
        define_method(name) { |*args| Kerberus::Compatibility.unavailable("KleinBitmap.#{name}", 'Algoritmo/formato proprietario ainda nao reproduzido') }
      end
    end
    module KleinSprite
      attr_accessor :kleinPatternBitmap
      def set_pattern(pattern, alpha, everyframe = false)
        raise ArgumentError, 'Alpha invalido' unless alpha.is_a?(Numeric) && alpha.finite?
        Kerberus::Compatibility.unavailable('KleinBitmap.set_pattern', 'Efeito excede limite de 16 MiB') if bitmap.width * bitmap.height * 4 > BitmapAdapter::LIMIT
        if everyframe || !(@kerberus_pattern_output && bitmap.equal?(@kerberus_pattern_output))
          next_source = bitmap.animated? ? bitmap.snap_to_bitmap : bitmap.clone
          begin; next_output = next_source.clone; rescue Exception; next_source.dispose; raise; end
          @kerberus_pattern_source.dispose if @kerberus_pattern_source && !@kerberus_pattern_source.disposed?
          @kerberus_pattern_output.dispose if @kerberus_pattern_output && !@kerberus_pattern_output.disposed?
          @kerberus_pattern_source = next_source
          @kerberus_pattern_output = next_output
        end
        target = BitmapAdapter.bytes(@kerberus_pattern_source)
        pixels = BitmapAdapter.bytes(pattern)
        raise ArgumentError, 'Pattern vazio' if pattern.width == 0 || pattern.height == 0
        opacity = [[alpha.to_f, 0].max, 255].min / 255.0
        w = @kerberus_pattern_source.width
        (0...(target.bytesize / 4)).each do |pixel|
          i = pixel * 4
          next if target.getbyte(i + 3) == 0
          offset = (((pixel / w) % pattern.height) * pattern.width + (pixel % w) % pattern.width) * 4
          mix = opacity * pixels.getbyte(offset + 3) / 255.0
          3.times { |j| target.setbyte(i + j, (target.getbyte(i + j) * (1 - mix) + pixels.getbyte(offset + j) * mix).round) }
        end
        @kerberus_pattern_output.raw_data = target
        self.bitmap = @kerberus_pattern_output
      end
      def delete_pattern
        return unless @kerberus_pattern_source
        if bitmap.equal?(@kerberus_pattern_output)
          self.bitmap = @kerberus_pattern_source
        elsif !@kerberus_pattern_source.disposed?
          @kerberus_pattern_source.dispose
        end
        @kerberus_pattern_output.dispose unless @kerberus_pattern_output.disposed?
        @kerberus_pattern_output = @kerberus_pattern_source = nil
      end
      def dispose
        [@kerberus_pattern_source, @kerberus_pattern_output].compact.each { |item| item.dispose unless item.disposed? }
        @kerberus_pattern_source = @kerberus_pattern_output = nil
        super
      end
    end
    def self.install_klein
      Bitmap.prepend(KleinBitmap) unless Bitmap.ancestors.include?(KleinBitmap)
      Sprite.prepend(KleinSprite) unless Sprite.ancestors.include?(KleinSprite)
      Object.const_set(:KLEIN_BFUNCS_WORKING, true) unless defined?(::KLEIN_BFUNCS_WORKING)
      Kernel.send(:define_method, :compare_klein_bitmaps) do |a, b|
        a.width == b.width && a.height == b.height && BitmapAdapter.bytes(a) == BitmapAdapter.bytes(b)
      end
      Kernel.send(:define_method, :klein_bitmap_version) { 1 }
      Kernel.send(:define_method, :klein_dll) { |*args| Kerberus::Compatibility.unavailable('KleinBitmap direct DLL', 'Use os metodos Bitmap/Sprite adaptados') }
      Kernel.send(:module_function, :compare_klein_bitmaps, :klein_bitmap_version, :klein_dll)
      Kerberus::Compatibility.event('APPLIED', 'BITMAP_NATIVE', 'Scroll, cores, negativo, pattern e comparacao de pixels; paletas/retro/outline indisponiveis')
    end
    module Gif
      def initialize(file, hue = 0)
        # KERBERUS_URANIUM_EMPTY_AUTOTILE_FIX_6001
        normalized = file.to_s.tr('\\', '/')
        if normalized.sub(%r{/+\z}, '') == 'Graphics/Autotiles'
          @kerberus_bitmap = Bitmap.new(32, 32)
          @kerberus_frames = {}
          Kerberus::Compatibility.event('PROFILE_REPLACED','empty autotile','transparent Bitmap 32x32')
          return
        end
        path = defined?(RTP) ? RTP.getImagePath(file) : file
        @kerberus_bitmap = Bitmap.new(path)
        @kerberus_frames = {}
        begin
          if hue != 0 && bitmap.animated?
            # mkxp rejects hue_change on animated bitmaps. Rebuild through its
            # native frame API, once, without Windows object addresses.
            if bitmap.frame_count * width * height * 4 > BitmapAdapter::LIMIT
              Kerberus::Compatibility.unavailable('GIF hue', 'Animacao colorida excede limite de 16 MiB')
            end
            original, colored = bitmap, nil
            begin
              original.frame_count.times do |index|
                original.goto_and_stop(index)
                frame = original.snap_to_bitmap
                begin
                  frame.hue_change(hue)
                  colored ? colored.add_frame(frame) : colored = frame
                ensure
                  frame.dispose unless frame.equal?(colored) || frame.disposed?
                end
              end
              colored.frame_rate = original.frame_rate
              colored.looping = original.looping
              @kerberus_bitmap = colored
            rescue Exception
              colored.dispose if colored && !colored.disposed?
              raise
            ensure
              original.dispose unless original.disposed?
            end
          elsif hue != 0
            bitmap.hue_change(hue)
          end
        rescue Exception
          bitmap.dispose unless bitmap.disposed?
          raise
        end
        @kerberus_bitmap.play if @kerberus_bitmap.animated?
      end
      def bitmap; @kerberus_bitmap; end
      def width; bitmap.width; end
      def height; bitmap.height; end
      def length; bitmap.animated? ? bitmap.frame_count : 1; end
      def currentIndex; bitmap.animated? ? bitmap.current_frame : 0; end
      def disposed?; bitmap.disposed?; end
      def update; nil; end # animated Bitmap advances inside mkxp's renderer
      def deanimate
        if bitmap.animated?
          original = bitmap
          original.goto_and_stop(0)
          @kerberus_bitmap = original.snap_to_bitmap
          original.dispose
          @kerberus_frames.each_value { |frame| frame.dispose unless frame.disposed? }
          @kerberus_frames.clear
        end
        bitmap
      end
      def totalFrames; length * frameDelay; end
      def frameDelay(index = currentIndex)
        Kerberus::Compatibility.event('FALLBACK', 'GifBitmap.frameDelay', 'Duracao media; timing real e mantido pelo decoder nativo')
        bitmap.animated? ? Graphics.frame_rate.to_f / bitmap.frame_rate : 1
      end
      def [](index)
        return nil unless index.is_a?(Integer) && index.between?(0, length - 1)
        return bitmap if length == 1
        return @kerberus_frames[index] if @kerberus_frames.key?(index)
        Kerberus::Compatibility.unavailable('GIF frame cache', 'Frames extraidos excedem 16 MiB') if (1 + @kerberus_frames.size) * width * height * 4 > BitmapAdapter::LIMIT
        frame, playing = bitmap.current_frame, bitmap.playing
        begin
          bitmap.goto_and_stop(index)
          @kerberus_frames[index] = bitmap.snap_to_bitmap
        ensure
          bitmap.goto_and_stop(frame)
          bitmap.play if playing
        end
        @kerberus_frames[index]
      end
      def each; length.times { |index| yield self[index] }; end
      def dispose
        @kerberus_frames.each_value { |frame| frame.dispose unless frame.disposed? }
        @kerberus_frames.clear
        bitmap.dispose unless bitmap.disposed?
      end
      def copy
        duplicate = clone
        duplicate.instance_variable_set(:@kerberus_bitmap, bitmap.clone)
        duplicate.instance_variable_set(:@kerberus_frames, {})
        duplicate
      end
    end
    def self.install_gif
      ::GifBitmap.prepend(Gif) unless ::GifBitmap.ancestors.include?(Gif)
    end
  end
end

module Kerberus::Compatibility
  module Doctor
    MAX_FINDINGS = 256
    RULES = [
      ['R18_HASH_INDEX', /\.index\s*\([^\n)]*\)/, 'Hash#index pode exigir semantica Ruby 1.8; shim global instalado'],
      ['R18_STRING_BYTES', /(?:getbyte|setbyte|byteslice|\.unpack\s*\()/, 'script manipula bytes; String byte shim ativo'],
      ['R18_THREAD', /Thread\.(?:critical|exclusive)/, 'API antiga de Thread; shim instalado'],
      ['R18_FIXNUM', /\b(?:Fixnum|Bignum)\b/, 'constante numerica legada detectada'],
      ['IO_MARSHAL', /Marshal\.load|load_data|pbRgssOpen/, 'IO/Marshal deve ser validado em runtime'],
      ['ENCODING_CJK', /WordRegexp|requireCJKFont|FullWidthLatin/, 'regex CJK passa por normalizacao UTF-8'],
      ['WIN32', /Win32API\.new|Win32API\s*\(/, 'Win32API passa pelo Morph'],
      ['ZLIB', /\bZlib::|require\s*[\( ]*[\"\']zlib/, 'Zlib requerido pelo jogo'],
      ['KLEIN', /KLEIN_BFUNCS|klein_(?:dll|bitmap_version)|compare_klein_bitmaps/, 'KleinBitmap usa provider nativo parcial'],
      ['HMODE7', /MGC_Hmode7|renderHM7|drawMapTileset/, 'HMode7 continua bloqueio nativo quando executado'],
      ['NETWORK', /(?:Win32API.*ws2_32|WSAGetLastError|\bsocket\b)/i, 'rede WinSock continua limitada']
    ].freeze

    def self.scan(scripts, profile)
      counts = Hash.new(0)
      sections = Hash.new { |h, k| h[k] = [] }
      scripts.each_with_index do |entry, index|
        source = entry[3].to_s
        RULES.each do |id, regex, _detail|
          next unless source.match?(regex)
          counts[id] += source.scan(regex).length
          sections[id] << index if sections[id].length < 16
        end
      end
      RULES.each do |id, _regex, detail|
        next unless counts[id] > 0
        Kerberus::Compatibility.event('DOCTOR', id, "count=#{counts[id]} sections=#{sections[id].join(',')} #{detail}")
      end
      hard = []
      hard << 'HMODE7' if counts['HMODE7'] > 0
      report = { profile: profile, scripts: scripts.length, counts: counts, sections: sections, hard: hard }
      $KERBERUS_DOCTOR_REPORT = report
      report
    end

    def self.guard_stdlib(report)
      return unless report
      if report[:counts]['ZLIB'] > 0 && !defined?(::Zlib)
        begin
          require 'zlib'
          Kerberus::Compatibility.event('DOCTOR_FIX', 'ZLIB', 'stdlib carregada antes dos scripts')
        rescue LoadError => error
          Kerberus::Compatibility.event('DOCTOR_WARN', 'ZLIB', error.message)
        end
      end
    end
  end
end

module Kerberus::Compatibility
  module Essentials
    def self.transform(source)
      text = Source.syntax(source)
      # KERBERUS_AUDIO_DIRECT_FIX_516
      # Old Essentials/Ruby 1.8 binary parsers expect String#[index] to return
      # an Integer byte. Ruby 3 returns a one-character String instead.
      #
      # Keep this local to the legacy AudioUtilities parser. Do not change
      # String#[] globally.
      if Source.signature(text, 'def getOggPage', 'def oggfiletime', 'def getPlayTime2')
        audio_before = text.dup

        # OGG and MP3 byte-at-a-time reads.
        text = text.gsub(/\b([A-Za-z_][A-Za-z0-9_]*)\.read\(1\)\[0\]/) do
          "Kerberus::Compatibility::Ruby18.byte_at(#{Regexp.last_match(1)}.read(1), 0)"
        end

        # rstr is the 3-byte MP3 frame header. Every numeric index here is a
        # byte access under the Ruby 1.8 semantics expected by this parser.
        text = text.gsub(/\brstr\[(\d+)\]/) do
          "Kerberus::Compatibility::Ruby18.byte_at(rstr, #{Regexp.last_match(1)})"
        end

        if text != audio_before
          text << "\n# KERBERUS_AUDIO_DIRECT_FIX_516_APPLIED\n"
          Kerberus::Compatibility.event(
            'RUBY18_AUDIO_BYTES',
            'AudioUtilities direct',
            'Essentials.transform converted legacy binary String byte indexing to getbyte'
          )
        else
          Kerberus::Compatibility.event(
            'RUBY18_AUDIO_BYTES',
            'AudioUtilities direct',
            'legacy parser detected but no byte-index expression required conversion'
          )
        end
      end
      if Source.signature(text, 'class AudioContext', 'AudioContextInitialize', 'module AudioState')
        return "Kerberus::Compatibility::AudioAdapter.install\n"
      end
      if Source.signature(text, 'def self.buttonToKey', 'def self.updateKeyState', 'GetAsyncKeyState')
        text += "\nKerberus::Compatibility::InputAdapter.install\n"
      end
      if Source.signature(text, 'class Window_TextEntry_Keyboard', '@toUnicode', 'GetKeyboardState')
        start = text.index('    if !@toUnicode')
        finish = start && text.index("\n  end\nend", start)
        raise ArgumentError, 'Editor de texto alterado; adaptacao cancelada' unless start && finish
        text[start...finish] = "    incoming = Kerberus::Compatibility.call_native('Input', :gets)\n    incoming.each_char { |character| insert(character) unless character.match?(/[\\x00-\\x1f\\x7f]/) }\n"
        text += "\nKerberus::Compatibility::InputAdapter.install_text\n"
      end
      if Source.signature(text, 'def pbSetResizeFactor2', 'RtlMoveMemory_pi', 'def saveToPng')
        # Desktop scaling duplicates the SDL viewport on Android. Keep logical
        # dimensions and the existing sprite classes; SDL fits the game to screen.
        text = text.sub(/(def pbSetResizeFactor2\([^\n]*\)\n)/, "\\1  factor = 1.0 # Android viewport owns presentation scaling\n")
        text += "\nKerberus::Compatibility::BitmapAdapter.install_legacy\n"
      end
      if Source.signature(text, 'module GifLibrary', 'class GifBitmap', 'GifToPngFilesInMemory')
        text = text.sub('if safeExists?("gif.dll")', 'if Kerberus::Compatibility::Essentials.windows_gif_decoder?')
        text += "\nKerberus::Compatibility::BitmapAdapter.install_gif\n"
      end
      if Source.signature(text, 'def getUnicodeStringFromAnsi(addr)', 'def getUnicodeString(addr)')
        text = Source.method_body(text, 'getUnicodeStringFromAnsi', "return Kerberus::Compatibility::Essentials.ansi_string(addr)\n")
        text = Source.method_body(text, 'getUnicodeString', "return Kerberus::Compatibility::Essentials.utf16_string(addr)\n")
      end
      if Source.signature(text, 'FontInstaller', 'AddFontResource', 'WriteProfileString')
        text = text.gsub(/^([ \t]*)FontInstaller\.install\s*$/, "\\1Kerberus::Compatibility.event('PROFILE_REPLACED', 'FontInstaller', 'Fonts/ e indexado pelo mkxp; nao instala fontes no sistema')")
      end
      if Source.signature(text, 'def Thread.exclusive', 'Thread.critical')
        text = Source.method_body(text, 'Thread.exclusive', "Kerberus::Compatibility::Ruby18.exclusive { yield }\n")
      end
      if Source.signature(text, 'TakeScreenshot', 'capturefile')
        text = text.gsub(/capturefile && safeExists\?\("rubyscreen.dll"\)/, 'capturefile')
        text = text.gsub(/(capture%[^\"]*)\.bmp/, '\\1.png')
      end
      text
    end
    def self.windows_gif_decoder?
      Kerberus::Compatibility.event('PROFILE_REPLACED', 'gif.dll', 'Bitmap animado nativo; nenhum ponteiro Windows')
      false
    end
    def self.ansi_string(value)
      raise InvalidParameter, 'Endereco de memoria nao suportado' unless value.is_a?(String)
      bytes = value.b.split("\0", 2).first.to_s
      utf8 = bytes.dup.force_encoding('UTF-8')
      utf8.valid_encoding? ? utf8 : bytes.force_encoding('ISO-8859-1').encode('UTF-8')
    end
    def self.utf16_string(value)
      return '' if value == 0
      raise InvalidParameter, 'Endereco de memoria nao suportado' unless value.is_a?(String) && value.bytesize.even?
      units = value.b.unpack('v*').take_while { |unit| unit != 0 }
      units.pack('v*').force_encoding('UTF-16LE').encode('UTF-8')
    end
  end
end

module Kerberus::Compatibility
  # Generic RGSS1/Ruby 1.8 compatibility pass. This is deliberately separate
  # from game profiles: every RGSS1 project gets the language/runtime fixes,
  # while Uranium/Insurgence profiles only handle their game-specific APIs.
  module ClassicCore520
    MARKER = 'KERBERUS_CLASSIC_CORE_520'

    LEGACY_STRING_ALIASES = [
      [/^(\s*)alias\s+getbyte\s+\[\]\s*$/, :getbyte],
      [/^(\s*)alias\s+setbyte\s+\[\]=\s*$/, :setbyte],
      [/^(\s*)alias\s+bytesize\s+size\s*$/, :bytesize],
      [/^(\s*)alias_method\s*:getbyte\s*,\s*:\[\]\s*$/, :getbyte],
      [/^(\s*)alias_method\s*:setbyte\s*,\s*:\[\]=\s*$/, :setbyte],
      [/^(\s*)alias_method\s*:bytesize\s*,\s*:size\s*$/, :bytesize],
      [/^(\s*)alias_method\s*\(\s*:getbyte\s*,\s*:\[\]\s*\)\s*$/, :getbyte],
      [/^(\s*)alias_method\s*\(\s*:setbyte\s*,\s*:\[\]=\s*\)\s*$/, :setbyte],
      [/^(\s*)alias_method\s*\(\s*:bytesize\s*,\s*:size\s*\)\s*$/, :bytesize]
    ].freeze

    def self.transform(source)
      text = Source.syntax(source)
      return text if text.include?(MARKER)
      changes = []

      # A common XP/VX compatibility shim aliases Ruby 1.8's String#[] to
      # getbyte. On Ruby 3 that DESTROYS the native Integer-returning getbyte
      # and turns it back into a one-character String. Keep Ruby 3's native
      # getbyte/setbyte/bytesize instead.
      if text.include?('class String')
        LEGACY_STRING_ALIASES.each do |pattern, name|
          before = text
          text = text.gsub(pattern) do
            indent = Regexp.last_match(1)
            "#{indent}# #{MARKER}: keep native String##{name}"
          end
          changes << "String##{name}" if text != before
        end
      end

      # Ruby 1.8: String#[Integer] => byte Integer.
      # Ruby 3:   String#[Integer] => one-character String.
      # One-byte binary reads are unambiguous and safe to convert globally for
      # RGSS1. Use our captured native method, not String#getbyte dispatch,
      # because old game scripts may redefine getbyte later.
      before = text
      text = text.gsub(/\b([A-Za-z_@][A-Za-z0-9_@.]*)\.read\s*\(\s*1\s*\)\s*\[\s*0\s*\]/) do
        "Kerberus::Compatibility::Ruby18.byte_at(#{Regexp.last_match(1)}.read(1), 0)"
      end
      changes << 'read(1)[0]' if text != before

      unless changes.empty?
        Kerberus::Compatibility.event('RUBY18_CORE', 'ClassicCore520', "normalized #{changes.uniq.join(',')}")
      end

      text << "\n# #{MARKER}\n"
      text
    end
  end
end

module Kerberus::Compatibility
  module LegacySweep511
    MARKER = 'KERBERUS_RGSS1_SWEEP_511'

    def self.event(rule, detail)
      Kerberus::Compatibility.event('RUBY18_SWEEP', rule, detail)
    rescue StandardError
    end

    def self.transform(source)
      text = source.dup

      # Ruby >= 3 removed deprecated aliases still used by Essentials v17.
      if text.include?('File.exists?(')
        text = text.gsub('File.exists?(', 'File.exist?(')
        event('File.exists?', 'File.exist?')
      end
      if text.include?('Dir.exists?(')
        text = text.gsub('Dir.exists?(', 'Dir.exist?(')
        event('Dir.exists?', 'Dir.exist?')
      end

      # Ruby 1.8 Hash#index(value) returned the matching key.
      if text.include?('CONTROLSLIST.index(keyCode)')
        text = text.gsub('CONTROLSLIST.index(keyCode)', 'CONTROLSLIST.key(keyCode)')
        event('Hash#index', 'CONTROLSLIST usa Hash#key no Ruby moderno')
      end

      # Essentials v17 FileInputMixin assumes each_byte always yields Integer.
      # Some Uranium StringInput implementations delegate to getc, which yields
      # a one-byte String in modern Ruby.
      if text.include?('module FileInputMixin') &&
         text.include?('def fgetdw') &&
         text.include?('class StringInput < IO')
        before = text
        text = text.gsub(/(each_byte do \|i\|\r?\n)([ \t]*)/) do
          head = Regexp.last_match(1)
          indent = Regexp.last_match(2)
          guard = "#{indent}i = i.ord if i.is_a?(String)\n"
          head + indent + guard
        end
        event('FileInputMixin', 'fgetb/fgetw/fgetdw normalizam byte String -> Integer') if text != before
      end

      # Ruby 1.8 String#[n] returned a byte integer. Restrict the rewrite to
      # comparisons against hexadecimal byte literals, avoiding Array accesses.
      before = text
      text = text.gsub(/\b([A-Za-z_][A-Za-z0-9_]*)\[(\d+)\](\s*(?:==|!=)\s*0x[0-9A-Fa-f]+)/) do
        "Kerberus::Compatibility::Ruby18.byte_at(#{Regexp.last_match(1)}, #{Regexp.last_match(2)})#{Regexp.last_match(3)}"
      end
      event('String byte index', 'comparacoes binaria usam String#getbyte') if text != before

      # Uranium ships a StringInput < IO implemented entirely in Ruby. In Ruby
      # 3, inherited IO#getbyte/binmode attempt to access an uninitialized native
      # stream. Override only this game class; do not monkey-patch String globally.
      if text.include?('class StringInput') &&
         text.include?('module ::Marshal') &&
         text.include?('def pbRgssOpen') &&
         !text.include?(MARKER)
        text = text.gsub('@string.each(&block)', '@string.each_line(&block)')
        text << <<~'RUBY'

          # KERBERUS_RGSS1_SWEEP_511
          class StringInput
            def binmode
              self
            end

            def pos
              raise IOError, 'closed stream' if @closed
              [@pos, @string.bytesize].min
            end

            def seek(offset, whence = IO::SEEK_SET)
              raise IOError, 'closed stream' if @closed
              case whence
              when IO::SEEK_SET
                @pos = offset
              when IO::SEEK_CUR
                @pos += offset
              when IO::SEEK_END
                @pos = @string.bytesize - offset
              else
                raise ArgumentError, "unknown seek flag: #{whence}"
              end
              @pos = 0 if @pos < 0
              @pos = [@pos, @string.bytesize + 1].min
              offset
            end

            def eof?
              raise IOError, 'closed stream' if @closed
              @pos >= @string.bytesize
            end

            def getbyte
              raise IOError, 'closed stream' if @closed
              return nil if @pos >= @string.bytesize
              byte = Kerberus::Compatibility::Ruby18.byte_at(@string, @pos)
              @pos += 1
              byte
            end

            def getc
              byte = getbyte
              byte.nil? ? nil : byte.chr(Encoding::BINARY)
            end

            def each_byte
              return enum_for(:each_byte) unless block_given?
              while (byte = getbyte)
                yield byte
              end
              self
            end

            def read(len = nil, outbuf = nil)
              raise IOError, 'closed stream' if @closed
              if len.nil?
                data = @string.byteslice(@pos, @string.bytesize - @pos) || ''.b
                @pos = @string.bytesize
              else
                len = Integer(len)
                raise ArgumentError, 'negative length' if len < 0
                data = ''.b if len == 0
                if len > 0
                  data = @string.byteslice(@pos, len)
                  return nil if data.nil?
                  @pos += data.bytesize
                end
              end
              if outbuf
                outbuf.replace(data)
                outbuf
              else
                data
              end
            end

            def gets
              raise IOError, 'closed stream' if @closed
              return nil if @pos >= @string.bytesize
              binary = @string.b
              idx = binary.index("\n".b, @pos)
              if idx
                finish = idx + 1
                line = @string.byteslice(@pos, finish - @pos)
                @pos = finish
              else
                line = @string.byteslice(@pos, @string.bytesize - @pos)
                @pos = @string.bytesize
              end
              @lineno += 1
              line
            end
          end
        RUBY
        event('StringInput', 'IO binario/Marshal em bytes sem stream nativo')
      end

      text
    end
  end
end

module Kerberus::Compatibility
  module DisposeTrace513
    MARKER = 'KERBERUS_DISPOSE_TRACE_513'

    def self.event(stage, detail)
      Kerberus::Compatibility.event('DISPOSE_TRACE', stage, detail)
    rescue Exception
      begin
        warn("[KERBERUS][DISPOSE_TRACE][#{stage}] #{detail}")
      rescue Exception
      end
    end

    def self.transform(source)
      text = source.dup

      # Instrument only the Essentials helper script that owns both disposal
      # helpers. We append wrappers instead of replacing the original methods.
      if text.include?('def pbDisposeSpriteHash') &&
         text.include?('def pbDisposeSprite') &&
         !text.include?(MARKER)
        text << <<~'RUBY'

          # KERBERUS_DISPOSE_TRACE_513
          module KerberusDisposeTrace513
            def self.safe(label)
              value = yield
              "#{label}=#{value.inspect}"
            rescue Exception => e
              "#{label}=<#{e.class}: #{e.message}>"
            end

            def self.describe(obj)
              return 'object=nil' if obj.nil?

              parts = []
              parts << safe('class') { obj.class.name || obj.class.to_s }
              parts << safe('object_id') { obj.object_id }
              parts << safe('ivars') { obj.instance_variables }
              parts << safe('ancestors') do
                obj.class.ancestors[0, 12].map { |c| c.respond_to?(:name) && c.name ? c.name : c.to_s }
              end
              parts << safe('initialize_owner') { obj.class.instance_method(:initialize).owner.to_s }
              parts << safe('initialize_source') { obj.class.instance_method(:initialize).source_location }
              parts << safe('dispose_owner') { obj.class.instance_method(:dispose).owner.to_s }
              parts << safe('dispose_source') { obj.class.instance_method(:dispose).source_location }
              parts << safe('responds_disposed') { obj.respond_to?(:disposed?) }
              if begin obj.respond_to?(:disposed?) rescue false end
                parts << safe('disposed?') { obj.disposed? }
              end
              parts.join(' ')
            end

            def self.hash_info(hash)
              parts = []
              parts << safe('hash_class') { hash.class.name || hash.class.to_s }
              parts << safe('hash_object_id') { hash.object_id }
              parts << safe('size') { hash.respond_to?(:size) ? hash.size : nil }
              parts << safe('keys') do
                if hash.respond_to?(:keys)
                  ks = hash.keys
                  ks.length > 64 ? (ks[0, 64] + [:'...truncated...']) : ks
                else
                  nil
                end
              end
              parts.join(' ')
            end

            def self.log(stage, detail)
              Kerberus::Compatibility.event('DISPOSE_TRACE', stage, detail)
            rescue Exception
              begin
                warn("[KERBERUS][DISPOSE_TRACE][#{stage}] #{detail}")
              rescue Exception
              end
            end
          end

          unless Object.private_method_defined?(:__kerberus_pbDisposeSprite_513)
            Object.class_eval do
              alias_method :__kerberus_pbDisposeSprite_513, :pbDisposeSprite
              alias_method :__kerberus_pbDisposeSpriteHash_513, :pbDisposeSpriteHash
            end
          end

          def pbDisposeSprite(sprites, id)
            obj = nil
            lookup_error = nil
            begin
              obj = sprites[id]
            rescue Exception => e
              lookup_error = "#{e.class}: #{e.message}"
            end

            KerberusDisposeTrace513.log(
              'SPRITE_BEFORE',
              "key=#{id.inspect} lookup_error=#{lookup_error.inspect} " +
              KerberusDisposeTrace513.describe(obj)
            )

            begin
              result = __kerberus_pbDisposeSprite_513(sprites, id)
              KerberusDisposeTrace513.log(
                'SPRITE_AFTER',
                "key=#{id.inspect} result=#{result.inspect}"
              )
              result
            rescue Exception => e
              KerberusDisposeTrace513.log(
                'SPRITE_FAIL',
                "key=#{id.inspect} error=#{e.class}: #{e.message} " +
                KerberusDisposeTrace513.describe(obj) +
                " caller=#{caller(0, 12).join(' <- ')}"
              )
              raise
            end
          end

          def pbDisposeSpriteHash(sprites)
            KerberusDisposeTrace513.log(
              'HASH_BEGIN',
              KerberusDisposeTrace513.hash_info(sprites)
            )
            begin
              result = __kerberus_pbDisposeSpriteHash_513(sprites)
              KerberusDisposeTrace513.log(
                'HASH_END',
                KerberusDisposeTrace513.hash_info(sprites)
              )
              result
            rescue Exception => e
              KerberusDisposeTrace513.log(
                'HASH_FAIL',
                "error=#{e.class}: #{e.message} " +
                KerberusDisposeTrace513.hash_info(sprites) +
                " caller=#{caller(0, 12).join(' <- ')}"
              )
              raise
            end
          end
        RUBY
        event('INSTALL', 'wrappers de pbDisposeSprite/pbDisposeSpriteHash adicionados ao script em memoria')
      end

      text
    end
  end
end

module Kerberus::Compatibility
  module PlaneLifecycle514
    MARKER = 'KERBERUS_LARGEPLANE_LIFECYCLE_FIX_514'

    def self.event(rule, detail)
      Kerberus::Compatibility.event('RGSS1_LIFECYCLE_FIX', rule, detail)
    rescue Exception
    end

    def self.transform(source)
      text = source.dup
      return text if text.include?(MARKER)
      return text unless text.include?('class LargePlane < Plane')
      return text unless text.include?('@__sprite=Sprite.new(viewport)') ||
                         text.include?('@__sprite = Sprite.new(viewport)')

      start = text.index('class LargePlane < Plane')
      return text unless start

      finish = text.index(/\nclass\s+\w+\s*<\s*LargePlane\b/, start + 1)
      finish ||= text.length
      segment = text[start...finish]

      # LargePlane is a pure Ruby facade over @__sprite. It deliberately does
      # not call Plane#initialize, therefore calling Plane#dispose is invalid in
      # mkxp-z, whose native backing object is created by initialize.
      # There is exactly one bare `super` in the LargePlane body: dispose.
      supers = segment.scan(/^([ \t]*)super[ \t]*\r?$/)
      unless supers.length == 1
        event('LargePlane', "patch skipped: expected 1 bare super, found #{supers.length}")
        return text
      end

      segment2 = segment.sub(/^([ \t]*)super[ \t]*\r?$/) do
        indent = Regexp.last_match(1)
        "#{indent}# #{MARKER}: Plane#initialize was never called; do not call Plane#dispose"
      end

      return text if segment2 == segment

      text = text[0...start] + segment2 + text[finish..-1].to_s
      event('LargePlane', 'removed invalid native Plane#dispose call; @__sprite cleanup preserved')
      text
    end
  end
end

module Kerberus::Compatibility
  module AudioByteSemantics515
    MARKER = 'KERBERUS_AUDIO_BYTE_SEMANTICS_FIX_515'

    def self.event(rule, detail)
      Kerberus::Compatibility.event('RUBY18_AUDIO_BYTES', rule, detail)
    rescue Exception
    end

    def self.transform(source)
      text = source.dup
      return text if text.include?(MARKER)

      # Restrict this compatibility rewrite to the old Essentials/Uranium
      # binary audio parser. Do not alter String#[] globally.
      return text unless text.include?('def getOggPage')
      return text unless text.include?('def oggfiletime')
      return text unless text.include?('def getPlayTime2')

      changed = 0

      # Ruby 1.8: "abc"[0] => Integer.
      # Ruby 3.x: "abc"[0] => one-character String.
      before = text
      text = text.gsub(/file\.read\(1\)\[0\]/, 'Kerberus::Compatibility::Ruby18.byte_at(file.read(1), 0)')
      changed += 1 if text != before

      # The MP3 frame parser reads a 3-byte String into rstr and performs
      # integer comparisons/bit shifts on rstr[0] and rstr[1].
      before = text
      text = text.gsub(/\brstr\[0\](?=\s*==\s*0x[0-9A-Fa-f]+)/, 'rstr.getbyte(0)')
      changed += 1 if text != before

      before = text
      text = text.gsub(/\brstr\[1\](?=\s*>>)/, 'rstr.getbyte(1)')
      changed += 1 if text != before

      if changed > 0
        text << "\n# #{MARKER}\n"
        event(
          'AudioUtilities',
          'binary String byte indexing converted to String#getbyte for OGG/MP3 parser'
        )
      else
        event(
          'AudioUtilities',
          'parser detected but no old Ruby 1.8 byte-index patterns were found'
        )
      end

      text
    end
  end
end

module Kerberus::Compatibility
  module Uranium
    def self.detect?(sources)
      sources.any? { |s| Source.signature(s, 'RGSSLinker_Initialize', 'Uranium.ini') } &&
        sources.any? { |s| Source.signature(s, 'Init_FmodEx', 'LOOP_TABLE', 'bgmvolume') }
    end
    def self.transform(source)
      text = DisposeTrace513.transform(PlaneLifecycle514.transform(AudioByteSemantics515.transform(LegacySweep511.transform(Essentials.transform(source)))))

      # KERBERUS_URANIUM_GETC_BYTE_FIX
      # Essentials v17 espera bytes numericos em StringInput#each_byte.
      if Source.signature(
        text,
        'class StringInput < IO',
        'def each_byte',
        'yield getc'
      )
        text = text.sub(/^(\s*)yield getc\s*$/) do
          indent = $1
          "#{indent}__kerberus_byte = getc\n" \
          "#{indent}yield(__kerberus_byte.is_a?(String) ? " \
          "Kerberus::Compatibility::Ruby18.byte_at(__kerberus_byte, 0) : __kerberus_byte)"
        end

        Kerberus::Compatibility.event(
          'RUBY3_PATCH',
          'File_Mixins/StringInput',
          'getc convertido para byte Integer'
        )
      end

      # KERBERUS_URANIUM_FILEMIXINS_BYTE_FIX
      #
      # Pokemon Essentials v17 foi escrito para semantica Ruby 1.8,
      # onde varios leitores internos trabalhavam com bytes numericos.
      # Em Ruby 3, String#[Integer] pode produzir String de 1 byte.
      #
      # File_Mixins/fgetdw executa operacoes bitwise e precisa de Integer.
      if Source.signature(text, 'def fgetdw', 'each_byte')
        text = text.gsub(
          /yield\s+([A-Za-z_@][A-Za-z0-9_@]*\s*\[[^\]\n]+\])/
        ) do
          expr = $1
          "begin\n" \
          "  __kerberus_byte = #{expr}\n" \
          "  yield(__kerberus_byte.is_a?(String) ? Kerberus::Compatibility::Ruby18.byte_at(__kerberus_byte, 0) : __kerberus_byte)\n" \
          "end"
        end

        text = text.gsub(
          /yield\(\s*([A-Za-z_@][A-Za-z0-9_@]*\s*\[[^\]\n]+\])\s*\)/
        ) do
          expr = $1
          "begin\n" \
          "  __kerberus_byte = #{expr}\n" \
          "  yield(__kerberus_byte.is_a?(String) ? Kerberus::Compatibility::Ruby18.byte_at(__kerberus_byte, 0) : __kerberus_byte)\n" \
          "end"
        end

        Kerberus::Compatibility.event(
          'RUBY3_PATCH',
          'File_Mixins',
          'StringInput each_byte normalizado para Integer'
        )
      end
      if Source.signature(text, 'RGSSLinker_Initialize', 'def load_module')
        return "Kerberus::Compatibility::Uranium.install_loader\n"
      end
      if Source.signature(text, 'Init_FmodEx', 'LOOP_TABLE', 'bgmvolume')
        loop_text = text[/LOOP_TABLE\s*=\s*\[(.*?)\]/m, 1]
        unless loop_text && loop_text.lines.all? { |line| line.strip.empty? || line.strip.start_with?('#') }
          raise Unavailable, 'FMOD LOOP_TABLE personalizada: precisa de suporte a pontos de loop antes de executar'
        end
        return "Kerberus::Compatibility::AudioAdapter.install(true)\n"
      end
      if Source.signature(text, 'KLEIN_BFUNCS_DLL', 'def klein_dll', 'compare_klein_bitmaps')
        return "Kerberus::Compatibility::BitmapAdapter.install_klein\n"
      end
      text
    end
    def self.install_loader
      Kernel.send(:define_method, :load_module) do |library, symbol|
        if Win32.library(library) == 'rgss fmodex' && symbol == 'Init_FmodEx'
          AudioAdapter.install(true)
          Kerberus::Compatibility.event('PROFILE_REPLACED', 'RGSS Linker', 'Audio nativo; nao carrega ABI Ruby 1.8')
          true
        else
          Kerberus::Compatibility.unavailable("#{library}!#{symbol}", 'Extensao RGSS Linker nao classificada')
        end
      end
      Kernel.send(:module_function, :load_module)
    end
  end
end

module Kerberus::Compatibility
  module Insurgence
    def self.detect?(sources)
      sources.any? { |s| Source.signature(s, 'MGC_Hmode7', 'renderHM7', 'drawMapTileset') } &&
        sources.any? { |s| s.b.include?('Insurgence') || s.b.include?('INSURGENCE') }
    end
    def self.transform(source)
      text = LegacySweep511.transform(Essentials.transform(source))
      if Source.signature(text, 'def update_command', '@cmdCult', 'array[int]')
        # The cancellation branch was a break outside any loop. Return to the
        # existing command window without changing quest/story state.
        pattern = /(if array\[int\]=="\(Cancel\)"\s*\n\s*)break\b/
        text = text.sub(pattern, '\\1return')
      end
      if Source.signature(text, 'def battle', 'return tradeorbattle')
        text = text.gsub(/(return tradeorbattle\s*\n)(\s*)break\s*\n/, '\\1\\2# unreachable legacy break removed' + "\n")
      end
      if Source.signature(text, 'module Keys', '@getKeyboardState', 'glitch_input_keys_update')
        text += "\nKerberus::Compatibility::InputAdapter.install_keys\n"
      end
      # HMode7 and network constructors are classified but deferred by Win32.
      # No map, battle, or online code is removed to make a syntax test pass.
      text
    end
  end
end

module Kerberus::Compatibility
  class << self
    def detect(scripts)
      sources = scripts.map { |entry| entry[3].to_s }
      uranium, insurgence = Uranium.detect?(sources), Insurgence.detect?(sources)
      raise ArgumentError, 'Perfis conflitantes: Uranium e Insurgence' if uranium && insurgence
      uranium ? :uranium : insurgence ? :insurgence : nil
    end
    def prepare(scripts)
      selected = detect(scripts)
      rgss1 = defined?($KERBERUS_RGSS_VERSION) && $KERBERUS_RGSS_VERSION.to_i == 1
      return [nil, []] unless selected || rgss1
      transformer = selected == :uranium ? Uranium : selected == :insurgence ? Insurgence : nil
      transformed = []
      errors = []
      scripts.each_with_index do |entry, i|
        original = entry[3]
        raise ArgumentError, "Script #{i}: fonte ausente" unless original.is_a?(String)
        raise ArgumentError, "Script #{i}: excede 4 MiB" if original.bytesize > 4 * 1024 * 1024
        begin
          value = ClassicCore520.transform(original)
          value = transformer.transform(value) if transformer
          value = value.force_encoding('UTF-8')
          # mkxp-z evaluates RGSS sections with Kernel.eval(..., nil, filename),
          # so top-level `self` is nil. Ruby's lexical `using` cannot be invoked
          # there. Byte compatibility is installed once for the selected legacy
          # game immediately before the transformed sections are published.
          RubyVM::InstructionSequence.compile(value, "Section#{i.to_s.rjust(3, '0')}", nil, 1)
          transformed << value
        rescue SyntaxError, ArgumentError, Unavailable => error
          errors << "Section#{i.to_s.rjust(3, '0')}: #{error.message.lines.first.to_s.strip}"
        end
      end
      unless errors.empty?
        errors.first(32).each { |error| event('SYNTAX_REJECTED', selected.to_s, error) }
        raise SyntaxError, "Kerberus #{selected}: #{errors.length}/#{scripts.length} scripts rejeitados; originais preservados.\n#{errors.first(8).join("\n")}"
      end
      [selected || :rgss1, transformed]
    end
    def activate(scripts)
      return if @activated
      if ENV['KERBERUS_COMPAT_MODE'] == 'off'
        event('PROFILE_DISABLED', 'Pokemon Compatibility', 'Desativado pelo usuario para este jogo')
        return
      end
      selected, transformed = prepare(scripts)
      return unless selected
      report = Doctor.scan(scripts, selected)
      Doctor.guard_stdlib(report)
      remember_native
      @profile = selected
      Ruby18.install(true)
      Win32.install

      remaining_cjk = []
      transformed.each_with_index do |source, index|
        if source.include?('FullWidthLatin = /(?:\\xef') ||
           source.include?('FullWidthNumber = /(?:\\xef') ||
           source.match?(/^\s*(?:CJ|WordRegexp)\s*=.*\/n\s*$/)
          remaining_cjk << index
        end
      end
      unless remaining_cjk.empty?
        raise Unavailable,
          "CJK Ruby 1.8 ainda binario nas sections #{remaining_cjk.first(16).join(',')}"
      end

      # Atomic publication after EVERY section passes compilation and the
      # runtime-only CJK compatibility guard passes.
      scripts.each_with_index { |entry, i| entry[3] = transformed[i] }
      @activated = true
      $KERBERUS_URANIUM_COMPAT_ACTIVE = selected == :uranium
      event('STATIC_OK', selected.to_s, "#{scripts.size}/#{scripts.size} scripts syntax OK; Doctor ativo; precisa teste no Android")
    end
  end
end


# KERBERUS_PRE_SWEEP_ENCODING_FIX_510
# RGSS1 antigo pode misturar UTF-8 e Windows-1252.
# Isto precisa acontecer ANTES do Compatibility Sweep.
begin
  _kerberus_encoding_fixed = 0

  if defined?($RGSS_SCRIPTS) && $RGSS_SCRIPTS.respond_to?(:each)
    $RGSS_SCRIPTS.each do |_entry|
      next unless _entry.is_a?(Array)

      _idx =
        if _entry.length > 3 && _entry[3].is_a?(String)
          3
        elsif _entry.length > 2 && _entry[2].is_a?(String)
          2
        else
          nil
        end

      next unless _idx

      _src = _entry[_idx]
      _utf8 = _src.b.dup.force_encoding(Encoding::UTF_8)

      unless _utf8.valid_encoding?
        _utf8 = _utf8.scrub do |_bad|
          begin
            _bad.dup
                .force_encoding(Encoding.find("Windows-1252"))
                .encode(
                  Encoding::UTF_8,
                  invalid: :replace,
                  undef: :replace,
                  replace: "\uFFFD"
                )
          rescue EncodingError
            _bad.dup
                .force_encoding(Encoding.find("ISO-8859-1"))
                .encode(Encoding::UTF_8)
          end
        end

        _kerberus_encoding_fixed += 1
      end

      _entry[_idx] = _utf8
    end
  end

  if _kerberus_encoding_fixed > 0 &&
     defined?(Kerberus::Compatibility) &&
     Kerberus::Compatibility.respond_to?(:event)

    Kerberus::Compatibility.event(
      "RUBY3_PATCH",
      "Pre-sweep encoding",
      "#{_kerberus_encoding_fixed} script(s) normalized before sweep"
    )
  end
rescue StandardError
  # Nunca interromper o boot por causa do normalizador.
end

Kerberus::Compatibility.activate($RGSS_SCRIPTS)

# KERBERUS_STRINGINPUT_POST_SWEEP_FIX_510
# Essentials/RGSS1 antigo usa StringInput < IO.
# No Ruby 3 isso cria um IO sem stream nativo e Marshal.load cai em:
# IOError: uninitialized stream.
begin
  if defined?($RGSS_SCRIPTS) && $RGSS_SCRIPTS.respond_to?(:each)
    $RGSS_SCRIPTS.each do |_entry|
      next unless _entry.is_a?(Array)

      _idx =
        if _entry.length > 3 && _entry[3].is_a?(String)
          3
        elsif _entry.length > 2 && _entry[2].is_a?(String)
          2
        else
          nil
        end

      next unless _idx

      _src = _entry[_idx]

      next unless _src.include?("class StringInput") &&
                  _src.include?("module ::Marshal") &&
                  _src.include?("alias oldload load")

      # Ruby 3 nao pode tratar esse objeto como IO nativo nao inicializado.
      _src = _src.gsub(
        /class\s+StringInput\s*<\s*IO\b/,
        "class StringInput"
      )

      # Adiciona protocolo de leitura byte a byte esperado pelo Marshal moderno.
      unless _src.include?("KERBERUS_STRINGINPUT_GETBYTE_510")
        _anchor = "  alias sysread read\n"

        if _src.include?(_anchor)
          _getbyte = <<~'RUBY'
              alias sysread read

              # KERBERUS_STRINGINPUT_GETBYTE_510
              def getbyte
                raise IOError, 'closed stream' if @closed
                return nil if @pos >= @string.bytesize
                byte = @string.getbyte(@pos)
                @pos += 1
                byte
              end
          RUBY

          _src = _src.sub(_anchor, _getbyte)
        end
      end

      # Mais robusto: quando Marshal recebe StringInput, entrega diretamente
      # os bytes restantes para o Marshal nativo do Ruby 3.
      unless _src.include?("KERBERUS_MARSHAL_STRINGINPUT_510")
        _old = "        oldload(port,*arg)\n"

        if _src.scan(_old).length == 1
          _new = <<~'RUBY'
                # KERBERUS_MARSHAL_STRINGINPUT_510
                if defined?(StringInput) && port.is_a?(StringInput)
                  remaining = port.string.byteslice(
                    port.pos,
                    port.string.bytesize - port.pos
                  ) || "".b

                  value = oldload(remaining,*arg)
                  port.pos = port.string.bytesize + 1
                  value
                else
                  oldload(port,*arg)
                end
          RUBY

          _src = _src.sub(_old, _new)
        end
      end

      _entry[_idx] = _src
    end
  end
rescue StandardError => _e
  begin
    Kerberus::Compatibility.event(
      "RUBY3_PATCH",
      "StringInput/Marshal",
      "post-sweep repair failed: #{_e.class}: #{_e.message}"
    )
  rescue StandardError
  end
end



# KERBERUS_CJK_POST_SWEEP_FIX_510
# Pokemon Uranium possui CJK Utilities antigo.
# Algumas transformacoes deixam WordRegexp::CJ definido enquanto o jogo
# continua referenciando WordRegexp::CJK.
begin
  if defined?($RGSS_SCRIPTS) && $RGSS_SCRIPTS.respond_to?(:each)
    $RGSS_SCRIPTS.each do |_entry|
      next unless _entry.is_a?(Array)

      _idx =
        if _entry.length > 3 && _entry[3].is_a?(String)
          3
        elsif _entry.length > 2 && _entry[2].is_a?(String)
          2
        else
          nil
        end

      next unless _idx

      _src = _entry[_idx]

      next unless _src.include?("CJKUtils") &&
                  _src.include?("WordRegexp")

      # Se o transformer deixou apenas CJ, restaura o nome CJK esperado
      # pelo codigo original, mas mantem CJ como alias por compatibilidade.
      unless _src.match?(/^\s*CJK\s*=/)
        _src = _src.sub(
          /^(\s*)CJ\s*=\s*(.+)$/,
          "\\1CJK = \\2\n\\1CJ = CJK"
        )
      end

      _entry[_idx] = _src
    end
  end
rescue StandardError => _e
  begin
    Kerberus::Compatibility.event(
      "RUBY3_PATCH",
      "CJK Utilities",
      "post-sweep CJK alias repair failed: #{_e.class}"
    )
  rescue StandardError
  end
end





# KERBERUS_EACH_BYTE_INTEGER_FIX_511
# Ruby 1.8/RGSS1 expects String#each_byte to yield Integer values.
# Use bytesize/getbyte directly so no older String shim can turn bytes into 1-char Strings.
module Kerberus
  module Compatibility
    module Ruby18
      module EachByteIntegerFix511
        def each_byte
          return enum_for(:each_byte) unless block_given?
          i = 0
          n = bytesize
          while i < n
            yield Ruby18.byte_at(self, i)
            i += 1
          end
          self
        end
      end
    end
  end
end

unless String.ancestors.include?(Kerberus::Compatibility::Ruby18::EachByteIntegerFix511)
  String.prepend(Kerberus::Compatibility::Ruby18::EachByteIntegerFix511)
end


# KERBERUS_BYTE_SEMANTICS_FIX_512
module Kerberus
  module Compatibility
    module Ruby18
      def self.integer_byte(value)
        return value if value.is_a?(Integer)
        return value.ord if value.is_a?(String) && value.bytesize == 1
        value
      end
    end
  end
end

)KUC";
