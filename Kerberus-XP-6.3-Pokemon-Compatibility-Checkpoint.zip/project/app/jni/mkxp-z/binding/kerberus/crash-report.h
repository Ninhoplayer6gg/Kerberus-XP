#ifndef KERBERUS_CRASH_REPORT_H
#define KERBERUS_CRASH_REPORT_H
// Kerberus (6.6.2, legacy18): native crash report.
//
// A handler for SIGSEGV, SIGBUS, SIGFPE, SIGILL, SIGABRT and SIGTRAP appends
// a [CRASH] block to the runtime log: signal, code, fault address, thread,
// pc/lr, a backtrace with library and offset (and the symbol when the library
// exports it), the Ruby script line that was running and the process memory.
// Then the previous handlers are put back and the signal goes on to them, so
// Android's debuggerd still writes its tombstone and the process ends as
// before. Installed before ruby_init.
//
// Only async-signal-safe calls are used for the report itself (open, read,
// write, prctl), plus _Unwind_Backtrace and dladdr, which crash reporters on
// Android also call from their handlers. Ruby is not called: ruby_sourcefile
// and ruby_sourceline (declared by Ruby 1.8's intern.h) are only read.
#include <signal.h>
#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <dlfcn.h>
#include <unwind.h>
#include <ucontext.h>
#include <sys/prctl.h>
#include <sys/syscall.h>

static int kerberusCrashFd = -1;
static volatile sig_atomic_t kerberusCrashBusy = 0;
static const int kerberusCrashSignals[] = {SIGSEGV, SIGBUS, SIGFPE, SIGILL, SIGABRT, SIGTRAP};
static const int kerberusCrashSignalCount = (int) (sizeof(kerberusCrashSignals) / sizeof(kerberusCrashSignals[0]));
static struct sigaction kerberusCrashOld[sizeof(kerberusCrashSignals) / sizeof(kerberusCrashSignals[0])];

struct KerberusCrashText {
    char data[2048];
    size_t size;
};

static void kerberusCrashPut(KerberusCrashText &text, const char *value) {
    while (value && *value && text.size + 1 < sizeof(text.data))
        text.data[text.size++] = *value++;
}

static void kerberusCrashPutN(KerberusCrashText &text, const char *value, size_t limit) {
    for (size_t i = 0; value && value[i] && i < limit && text.size + 1 < sizeof(text.data); ++i)
        text.data[text.size++] = value[i];
}

static void kerberusCrashHex(KerberusCrashText &text, uintptr_t value) {
    char digits[2 + sizeof(uintptr_t) * 2 + 1];
    size_t count = sizeof(uintptr_t) * 2;
    digits[0] = '0';
    digits[1] = 'x';
    for (size_t i = 0; i < count; ++i)
        digits[2 + i] = "0123456789abcdef"[(value >> (4 * (count - 1 - i))) & 0xf];
    digits[2 + count] = 0;
    kerberusCrashPut(text, digits);
}

static void kerberusCrashDec(KerberusCrashText &text, long value) {
    char digits[24];
    size_t count = 0;
    bool negative = value < 0;
    unsigned long magnitude = negative ? (unsigned long) (-(value + 1)) + 1 : (unsigned long) value;
    do {
        digits[count++] = (char) ('0' + magnitude % 10);
        magnitude /= 10;
    } while (magnitude && count < sizeof(digits));
    if (negative)
        kerberusCrashPut(text, "-");
    while (count) {
        char digit[2] = {digits[--count], 0};
        kerberusCrashPut(text, digit);
    }
}

static void kerberusCrashFlush(KerberusCrashText &text) {
    size_t done = 0;
    while (kerberusCrashFd >= 0 && done < text.size) {
        ssize_t wrote = write(kerberusCrashFd, text.data + done, text.size - done);
        if (wrote <= 0)
            break;
        done += (size_t) wrote;
    }
    text.size = 0;
}

static const char *kerberusCrashSignalName(int sig) {
    switch (sig) {
    case SIGSEGV: return "SIGSEGV";
    case SIGBUS: return "SIGBUS";
    case SIGFPE: return "SIGFPE";
    case SIGILL: return "SIGILL";
    case SIGABRT: return "SIGABRT";
    case SIGTRAP: return "SIGTRAP";
    default: return "?";
    }
}

// "libname.so +0xoffset (symbol+0xdelta)" for an address. A return address
// is looked up one byte back: after a call to a noreturn function it can be
// the first byte past the caller.
static void kerberusCrashWhere(KerberusCrashText &text, uintptr_t pc, bool returnAddress) {
    kerberusCrashHex(text, pc);
    Dl_info info;
    uintptr_t lookup = returnAddress && pc ? pc - 1 : pc;
    if (lookup && dladdr(reinterpret_cast<void *>(lookup), &info) && info.dli_fname) {
        const char *name = strrchr(info.dli_fname, '/');
        kerberusCrashPut(text, " ");
        kerberusCrashPut(text, name ? name + 1 : info.dli_fname);
        kerberusCrashPut(text, " +");
        kerberusCrashHex(text, pc - reinterpret_cast<uintptr_t>(info.dli_fbase));
        if (info.dli_sname) {
            kerberusCrashPut(text, " (");
            kerberusCrashPutN(text, info.dli_sname, 160);
            kerberusCrashPut(text, "+");
            kerberusCrashHex(text, pc - reinterpret_cast<uintptr_t>(info.dli_saddr));
            kerberusCrashPut(text, ")");
        }
    }
    kerberusCrashPut(text, "\n");
}

struct KerberusCrashFrames {
    uintptr_t pc[32];
    bool returnAddress[32];
    int count;
};

static _Unwind_Reason_Code kerberusCrashStep(struct _Unwind_Context *context, void *arg) {
    KerberusCrashFrames *frames = static_cast<KerberusCrashFrames *>(arg);
    int beforeInstruction = 0;
    uintptr_t pc = _Unwind_GetIPInfo(context, &beforeInstruction);
    if (pc) {
        if (frames->count >= (int) (sizeof(frames->pc) / sizeof(frames->pc[0])))
            return _URC_END_OF_STACK;
        frames->returnAddress[frames->count] = !beforeInstruction;
        frames->pc[frames->count++] = pc;
    }
    return _URC_NO_REASON;
}

// VmRSS and VmHWM lines of /proc/self/status.
static void kerberusCrashMemory(KerberusCrashText &text) {
    int fd = open("/proc/self/status", O_RDONLY | O_CLOEXEC);
    if (fd < 0)
        return;
    char status[4096];
    ssize_t got = read(fd, status, sizeof(status) - 1);
    close(fd);
    if (got <= 0)
        return;
    status[got] = 0;
    kerberusCrashPut(text, "memoria:");
    const char *keys[] = {"VmRSS:", "VmHWM:"};
    for (int k = 0; k < 2; ++k) {
        const char *line = strstr(status, keys[k]);
        if (!line)
            continue;
        const char *end = strchr(line, '\n');
        kerberusCrashPut(text, " ");
        for (const char *c = line; c < (end ? end : line + 40); ++c)
            if (*c != ' ' && *c != '\t' && text.size + 1 < sizeof(text.data))
                text.data[text.size++] = *c;
    }
    kerberusCrashPut(text, "\n");
}

static void kerberusCrashRestore() {
    for (int i = 0; i < kerberusCrashSignalCount; ++i)
        sigaction(kerberusCrashSignals[i], &kerberusCrashOld[i], 0);
}

static void kerberusCrashHandler(int sig, siginfo_t *info, void *context) {
    if (!kerberusCrashBusy) {
        kerberusCrashBusy = 1;
        KerberusCrashText text;
        text.size = 0;
        kerberusCrashPut(text, "[CRASH] sinal ");
        kerberusCrashDec(text, sig);
        kerberusCrashPut(text, " (");
        kerberusCrashPut(text, kerberusCrashSignalName(sig));
        kerberusCrashPut(text, ") codigo ");
        kerberusCrashDec(text, info ? info->si_code : 0);
        kerberusCrashPut(text, " endereco ");
        kerberusCrashHex(text, info ? reinterpret_cast<uintptr_t>(info->si_addr) : 0);
        char thread[17] = {0};
        prctl(PR_GET_NAME, thread, 0, 0, 0);
        kerberusCrashPut(text, " thread ");
        kerberusCrashDec(text, (long) syscall(SYS_gettid));
        kerberusCrashPut(text, " (");
        kerberusCrashPutN(text, thread, 16);
        kerberusCrashPut(text, ")\n");
        kerberusCrashFlush(text);
#if defined(__aarch64__)
        if (context) {
            const ucontext_t *uc = static_cast<const ucontext_t *>(context);
            kerberusCrashPut(text, "pc ");
            kerberusCrashWhere(text, (uintptr_t) uc->uc_mcontext.pc, false);
            kerberusCrashPut(text, "lr ");
            kerberusCrashWhere(text, (uintptr_t) uc->uc_mcontext.regs[30], true);
            kerberusCrashFlush(text);
        }
#else
        (void) context;
#endif
        KerberusCrashFrames frames;
        frames.count = 0;
        _Unwind_Backtrace(kerberusCrashStep, &frames);
        for (int i = 0; i < frames.count; ++i) {
            kerberusCrashPut(text, "#");
            if (i < 10)
                kerberusCrashPut(text, "0");
            kerberusCrashDec(text, i);
            kerberusCrashPut(text, " ");
            kerberusCrashWhere(text, frames.pc[i], frames.returnAddress[i]);
            kerberusCrashFlush(text);
        }
        if (ruby_sourcefile) {
            kerberusCrashPut(text, "ruby: ");
            kerberusCrashPutN(text, ruby_sourcefile, 96);
            kerberusCrashPut(text, ":");
            kerberusCrashDec(text, ruby_sourceline);
            kerberusCrashPut(text, " (ultima linha Ruby em execucao)\n");
        }
        kerberusCrashMemory(text);
        kerberusCrashFlush(text);
    }
    // Hand the signal to the handlers that were there before (debuggerd).
    kerberusCrashRestore();
    if (!info || info->si_code <= 0 || sig == SIGABRT)
        syscall(SYS_tgkill, getpid(), syscall(SYS_gettid), sig);
}

// Opens the runtime log now (the handler may not allocate or look up
// environment variables) and installs the handler.
static bool kerberusInstallCrashReport(const char *logPath) {
    if (!logPath || !*logPath || kerberusCrashFd >= 0)
        return false;
    kerberusCrashFd = open(logPath, O_WRONLY | O_APPEND | O_CREAT | O_CLOEXEC, 0644);
    if (kerberusCrashFd < 0)
        return false;
    struct sigaction action;
    memset(&action, 0, sizeof(action));
    action.sa_sigaction = kerberusCrashHandler;
    action.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigemptyset(&action.sa_mask);
    for (int i = 0; i < kerberusCrashSignalCount; ++i)
        sigaction(kerberusCrashSignals[i], &action, &kerberusCrashOld[i]);
    return true;
}
#endif
