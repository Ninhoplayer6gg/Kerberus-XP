#pragma once
// Kerberus (legacy18): line of a Ruby 1.8 SyntaxError.
//
// Ruby 1.8 raises a SyntaxError at the section's LAST line (where the
// parser gave up); the line of each error opens a line of the message:
//   compile error
//   Section253:270: undefined (?...) sequence: /(?<!\\)"/
// Returns the first "<file>:<digits>:" line number of the message, or
// FALLBACK (the backtrace line) when the message has none for FILE.
#include <string>

static inline std::string kerberusSyntaxErrorLine(const std::string &file, const std::string &message,
                                                  const std::string &fallback)
{
    if (file.empty())
        return fallback;
    const std::string key = file + ":";
    for (size_t at = message.find(key); at != std::string::npos; at = message.find(key, at + 1)) {
        size_t digits = at + key.size(), end = digits;
        while (end < message.size() && message[end] >= '0' && message[end] <= '9')
            ++end;
        if ((at == 0 || message[at - 1] == '\n') && end > digits && end < message.size() && message[end] == ':')
            return message.substr(digits, end - digits);
    }
    return fallback;
}
