#ifndef KERBERUS_HM7_CORE_H
#define KERBERUS_HM7_CORE_H

// Kerberus port of MGC's H-Mode7 renderer: the eight exports of
// MGC_Hmode7.dll (H-Mode7 Engine v1.2.1, MGC/MGCaladtogel, 2011) used by RPG
// Maker XP games such as Pokemon Insurgence. The DLL is x86 Windows code and
// cannot run on Android. This is a reimplementation written from an analysis
// of what each export does; no code or data of the DLL is included except
// the 64 values of the lighting ramp (applyLighting), which are the effect
// itself. Every function was checked byte for byte against the original DLL
// running in an x86 emulator, on generated inputs (Kerberus 6.6 notes).
//
// Data is laid out as the DLL sees RGSS1 objects, so the arithmetic follows
// it exactly:
//   Bitmap  BGRA pixels, `top` = first pixel of the top row, rows go DOWN in
//           memory: pixel(x, y) = top + 4 * x - 4 * w * y
//   Table   int16 data, x fastest, then y, then z
//   Value   a Ruby 1.8 value as stored in an Array: Fixnum 2n+1, false 0,
//           true 2, nil 4 (the DLL uses some of them without decoding)
// The DLL takes the objects' sizes for granted. Here every function checks
// them first: a call whose objects do not have the sizes H-Mode7 creates
// returns false and changes nothing, and a single entry pointing outside an
// image (a tile id past the tileset, for instance) is skipped and counted
// instead of being read out of bounds.
#include <cstdint>

namespace kerberus { namespace hm7 {

typedef int32_t Value;

struct Bitmap {
    int32_t w = 0, h = 0;
    uint8_t *top = nullptr;
};

struct Table {
    int32_t xs = 0, ys = 0, zs = 0;
    int16_t *data = nullptr;
};

// One 3-layer combination of the map (drawMapTileset, refreshMapTileset):
// index in the map tileset and the tile ids of layers 1-3 (0 = empty, < 384
// autotile, >= 384 tileset); `counted` = layers that count for the
// characters' altitude.
struct TileEntry {
    int32_t index, layer1, layer2, layer3, counted;
};

// Walls (drawTextureset): one textures-hash entry = basic tile `index` of
// the map, its tile id and its texture (tileset tile: 160x32, block 0 heights
// + 4 faces; autotile: 128x32, 4 faces, heights from the Texture_Auto sheet).
struct TextureEntry {
    int32_t index, tile;
    Bitmap *texture;
};

// HM7::Tilemap @params, in order.
struct RenderParams {
    Bitmap render;       // [0]  frame (640x480, 480x360 or 320x240)
    Table compute;       // [1]  computeM7 table: map x / y seen at each screen pixel
    Bitmap rows;         // [2]  per row: fade colour, zoom, x scale; line 2 = column tops
    Table heightmap;     // [3]
    Bitmap mapTileset;   // [4]  512 wide
    Table tiletable;     // [5]
    Bitmap textureset;   // [6]  160 wide
    Value loopX, loopY;  // [7] [8]
    Value cameraMode;    // [9]
    Bitmap buffer;       // [10] render size: translucent sprite pixels
    Value lessCut;       // [11]
    Value noBlackCut;    // [12]
};

// One @render_surfaces entry: [type, screen_x, screen_y, bitmap, altitude,
// blend_type]; bitmap nullptr = nothing to draw.
struct Surface {
    Value x, y, altitude, blend;
    Bitmap *bitmap;
};

namespace detail {

// 32-bit two's complement arithmetic, as the x86 code does it.
inline int32_t mul(int32_t a, int32_t b) { return (int32_t)((uint32_t)a * (uint32_t)b); }
inline int32_t add(int32_t a, int32_t b) { return (int32_t)((uint32_t)a + (uint32_t)b); }
inline int32_t sub(int32_t a, int32_t b) { return (int32_t)((uint32_t)a - (uint32_t)b); }
inline int32_t sar(int32_t a, int n) { return a >> n; }                       // arithmetic
inline int32_t shr(int32_t a, int n) { return (int32_t)((uint32_t)a >> n); }  // logical
inline int32_t shl(int32_t a, int n) { return (int32_t)((uint32_t)a << n); }
inline int32_t idiv(int32_t a, int32_t b) { return a / b; }                   // b != 0 checked by callers
// x / 960, rounding toward zero (the compiler's multiply-by-reciprocal form)
inline int32_t div960(int32_t x) {
    int32_t t = (int32_t)(((int64_t)x * (int64_t)(int32_t)0x88888889) >> 32);
    t = sar(add(t, x), 9);
    return add(t, shr(t, 31));
}
inline uint8_t *px(const Bitmap &b, int32_t x, int32_t y) { return b.top + 4 * x - 4 * b.w * y; }
inline bool sized(const Bitmap &b) { return b.top && b.w > 0 && b.h > 0; }
inline int64_t cells(const Table &t) { return (int64_t)t.xs * t.ys * t.zs; }
inline bool sized(const Table &t) { return t.data && t.xs > 0 && t.ys > 0 && t.zs > 0; }
// Pointer to 4 bytes inside the bitmap's pixels, or nullptr.
inline const uint8_t *inside(const Bitmap &b, const uint8_t *p) {
    const uint8_t *base = b.top - 4 * b.w * (b.h - 1);
    return p >= base && p + 4 <= base + 4 * b.w * b.h ? p : nullptr;
}
inline int32_t clampHigh(int32_t v) { return v > 255 ? 255 : v; }
inline int32_t clampLow(int32_t v) { return v < 0 ? 0 : v; }
inline int32_t clampBoth(int32_t v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }

}  // namespace detail

// Sprite translucency: alpha = alpha * (opacity + 1) / 256.
inline bool applyOpacity(Bitmap &bitmap, int32_t opacity) {
    using namespace detail;
    if (!sized(bitmap)) return false;
    const int32_t factor = add(opacity, 1);
    for (int32_t y = 0; y < bitmap.h; ++y)
        for (int32_t x = 0; x < bitmap.w; ++x) {
            uint8_t *alpha = px(bitmap, x, y) + 3;
            *alpha = (uint8_t)sar(mul(*alpha, factor), 8);
        }
    return true;
}

// params: [cos_alpha, sin_alpha, distance_h, pivot_map, slope_value_map,
// corrective_value_map, height_limit, cos_theta, sin_theta, distance_p, zoom_map]
// For each screen row y from the horizon down: table plane 0/1 = the map x/y
// seen at each pixel of the row; rows bitmap line 0 = fading colour of the
// row, line 1 = the row's zoom (R << 8 | A, /4096) and x scale (B << 8 | G).
inline bool computeM7(Table &table, Bitmap &rows, const Value *p) {
    using namespace detail;
    if (!sized(table) || table.zs < 2 || !sized(rows) || rows.h < 2 || rows.w < table.ys) return false;
    const int32_t sinA = p[1], slope = p[4], corr = p[5];   // used undecoded
    const int32_t cosT = p[7], sinT = p[8];                 // used undecoded
    const int32_t limit = shr(p[6], 1), zoom = shr(p[10], 1);
    const int32_t dh = shr(p[2], 1), dp = shr(p[9], 1);
    const int32_t pivot = shr(p[3], 1);
    const int32_t xs = table.xs, ys = table.ys, plane = mul(ys, xs);
    const int32_t half = sar(xs, 1);
    int16_t *data = table.data;
    const uint8_t *fade = px(rows, 0, 0);
    const int32_t fadeB = fade[0], fadeG = fade[1], fadeR = fade[2], fadeA = fade[3];

    int32_t y = limit < 0 ? 0 : limit;
    if (y >= ys) return true;
    int32_t den = add(mul(sub(y, pivot), sinA), mul(sub(dh, dp), p[0]));
    int32_t num = mul(sub(y, pivot), dh);
    int32_t w = add(mul(y, slope), corr);
    int32_t row = mul(y, xs);
    for (int32_t left = sub(ys, y); left != 0; --left, ++y) {
        const int32_t d = sar(den, 12);
        const int32_t q = d ? idiv(num, d) : 0;  // the DLL divides by zero here (crash)
        const int32_t yy = add(sar(mul(q, zoom), 12), pivot);
        const int32_t dy = sub(yy, pivot);
        const int32_t dySin = mul(dy, sinT), dyCos = mul(dy, cosT);
        const int32_t far = sub(pivot, yy);
        if (far >= 0) {
            uint8_t *c = px(rows, y, 0);
            int32_t v;
            v = div960(mul(far, fadeB)); c[0] = (uint8_t)(v > 255 ? 255 : v);
            v = div960(mul(far, fadeG)); c[1] = (uint8_t)(v > 255 ? 255 : v);
            v = div960(mul(far, fadeR)); c[2] = (uint8_t)(v > 255 ? 255 : v);
            c[3] = (uint8_t)fadeA;
        }
        uint8_t *line1 = px(rows, y, 1);
        for (int32_t j = 0; j < half; ++j) {
            int32_t xx = w ? idiv(shl(sub(half, j), 18), w) : 0;
            xx = sar(mul(xx, zoom), 12);
            if (j == 0 && xx != 0) {  // same: the DLL divides by zero when xx is 0
                const int32_t sx = idiv(mul(half, sinA), xx);
                line1[1] = (uint8_t)sx;
                line1[0] = (uint8_t)sar(sx, 8);
                const int32_t z = idiv(shl(half, 12), xx);
                line1[2] = (uint8_t)sar(z, 8);
                line1[3] = (uint8_t)z;
            }
            const int32_t nx = sub(sub(half, xx), half);   // -xx
            data[add(row, j)] = (int16_t)add(sar(sub(mul(nx, cosT), dySin), 12), half);
            data[add(add(plane, row), j)] = (int16_t)add(sar(add(mul(nx, sinT), dyCos), 12), pivot);
            data[sub(add(row, xs), add(j, 1))] = (int16_t)add(sar(sub(mul(xx, cosT), dySin), 12), half);
            data[sub(add(add(plane, row), xs), add(j, 1))] = (int16_t)add(sar(add(mul(xx, sinT), dyCos), 12), pivot);
        }
        den = add(den, sinA);
        num = add(num, dh);
        w = add(w, slope);
        row = add(row, xs);
    }
    return true;
}

// heightmap (2 * map width) x (1.5 * map height):
//   [2x, y]                      ground height + all layers (drawing)
//   [x + mw * (y & 1), mh + y/2] ground height + the layers counted in the
//                                tile's alpha (characters' altitude)
// Ground height: blue channel of `pattern` stretched over the map (tenths,
// bilinear). Layer heights: the pixel right of (64 * (tile & 7) +
// 2 * (x & 31), 32 * (tile >> 3) + (y & 31)) in the map tileset.
// skipped: pixels whose tile is not in the map tileset (layers count as 0).
inline bool drawHeightmap(Table &heightmap, Bitmap &pattern, Bitmap &mapTileset, Table &tiles, int32_t &skipped) {
    using namespace detail;
    skipped = 0;
    const int32_t hxs = heightmap.xs, txs = tiles.xs;
    const int32_t mh = shl(tiles.ys, 5), mw = shl(txs, 3);
    if (!sized(heightmap) || !sized(tiles) || !sized(pattern) || !sized(mapTileset) || mapTileset.w != 512) return false;
    if (hxs < 2 * (int64_t)mw || cells(heightmap) < (int64_t)mh * hxs + (int64_t)mw * mh) return false;
    static const uint8_t noLayers[4] = {0, 0, 0, 0};
    const int32_t pw = pattern.w, ph = pattern.h;
    int16_t *data = heightmap.data;
    for (int32_t y = sub(mh, 1); y >= 0; --y) {
        const int32_t fy10 = idiv(mul(mul(10, ph), y), mh);
        const int32_t iy = idiv(fy10, 10);
        const int32_t fy = (int8_t)(uint8_t)(fy10 - iy * 10);
        const int32_t tileRow = mul(sar(y, 5), txs);
        for (int32_t x = sub(mw, 1); x >= 0; --x) {
            const int32_t fx10 = idiv(mul(mul(10, pw), x), mw);
            const int32_t ix = idiv(fx10, 10);
            const int32_t fx = (int8_t)(uint8_t)(fx10 - ix * 10);
            const uint8_t *p00 = px(pattern, ix, iy);
            int32_t h;
            if (iy != ph - 1) {
                const uint8_t *p01 = px(pattern, ix, iy + 1);
                if (ix != pw - 1)
                    h = (p00[4] * (10 - fy) * fx + p01[4] * fx * fy + p01[0] * (10 - fx) * fy +
                         p00[0] * (10 - fx) * (10 - fy)) / 100;
                else
                    h = (p01[0] * fy + (10 - fy) * p00[0]) / 10;
            } else if (ix != pw - 1) {
                h = (p00[4] * fx + (10 - fx) * p00[0]) / 10;
            } else {
                h = p00[0];
            }
            h &= 0xFFFF;
            const int32_t tile = (uint16_t)tiles.data[add(sar(x, 3) & ~3, tileRow)];
            const int32_t tileS = (int16_t)tile;
            const uint8_t *layers = noLayers;
            if (tileS >= 0 && 32 * (tileS >> 3) + (y & 31) < mapTileset.h) {
                const int32_t xm = (int16_t)(uint16_t)shl(add(sub(shl(tile & 7, 5), x & ~31), x & 0xFFFF), 1);
                layers = mapTileset.top + add(shl(add(xm, shl(sub(y & ~31, shl(tileS & ~7, 2)), 9)), 2), -shl(y, 11)) + 4;
            } else {
                ++skipped;
            }
            int32_t counted = 0;
            const int32_t n = layers[3] > 4 ? 4 : layers[3];  // layer count, 0..3 in practice
            for (int32_t i = 0; i < n; ++i) counted = (counted + layers[i]) & 0xFFFF;
            data[add(mul(hxs, y), shl(x, 1))] = (int16_t)(uint16_t)(layers[2] + layers[1] + layers[0] + h);
            data[add(add(mul(mh, hxs), mul(mw, y)), x)] = (int16_t)(uint16_t)(counted + h);
        }
    }
    return true;
}

namespace detail {
// light/shadow strength by slope length (about 90 / n), from the DLL's data
const int8_t kRamp[0x40] = {0, 0, 45, 26, 18, 14, 11, 9, 8, 7, 6, 5, 5, 4, 4, 4, 3, 3, 3, 3, 3, 2, 2, 2, 2,
                            2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
                            1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
}  // namespace detail

// Shading of the drawing heights (odd columns of the upper part): along each
// row, a run that ends one step higher is lit with a ramp, a run that ends one
// step lower after a drop is darkened, and pixels behind a drop of more than
// one step are in shadow (-50) until the terrain comes back up.
inline bool applyLighting(Table &heightmap) {
    using namespace detail;
    if (!sized(heightmap)) return false;
    const int32_t xs = heightmap.xs;
    const int32_t rows = (int32_t)((uint32_t)(((uint64_t)(uint32_t)shl(heightmap.ys, 1) * 0xAAAAAAABull) >> 32) >> 1);
    const int32_t half = sar(xs, 1);
    int32_t prev = 0;  // the DLL starts it with the argument; always set at a row's first pixel
    for (int32_t row = 0; row < rows; ++row) {
        int16_t *line = heightmap.data + (intptr_t)row * xs;
        bool started = false, rising = false;
        int32_t shadow = 0, run = 0;
        for (int32_t x = 0; x < half; ++x) {
            const int32_t h = sar(line[2 * x], 3);
            ++run;
            if (!started) { started = true; prev = h; continue; }
            if (shadow != 0) {
                --shadow;
                if (h < shadow) { line[2 * x + 1] = -50; continue; }
                shadow = 0; run = 1; prev = h; continue;
            }
            if (h > prev) {
                if (h - prev - 1 == 0) {
                    if (!rising) {
                        const int32_t c = run > 0x33 ? 0x33 : run;
                        const int16_t v = kRamp[c];
                        for (int32_t k = 1; k < c; ++k) line[2 * (x - c + k) + 1] = v;
                    }
                } else if (rising) {
                    const int32_t c = run - 1 > 0x32 ? 0x32 : run - 1;
                    const int16_t v = (int16_t)-kRamp[c + 1];
                    for (int32_t k = 0; k < c; ++k) line[2 * (x - run + 1 + k) + 1] = v;
                }
                rising = false; run = 1; prev = h; continue;
            }
            if (h == prev) continue;
            if (rising) {
                const int32_t c = run - 1 > 0x32 ? 0x32 : run - 1;
                const int16_t v = (int16_t)-kRamp[c + 1];
                for (int32_t k = 0; k < c; ++k) line[2 * (x - run + 1 + k) + 1] = v;
            }
            if (prev - h - 1 != 0) { line[2 * x + 1] = -50; shadow = prev; }
            else rising = true;
            run = 1; prev = h;
        }
    }
    return true;
}

namespace detail {
// A 32x32 tile source: tilesets and autotile sheets are 256 pixels wide
// (the DLL's stride); false when the tile is not inside the image.
inline bool tileInside(const Bitmap *b, int32_t sy) {
    return b && b->top && b->w == 256 && sy >= 0 && sy + 32 <= b->h;
}
inline bool entryInside(const Bitmap &mapTileset, int32_t index) {
    return index >= 0 && 32 * (int64_t)(index >> 3) + 32 <= mapTileset.h;
}

// 32x32 tile of one layer into the map tileset entry `index` (64x32 there):
// even pixels = colour (first opaque layer from the top wins), odd pixels =
// height of each layer (B, G, R for layers 1-3) and the counted layers (A).
inline void copyLayer(Bitmap &dst, int32_t index, int32_t layerByte, int32_t counted, const uint8_t *src,
                      const uint8_t *heights, int32_t sx, int32_t sy) {
    for (int32_t r = 31; r >= 0; --r) {
        uint8_t *row = dst.top + 4 * 64 * (index & 7) - 2048 * (32 * (index >> 3) + r);
        const uint8_t *s = src + 4 * sx - 1024 * (sy + r);
        const uint8_t *h = heights + 4 * sx - 1024 * (sy + r);
        for (int32_t c = 31; c >= 0; --c) {
            uint8_t *even = row + 8 * c, *odd = even + 4;
            odd[layerByte] = h[4 * c];
            odd[3] = (uint8_t)counted;
            if (even[3] == 0 && s[4 * c + 3] != 0) {
                even[0] = s[4 * c]; even[1] = s[4 * c + 1]; even[2] = s[4 * c + 2]; even[3] = 0xFF;
            }
        }
    }
}
}  // namespace detail

// The map's own tileset: one 64x32 entry per 3-layer combination (layers
// drawn 3, 2, 1). autotiles[i] / autoHmaps[i]: HM7::Bitmap_Autotiles
// (256x192) of autotile i, nullptr when the map has none there.
// skipped: layers whose tile is outside its image (the DLL reads past it).
inline bool drawMapTileset(Bitmap &mapTileset, Bitmap &tileset, Bitmap &heightset, const TileEntry *entries,
                           int32_t count, Bitmap *const *autotiles, Bitmap *const *autoHmaps, int32_t &skipped) {
    using namespace detail;
    skipped = 0;
    if (!sized(mapTileset) || mapTileset.w != 512) return false;
    for (int32_t e = 0; e < count; ++e) {
        const TileEntry &entry = entries[e];
        if (!entryInside(mapTileset, entry.index)) { ++skipped; continue; }
        const int32_t layers[3] = {entry.layer3, entry.layer2, entry.layer1};
        for (int32_t l = 0; l < 3; ++l) {
            const int32_t tile = layers[l], layerByte = 2 - l;
            if (tile >= 384) {
                const int32_t t = tile - 384, sy = 32 * (t >> 3);
                if (!tileInside(&tileset, sy) || !tileInside(&heightset, sy)) { ++skipped; continue; }
                copyLayer(mapTileset, entry.index, layerByte, entry.counted, tileset.top, heightset.top, 32 * (t & 7), sy);
            } else {
                const int32_t a = tile / 48;
                if (a <= 0) continue;
                Bitmap *graphics = autotiles[a - 1], *hmap = autoHmaps[a - 1];
                if (!graphics || !hmap) continue;  // the DLL would read a Fixnum as a Bitmap and crash
                const int32_t pattern = tile - 48 * a, sy = 32 * (pattern >> 3);
                if (!tileInside(graphics, sy) || !tileInside(hmap, sy)) { ++skipped; continue; }
                copyLayer(mapTileset, entry.index, layerByte, entry.counted, graphics->top, hmap->top, 32 * (pattern & 7), sy);
            }
        }
    }
    return true;
}

// Animated autotiles: colours of layers 1, 2, 3 copied again over the entry
// (opaque pixels only, alpha included); heights unchanged.
inline bool refreshMapTileset(Bitmap &mapTileset, Bitmap &tileset, const TileEntry *entries, int32_t count,
                              Bitmap *const *autotiles, int32_t &skipped) {
    using namespace detail;
    skipped = 0;
    if (!sized(mapTileset) || mapTileset.w != 512) return false;
    for (int32_t e = 0; e < count; ++e) {
        const TileEntry &entry = entries[e];
        if (!entryInside(mapTileset, entry.index)) { ++skipped; continue; }
        const int32_t layers[3] = {entry.layer1, entry.layer2, entry.layer3};
        for (int32_t l = 0; l < 3; ++l) {
            const int32_t tile = layers[l];
            const Bitmap *source;
            int32_t sx, sy;
            if (tile >= 384) {
                source = &tileset; sx = 32 * ((tile - 384) & 7); sy = 32 * ((tile - 384) >> 3);
            } else {
                const int32_t a = tile / 48;
                if ((int8_t)a <= 0) continue;
                source = autotiles[a - 1];
                if (!source) continue;  // Fixnum read as a Bitmap in the DLL
                const int32_t pattern = tile - 48 * a;
                sx = 32 * (pattern & 7); sy = 32 * (pattern >> 3);
            }
            if (!tileInside(source, sy)) { ++skipped; continue; }
            for (int32_t r = 31; r >= 0; --r) {
                uint8_t *row = mapTileset.top + 4 * 64 * (entry.index & 7) - 2048 * (32 * (entry.index >> 3) + r);
                const uint8_t *s = source->top + 4 * sx - 1024 * (sy + r);
                for (int32_t c = 31; c >= 0; --c) {
                    const uint8_t *p = s + 4 * c;
                    if (p[3] == 0) continue;
                    uint8_t *even = row + 8 * c;
                    even[0] = p[0]; even[1] = p[1]; even[2] = p[2]; even[3] = p[3];
                }
            }
        }
    }
    return true;
}

namespace detail {
inline uint8_t wallMarker(const uint8_t *p) { return p[2] ? 0x20 : p[1] ? 0x40 : p[0] ? 0x60 : 0x80; }
inline void copyPixel(uint8_t *d, const uint8_t *s) { d[0] = s[0]; d[1] = s[1]; d[2] = s[2]; d[3] = s[3]; }
}  // namespace detail

// textureset: 160 x 32n. Row band `index`: x 0-31 = wall marker in the blue
// channel (0x20 red, 0x40 green, 0x60 blue, 0x80 none, from the heights
// image), x 32-159 = the 4 faces turned a quarter (column u of the band =
// row u of the face). skipped: entries without a texture of the expected
// size (the DLL loops forever on a disposed one).
inline bool drawTextureset(Bitmap &textureset, const TextureEntry *entries, int32_t count, Bitmap &textureAuto,
                           int32_t &skipped) {
    using namespace detail;
    skipped = 0;
    if (!sized(textureset) || textureset.w != 160) return false;
    for (int32_t e = 0; e < count; ++e) {
        const TextureEntry &entry = entries[e];
        Bitmap *tex = entry.texture;
        const int32_t band = 32 * entry.index;
        if (!tex || !tex->top || entry.index < 0 || band + 32 > textureset.h || tex->h < 32) { ++skipped; continue; }
        if (entry.tile >= 384) {
            if (tex->w != 160) { ++skipped; continue; }
            for (int32_t u = 0; u < 32; ++u)
                for (int32_t v = 0; v < 32; ++v) {
                    px(textureset, v, band + u)[0] = wallMarker(px(*tex, v, u));
                    copyPixel(px(textureset, 128 + u, band + v), px(*tex, 128 + v, u));
                    copyPixel(px(textureset, 96 + u, band + v), px(*tex, 127 - v, u));
                    copyPixel(px(textureset, 64 + u, band + v), px(*tex, 95 - v, u));
                    copyPixel(px(textureset, 32 + u, band + v), px(*tex, 32 + v, u));
                }
        } else {
            const int32_t pattern = entry.tile % 48;
            const int32_t sx = 32 * (pattern & 7), sy = 32 * (pattern >> 3);
            if (tex->w != 128 || !textureAuto.top || textureAuto.w != 256 || sy < 0 || sy + 32 > textureAuto.h) {
                ++skipped;
                continue;
            }
            for (int32_t u = 0; u < 32; ++u)
                for (int32_t v = 0; v < 32; ++v) {
                    px(textureset, v, band + u)[0] = wallMarker(px(textureAuto, sx + v, sy + u));
                    copyPixel(px(textureset, 128 + u, band + v), px(*tex, 96 + v, u));
                    copyPixel(px(textureset, 96 + u, band + v), px(*tex, 95 - v, u));
                    copyPixel(px(textureset, 64 + u, band + v), px(*tex, 63 - v, u));
                    copyPixel(px(textureset, 32 + u, band + v), px(*tex, v, u));
                }
        }
    }
    return true;
}

namespace detail {

// Fading colour of a screen row (rows line 0): added when its alpha is set,
// subtracted otherwise.
struct Fade {
    int32_t b, g, r;
    bool add;
};

// A translucent sprite pixel waits in the buffer with the render alpha set
// to its blend type + 1; whatever is drawn behind it gets it mixed in.
inline void mixWaiting(uint8_t marker, const uint8_t *buf, int32_t &b, int32_t &g, int32_t &r) {
    const int32_t a = buf[3];
    if (marker == 1) {
        const int32_t k = 255 - a;
        b = sar(buf[0] * a + k * b, 8);
        g = sar(buf[1] * a + k * g, 8);
        r = sar(buf[2] * a + k * r, 8);
    } else if (marker == 2) {
        b = clampHigh(b + sar(buf[0] * a, 8));
        g = clampHigh(g + sar(buf[1] * a, 8));
        r = clampHigh(r + sar(buf[2] * a, 8));
    } else if (marker == 3) {
        b = clampLow(b - sar(buf[0] * a, 8));
        g = clampLow(g - sar(buf[1] * a, 8));
        r = clampLow(r - sar(buf[2] * a, 8));
    }
}

struct SpriteState {
    int32_t sx = 0, sy = 0;          // screen position; the DLL keeps them as 16-bit values
    int32_t altitude = 0, blend = 0;
    int32_t w = 0, h = 0;
    const Bitmap *bitmap = nullptr;
    int32_t zoomW = 0, zoomH = 0, base = 0;  // size on screen, screen row of its feet
    void load(const Surface &s) {
        sx = (uint16_t)shr(s.x, 1);
        sy = (uint16_t)shr(s.y, 1);
        altitude = shr(s.altitude, 1);
        blend = (uint8_t)shr(s.blend, 1);
        bitmap = s.bitmap && s.bitmap->top ? s.bitmap : nullptr;
        w = bitmap ? bitmap->w : 0;
        h = bitmap ? bitmap->h : 0;
    }
    int32_t x16() const { return (int16_t)sx; }
    int32_t y16() const { return (int16_t)sy; }
};

// One column of a sprite to draw at screen row j: before the ground of
// (j, column), or after it when a sprite that starts left of the column is
// found later on the same row (the DLL then goes back over the columns it
// passed, which already have their ground for that row).
struct SpriteOp {
    int32_t j, col4, zoomH, base, h, blend;
    const Bitmap *bitmap;
    bool afterGround;
};

struct RowInfo {
    Fade fade;
    int32_t xScale, zoom;
};

// Frame state shared by the column workers; everything here is read-only
// while they run, except what each worker writes in its own columns.
struct Frame {
    Bitmap render, rows, buffer, tiles, walls;
    const int16_t *compute = nullptr, *tiletable = nullptr, *heightmap = nullptr;
    int64_t ttSize = 0, hmSize = 0;
    int32_t cxs = 0, cys = 0, plane = 0, renderW = 0, renderRows = 0;
    int32_t ttXs = 0, mapW = 0, mapH = 0, hmXs = 0;
    int32_t loopX = 0, loopY = 0, camera = 0, lastJ = 0, step = 1;
    int8_t cameraMode = 0;
    uint8_t noBlackCut = 0;
    Value offsetX = 0, offsetY = 0;
    const RowInfo *rowInfo = nullptr;          // indexed by j
    const SpriteOp *const *columnOps = nullptr;  // per column, ordered by j descending
    const int32_t *columnOpCount = nullptr;

    // Map point seen at (j, x); false when it is outside a map that does not loop.
    bool mapPoint(int32_t j, int32_t x, int32_t &mx, int32_t &my) const {
        const int32_t rowBase = mul(j, cxs);
        mx = add(compute[rowBase + x], offsetX);
        my = add(compute[add(rowBase, plane) + x], offsetY);
        if (!loopX) {
            if (mx >= mapW || mx < 0) return false;
        } else if (mx >= mapW) {
            mx = sub(mx, mul(mx / mapW, mapW));
        } else if (mx < 0) {
            mx = sub(mx, mul(sub(mx / mapW, 1), mapW));
        }
        if (!loopY) {
            if (my >= mapH || my < 0) return false;
        } else if (my >= mapH) {
            my = sub(my, mul(my / mapH, mapH));
        } else if (my < 0) {
            do my = add(my, mapH); while (my < 0);
        }
        return true;
    }

    // one column of a sprite, rows base-zoomH+1 .. base
    void drawSprite(int32_t x, const SpriteOp &op, int32_t columnTop) const {
        const int32_t zoom = rowInfo[op.j].zoom;
        if (zoom == 0 || !op.bitmap) return;  // the DLL divides by zoom
        const Fade &fade = rowInfo[op.j].fade;
        int32_t left = op.zoomH, y = sub(op.base, left);
        for (;;) {
            --left;
            y = add(y, 1);
            if (columnTop <= y || add(sub(1, renderRows), y) > 0) break;
            uint8_t *dst = y >= 0 ? px(render, x, y) : nullptr;
            const uint8_t marker = dst ? dst[3] : 0xFE;
            if (marker != 0xFE) {
                const int32_t srow = sub(sub(op.h, shl(left, 12) / zoom), 1);
                const Bitmap &bmp = *op.bitmap;
                const uint8_t *src = inside(bmp, bmp.top + op.col4 - mul(srow, 4 * bmp.w));
                if (src && src[3] != 0) {
                    int32_t b = src[0], g = src[1], r = src[2];
                    if (fade.add) {
                        b = clampHigh(b + fade.b); g = clampHigh(g + fade.g); r = clampHigh(r + fade.r);
                    } else {
                        b = clampLow(b - fade.b); g = clampLow(g - fade.g); r = clampLow(r - fade.r);
                    }
                    uint8_t *waiting = px(buffer, x, y);
                    if (marker != 0 && marker <= 3) mixWaiting(marker, waiting, b, g, r);
                    if (op.blend == 0 && src[3] == 255) {
                        dst[0] = (uint8_t)b; dst[1] = (uint8_t)g; dst[2] = (uint8_t)r; dst[3] = 0xFE;
                    } else {
                        dst[3] = (uint8_t)(op.blend + 1);
                        waiting[0] = (uint8_t)b; waiting[1] = (uint8_t)g; waiting[2] = (uint8_t)r;
                        waiting[3] = src[3];
                    }
                }
            }
            if (left <= 0) break;
        }
    }

    // Columns [from, to) (stepping like the frame), every row from the
    // bottom up. Returns the camera target found in these columns.
    int32_t columns(int32_t from, int32_t to) const {
        static const int16_t noTiles[4] = {0, 0, 0, 0};
        static const uint8_t noPixel[8] = {0, 0, 0, 0, 0, 0, 0, 0};
        int32_t result = 0;
        const int32_t count = (to - from + step - 1) / step;
        if (count <= 0) return 0;
        // next op of each column (ops are ordered by row, bottom up)
        int32_t opIndex[1024];
        int32_t *next = count <= 1024 ? opIndex : new int32_t[count];
        for (int32_t i = 0; i < count; ++i) next[i] = 0;
        for (int32_t j = cys - 1; j >= lastJ && j >= 0; --j) {
            const int32_t screenY = add(j, camera);
            const RowInfo &row = rowInfo[j];
            const Fade &fade = row.fade;
            const int32_t xScale = row.xScale;
            for (int32_t i = 0, x = from; i < count; ++i, x += step) {
                const SpriteOp *ops = columnOps[x];
                const int32_t opCount = columnOpCount[x];
                int32_t &op = next[i];
                // line 2: highest screen row drawn so far in this column
                uint8_t *columnTopPx = px(rows, x, 2);
                int32_t columnTop;
                if (j == cys - 1) {
                    columnTop = add(camera, renderRows);
                    columnTopPx[0] = (uint8_t)sar(columnTop, 8);
                    columnTopPx[1] = (uint8_t)columnTop;
                } else {
                    columnTop = (columnTopPx[0] << 8) + columnTopPx[1];
                }
                int32_t mx, my;
                if (!mapPoint(j, x, mx, my)) {  // outside the map: sky
                    if (screenY < columnTop) {
                        bool drawn = false;
                        if (screenY < renderRows && screenY >= 0) {
                            uint8_t *alpha = px(render, x, screenY) + 3;
                            if (*alpha == 0xFE) {
                                *alpha = 0xFF;
                                drawn = true;
                            } else {
                                *alpha = 0;
                            }
                        }
                        if (!drawn) {
                            columnTopPx[0] = (uint8_t)sar(screenY, 8);
                            columnTopPx[1] = (uint8_t)screenY;
                        }
                    }
                    for (; op < opCount && ops[op].j == j; ++op)
                        drawSprite(x, ops[op], (columnTopPx[0] << 8) + columnTopPx[1]);
                    continue;
                }

                const int64_t tIndex = (int64_t)sar(my, 5) * ttXs + (sar(mx, 3) & ~3);
                const int16_t *tt = tIndex >= 0 && tIndex + 4 <= ttSize ? tiletable + tIndex : noTiles;
                const int32_t tile = (uint16_t)tt[0];
                const int32_t subX = mx & 31, subY = my & 31;
                const int32_t tileRow = 32 * (tile >> 3) + subY;
                const uint8_t *ground = tile < 0x8000 && tileRow < tiles.h ? px(tiles, 2 * ((tile & 7) * 32 + subX), tileRow) : noPixel;
                const int64_t hIndex = (int64_t)my * hmXs + 2 * (int64_t)mx;
                const bool hOk = hIndex >= 0 && hIndex + 2 <= hmSize;
                const int32_t height = hOk ? heightmap[hIndex] : 0;
                const int32_t light = hOk ? heightmap[hIndex + 1] : 0;
                int32_t hScreen = sar(mul(height, xScale), 15);
                const int32_t h3 = sar(ground[6] * xScale, 15), h2 = sar(ground[5] * xScale, 15), h1 = sar(ground[4] * xScale, 15);
                const int32_t h32 = h3 + h2, hAll = h32 + h1;
                const int32_t texH1 = ground[4] >> 3, texH2 = ground[5] >> 3, texH3 = ground[6] >> 3;
                const uint8_t groundAlpha = ground[3];
                int32_t over = 0;
                if (hScreen > screenY) {
                    over = hScreen - screenY;
                    hScreen = screenY;
                }
                if (j == renderRows - 1) {  // camera: highest ground under the bottom row
                    int32_t v = hScreen;
                    if (cameraMode <= 1) v -= hAll;
                    if (v > result) result = v;
                }
                const int32_t groundY = sub(screenY, hScreen);

                // a sprite standing on this screen row, drawn before the ground
                if (op < opCount && ops[op].j == j && !ops[op].afterGround) drawSprite(x, ops[op++], columnTop);

                // ground: top pixel, then the walls of layers 3, 2, 1, then the
                // ground side, down to what is already drawn
                if (groundY < columnTop) {
                    bool below = false, have3 = false, have2 = false, have1 = false;
                    const uint8_t *wall = nullptr;
                    auto wallTexels = [&](int32_t basic) -> const uint8_t * {
                        const int32_t band = (int16_t)(uint16_t)(basic << 5);
                        const int32_t rowY = band + subY, rowX = band + subX;
                        if (rowY < 0 || rowY >= walls.h) return nullptr;
                        const uint8_t marker = px(walls, subX, rowY)[0];
                        if (marker == 0x20) return walls.top + 0x80 - 640 * rowX;
                        if (marker == 0x40) return px(walls, 64, rowY);
                        if (marker == 0x60) return walls.top + 0x180 - 640 * rowX;
                        return walls.top + 4 * marker - 640 * rowY;
                    };
                    auto texel = [&](int32_t along, int32_t texHeight, int32_t layerHeight) -> const uint8_t * {
                        const int32_t q = mul(along, texHeight) / layerHeight;
                        const int16_t offset = (int16_t)(uint16_t)(4 * (q - texHeight + 31));
                        if (offset >= 0x80 || !wall) return ground;
                        const uint8_t *t = inside(walls, wall + offset);
                        return t && t[3] != 0 ? t : ground;
                    };
                    int32_t k = hScreen, y = groundY;
                    for (;;) {
                        if (add(sub(y, renderRows), 1) > 0) break;
                        uint8_t *dst = y >= 0 ? px(render, x, y) : nullptr;
                        if (!dst) {
                        } else if (dst[3] == 0xFE) {
                            dst[3] = 0xFF;
                        } else if (k < hScreen && j == cys - 1 && !noBlackCut) {
                            dst[0] = dst[1] = dst[2] = 0;
                            dst[3] = 0xFF;
                        } else {
                            const uint8_t marker = dst[3];
                            const int32_t d = sub(hScreen, k);
                            const uint8_t *src = ground;
                            bool isTop = false;
                            if (d == 0) {
                                isTop = true;
                            } else if (d <= h3) {
                                if (!have3) { wall = wallTexels(tt[3]); have3 = true; }
                                src = texel(add(over, d), texH3, h3);
                            } else if (d <= h32) {
                                if (!have2) { wall = wallTexels(tt[2]); have2 = true; }
                                src = texel(sub(add(over, d), h3), texH2, h2);
                            } else if (d <= hAll) {
                                if (!have1) { wall = wallTexels(tt[1]); have1 = true; }
                                src = texel(sub(add(over, d), h32), texH1, h1);
                            } else {
                                below = true;
                            }
                            int32_t b = src[0], g = src[1], r = src[2];
                            const bool lit = light != 0 && (isTop || below);
                            if (fade.add) {
                                b += fade.b; g += fade.g; r += fade.r;
                                if (lit) {
                                    b = clampBoth(b + light); g = clampBoth(g + light); r = clampBoth(r + light);
                                } else {
                                    b = clampHigh(b); g = clampHigh(g); r = clampHigh(r);
                                }
                            } else {
                                b -= fade.b; g -= fade.g; r -= fade.r;
                                if (lit) { b += light; g += light; r += light; }
                                b = clampBoth(b); g = clampBoth(g); r = clampBoth(r);
                            }
                            if (marker != 0 && marker <= 3) mixWaiting(marker, px(buffer, x, y), b, g, r);
                            dst[0] = (uint8_t)b; dst[1] = (uint8_t)g; dst[2] = (uint8_t)r; dst[3] = groundAlpha;
                        }
                        k = sub(k, 1);
                        y = sub(screenY, k);
                        if (!(y < columnTop)) break;
                    }
                    columnTopPx[0] = (uint8_t)sar(groundY, 8);
                    columnTopPx[1] = (uint8_t)groundY;
                }

                // sprites found later on this row that cover this column
                for (; op < opCount && ops[op].j == j; ++op)
                    drawSprite(x, ops[op], (columnTopPx[0] << 8) + columnTopPx[1]);
            }
        }
        if (next != opIndex) delete[] next;
        return result;
    }
};

}  // namespace detail

// Runs `work(part)` for parts 0..parts-1, possibly at the same time; set by
// the engine (a thread pool), nullptr = one after the other.
typedef void (*ParallelFor)(int32_t parts, void (*work)(void *, int32_t), void *context);

// One frame. vars: [height_limit, offset_x, offset_y, filter, camera_y].
// Screen rows are drawn from the bottom up; in each column the ground is
// drawn from its top (map tileset colour) down over its walls (textureset
// faces of layers 3, 2, 1, then the ground side) to the highest point drawn
// so far (rows line 2), and the sprites (sorted by screen row, lowest first)
// are drawn when their row is reached, so nearer ground hides them.
// render alpha: 0xFF/0xFE drawn (0xFE = by a sprite, this frame), 1-3 = a
// translucent sprite pixel waiting in `buffer` (blend type + 1), 0 = sky.
// target: the camera's target height (vars[4] follows it in Ruby).
//
// Columns only meet through the sprites, which the DLL looks for in screen
// order as it goes. So the sprite search runs first over the whole frame
// (cheap) and lists the sprite columns to draw in each screen column; then
// the columns are drawn, in `parts` groups that can run at the same time,
// each column in the DLL's order. The result is the same for any `parts`.
inline bool renderHM7(RenderParams &p, const Value *vars, const Surface *surfaces, int32_t count, int32_t &target,
                      int32_t parts = 1, ParallelFor parallel = nullptr) {
    using namespace detail;
    target = 0;
    Frame f;
    f.render = p.render; f.rows = p.rows; f.buffer = p.buffer; f.tiles = p.mapTileset; f.walls = p.textureset;
    f.cxs = p.compute.xs; f.cys = p.compute.ys;
    f.renderW = p.render.w;
    f.renderRows = (p.lessCut & ~1) ? sar(f.cys, 1) : f.cys;
    f.ttXs = p.tiletable.xs; f.mapW = mul(f.ttXs, 8); f.mapH = shl(p.tiletable.ys, 5);
    f.hmXs = p.heightmap.xs;
    const Bitmap &render = p.render, &rows = p.rows;
    if (!sized(render) || !sized(rows) || !sized(p.buffer) || !sized(f.tiles) || !sized(f.walls)) return false;
    if (!sized(p.compute) || !sized(p.heightmap) || !sized(p.tiletable)) return false;
    if (p.buffer.w != f.renderW || p.buffer.h != render.h) return false;
    if (f.cxs < f.renderW || p.compute.zs < 2 || f.renderRows > render.h) return false;
    if (rows.h < 3 || rows.w < f.cys || rows.w < f.renderW) return false;
    if (f.tiles.w != 512 || f.walls.w != 160) return false;
    if (f.ttXs % 4 || f.hmXs < 2 * (int64_t)f.mapW || p.heightmap.ys < f.mapH || f.mapW <= 0 || f.mapH <= 0) return false;
    f.compute = p.compute.data; f.tiletable = p.tiletable.data; f.heightmap = p.heightmap.data;
    f.ttSize = cells(p.tiletable); f.hmSize = cells(p.heightmap);
    f.plane = mul(f.cys, f.cxs);
    f.loopX = shr(p.loopX, 1); f.loopY = shr(p.loopY, 1);
    f.cameraMode = (int8_t)shr(p.cameraMode, 1);
    f.noBlackCut = (uint8_t)shr(p.noBlackCut, 1);
    const int32_t heightLimit = shr(vars[0], 1);
    f.offsetX = vars[1]; f.offsetY = vars[2];  // used undecoded
    const uint8_t filter = (uint8_t)shr(vars[3], 1);
    f.camera = shr(vars[4], 1);
    // filter: every other column per frame, alternating
    f.step = filter == 0 ? 1 : 2;
    const int32_t startX = filter <= 1 ? 0 : 1;

    // rows above the horizon: nothing
    int32_t topRow = add(heightLimit < 0 ? 0 : heightLimit, f.camera);
    if (topRow >= f.renderRows) topRow = f.renderRows - 1;
    for (int32_t r = topRow - 1; r >= 0; --r)
        for (int32_t x = startX; x < f.renderW; x += f.step) px(render, x, r)[3] = 0;
    f.lastJ = sub(topRow, f.camera);

    // per screen row: fade colour, x scale, zoom
    struct Owned {
        RowInfo *rowInfo = nullptr;
        SpriteOp **columnOps = nullptr;
        int32_t *columnOpCount = nullptr, *capacity = nullptr;
        ~Owned() {
            delete[] rowInfo;
            if (columnOps)
                for (int32_t i = 0; i < width; ++i) delete[] columnOps[i];
            delete[] columnOps;
            delete[] columnOpCount;
            delete[] capacity;
        }
        int32_t width = 0;
    } own;
    own.rowInfo = new RowInfo[f.cys];
    for (int32_t j = 0; j < f.cys; ++j) {
        const uint8_t *line0 = px(rows, j, 0), *line1 = px(rows, j, 1);
        own.rowInfo[j].fade = {line0[0], line0[1], line0[2], line0[3] != 0};
        own.rowInfo[j].xScale = (line1[0] << 8) + line1[1];
        own.rowInfo[j].zoom = (line1[2] << 8) + line1[3];
    }
    own.width = f.renderW;
    own.columnOps = new SpriteOp *[f.renderW]();
    own.columnOpCount = new int32_t[f.renderW]();
    own.capacity = new int32_t[f.renderW]();
    auto addOp = [&](int32_t column, const SpriteOp &op) {
        int32_t &n = own.columnOpCount[column], &cap = own.capacity[column];
        if (n == cap) {
            const int32_t grown = cap ? 2 * cap : 8;
            SpriteOp *more = new SpriteOp[grown];
            for (int32_t i = 0; i < n; ++i) more[i] = own.columnOps[column][i];
            delete[] own.columnOps[column];
            own.columnOps[column] = more;
            cap = grown;
        }
        own.columnOps[column][n++] = op;
    };

    // sprite search, in the DLL's order (rows bottom up, columns left to right)
    if (count > 0) {
        SpriteState sprite;
        int32_t next = 1;
        bool spritesLeft = true, drawing = false, centred = false;
        sprite.load(surfaces[0]);
        for (int32_t j = f.cys - 1; j >= f.lastJ && j >= 0 && (spritesLeft || drawing); --j) {
            const int32_t screenY = add(j, f.camera);
            const int32_t xScale = own.rowInfo[j].xScale, zoom = own.rowInfo[j].zoom;
            auto spriteColumn = [&](int32_t dx) { return zoom ? shl(dx, 12) / zoom * 4 : 0; };
            auto placeSprite = [&]() {
                sprite.zoomH = sar(mul(zoom, sprite.h), 12);
                sprite.base = sub(screenY, sar(mul(xScale, sprite.altitude), 15));
                drawing = true;
                if (sprite.zoomH > sprite.base) sprite.zoomH = sprite.base;
            };
            auto draw = [&](int32_t column, int32_t col4, bool afterGround) {
                SpriteOp op = {j, col4, sprite.zoomH, sprite.base, sprite.h, sprite.blend, sprite.bitmap, afterGround};
                addOp(column, op);
            };
            for (int32_t x = startX; x < f.renderW && (spritesLeft || drawing); x += f.step) {
                int32_t mx, my;
                if (!f.mapPoint(j, x, mx, my)) continue;  // the DLL looks for sprites on the map only
                if (drawing) {
                    const int32_t dx = sub(x, sprite.x16());
                    if (dx < sprite.zoomW && j >= sprite.y16()) {
                        const int32_t col4 = spriteColumn(dx);
                        if (sprite.zoomH > 0) draw(x, col4, false);
                    } else {
                        drawing = false;
                        centred = false;
                        if ((int16_t)next >= count) {
                            spritesLeft = false;
                        } else {
                            sprite.load(surfaces[(int16_t)next]);
                            next++;
                            if (j == sprite.y16()) {
                                sprite.zoomW = sar(mul(zoom, sprite.w), 12);
                                sprite.sx = sub(sprite.sx, sar(sprite.zoomW, 1));
                                centred = true;
                                const int32_t sx = sprite.x16();
                                if (x >= sx) {
                                    placeSprite();
                                    // the columns this sprite covers that were passed already
                                    int32_t from = sx < 0 ? 0 : sx;
                                    if (f.step == 2) from += (x - from) & 1;
                                    for (int32_t c = from, d = from - sx; c <= x; c += f.step, d += f.step) {
                                        if (d >= sprite.zoomW) continue;
                                        const int32_t col4 = spriteColumn(d);
                                        if (sprite.zoomH <= 0) continue;
                                        draw(c, col4, c != x);
                                    }
                                }
                            }
                        }
                    }
                } else if (spritesLeft) {
                    if (j == sprite.y16() && !centred) {
                        sprite.zoomW = sar(mul(zoom, sprite.w), 12);
                        sprite.sx = sub(sprite.sx, sar(sprite.zoomW, 1));
                        centred = true;
                    }
                    if (j == sprite.y16() && x >= sprite.x16()) {
                        const int32_t col4 = spriteColumn(sub(x, sprite.x16()));
                        placeSprite();
                        if (sprite.zoomH > 0) draw(x, col4, false);
                    }
                }
            }
        }
    }
    f.rowInfo = own.rowInfo;
    f.columnOps = own.columnOps;
    f.columnOpCount = own.columnOpCount;

    // the columns, in parts of whole column steps
    const int32_t columns = f.renderW > startX ? (f.renderW - startX + f.step - 1) / f.step : 0;
    if (parts < 1 || !parallel) parts = 1;
    if (parts > columns) parts = columns > 0 ? columns : 1;
    struct Job {
        const Frame *frame;
        int32_t startX, columns, parts;
        int32_t results[64];
        static void run(void *context, int32_t part) {
            Job *job = static_cast<Job *>(context);
            const Frame &f = *job->frame;
            const int32_t a = job->columns * part / job->parts, b = job->columns * (part + 1) / job->parts;
            job->results[part] = f.columns(job->startX + a * f.step, job->startX + b * f.step);
        }
    } job = {&f, startX, columns, parts > 64 ? 64 : parts, {0}};
    if (job.parts == 1) Job::run(&job, 0);
    else parallel(job.parts, &Job::run, &job);
    int32_t result = 0;
    for (int32_t i = 0; i < job.parts; ++i)
        if (job.results[i] > result) result = job.results[i];
    target = result;
    return true;
}

}}  // namespace kerberus::hm7

#endif
