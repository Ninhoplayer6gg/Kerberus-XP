#ifndef KERBERUS_HM7_NATIVE_H
#define KERBERUS_HM7_NATIVE_H
// Kerberus 6.6, legacy18 only: MGC_Hmode7.dll (H-Mode7, Pokemon Insurgence)
// on kerberus/hm7-core.h. legacy18/53_media_misc.rb turns the __id__ values
// the game passes to the DLL back into objects and calls KerberusNative.hm7_*.
//
// Tables are used in place: mkxp-z keeps them as int16 arrays laid out like
// RGSS1. Bitmaps live on the GPU, so each Bitmap used here has a CPU copy in
// the DLL's layout (BGRA, bottom row first). The copy is refreshed from the
// Bitmap when anything else changed it (Bitmap::modified) and written back
// after a call changed it, with two exceptions that only the renderer itself
// reads: the sprite buffer (params[10]) and line 2 of the rows bitmap (column
// tops, rewritten at the start of every frame) stay on the CPU.
#include "hm7-core.h"
#include "../binding-types.h"
#include "bitmap.h"
#include "table.h"
#include "etc.h"
#include "exception.h"
#include "util.h"
#include <SDL_timer.h>
#include <algorithm>
#include <atomic>
#include <condition_variable>
#include <cstdlib>
#include <mutex>
#include <thread>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

struct KerberusHm7Shadow {
    Bitmap *bitmap = nullptr;
    int w = 0, h = 0;
    std::vector<uint8_t> pixels;  // DLL layout: row h-1 first
    bool fresh = false;           // pixels == what the Bitmap holds (or newer, written by us)
    bool uploading = false;
    sigslot::connection modifiedCon, disposedCon;
    kerberus::hm7::Bitmap view() {
        kerberus::hm7::Bitmap b;
        b.w = w;
        b.h = h;
        b.top = pixels.data() + size_t(h - 1) * size_t(w) * 4;
        return b;
    }
};

struct KerberusHm7Stats {
    unsigned long long readBytes = 0, writeBytes = 0;
    unsigned long reads = 0, writes = 0, frames = 0;
    unsigned long long renderMicros = 0, lastRenderMicros = 0;
};

static std::unordered_map<Bitmap *, KerberusHm7Shadow *> kerberusHm7Shadows;
static KerberusHm7Stats kerberusHm7Stats;
static std::vector<uint8_t> kerberusHm7Scratch;
#ifdef KERBERUS_DESKTOP_HARNESS
#include <map>
static std::map<std::string, int> kerberusHm7ReadSizes;  // harness: GPU reads by bitmap size
#endif

static void kerberusHm7Drop(Bitmap *bitmap) {
    std::unordered_map<Bitmap *, KerberusHm7Shadow *>::iterator entry = kerberusHm7Shadows.find(bitmap);
    if (entry == kerberusHm7Shadows.end()) return;
    KerberusHm7Shadow *shadow = entry->second;
    kerberusHm7Shadows.erase(entry);
    shadow->modifiedCon.disconnect();
    shadow->disposedCon.disconnect();
    delete shadow;
}

// A Bitmap freed without dispose leaves its entry behind with dead
// connections; its address may come back for another Bitmap.
static void kerberusHm7Sweep() {
    std::vector<Bitmap *> dead;
    for (std::unordered_map<Bitmap *, KerberusHm7Shadow *>::iterator it = kerberusHm7Shadows.begin();
         it != kerberusHm7Shadows.end(); ++it)
        if (!it->second->disposedCon.connected()) dead.push_back(it->first);
    for (size_t i = 0; i < dead.size(); ++i) kerberusHm7Drop(dead[i]);
}

// RGBA top-down (mkxp-z) <-> BGRA bottom-up (DLL), one row at a time.
static void kerberusHm7Convert(const uint8_t *src, uint8_t *dst, int w, int h) {
    const size_t stride = size_t(w) * 4;
    for (int y = 0; y < h; ++y) {
        const uint8_t *s = src + size_t(y) * stride;
        uint8_t *d = dst + size_t(h - 1 - y) * stride;
        for (int x = 0; x < w; ++x) {  // swap bytes 0 and 2 (little-endian words)
            uint32_t v;
            std::memcpy(&v, s + 4 * x, 4);
            v = (v & 0xFF00FF00u) | ((v >> 16) & 0xFFu) | ((v & 0xFFu) << 16);
            std::memcpy(d + 4 * x, &v, 4);
        }
    }
}

// read = false: the caller rewrites every pixel, nothing is read back.
static KerberusHm7Shadow *kerberusHm7ShadowOf(Bitmap *bitmap, bool read = true) {
    std::unordered_map<Bitmap *, KerberusHm7Shadow *>::iterator entry = kerberusHm7Shadows.find(bitmap);
    if (entry != kerberusHm7Shadows.end() && !entry->second->disposedCon.connected()) {
        kerberusHm7Drop(bitmap);
        entry = kerberusHm7Shadows.end();
    }
    KerberusHm7Shadow *shadow;
    if (entry == kerberusHm7Shadows.end()) {
        if (kerberusHm7Shadows.size() >= 64) kerberusHm7Sweep();
        shadow = new KerberusHm7Shadow();
        shadow->bitmap = bitmap;
        shadow->modifiedCon = bitmap->modified.connect([shadow]() {
            if (!shadow->uploading) shadow->fresh = false;
        });
        shadow->disposedCon = bitmap->wasDisposed.connect([bitmap]() { kerberusHm7Drop(bitmap); });
        kerberusHm7Shadows[bitmap] = shadow;
    } else {
        shadow = entry->second;
    }
    const int w = bitmap->width(), h = bitmap->height();
    if (shadow->w != w || shadow->h != h || shadow->pixels.size() != size_t(w) * size_t(h) * 4) {
        shadow->w = w;
        shadow->h = h;
        shadow->pixels.assign(size_t(w) * size_t(h) * 4, 0);
        shadow->fresh = false;
    }
    if (!shadow->fresh && !read) {
        std::fill(shadow->pixels.begin(), shadow->pixels.end(), 0);
    } else if (!shadow->fresh) {
        const size_t bytes = shadow->pixels.size();
        kerberusHm7Scratch.resize(bytes);
        if (bytes && !bitmap->getRaw(kerberusHm7Scratch.data(), int(bytes)))
            throw Exception(Exception::MKXPError, "MGC_Hmode7: leitura dos pixels do Bitmap %dx%d falhou", w, h);
        kerberusHm7Convert(kerberusHm7Scratch.data(), shadow->pixels.data(), w, h);
        shadow->fresh = true;
        kerberusHm7Stats.reads++;
        kerberusHm7Stats.readBytes += bytes;
#ifdef KERBERUS_DESKTOP_HARNESS
        kerberusHm7ReadSizes[std::to_string(w) + "x" + std::to_string(h)]++;
#endif
    }
    return shadow;
}

static void kerberusHm7Upload(KerberusHm7Shadow *shadow) {
    const size_t bytes = shadow->pixels.size();
    if (!bytes) return;
    // DLL layout -> RGBA top-down: the same row flip and channel swap
    kerberusHm7Scratch.resize(bytes);
    kerberusHm7Convert(shadow->pixels.data(), kerberusHm7Scratch.data(), shadow->w, shadow->h);
    shadow->uploading = true;
    try {
        shadow->bitmap->replaceRaw(kerberusHm7Scratch.data(), int(bytes));
    } catch (...) {
        shadow->uploading = false;
        throw;
    }
    shadow->uploading = false;
    kerberusHm7Stats.writes++;
    kerberusHm7Stats.writeBytes += bytes;
}

// ---------------------------------------------------------------------------
// Workers for renderHM7: the frame's columns are cut in parts that the game
// thread and up to 3 workers take in turn. The pool lives as long as the
// process (never destroyed, so no thread outlives its objects at exit).
// KERBERUS_HM7_THREADS=1 draws everything on the game thread.
// ---------------------------------------------------------------------------
struct KerberusHm7Job {
    void (*work)(void *, int32_t) = nullptr;
    void *context = nullptr;
    int32_t parts = 0;
    std::atomic<int32_t> next{0};
    int32_t finished = 0, active = 0;  // under the pool's mutex
};

class KerberusHm7Pool {
public:
    static KerberusHm7Pool &get() {
        static KerberusHm7Pool *pool = new KerberusHm7Pool();
        return *pool;
    }
    int threads() const { return workers + 1; }
    void run(int32_t parts, void (*work)(void *, int32_t), void *context) {
        KerberusHm7Job job;
        job.work = work;
        job.context = context;
        job.parts = parts;
        {
            std::lock_guard<std::mutex> lock(mutex);
            current = &job;
            ++generation;
        }
        wake.notify_all();
        int32_t did = 0;
        for (int32_t part; (part = job.next.fetch_add(1)) < parts; ++did) work(context, part);
        std::unique_lock<std::mutex> lock(mutex);
        job.finished += did;
        done.wait(lock, [&job] { return job.finished == job.parts && job.active == 0; });
        current = nullptr;
    }

private:
    KerberusHm7Pool() {
        const char *setting = std::getenv("KERBERUS_HM7_THREADS");
        unsigned cpus = std::thread::hardware_concurrency();
        int wanted = setting && *setting ? std::atoi(setting) : int(cpus > 4 ? 4 : cpus);
        workers = wanted > 1 ? (wanted > 4 ? 3 : wanted - 1) : 0;
        for (int i = 0; i < workers; ++i) std::thread(&KerberusHm7Pool::loop, this).detach();
    }
    void loop() {
        unsigned long seen = 0;
        std::unique_lock<std::mutex> lock(mutex);
        for (;;) {
            wake.wait(lock, [this, &seen] { return current && generation != seen; });
            seen = generation;
            KerberusHm7Job *job = current;
            job->active++;
            lock.unlock();
            int32_t did = 0;
            for (int32_t part; (part = job->next.fetch_add(1)) < job->parts; ++did) job->work(job->context, part);
            lock.lock();
            job->finished += did;
            job->active--;
            done.notify_all();
        }
    }
    std::mutex mutex;
    std::condition_variable wake, done;
    KerberusHm7Job *current = nullptr;
    unsigned long generation = 0;
    int workers = 0;
};

static void kerberusHm7Parallel(int32_t parts, void (*work)(void *, int32_t), void *context) {
    KerberusHm7Pool::get().run(parts, work, context);
}

// ---------------------------------------------------------------------------
// Ruby objects
// ---------------------------------------------------------------------------
static Bitmap *kerberusHm7Bitmap(VALUE value, const char *what) {
    if (NIL_P(value) || FIXNUM_P(value) || SYMBOL_P(value) || value == Qtrue || value == Qfalse)
        rb_raise(rb_eTypeError, "MGC_Hmode7: %s deve ser um Bitmap (recebido %s)", what, rb_obj_classname(value));
    Bitmap *bitmap = getPrivateDataCheck<Bitmap>(value, BitmapType);
    if (!bitmap || bitmap->isDisposed())
        rb_raise(rb_eArgError, "MGC_Hmode7: %s e um Bitmap descartado", what);
    return bitmap;
}

// Autotile slots hold Fixnum 0 when the map has no autotile there.
static Bitmap *kerberusHm7OptionalBitmap(VALUE value, const char *what) {
    if (FIXNUM_P(value) || NIL_P(value)) return nullptr;
    return kerberusHm7Bitmap(value, what);
}

static kerberus::hm7::Table kerberusHm7Table(VALUE value, const char *what, ::Table **object = nullptr) {
    if (NIL_P(value) || FIXNUM_P(value) || SYMBOL_P(value) || value == Qtrue || value == Qfalse)
        rb_raise(rb_eTypeError, "MGC_Hmode7: %s deve ser uma Table (recebido %s)", what, rb_obj_classname(value));
    ::Table *table = getPrivateDataCheck< ::Table>(value, TableType);
    kerberus::hm7::Table view;
    view.xs = table->xSize();
    view.ys = table->ySize();
    view.zs = table->zSize();
    view.data = view.xs > 0 && view.ys > 0 && view.zs > 0 ? &table->at(0, 0, 0) : nullptr;
    if (object) *object = table;
    return view;
}

// The DLL reads these array elements as raw Ruby 1.8 values (Fixnum 2n+1,
// false 0, true 2, nil 4); any other object would be a pointer to it there.
static kerberus::hm7::Value kerberusHm7Raw(VALUE value, const char *what) {
    if (FIXNUM_P(value)) return kerberus::hm7::Value(uint32_t((unsigned long)FIX2LONG(value) << 1 | 1));
    if (value == Qfalse) return 0;
    if (value == Qtrue) return 2;
    if (NIL_P(value)) return 4;
    rb_raise(rb_eTypeError, "MGC_Hmode7: %s deve ser Integer, true, false ou nil (recebido %s)", what,
             rb_obj_classname(value));
    return 0;
}

static VALUE kerberusHm7Array(VALUE value, long minimum, const char *what) {
    if (TYPE(value) != T_ARRAY)
        rb_raise(rb_eTypeError, "MGC_Hmode7: %s deve ser um Array (recebido %s)", what, rb_obj_classname(value));
    if (RARRAY_LEN(value) < minimum)
        rb_raise(rb_eArgError, "MGC_Hmode7: %s precisa de %ld elementos (tem %ld)", what, minimum, (long)RARRAY_LEN(value));
    return value;
}

static void kerberusHm7Refused(const char *function) {
    rb_raise(rb_eArgError, "MGC_Hmode7: %s recusado: os objetos nao tem os tamanhos que o H-Mode7 cria "
                           "(nada foi desenhado)", function);
}

// tilemap hash {index => [layer1, layer2, layer3, counted]}
static std::vector<kerberus::hm7::TileEntry> kerberusHm7TileEntries(VALUE hash) {
    if (TYPE(hash) != T_HASH)
        rb_raise(rb_eTypeError, "MGC_Hmode7: tilemap_hash deve ser um Hash (recebido %s)", rb_obj_classname(hash));
    VALUE pairs = rb_funcall(hash, rb_intern("to_a"), 0);
    std::vector<kerberus::hm7::TileEntry> entries;
    entries.reserve(RARRAY_LEN(pairs));
    for (long i = 0; i < RARRAY_LEN(pairs); ++i) {
        VALUE pair = RARRAY_PTR(pairs)[i];
        VALUE record = kerberusHm7Array(RARRAY_PTR(pair)[1], 4, "entrada do tilemap_hash");
        kerberus::hm7::TileEntry entry;
        entry.index = NUM2INT(RARRAY_PTR(pair)[0]);
        entry.layer1 = NUM2INT(RARRAY_PTR(record)[0]);
        entry.layer2 = NUM2INT(RARRAY_PTR(record)[1]);
        entry.layer3 = NUM2INT(RARRAY_PTR(record)[2]);
        entry.counted = NUM2INT(RARRAY_PTR(record)[3]);
        entries.push_back(entry);
    }
    return entries;
}

// auto_tilesets: 7 autotile sheets (or 0), then (drawMapTileset) 7 heights.
static void kerberusHm7Autotiles(VALUE array, long count, kerberus::hm7::Bitmap *views, kerberus::hm7::Bitmap **slots) {
    kerberusHm7Array(array, count, "auto_tilesets");
    for (long i = 0; i < count; ++i) {
        Bitmap *bitmap = kerberusHm7OptionalBitmap(RARRAY_PTR(array)[i], "auto_tilesets[i]");
        slots[i] = nullptr;
        if (!bitmap) continue;
        views[i] = kerberusHm7ShadowOf(bitmap)->view();
        slots[i] = &views[i];
    }
}

static void kerberusHm7Trace(const char *function, int skipped) {
    if (skipped <= 0) return;
    VALUE module = rb_const_get(rb_cObject, rb_intern("KerberusLegacy18"));
    rb_funcall(module, rb_intern("runtime_trace"), 2, rb_str_new2("HM7"),
               rb_str_new2((std::string(function) + ": " + std::to_string(skipped) +
                            " entradas fora das imagens ignoradas (a DLL leria fora da memoria)").c_str()));
}

// ---------------------------------------------------------------------------
// The eight exports
// ---------------------------------------------------------------------------
static VALUE kerberusHm7ApplyOpacity(VALUE, VALUE bitmapObj, VALUE opacity) {
    Bitmap *bitmap = kerberusHm7Bitmap(bitmapObj, "bitmap");
    const int value = NUM2INT(opacity);
    if (value == 255) return INT2FIX(0);  // alpha * 256 >> 8: no pixel changes
    GUARD_EXC(
        KerberusHm7Shadow *shadow = kerberusHm7ShadowOf(bitmap);
        kerberus::hm7::Bitmap view = shadow->view();
        kerberus::hm7::applyOpacity(view, value);
        kerberusHm7Upload(shadow);
    )
    return INT2FIX(0);
}

static VALUE kerberusHm7ComputeM7(VALUE, VALUE tableObj, VALUE rowsObj, VALUE paramsObj) {
    ::Table *object = nullptr;
    kerberus::hm7::Table table = kerberusHm7Table(tableObj, "computetable", &object);
    Bitmap *rows = kerberusHm7Bitmap(rowsObj, "rowsdata");
    kerberusHm7Array(paramsObj, 11, "parameters");
    kerberus::hm7::Value params[11];
    for (int i = 0; i < 11; ++i) params[i] = kerberusHm7Raw(RARRAY_PTR(paramsObj)[i], "parameters[i]");
    bool ok = false;
    GUARD_EXC(
        KerberusHm7Shadow *shadow = kerberusHm7ShadowOf(rows);
        kerberus::hm7::Bitmap view = shadow->view();
        ok = kerberus::hm7::computeM7(table, view, params);
        if (ok) {
            kerberusHm7Upload(shadow);
            object->modified();
        }
    )
    if (!ok) kerberusHm7Refused("computeM7");
    return INT2FIX(0);
}

static VALUE kerberusHm7DrawHeightmap(VALUE, VALUE heightmapObj, VALUE patternObj, VALUE tilesetObj, VALUE tilesObj) {
    ::Table *object = nullptr;
    kerberus::hm7::Table heightmap = kerberusHm7Table(heightmapObj, "heightmap", &object);
    kerberus::hm7::Table tiles = kerberusHm7Table(tilesObj, "tiletable");
    Bitmap *pattern = kerberusHm7Bitmap(patternObj, "heightpattern");
    Bitmap *mapTileset = kerberusHm7Bitmap(tilesetObj, "map_tileset");
    bool ok = false;
    int32_t skipped = 0;
    GUARD_EXC(
        kerberus::hm7::Bitmap patternView = kerberusHm7ShadowOf(pattern)->view();
        kerberus::hm7::Bitmap tilesetView = kerberusHm7ShadowOf(mapTileset)->view();
        ok = kerberus::hm7::drawHeightmap(heightmap, patternView, tilesetView, tiles, skipped);
        if (ok) object->modified();
    )
    kerberusHm7Drop(pattern);  // used once
    if (!ok) kerberusHm7Refused("drawHeightmap");
    kerberusHm7Trace("drawHeightmap", skipped);
    return INT2FIX(0);
}

static VALUE kerberusHm7ApplyLighting(VALUE, VALUE heightmapObj) {
    ::Table *object = nullptr;
    kerberus::hm7::Table heightmap = kerberusHm7Table(heightmapObj, "heightmap", &object);
    if (!kerberus::hm7::applyLighting(heightmap)) kerberusHm7Refused("applyLighting");
    object->modified();
    return INT2FIX(0);
}

static VALUE kerberusHm7DrawMapTileset(VALUE, VALUE mapTilesetObj, VALUE tilesetObj, VALUE heightsetObj, VALUE hash,
                                       VALUE autotilesObj) {
    Bitmap *mapTileset = kerberusHm7Bitmap(mapTilesetObj, "map_tileset");
    Bitmap *tileset = kerberusHm7Bitmap(tilesetObj, "tileset");
    Bitmap *heightset = kerberusHm7Bitmap(heightsetObj, "heightset");
    std::vector<kerberus::hm7::TileEntry> entries = kerberusHm7TileEntries(hash);
    bool ok = false;
    int32_t skipped = 0;
    GUARD_EXC(
        kerberus::hm7::Bitmap views[14];
        kerberus::hm7::Bitmap *slots[14];
        kerberusHm7Autotiles(autotilesObj, 14, views, slots);
        kerberus::hm7::Bitmap tilesetView = kerberusHm7ShadowOf(tileset)->view();
        kerberus::hm7::Bitmap heightsetView = kerberusHm7ShadowOf(heightset)->view();
        KerberusHm7Shadow *shadow = kerberusHm7ShadowOf(mapTileset);
        kerberus::hm7::Bitmap view = shadow->view();
        ok = kerberus::hm7::drawMapTileset(view, tilesetView, heightsetView, entries.data(), int32_t(entries.size()),
                                           slots, slots + 7, skipped);
        if (ok) kerberusHm7Upload(shadow);
    )
    kerberusHm7Drop(heightset);  // used once; the tileset stays for refreshMapTileset
    for (long i = 7; i < 14 && i < RARRAY_LEN(autotilesObj); ++i) {
        Bitmap *hmap = kerberusHm7OptionalBitmap(RARRAY_PTR(autotilesObj)[i], "auto_tilesets[i]");
        if (hmap) kerberusHm7Drop(hmap);
    }
    if (!ok) kerberusHm7Refused("drawMapTileset");
    kerberusHm7Trace("drawMapTileset", skipped);
    return INT2FIX(0);
}

static VALUE kerberusHm7DrawTextureset(VALUE, VALUE hash, VALUE texturesetObj, VALUE textureAutoObj) {
    Bitmap *textureset = kerberusHm7Bitmap(texturesetObj, "textureset");
    Bitmap *textureAuto = kerberusHm7Bitmap(textureAutoObj, "texture_auto");
    if (TYPE(hash) != T_HASH)
        rb_raise(rb_eTypeError, "MGC_Hmode7: textures deve ser um Hash (recebido %s)", rb_obj_classname(hash));
    VALUE pairs = rb_funcall(hash, rb_intern("to_a"), 0);
    std::vector<Bitmap *> textures;
    std::vector<kerberus::hm7::TextureEntry> entries(RARRAY_LEN(pairs));
    std::vector<kerberus::hm7::Bitmap> views(RARRAY_LEN(pairs));
    bool ok = false;
    int32_t skipped = 0;
    for (long i = 0; i < RARRAY_LEN(pairs); ++i) {
        VALUE pair = RARRAY_PTR(pairs)[i];
        VALUE record = kerberusHm7Array(RARRAY_PTR(pair)[1], 2, "entrada de textures");
        entries[i].index = NUM2INT(RARRAY_PTR(pair)[0]);
        entries[i].tile = NUM2INT(RARRAY_PTR(record)[0]);
        textures.push_back(kerberusHm7Bitmap(RARRAY_PTR(record)[1], "textura"));
    }
    GUARD_EXC(
        for (size_t i = 0; i < entries.size(); ++i) {
            views[i] = kerberusHm7ShadowOf(textures[i])->view();
            entries[i].texture = &views[i];
        }
        kerberus::hm7::Bitmap autoView = kerberusHm7ShadowOf(textureAuto)->view();
        KerberusHm7Shadow *shadow = kerberusHm7ShadowOf(textureset);
        kerberus::hm7::Bitmap view = shadow->view();
        ok = kerberus::hm7::drawTextureset(view, entries.data(), int32_t(entries.size()), autoView, skipped);
        if (ok) kerberusHm7Upload(shadow);
    )
    for (size_t i = 0; i < textures.size(); ++i) kerberusHm7Drop(textures[i]);  // used once
    kerberusHm7Drop(textureAuto);
    if (!ok) kerberusHm7Refused("drawTextureset");
    kerberusHm7Trace("drawTextureset", skipped);
    return INT2FIX(0);
}

static VALUE kerberusHm7RefreshMapTileset(VALUE, VALUE mapTilesetObj, VALUE tilesetObj, VALUE hash, VALUE autotilesObj) {
    Bitmap *mapTileset = kerberusHm7Bitmap(mapTilesetObj, "map_tileset");
    Bitmap *tileset = kerberusHm7Bitmap(tilesetObj, "tileset");
    std::vector<kerberus::hm7::TileEntry> entries = kerberusHm7TileEntries(hash);
    bool ok = false;
    int32_t skipped = 0;
    GUARD_EXC(
        kerberus::hm7::Bitmap views[7];
        kerberus::hm7::Bitmap *slots[7];
        kerberusHm7Autotiles(autotilesObj, 7, views, slots);
        kerberus::hm7::Bitmap tilesetView = kerberusHm7ShadowOf(tileset)->view();
        KerberusHm7Shadow *shadow = kerberusHm7ShadowOf(mapTileset);
        kerberus::hm7::Bitmap view = shadow->view();
        ok = kerberus::hm7::refreshMapTileset(view, tilesetView, entries.data(), int32_t(entries.size()), slots, skipped);
        if (ok) kerberusHm7Upload(shadow);
    )
    if (!ok) kerberusHm7Refused("refreshMapTileset");
    kerberusHm7Trace("refreshMapTileset", skipped);
    return INT2FIX(0);
}

static VALUE kerberusHm7Render(VALUE, VALUE paramsObj, VALUE varsObj, VALUE surfacesObj) {
    kerberusHm7Array(paramsObj, 13, "params");
    kerberusHm7Array(varsObj, 5, "vars");
    kerberusHm7Array(surfacesObj, 0, "render_surfaces");
    VALUE *params = RARRAY_PTR(paramsObj);
    kerberus::hm7::RenderParams p;
    Bitmap *render = kerberusHm7Bitmap(params[0], "params[0] (render)");
    p.compute = kerberusHm7Table(params[1], "params[1] (computetable)");
    Bitmap *rows = kerberusHm7Bitmap(params[2], "params[2] (rowsdata)");
    p.heightmap = kerberusHm7Table(params[3], "params[3] (heightmap)");
    Bitmap *mapTileset = kerberusHm7Bitmap(params[4], "params[4] (map_tileset)");
    p.tiletable = kerberusHm7Table(params[5], "params[5] (tiletable)");
    Bitmap *textureset = kerberusHm7Bitmap(params[6], "params[6] (textureset)");
    p.loopX = kerberusHm7Raw(params[7], "params[7] (loop_x)");
    p.loopY = kerberusHm7Raw(params[8], "params[8] (loop_y)");
    p.cameraMode = kerberusHm7Raw(params[9], "params[9] (camera_mode)");
    Bitmap *buffer = kerberusHm7Bitmap(params[10], "params[10] (buffer)");
    p.lessCut = kerberusHm7Raw(params[11], "params[11] (less_cut)");
    p.noBlackCut = kerberusHm7Raw(params[12], "params[12] (no_black_cut)");
    kerberus::hm7::Value vars[5];
    for (int i = 0; i < 5; ++i) vars[i] = kerberusHm7Raw(RARRAY_PTR(varsObj)[i], "vars[i]");
    const long count = RARRAY_LEN(surfacesObj);
    std::vector<kerberus::hm7::Surface> surfaces(count);
    std::vector<Bitmap *> surfaceBitmaps(count);
    std::vector<kerberus::hm7::Bitmap> surfaceViews(count);
    for (long i = 0; i < count; ++i) {
        VALUE data = kerberusHm7Array(RARRAY_PTR(surfacesObj)[i], 6, "render_surfaces[i]");
        surfaces[i].x = kerberusHm7Raw(RARRAY_PTR(data)[1], "screen_x");
        surfaces[i].y = kerberusHm7Raw(RARRAY_PTR(data)[2], "screen_y");
        surfaceBitmaps[i] = kerberusHm7Bitmap(RARRAY_PTR(data)[3], "bitmap da surface");
        surfaces[i].altitude = kerberusHm7Raw(RARRAY_PTR(data)[4], "altitude");
        surfaces[i].blend = kerberusHm7Raw(RARRAY_PTR(data)[5], "blend_type");
    }
    bool ok = false;
    int32_t target = 0;
    GUARD_EXC(
        for (long i = 0; i < count; ++i) {
            surfaceViews[i] = kerberusHm7ShadowOf(surfaceBitmaps[i])->view();
            surfaces[i].bitmap = &surfaceViews[i];
        }
        KerberusHm7Shadow *renderShadow = kerberusHm7ShadowOf(render);
        p.render = renderShadow->view();
        p.rows = kerberusHm7ShadowOf(rows)->view();
        p.mapTileset = kerberusHm7ShadowOf(mapTileset)->view();
        p.textureset = kerberusHm7ShadowOf(textureset)->view();
        p.buffer = kerberusHm7ShadowOf(buffer)->view();
        const Uint64 start = SDL_GetPerformanceCounter();
        const int threads = KerberusHm7Pool::get().threads();
        ok = kerberus::hm7::renderHM7(p, vars, surfaces.data(), int32_t(count), target, threads > 1 ? 8 : 1,
                                      threads > 1 ? kerberusHm7Parallel : nullptr);
        const Uint64 micros = (SDL_GetPerformanceCounter() - start) * 1000000ULL / SDL_GetPerformanceFrequency();
        kerberusHm7Stats.frames++;
        kerberusHm7Stats.lastRenderMicros = micros;
        kerberusHm7Stats.renderMicros += micros;
        if (ok) kerberusHm7Upload(renderShadow);
    )
    if (!ok) kerberusHm7Refused("renderHM7");
    return INT2NUM(target);
}

// HM7::Surface#update (in-memory port hm7_surface) without reading the GPU:
// `bitmap.clear; bitmap.blt(0, 0, set, Rect(x, y, w, h));
// HM7.apply_opacity(bitmap, opacity)`. On a cleared bitmap a blt at full
// opacity is a plain copy in mkxp-z (no blending), so the copy is made from
// the sheet's CPU copy (read once) and uploaded. false, and the script does it
// itself, when the rectangle is not inside both bitmaps or one of them is a
// mega or animated bitmap.
static VALUE kerberusHm7Surface(int argc, VALUE *argv, VALUE) {
    if (argc != 7) rb_raise(rb_eArgError, "hm7_surface: 7 argumentos esperados (recebidos %d)", argc);
    Bitmap *bitmap = kerberusHm7Bitmap(argv[0], "bitmap da surface");
    Bitmap *sheet = kerberusHm7Bitmap(argv[1], "bitmap_set");
    const int x = NUM2INT(argv[2]), y = NUM2INT(argv[3]), w = NUM2INT(argv[4]), h = NUM2INT(argv[5]);
    const int opacity = NUM2INT(argv[6]);
    if (bitmap->isMega() || sheet->isMega() || bitmap->isAnimated() || sheet->isAnimated()) return Qfalse;
    if (w <= 0 || h <= 0 || x < 0 || y < 0 || x + w > sheet->width() || y + h > sheet->height() ||
        w > bitmap->width() || h > bitmap->height())
        return Qfalse;
    GUARD_EXC(
        KerberusHm7Shadow *source = kerberusHm7ShadowOf(sheet);
        KerberusHm7Shadow *shadow = kerberusHm7ShadowOf(bitmap, false);
        std::fill(shadow->pixels.begin(), shadow->pixels.end(), 0);
        kerberus::hm7::Bitmap from = source->view();
        kerberus::hm7::Bitmap to = shadow->view();
        for (int r = 0; r < h; ++r)
            std::memcpy(to.top - size_t(r) * 4 * to.w, from.top + 4 * x - size_t(y + r) * 4 * from.w, size_t(w) * 4);
        shadow->fresh = true;
        if (opacity != 255) kerberus::hm7::applyOpacity(to, opacity);
        kerberusHm7Upload(shadow);
    )
    return Qtrue;
}

// Bitmap#set_pixel that keeps the CPU copy (in-memory port hm7_rows): the
// HM7 scripts set the fading colour in pixel (0, 0) of the rows bitmap before
// every computeM7, which would otherwise mean a GPU read per camera change.
// The pixel is converted as Bitmap::setPixel does ((uint8) clamp 0..255).
static VALUE kerberusHm7SetPixel(VALUE, VALUE bitmapObj, VALUE xv, VALUE yv, VALUE colorObj) {
    Bitmap *bitmap = kerberusHm7Bitmap(bitmapObj, "bitmap");
    const int x = NUM2INT(xv), y = NUM2INT(yv);
    Color *color = getPrivateDataCheck<Color>(colorObj, ColorType);
    std::unordered_map<Bitmap *, KerberusHm7Shadow *>::iterator entry = kerberusHm7Shadows.find(bitmap);
    KerberusHm7Shadow *shadow = entry != kerberusHm7Shadows.end() && entry->second->disposedCon.connected() &&
                                entry->second->fresh && !bitmap->isMega() && !bitmap->isAnimated()
                                ? entry->second : nullptr;
    if (shadow && x >= 0 && y >= 0 && x < shadow->w && y < shadow->h) {
        uint8_t *p = kerberus::hm7::detail::px(shadow->view(), x, y);
        p[0] = (uint8_t) clamp<double>(color->blue, 0, 255);
        p[1] = (uint8_t) clamp<double>(color->green, 0, 255);
        p[2] = (uint8_t) clamp<double>(color->red, 0, 255);
        p[3] = (uint8_t) clamp<double>(color->alpha, 0, 255);
        shadow->uploading = true;  // same change on the GPU: the copy stays valid
        try {
            bitmap->setPixel(x, y, *color);
        } catch (const Exception &exc) {
            shadow->uploading = false;
            shadow->fresh = false;
            raiseRbExc(exc);
        }
        shadow->uploading = false;
    } else {
        GUARD_EXC(bitmap->setPixel(x, y, *color);)
    }
    return bitmapObj;
}

// [frames, total render us, last render us, reads, read bytes, writes, write bytes, copies]
static VALUE kerberusHm7StatsValue(VALUE) {
    const KerberusHm7Stats &s = kerberusHm7Stats;
    VALUE values[8] = {ULONG2NUM(s.frames), ULL2NUM(s.renderMicros), ULL2NUM(s.lastRenderMicros), ULONG2NUM(s.reads),
                       ULL2NUM(s.readBytes), ULONG2NUM(s.writes), ULL2NUM(s.writeBytes),
                       ULONG2NUM(kerberusHm7Shadows.size())};
    return rb_ary_new4(8, values);
}

#ifdef KERBERUS_DESKTOP_HARNESS
// Desktop harness only: the CPU copy of a Bitmap as the renderer sees it
// ([w, h, BGRA bytes, bottom row first]), to replay a frame on the DLL.
static VALUE kerberusHm7Shadow(VALUE, VALUE bitmapObj) {
    Bitmap *bitmap = kerberusHm7Bitmap(bitmapObj, "bitmap");
    std::unordered_map<Bitmap *, KerberusHm7Shadow *>::iterator entry = kerberusHm7Shadows.find(bitmap);
    if (entry == kerberusHm7Shadows.end()) return Qnil;
    KerberusHm7Shadow *shadow = entry->second;
    return rb_ary_new3(4, INT2NUM(shadow->w), INT2NUM(shadow->h),
                       rb_str_new((const char *)shadow->pixels.data(), long(shadow->pixels.size())),
                       shadow->fresh ? Qtrue : Qfalse);
}

static VALUE kerberusHm7Reads(VALUE) {
    VALUE hash = rb_hash_new();
    for (std::map<std::string, int>::iterator it = kerberusHm7ReadSizes.begin(); it != kerberusHm7ReadSizes.end(); ++it)
        rb_hash_aset(hash, rb_str_new2(it->first.c_str()), INT2NUM(it->second));
    return hash;
}
#endif

static void kerberusHm7NativeInit(VALUE module) {
    rb_define_singleton_method(module, "hm7_apply_opacity", RUBY_METHOD_FUNC(kerberusHm7ApplyOpacity), 2);
    rb_define_singleton_method(module, "hm7_compute_m7", RUBY_METHOD_FUNC(kerberusHm7ComputeM7), 3);
    rb_define_singleton_method(module, "hm7_draw_heightmap", RUBY_METHOD_FUNC(kerberusHm7DrawHeightmap), 4);
    rb_define_singleton_method(module, "hm7_apply_lighting", RUBY_METHOD_FUNC(kerberusHm7ApplyLighting), 1);
    rb_define_singleton_method(module, "hm7_draw_map_tileset", RUBY_METHOD_FUNC(kerberusHm7DrawMapTileset), 5);
    rb_define_singleton_method(module, "hm7_draw_textureset", RUBY_METHOD_FUNC(kerberusHm7DrawTextureset), 3);
    rb_define_singleton_method(module, "hm7_refresh_map_tileset", RUBY_METHOD_FUNC(kerberusHm7RefreshMapTileset), 4);
    rb_define_singleton_method(module, "hm7_render", RUBY_METHOD_FUNC(kerberusHm7Render), 3);
    rb_define_singleton_method(module, "hm7_surface", RUBY_METHOD_FUNC(kerberusHm7Surface), -1);
    rb_define_singleton_method(module, "hm7_set_pixel", RUBY_METHOD_FUNC(kerberusHm7SetPixel), 4);
    rb_define_singleton_method(module, "hm7_stats", RUBY_METHOD_FUNC(kerberusHm7StatsValue), 0);
#ifdef KERBERUS_DESKTOP_HARNESS
    rb_define_singleton_method(module, "hm7_shadow", RUBY_METHOD_FUNC(kerberusHm7Shadow), 1);
    rb_define_singleton_method(module, "hm7_reads", RUBY_METHOD_FUNC(kerberusHm7Reads), 0);
#endif
}

#endif
