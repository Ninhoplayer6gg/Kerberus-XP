# Kerberus XP 6.3 - Legacy18 core.
#
# This source is evaluated by the REAL Ruby 1.8 interpreter linked into
# libmkxp-z18.so, after every RGSS section is decoded and before any game
# section runs. Keep it valid on MRI 1.8.7: no refinements, Encoding,
# keyword arguments, prepend, define_singleton_method, caller_locations,
# lambda literals, byte-level String helpers from 1.9 or RubyVM.
#
# Nothing here edits a file of the game. Script replacements (Kerberus Ports)
# happen only in memory, on $RGSS_SCRIPTS, before the section is evaluated.
module KerberusLegacy18
  VERSION = '6.4.0'
  RUNTIME = 'legacy18'

  # Every Kerberus diagnostic raised to game code is a RuntimeError, so
  # scripts that already `rescue` optional features keep working.
  class Error < RuntimeError; end

  @events = {}
  @event_count = 0
  @native = {}
  @config = nil
  @log_writes = 0

  def self.meta(object)
    class << object
      self
    end
  end

  # ---------------------------------------------------------------------
  # Configuration (environment prepared by MainActivity.java)
  # ---------------------------------------------------------------------
  def self.env(name)
    value = ENV[name]
    value.nil? || value.empty? ? nil : value
  end

  def self.config
    return @config if @config
    trace = (env('KERBERUS_WINTRACE') || 'summary').downcase
    trace = 'summary' unless %w(off summary detail).include?(trace)
    compat_log = env('KERBERUS_COMPAT_LOG')
    @config = {
      :trace => trace,
      :compat_log => compat_log,
      :compat_dir => compat_log ? File.dirname(compat_log) : nil,
      :runtime_log => env('KERBERUS_LOG_PATH'),
      :ports => env('KERBERUS_COMPAT_MODE') != 'off',
      :ports_disabled => (env('KERBERUS_PORTS_DISABLE') || '').split(',').map { |x| x.strip }.reject { |x| x.empty? },
      :filesystem => env('KERBERUS_FS_COMPAT') != 'off',
      :dump_scripts => env('KERBERUS_DUMP_SCRIPTS') == '1',
      :frameskip => env('KERBERUS_FRAMESKIP') != 'off',
      :perf_window => [(env('KERBERUS_PERF_WINDOW') || '1200').to_i, 60].max,
      :exec_name => env('KERBERUS_EXEC_NAME') || 'Game'
    }
  end

  def self.reset_config!
    @config = nil
  end

  def self.trace_level
    config[:trace]
  end

  # Private per-game directory (outside the game folder) used for the
  # virtual registry, virtual Windows folders and WINTRACE reports.
  def self.data_dir(*parts)
    base = config[:compat_dir]
    return nil unless base
    path = File.join(base, 'winbridge', *parts)
    ensure_dir(path)
    path
  end

  def self.ensure_dir(path)
    return path if raw_directory?(path)
    parent = File.dirname(path)
    ensure_dir(parent) unless parent == path || raw_directory?(parent)
    Dir.mkdir(path) unless raw_directory?(path)
    path
  end

  # ---------------------------------------------------------------------
  # Raw file helpers. They never go through the Windows path layer, so
  # diagnostics cannot recurse into the code they are reporting on.
  # ---------------------------------------------------------------------
  def self.raw_directory?(path)
    File.respond_to?(:kerberus_raw_directory?) ? File.kerberus_raw_directory?(path) : File.directory?(path)
  end

  def self.raw_file?(path)
    File.respond_to?(:kerberus_raw_file?) ? File.kerberus_raw_file?(path) : File.file?(path)
  end

  def self.raw_size(path)
    File.respond_to?(:kerberus_raw_size) ? File.kerberus_raw_size(path) : File.size(path)
  end

  def self.raw_write(path, text, mode)
    file = File.respond_to?(:kerberus_raw_open) ? File.kerberus_raw_open(path, mode) : File.open(path, mode)
    begin
      file.write(text)
    ensure
      file.close
    end
  end

  def self.raw_read(path)
    file = File.respond_to?(:kerberus_raw_open) ? File.kerberus_raw_open(path, 'rb') : File.open(path, 'rb')
    begin
      file.read
    ensure
      file.close
    end
  end

  # Append a bounded line to a diagnostic file. A full or read-only
  # partition must never change the game's result, so only IO errors are
  # absorbed here; programming errors still propagate.
  def self.append_bounded(path, line, limit)
    return false unless path
    begin
      if raw_file?(path) && raw_size(path) + line.length > limit
        previous = path + '.previous'
        File.delete(previous) if raw_file?(previous)
        File.rename(path, previous)
      end
      raw_write(path, line, 'ab')
      true
    rescue SystemCallError, IOError
      false
    end
  end

  def self.clean(text, limit)
    value = text.to_s.gsub(/[\r\n\t]/, ' ')
    value.length > limit ? value[0, limit] : value
  end

  # One line per distinct (kind, api). Goes to System.puts (logcat), to the
  # per-game compatibility log shown by the launcher and, when important,
  # to the runtime report.
  def self.event(kind, api, detail, important = false)
    key = kind.to_s + ':' + api.to_s
    return nil if @events[key]
    return nil if @event_count >= 1024
    @events[key] = true
    @event_count += 1
    line = '[' + kind.to_s + '] ' + api.to_s
    detail = detail.to_s
    line << ' ' << detail unless detail.empty?
    line = clean(line, 900)
    System.puts(line) if defined?(System) && System.respond_to?(:puts) && trace_level != 'off'
    append_bounded(config[:compat_log], line + "\n", 65536) unless trace_level == 'off'
    runtime_trace(kind.to_s, api.to_s + (detail.empty? ? '' : ' ' + detail)) if important
    line
  end

  def self.forget_events!
    @events = {}
    @event_count = 0
  end

  # Same format as the native kerberusTrace(), same report file.
  def self.runtime_trace(stage, detail)
    path = config[:runtime_log]
    return false unless path
    return false if raw_file?(path) && raw_size(path) >= 256 * 1024
    begin
      raw_write(path, '[' + stage.to_s + '] ' + clean(detail, 4096) + "\n", 'ab')
      true
    rescue SystemCallError, IOError
      false
    end
  end

  def self.runtime_block(title, fields)
    lines = ['[' + title + ']']
    fields.each { |pair| lines << pair[0].to_s + '=' + clean(pair[1], 400) }
    text = lines.join("\n")
    path = config[:runtime_log]
    if path && !(raw_file?(path) && raw_size(path) >= 256 * 1024)
      begin
        raw_write(path, text + "\n", 'ab')
      rescue SystemCallError, IOError
      end
    end
    System.puts(text) if defined?(System) && System.respond_to?(:puts)
    text
  end

  # ---------------------------------------------------------------------
  # Script location (Ruby 1.8 has only Kernel#caller strings)
  # ---------------------------------------------------------------------
  SECTION_FRAME = /\ASection(\d+):(\d+)/
  NAMED_FRAME = /\A(\d{3,}):(.*):(\d+)(?::in `.*')?\z/

  def self.script_name(index)
    scripts = $RGSS_SCRIPTS
    return nil unless scripts.is_a?(Array)
    entry = scripts[index]
    return nil unless entry.is_a?(Array) && entry[1].is_a?(String)
    clean(entry[1], 80)
  end

  # Returns [script_name, section_label, line] for the first frame that
  # belongs to a game section, or a neutral triple.
  def self.location(stack)
    (stack || []).each do |frame|
      frame = frame.to_s
      if frame =~ SECTION_FRAME
        index = $1.to_i
        line = $2.to_i
        return [script_name(index) || '?', format('Section%03d', index), line]
      elsif frame =~ NAMED_FRAME
        index = $1.to_i
        line = $3.to_i
        return [script_name(index) || $2, format('Section%03d', index), line]
      end
    end
    ['nao identificado', '-', 0]
  end

  def self.here
    location(caller(1))
  end

  # Maps every SectionNNN frame of a backtrace to the RMXP script name.
  def self.readable_backtrace(backtrace, limit)
    result = []
    (backtrace || []).each do |frame|
      break if result.length >= limit
      text = frame.to_s
      if text =~ SECTION_FRAME
        name = script_name($1.to_i)
        text = text + ' [' + name + ']' if name
      end
      result << text
    end
    result
  end

  def self.describe_exception(error)
    where = location(error.backtrace)
    [['script', where[0]], ['section', where[1]], ['line', where[2]],
     ['class', error.class.name], ['message', error.message],
     ['backtrace', readable_backtrace(error.backtrace, 12).join(' <- ')],
     ['runtime', RUNTIME]]
  end

  # ---------------------------------------------------------------------
  # Native mkxp-z methods, captured before game scripts can override them.
  # ---------------------------------------------------------------------
  NATIVE_TABLE = [
    ['Input', [:update, :press?, :trigger?, :repeat?, :release?, :count,
               :pressex?, :triggerex?, :repeatex?, :releaseex?, :repeatcount,
               :mouse_x, :mouse_y, :scroll_v, :gets, :text_input, :text_input=,
               :mouse_in_window?, :clipboard, :clipboard=]],
    ['Audio', [:bgm_play, :bgm_stop, :bgm_fade, :bgm_pos,
               :bgs_play, :bgs_stop, :bgs_fade, :bgs_pos,
               :me_play, :me_stop, :me_fade, :se_play, :se_stop]],
    ['Graphics', [:update, :width, :height, :snap_to_bitmap, :resize_screen,
                  :frame_count, :frame_rate, :play_movie, :fullscreen, :fullscreen=,
                  :frameskip, :frameskip=]],
    ['System', [:puts, :user_language, :power_state, :nproc, :memory,
                :window_title, :set_window_title, :game_title]]
  ]

  def self.remember_native
    return if @remembered
    @remembered = true
    NATIVE_TABLE.each do |pair|
      name = pair[0]
      next unless Object.const_defined?(name)
      mod = Object.const_get(name)
      pair[1].each do |method_name|
        @native[[name, method_name]] = mod.method(method_name) if mod.respond_to?(method_name)
      end
    end
    if defined?(::Input) && ::Input.const_defined?(:Controller)
      controller = ::Input::Controller
      [:connected?, :raw_button_states, :raw_axes, :power_level, :name].each do |method_name|
        @native[['Input::Controller', method_name]] = controller.method(method_name) if controller.respond_to?(method_name)
      end
    end
    @native[['Kernel', :print]] = Kernel.method(:print) if Kernel.respond_to?(:print)
  end

  # Method object (or nil) for hot paths: no key allocation per call.
  def self.native_method(mod, name)
    @native[[mod, name]]
  end

  def self.native?(mod, name)
    !@native[[mod, name]].nil?
  end

  def self.native(mod, name, *args)
    method = @native[[mod, name]]
    raise Error, 'Kerberus: binding nativo ausente: ' + mod.to_s + '.' + name.to_s unless method
    method.call(*args)
  end

  def self.forget_native!
    @native = {}
    @remembered = false
  end

  # Kernel-level helpers coming from pokemon-native.h. Tests run without
  # them, so each one has a Ruby fallback with the same meaning.
  def self.uptime_ms
    if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:uptime_ms)
      ::KerberusNative.uptime_ms
    else
      (Time.now.to_f * 1000.0).to_i
    end
  end

  def self.monotonic_ns
    if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:monotonic_ns)
      ::KerberusNative.monotonic_ns
    else
      (Time.now.to_f * 1000000000.0).to_i
    end
  end

  def self.focused?
    return ::KerberusNative.focused? if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:focused?)
    true
  end

  def self.thread_id
    return ::KerberusNative.thread_id if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:thread_id)
    Process.pid
  end
end
