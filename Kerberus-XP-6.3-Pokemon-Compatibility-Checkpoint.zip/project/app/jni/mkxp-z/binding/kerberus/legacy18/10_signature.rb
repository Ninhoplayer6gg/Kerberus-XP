# Kerberus WinBridge - Win32API signature normalization.
#
# Reference semantics: Ruby 1.8 ext/Win32API and mkxp-z MiniFFI.
#   imports: nil, a String (one type per character) or an Array of Strings
#            (first character of each item). Unknown characters are ignored
#            by Win32API; WinBridge ignores them too but records a warning.
#   exports: nil or a String; only its first character matters.
# Types: P pointer/buffer, S string pointer (= P), I/L/N 32-bit integer,
#        B BOOL (MiniFFI), V or "0" void.
# Extra accepted forms, all normalized before use:
#   "PPI:I"      imports and export joined (only when export is empty)
#   "%w(p i)"    literal percent-array text (never treated as a type)
#   0            legacy "no arguments" / void
module KerberusLegacy18
  module WinBridge
    # Win32API raises TypeError for values it cannot read as a String.
    class SignatureError < TypeError; end

    class Signature
      attr_reader :imports, :export, :raw_imports, :raw_export, :warnings

      def initialize(imports, export, raw_imports, raw_export, warnings)
        @imports = imports
        @export = export
        @raw_imports = raw_imports
        @raw_export = raw_export
        @warnings = warnings
      end

      def arity
        @imports.length
      end

      def imports_text
        @imports.empty? ? 'V' : @imports
      end

      def export_text
        @export.empty? ? 'V' : @export
      end

      def text
        imports_text + ':' + export_text
      end
    end

    module Signatures
      IMPORT_TYPES = { 'P' => 'P', 'S' => 'P', 'I' => 'I', 'L' => 'I', 'N' => 'I', 'B' => 'B' }
      SEPARATORS = " \t\r\n,;"
      PERCENT_ARRAY = /\A%[wWiI]?\s*[\(\[\{<](.*)[\)\]\}>]\z/m

      def self.raw(value)
        text = value.inspect
        text.length > 80 ? text[0, 80] + '...' : text
      end

      def self.parse(imports, export)
        warnings = []
        raw_imports = raw(imports)
        raw_export = raw(export)
        if imports.is_a?(String) && imports.index(':') && export_empty?(export)
          pair = imports.split(':', 2)
          imports = pair[0]
          export = pair[1]
          warnings << 'forma combinada imports:export normalizada'
        end
        Signature.new(parse_imports(imports, warnings), parse_export(export, warnings),
                      raw_imports, raw_export, warnings)
      end

      def self.export_empty?(value)
        value.nil? || value == 0 || (value.is_a?(String) && value.strip.empty?)
      end

      def self.string_value(value, role)
        return value if value.is_a?(String)
        return value.to_str if value.respond_to?(:to_str)
        raise SignatureError, 'assinatura ' + role + ' invalida: ' + raw(value) +
                              ' (esperado String, Array ou nil)'
      end

      def self.parse_imports(value, warnings)
        return '' if value.nil?
        if value == 0
          warnings << 'imports Integer 0 tratado como sem argumentos'
          return ''
        end
        if value.is_a?(Array)
          return items_to_types(value, warnings)
        end
        text = string_value(value, 'de imports')
        raise SignatureError, 'assinatura de imports excede 128 caracteres' if text.length > 128
        stripped = text.strip
        if stripped =~ PERCENT_ARRAY
          warnings << 'texto literal ' + stripped[0, 3] + '...) interpretado como lista de tipos'
          return items_to_types($1.split(/\s+/).reject { |item| item.empty? }, warnings)
        end
        upper = stripped.upcase
        return '' if upper == 'V' || upper == '0' || upper == 'VOID'
        result = ''
        ignored = ''
        upper.each_byte do |byte|
          char = byte.chr
          next if SEPARATORS.index(char)
          type = IMPORT_TYPES[char]
          if type
            result << type
          elsif char == 'V' || char == '0'
            ignored << char
          else
            ignored << char
          end
        end
        unless ignored.empty?
          warnings << 'caracteres ignorados como no Win32API: ' + ignored.inspect
        end
        raise SignatureError, 'mais de 16 parametros na assinatura' if result.length > 16
        result
      end

      def self.items_to_types(items, warnings)
        raise SignatureError, 'mais de 16 parametros na assinatura' if items.length > 16
        result = ''
        items.each do |item|
          text = string_value(item, 'de item')
          text = text.strip
          next if text.empty?
          type = IMPORT_TYPES[text[0, 1].upcase]
          if type
            result << type
            warnings << 'item ' + text.inspect + ': usado o primeiro caractere' if text.length > 1
          elsif text.upcase == 'V' || text == '0'
            next
          else
            warnings << 'item desconhecido ignorado: ' + text.inspect
          end
        end
        result
      end

      def self.parse_export(value, warnings)
        return '' if value.nil? || value == 0
        if value.is_a?(Array)
          warnings << 'export Array: usado o primeiro item'
          value = value.first
          return '' if value.nil?
        end
        text = string_value(value, 'de export').strip
        return '' if text.empty?
        if text =~ PERCENT_ARRAY
          words = $1.split(/\s+/).reject { |item| item.empty? }
          return '' if words.empty?
          text = words.first
        end
        first = text[0, 1].upcase
        return '' if first == 'V' || first == '0'
        type = IMPORT_TYPES[first]
        unless type
          warnings << 'export desconhecido ' + text.inspect + ' tratado como void'
          return ''
        end
        warnings << 'export ' + text.inspect + ': usado o primeiro caractere' if text.length > 1 && text.upcase != 'VOID'
        type
      end
    end
  end
end
