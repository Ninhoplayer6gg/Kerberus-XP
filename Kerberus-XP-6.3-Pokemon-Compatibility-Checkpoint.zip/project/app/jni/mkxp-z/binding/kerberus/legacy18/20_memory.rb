# Kerberus WinBridge - buffers, virtual memory and text conversion.
#
# Ruby 1.8 strings are byte arrays, which is exactly what Win32 buffers are.
# Real process addresses never cross this boundary: pointer-returning APIs
# hand out handles from a small virtual heap that only WinBridge providers
# (RtlMoveMemory, lstrlen, CoTaskMemFree...) understand.
module KerberusLegacy18
  module WinBridge
    class InvalidPointer < RuntimeError; end

    module Buffers
      LIMIT = 16 * 1024 * 1024

      def self.null?(value)
        value.nil? || value == 0
      end

      def self.need(value, size, writable, what)
        unless size.is_a?(Integer) && size >= 0 && size <= LIMIT
          raise ArgumentError, what + ': tamanho invalido ' + size.inspect
        end
        unless value.is_a?(String)
          raise InvalidPointer, what + ': esperado buffer String Ruby, recebido ' + value.class.name +
                                ' (enderecos numericos de memoria nao existem no Android)'
        end
        if value.length < size
          raise ArgumentError, what + ': buffer de ' + value.length.to_s + ' bytes; necessario ' + size.to_s
        end
        raise ArgumentError, what + ': buffer congelado' if writable && value.frozen?
        value
      end

      # Writes data at offset without changing the buffer length.
      def self.put(buffer, data, offset)
        offset ||= 0
        need(buffer, offset + data.length, true, 'buffer de saida')
        buffer[offset, data.length] = data unless data.empty?
        data.length
      end

      def self.put_u32(buffer, value, offset)
        put(buffer, [value & 0xffffffff].pack('V'), offset)
      end

      def self.u32(buffer, offset)
        need(buffer, offset + 4, false, 'DWORD')
        buffer[offset, 4].unpack('V')[0]
      end

      def self.pack_u64(value)
        [value & 0xffffffff, (value >> 32) & 0xffffffff].pack('VV')
      end

      # NUL-terminated ANSI/UTF-8 string argument.
      def self.c_string(value)
        return nil if null?(value)
        return Memory.c_string(value) if value.is_a?(Integer)
        text = value.is_a?(String) ? value : value.to_s
        index = text.index("\0")
        index ? text[0, index] : text
      end

      # NUL-terminated UTF-16LE string argument, returned as UTF-8.
      def self.wide_string(value)
        return nil if null?(value)
        return Memory.wide_string(value) if value.is_a?(Integer)
        Text.utf16le_to_utf8(Text.until_wide_nul(value.to_s))
      end

      # Copies text into an output buffer of `capacity` bytes, always NUL
      # terminated like the Win32 *A functions. Returns bytes copied.
      def self.copy_c_string(buffer, capacity, text)
        return 0 if capacity.nil? || capacity <= 0
        bytes = text[0, capacity - 1] || ''
        put(buffer, bytes + "\0", 0)
        bytes.length
      end
    end

    module Memory
      BASE = 0x7E000000
      STEP = 0x10000
      LIMIT = 256
      @blocks = {}
      @next = BASE

      def self.reset!
        @blocks = {}
        @next = BASE
      end

      def self.alloc(bytes)
        raise ArgumentError, 'heap virtual: bloco invalido' unless bytes.is_a?(String)
        raise ArgumentError, 'heap virtual: bloco maior que 64 KiB' if bytes.length > STEP
        raise ArgumentError, 'heap virtual esgotado (' + LIMIT.to_s + ' blocos)' if @blocks.size >= LIMIT
        handle = @next
        @next += STEP
        @next = BASE if @next >= BASE + STEP * 4096
        @next += STEP while @blocks[@next]
        @blocks[handle] = bytes.dup
        handle
      end

      def self.free(handle)
        return true if Buffers.null?(handle)
        !@blocks.delete(handle).nil?
      end

      def self.owns?(pointer)
        !locate(pointer).nil?
      end

      def self.count
        @blocks.size
      end

      # Resolves a pointer that may point inside a block.
      def self.locate(pointer)
        return nil unless pointer.is_a?(Integer)
        base = pointer - ((pointer - BASE) % STEP)
        block = @blocks[base]
        return nil unless block
        offset = pointer - base
        offset <= block.length ? [block, offset] : nil
      end

      def self.fetch(pointer, what)
        found = locate(pointer)
        return found if found
        raise InvalidPointer, what + ': ponteiro 0x' + (pointer.to_i & 0xffffffff).to_s(16) +
                              ' nao pertence ao heap virtual do Kerberus'
      end

      def self.read(pointer, length)
        return '' if length == 0
        if pointer.is_a?(String)
          Buffers.need(pointer, length, false, 'leitura')
          return pointer[0, length]
        end
        block, offset = fetch(pointer, 'leitura')
        if offset + length > block.length
          raise InvalidPointer, 'leitura de ' + length.to_s + ' bytes ultrapassa o bloco virtual'
        end
        block[offset, length]
      end

      def self.write(pointer, data)
        return 0 if data.empty?
        return Buffers.put(pointer, data, 0) if pointer.is_a?(String)
        block, offset = fetch(pointer, 'escrita')
        if offset + data.length > block.length
          raise InvalidPointer, 'escrita de ' + data.length.to_s + ' bytes ultrapassa o bloco virtual'
        end
        block[offset, data.length] = data
        data.length
      end

      def self.c_string(pointer)
        block, offset = fetch(pointer, 'string ANSI')
        tail = block[offset, block.length - offset] || ''
        index = tail.index("\0")
        index ? tail[0, index] : tail
      end

      def self.wide_string(pointer)
        block, offset = fetch(pointer, 'string UTF-16')
        Text.utf16le_to_utf8(Text.until_wide_nul(block[offset, block.length - offset] || ''))
      end

      def self.alloc_wide(text)
        alloc(Text.utf8_to_utf16le(text) + "\0\0")
      end
    end

    # UTF-8 <-> UTF-16LE and Windows-1252 without Encoding (Ruby 1.8).
    module Text
      CP1252 = {
        0x80 => 0x20AC, 0x82 => 0x201A, 0x83 => 0x0192, 0x84 => 0x201E, 0x85 => 0x2026,
        0x86 => 0x2020, 0x87 => 0x2021, 0x88 => 0x02C6, 0x89 => 0x2030, 0x8A => 0x0160,
        0x8B => 0x2039, 0x8C => 0x0152, 0x8E => 0x017D, 0x91 => 0x2018, 0x92 => 0x2019,
        0x93 => 0x201C, 0x94 => 0x201D, 0x95 => 0x2022, 0x96 => 0x2013, 0x97 => 0x2014,
        0x98 => 0x02DC, 0x99 => 0x2122, 0x9A => 0x0161, 0x9B => 0x203A, 0x9C => 0x0153,
        0x9E => 0x017E, 0x9F => 0x0178
      }
      CP1252_REVERSE = {}
      CP1252.each { |byte, code| CP1252_REVERSE[code] = byte }

      def self.until_wide_nul(bytes)
        index = 0
        while index + 1 < bytes.length
          return bytes[0, index] if bytes[index] == 0 && bytes[index + 1] == 0
          index += 2
        end
        bytes[0, bytes.length - (bytes.length % 2)]
      end

      def self.codepoints_utf8(text)
        text.unpack('U*')
      rescue ArgumentError
        # Not valid UTF-8: RGSS1 text files are often Windows-1252.
        codepoints_cp1252(text)
      end

      def self.codepoints_cp1252(bytes)
        result = []
        bytes.each_byte { |byte| result << (CP1252[byte] || byte) }
        result
      end

      def self.utf8_to_utf16le(text)
        units = []
        codepoints_utf8(text.to_s).each do |code|
          if code >= 0x10000
            code -= 0x10000
            units << (0xD800 | (code >> 10)) << (0xDC00 | (code & 0x3FF))
          else
            units << code
          end
        end
        units.pack('v*')
      end

      def self.utf16le_to_utf8(bytes)
        units = bytes.to_s.unpack('v*')
        codes = []
        index = 0
        while index < units.length
          unit = units[index]
          if unit >= 0xD800 && unit <= 0xDBFF && index + 1 < units.length &&
             units[index + 1] >= 0xDC00 && units[index + 1] <= 0xDFFF
            codes << (0x10000 + ((unit - 0xD800) << 10) + (units[index + 1] - 0xDC00))
            index += 2
          else
            codes << (unit >= 0xD800 && unit <= 0xDFFF ? 0xFFFD : unit)
            index += 1
          end
        end
        codes.pack('U*')
      end

      def self.cp1252_to_utf8(bytes)
        codepoints_cp1252(bytes.to_s).pack('U*')
      end

      def self.utf8_to_cp1252(text, default_char)
        used_default = false
        out = ''
        codepoints_utf8(text.to_s).each do |code|
          if code < 0x80 || (code >= 0xA0 && code <= 0xFF)
            out << code.chr
          elsif CP1252_REVERSE[code]
            out << CP1252_REVERSE[code].chr
          else
            out << default_char
            used_default = true
          end
        end
        [out, used_default]
      end
    end
  end
end
