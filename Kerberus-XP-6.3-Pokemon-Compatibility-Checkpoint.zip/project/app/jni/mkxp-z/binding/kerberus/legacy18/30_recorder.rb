# Kerberus Compatibility Recorder (WINTRACE).
#
# Distinguishes three levels of evidence for every Windows API:
#   DETECTED_STATIC - a literal Win32API.new("dll", "fn") exists in a script
#   DECLARED        - Win32API.new actually ran
#   CALLED_RUNTIME  - the object was called at least once
# Only CALLED_RUNTIME APIs can be blockers; the rest are never reported as
# incompatibilities. Counting is one integer increment per call.
module KerberusLegacy18
  module Recorder
    KIND_LABELS = [
      [:native, 'Native/equivalent'],
      [:port, 'Profile/port'],
      [:limited, 'Limited'],
      [:unavailable, 'Unavailable called']
    ]
    STATIC_CALL = /(?:Win32API|MiniFFI)\s*\.\s*new\s*\(?\s*(['"])([^'"\r\n]{1,120})\1\s*,\s*(['"])([^'"\r\n]{1,120})\3/
    ANY_CALL = /(?:Win32API|MiniFFI)\s*\.\s*new\b/

    @static = {}
    @dynamic = 0
    @bindings = []
    @blockers = {}
    @dirty = false
    @frames = 0

    def self.reset!
      @static = {}
      @dynamic = 0
      @bindings = []
      @blockers = {}
      @dirty = false
      @frames = 0
    end

    def self.bindings
      @bindings
    end

    def self.static
      @static
    end

    def self.scan_static(scripts)
      return unless scripts.is_a?(Array)
      scripts.each_with_index do |entry, index|
        next unless entry.is_a?(Array) && entry[3].is_a?(String)
        source = entry[3]
        next unless source.index('Win32API') || source.index('MiniFFI')
        literals = 0
        source.scan(STATIC_CALL) do
          key = WinBridge.library($2) + '!' + $4
          list = (@static[key] ||= [])
          list << index unless list.include?(index) || list.length >= 8
          literals += 1
        end
        total = source.scan(ANY_CALL).length
        @dynamic += total - literals if total > literals
      end
    end

    def self.declared(binding)
      @bindings << binding
      @dirty = true
      if KerberusLegacy18.trace_level == 'detail'
        where = binding.declared_at || []
        KerberusLegacy18.event('DECLARED', binding.key_text,
                               binding.signature.text + ' ' + binding.kind_label + ' @' + where[1].to_s + ':' + where[2].to_s)
      end
    end

    def self.first_call(binding)
      @dirty = true
      KerberusLegacy18.event('CALLED_RUNTIME', binding.key_text, binding.kind_label + '; ' + binding.note) unless KerberusLegacy18.trace_level == 'off'
    end

    def self.blocker(binding, where)
      key = binding.key_text
      entry = (@blockers[key] ||= [0, where])
      entry[0] += 1
      @dirty = true
      if entry[0] == 1
        KerberusLegacy18.runtime_block('WINBRIDGE', binding.diagnostic(where))
        flush('blocker')
      end
    end

    def self.blockers
      @blockers
    end

    # Called once per frame by the frame hook; cheap unless dirty.
    def self.tick
      @frames += 1
      return unless @dirty && @frames >= 600
      @frames = 0
      flush('periodic')
    end

    def self.summary_lines
      called = @bindings.select { |binding| binding.calls > 0 }
      total = 0
      called.each { |binding| total += binding.calls }
      lines = []
      lines << 'WINTRACE Kerberus ' + VERSION + ' ' + RUNTIME
      lines << 'API calls (distinct): ' + called.length.to_s
      lines << 'Invocations: ' + total.to_s
      KIND_LABELS.each do |pair|
        count = called.select { |binding| binding.kind_bucket == pair[0] }.length
        lines << pair[1] + ': ' + count.to_s
      end
      declared_only = @bindings.select { |binding| binding.calls == 0 }
      static_only = @static.keys.select { |key| !@bindings.any? { |binding| binding.key_text == key } }
      lines << 'Declared, never called: ' + declared_only.length.to_s
      lines << 'DETECTED_STATIC only (never declared): ' + static_only.length.to_s
      lines << 'Dynamic Win32API.new sites: ' + @dynamic.to_s
      lines << ''
      lines << 'Top APIs:'
      called.sort { |a, b| b.calls <=> a.calls }.first(12).each do |binding|
        lines << binding.key_text + ' - ' + binding.calls.to_s + ' calls [' + binding.kind_label + ']'
      end
      lines << ''
      lines << 'BLOCKERS:'
      if @blockers.empty?
        lines << '(nenhum)'
      else
        @blockers.keys.sort.each do |key|
          count, where = @blockers[key]
          lines << key + ' - ' + count.to_s + ' calls @' + where[1].to_s + ':' + where[2].to_s + ' (' + where[0].to_s + ')'
        end
      end
      limited = called.select { |binding| binding.kind_bucket == :limited }
      unless limited.empty?
        lines << ''
        lines << 'LIMITED (called):'
        limited.each { |binding| lines << binding.key_text + ' - ' + binding.note }
      end
      unless declared_only.empty?
        lines << ''
        lines << 'DECLARED (never called):'
        declared_only.first(40).each { |binding| lines << binding.key_text + ' [' + binding.kind_label + ']' }
      end
      unless static_only.empty?
        lines << ''
        lines << 'DETECTED_STATIC (never declared):'
        static_only.sort.first(40).each do |key|
          lines << key + ' sections=' + @static[key].map { |i| format('%03d', i) }.join(',')
        end
      end
      lines
    end

    def self.flush(reason)
      @dirty = false
      return false if KerberusLegacy18.trace_level == 'off'
      directory = KerberusLegacy18.data_dir
      return false unless directory
      text = summary_lines.join("\n") + "\n(" + reason.to_s + ")\n"
      begin
        KerberusLegacy18.raw_write(File.join(directory, 'wintrace.txt'), text, 'wb')
        true
      rescue SystemCallError, IOError
        false
      end
    end
  end

  # Evidence-based milestones. Each one is recorded once per session.
  module Milestones
    ORDER = %w(BOOT TITLE MAP BATTLE SAVE LONG_PLAY)
    @reached = {}
    @polls = 0
    @map_seconds = 0.0
    @last_poll = nil
    @last_position = nil
    @pending_saves = []

    def self.reset!
      @reached = {}
      @polls = 0
      @map_seconds = 0.0
      @last_poll = nil
      @last_position = nil
      @pending_saves = []
    end

    def self.reached
      @reached
    end

    def self.reach(name, detail)
      return false if @reached[name]
      @reached[name] = Time.now.to_i
      line = "MILESTONE\t" + name + "\t" + RUNTIME + "\t" + @reached[name].to_s + "\t" + KerberusLegacy18.clean(detail, 200) + "\n"
      directory = KerberusLegacy18.config[:compat_dir]
      KerberusLegacy18.append_bounded(File.join(directory, 'milestones.log'), line, 65536) if directory
      KerberusLegacy18.runtime_trace('MILESTONE', name + ' ' + detail.to_s)
      true
    end

    def self.save_candidate(path)
      text = path.to_s.tr('\\', '/')
      return unless text =~ /\.rxdata\z/i || text =~ /\.rvdata2?\z/i
      return if text =~ %r{(\A|/)Data/}i
      @pending_saves << text unless @pending_saves.include?(text) || @pending_saves.length >= 8
    end

    def self.scene_name
      scene = $scene
      scene.nil? ? '' : scene.class.name.to_s
    end

    def self.on_map?
      return false unless defined?(::Scene_Map) && $scene.is_a?(::Scene_Map)
      map = $game_map
      map && map.respond_to?(:map_id) && map.map_id.to_i > 0
    end

    def self.poll
      @polls += 1
      now = Time.now.to_f
      elapsed = @last_poll ? now - @last_poll : 0.0
      @last_poll = now
      name = scene_name
      reach('TITLE', name) if name =~ /Title/i
      if on_map?
        @map_seconds += elapsed if elapsed < 5.0
        player = $game_player
        if player && player.respond_to?(:x) && player.respond_to?(:y)
          position = [$game_map.map_id, player.x, player.y]
          reach('MAP', 'map_id=' + position[0].to_s + ' movimento confirmado') if @last_position && @last_position != position
          @last_position = position
        end
        reach('LONG_PLAY', (@map_seconds / 60).to_i.to_s + ' minutos em mapa nesta sessao') if @map_seconds >= 3600
      end
      if !@reached['BATTLE']
        if name =~ /Battle/
          reach('BATTLE', name)
        elsif @polls % 2 == 0 && caller(0).join(' ') =~ /in `(pbStartBattle|pbWildBattle|pbTrainerBattle|pbBattleAnimation|pbSceneStandby|pbDoubleWildBattle)'/
          reach('BATTLE', $1)
        end
      end
      check_saves unless @pending_saves.empty?
    end

    def self.check_saves
      @pending_saves.dup.each do |path|
        next unless KerberusLegacy18.raw_file?(path) && KerberusLegacy18.raw_size(path) > 0
        @pending_saves.delete(path)
        reach('SAVE', File.basename(path))
      end
    end
  end
end
