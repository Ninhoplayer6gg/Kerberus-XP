# Kerberus WinBridge - Win32API interception with deferred binding.
#
# Resolution chain for Win32API.new(dll, function, imports, exports):
#   1. Kerberus native provider (kernel32/user32/... equivalents)
#   2. Kerberus Port provider (replacement for a known fangame DLL)
#   3. Optional compatibility backend (reserved; nil in normal builds)
#   4. Real shared object (".so" names only) through mkxp-z MiniFFI
#   5. Deferred binding: construction succeeds, a call raises
#      WINBRIDGE_UNAVAILABLE with dll/function/signature/script/line.
#
# The object returned is always a real Win32API (MiniFFI) instance, so
# scripts that reopen Win32API, alias #call or test is_a?(Win32API) keep
# working. Only #initialize and #call are wrapped.
module KerberusLegacy18
  module WinBridge
    class Unavailable < KerberusLegacy18::Error; end

    ERROR_SUCCESS = 0
    ERROR_FILE_NOT_FOUND = 2
    ERROR_PATH_NOT_FOUND = 3
    ERROR_ACCESS_DENIED = 5
    ERROR_INVALID_HANDLE = 6
    ERROR_NOT_ENOUGH_MEMORY = 8
    ERROR_INVALID_PARAMETER = 87
    ERROR_CALL_NOT_IMPLEMENTED = 120
    ERROR_INSUFFICIENT_BUFFER = 122
    ERROR_MOD_NOT_FOUND = 126
    ERROR_PROC_NOT_FOUND = 127
    ERROR_ALREADY_EXISTS = 183
    ERROR_ENVVAR_NOT_FOUND = 203
    ERROR_MORE_DATA = 234
    ERROR_NO_MORE_ITEMS = 259
    ERROR_INVALID_WINDOW_HANDLE = 1400
    ERROR_DEVICE_NOT_CONNECTED = 1167

    DLL_ALIASES = {
      'xinput1_1' => 'xinput', 'xinput1_2' => 'xinput', 'xinput1_3' => 'xinput',
      'xinput1_4' => 'xinput', 'xinput9_1_0' => 'xinput',
      'wsock32' => 'ws2_32', 'kernelbase' => 'kernel32',
      'msvcr70' => 'msvcrt', 'msvcr71' => 'msvcrt', 'msvcr80' => 'msvcrt', 'msvcr90' => 'msvcrt',
      'msvcr100' => 'msvcrt', 'msvcr110' => 'msvcrt', 'msvcr120' => 'msvcrt', 'ucrtbase' => 'msvcrt',
      'rgss fmodex' => 'rgss_fmodex', 'rgss linker' => 'rgss_linker'
    }

    class Provider
      attr_reader :dll, :name, :kind, :note, :params, :impl

      def initialize(dll, name, kind, note, params, impl)
        @dll = dll
        @name = name
        @kind = kind
        @note = note
        @params = params
        @impl = impl
      end
    end

    # Shared by every Win32API object with the same dll/function/signature.
    class Binding
      attr_reader :dll, :function, :signature, :provider, :calls
      attr_accessor :declared_at

      def initialize(dll, function, signature, provider)
        @dll = dll
        @function = function
        @signature = signature
        @provider = provider
        @arity = signature.arity
        @export = signature.export
        @impl = provider.impl
        @calls = 0
        @too_few = provider.params && signature.arity < provider.params
      end

      def kind
        @provider.kind
      end

      def kind_bucket
        kind
      end

      def kind_label
        WinBridge.kind_label(kind)
      end

      def note
        @provider.note
      end

      def key_text
        @dll + '!' + @function
      end

      def invoke(args)
        if args.length != @arity
          raise KerberusLegacy18::Error, 'wrong number of parameters: expected ' + @arity.to_s + ', got ' +
                                         args.length.to_s + ' (' + key_text + ' ' + @signature.text + ')'
        end
        if @too_few
          raise ArgumentError, key_text + ' requer ' + @provider.params.to_s + ' parametros; a assinatura ' +
                               @signature.raw_imports + ' declara ' + @arity.to_s
        end
        @calls += 1
        Recorder.first_call(self) if @calls == 1
        result = @impl.call(args)
        case @export
        when '' then 0
        when 'I' then WinBridge.to_i32(result)
        when 'B' then !(result.nil? || result == false || result == 0)
        else WinBridge.pointer_result(result, self)
        end
      end

      def diagnostic(where)
        WinBridge.diagnostic_fields(self, where, 'provider', kind_label)
      end
    end

    # Declared API without a usable provider. Construction never fails;
    # every call raises a precise, rescuable Unavailable error.
    class Deferred
      attr_reader :dll, :function, :signature, :provider, :calls
      attr_accessor :declared_at

      def initialize(dll, function, signature, provider)
        @dll = dll
        @function = function
        @signature = signature
        @provider = provider
        @calls = 0
      end

      def kind
        :unavailable
      end

      def kind_bucket
        :unavailable
      end

      def kind_label
        @provider ? 'Unavailable (known)' : 'Unavailable (missing)'
      end

      def note
        @provider ? @provider.note : 'nenhum provider, port ou backend para esta API'
      end

      def key_text
        @dll + '!' + @function
      end

      def invoke(args)
        @calls += 1
        where = KerberusLegacy18.location(caller(0))
        Recorder.blocker(self, where)
        raise Unavailable, message(where)
      end

      def message(where)
        lines = ['WINBRIDGE_UNAVAILABLE']
        diagnostic(where).each { |pair| lines << pair[0] + '=' + pair[1].to_s }
        lines.join("\n")
      end

      def diagnostic(where)
        WinBridge.diagnostic_fields(self, where, 'provider', @provider ? 'unavailable' : 'missing')
      end
    end

    @providers = {}
    @bindings = {}
    @backend = nil
    @last_error = 0
    @installed = false

    class << self
      attr_accessor :backend
    end

    def self.reset!
      @bindings = {}
      @last_error = 0
    end

    def self.kind_label(kind)
      case kind
      when :native then 'Native/equivalent'
      when :port then 'Profile/port'
      when :limited then 'Limited'
      else 'Unavailable'
      end
    end

    def self.diagnostic_fields(binding, where, provider_key, provider_value)
      declared = binding.declared_at || []
      [['dll', binding.dll], ['function', binding.function],
       ['imports', binding.signature.imports_text], ['exports', binding.signature.export_text],
       ['signature', binding.signature.raw_imports + ' / ' + binding.signature.raw_export],
       [provider_key, provider_value], ['reason', binding.note],
       ['script', where[0]], ['section', where[1]], ['line', where[2]],
       ['declared', declared[1].to_s + ':' + declared[2].to_s + ' (' + declared[0].to_s + ')'],
       ['runtime', RUNTIME], ['call_count', binding.calls]]
    end

    # RGSS1 ran on 32-bit Windows: Win32API returned INT2NUM((long)eax).
    def self.to_i32(value)
      value = 1 if value == true
      value = 0 if value.nil? || value == false
      unless value.is_a?(Integer)
        raise TypeError, 'WinBridge: provider retornou ' + value.class.name + ' para export inteiro'
      end
      value &= 0xffffffff
      value >= 0x80000000 ? value - 0x100000000 : value
    end

    def self.pointer_result(value, binding)
      return value if value.is_a?(String)
      return Memory.c_string(value) if value.is_a?(Integer) && value != 0 && Memory.owns?(value)
      raise KerberusLegacy18::Error, binding.key_text + ': ponteiro nulo retornado para export P'
    end

    # ---------------------------------------------------------------------
    # Error state (GetLastError/SetLastError)
    # ---------------------------------------------------------------------
    def self.last_error
      @last_error
    end

    def self.last_error=(value)
      @last_error = value.to_i & 0xffffffff
    end

    # Documented Win32 failure: sets GetLastError and returns the failure
    # value the real API returns. Never reports success.
    def self.failure(error_code, result)
      @last_error = error_code
      result
    end

    def self.success(result)
      @last_error = ERROR_SUCCESS
      result
    end

    # ---------------------------------------------------------------------
    # Provider registry
    # ---------------------------------------------------------------------
    def self.library(value)
      text = value.to_s.tr('\\', '/')
      name = text.split('/').last.to_s.strip.downcase
      name = name[0, name.length - 4] if name.length > 4 && name[-4, 4] == '.dll'
      name = 'rgss1' if name =~ /\Argss1\d\d[a-z]?\z/
      DLL_ALIASES[name] || name
    end

    # kind: :native, :limited, :port or :unavailable. params: minimum
    # argument count the implementation reads (nil = any).
    def self.provide(dll, names, kind, note, params, &impl)
      table = (@providers[dll] ||= {})
      names = [names] unless names.is_a?(Array)
      names.each do |name|
        table[name] = Provider.new(dll, name, kind, note, params, impl)
      end
    end

    # Win32API tries the exact export first, then the ANSI "A" variant.
    def self.lookup(dll, function)
      table = @providers[dll]
      return nil unless table
      table[function] || table[function + 'A']
    end

    def self.provides_library?(dll)
      table = @providers[library(dll)]
      !table.nil? && table.values.any? { |provider| provider.kind != :unavailable }
    end

    def self.providers
      @providers
    end

    def self.native_library?(dll)
      text = dll.to_s.downcase
      text =~ /\.so(\.\d+)*\z/ ? true : false
    end

    # ---------------------------------------------------------------------
    # Binding creation
    # ---------------------------------------------------------------------
    def self.string_arg(value, what)
      return value if value.is_a?(String)
      return value.to_str if value.respond_to?(:to_str)
      raise TypeError, 'Win32API.new: ' + what + ' deve ser String, recebido ' + value.class.name
    end

    def self.attach(object, argv, block)
      unless argv.length >= 2 && argv.length <= 4
        raise ArgumentError, 'wrong number of arguments (' + argv.length.to_s + ' for 2..4)'
      end
      dll = string_arg(argv[0], 'DLL')
      function = string_arg(argv[1], 'funcao')
      if native_library?(dll)
        object.send(:kerberus_winbridge_native_initialize, *argv, &block)
        return nil
      end
      imports = argv[2]
      export = argv[3]
      key = dll + "\0" + function + "\0" + key_part(imports) + "\0" + key_part(export)
      binding = @bindings[key] || create(key, dll, function, imports, export)
      object.instance_variable_set(:@_kerberus_winbridge, binding)
      object.instance_variable_set(:@_funcname, function)
      object.instance_variable_set(:@_libname, dll)
      block.call(object) if block
      nil
    end

    def self.key_part(value)
      value.is_a?(String) ? value : value.inspect
    end

    def self.create(key, dll, function, imports, export)
      lib = library(dll)
      where = KerberusLegacy18.location(caller(0))
      begin
        signature = Signatures.parse(imports, export)
      rescue SignatureError => error
        fields = [['error', 'SIGNATURE_INVALID'], ['dll', lib], ['function', function],
                  ['imports', Signatures.raw(imports)], ['exports', Signatures.raw(export)],
                  ['reason', error.message], ['script', where[0]], ['section', where[1]],
                  ['line', where[2]], ['runtime', RUNTIME]]
        KerberusLegacy18.runtime_block('WINBRIDGE', fields)
        raise SignatureError, "WINBRIDGE_SIGNATURE\n" + fields.map { |pair| pair[0] + '=' + pair[1].to_s }.join("\n")
      end
      provider = lookup(lib, function)
      provider ||= @backend.resolve(lib, function, signature) if @backend
      binding = if provider && provider.kind != :unavailable
                  Binding.new(lib, function, signature, provider)
                else
                  Deferred.new(lib, function, signature, provider)
                end
      binding.declared_at = where
      signature.warnings.each do |warning|
        KerberusLegacy18.event('SIGNATURE_ADAPTED', binding.key_text,
                               warning + '; recebido ' + signature.raw_imports + ' / ' + signature.raw_export)
      end
      if provider && provider.params && signature.arity < provider.params
        KerberusLegacy18.event('SIGNATURE_ARITY', binding.key_text,
                               'assinatura ' + signature.text + ' tem menos parametros que a API (' + provider.params.to_s + ')', true)
      end
      Recorder.declared(binding)
      @bindings[key] = binding
    end

    # ---------------------------------------------------------------------
    # Installation on the real Win32API (mkxp-z MiniFFI) class
    # ---------------------------------------------------------------------
    def self.install
      return false if @installed
      @installed = true
      unless Object.const_defined?(:Win32API)
        # Builds without MiniFFI: keep the same public surface.
        Object.const_set(:Win32API, Class.new)
        ::Win32API.class_eval do
          def initialize(*argv)
            raise KerberusLegacy18::WinBridge::Unavailable, 'MiniFFI ausente neste build: ' + argv[0].to_s + '!' + argv[1].to_s
          end

          def call(*args)
            raise KerberusLegacy18::WinBridge::Unavailable, 'MiniFFI ausente neste build'
          end
        end
      end
      ::Win32API.class_eval do
        alias_method :kerberus_winbridge_native_initialize, :initialize
        alias_method :kerberus_winbridge_native_call, :call

        def initialize(*argv, &block)
          KerberusLegacy18::WinBridge.attach(self, argv, block)
        end

        def call(*args)
          bridge = @_kerberus_winbridge
          return bridge.invoke(args) if bridge
          kerberus_winbridge_native_call(*args)
        end

        alias_method :Call, :call
      end
      KerberusLegacy18.event('WINBRIDGE', 'Win32API', 'legacy18 WinBridge ativo; deferred binding habilitado')
      true
    end

    def self.installed?
      @installed
    end
  end
end
