# Kerberus WinBridge - native INI (GetPrivateProfile*/WritePrivateProfile*).
#
# Windows rules implemented:
#  - a file name without any directory separator lives in the Windows
#    directory (virtual, per game, outside the game folder);
#  - ".\Game.ini" and other relative/absolute paths use the real file;
#  - section and key names are case-insensitive, first match wins;
#  - only ";" starts a comment; values are trimmed and one pair of
#    surrounding quotes is removed;
#  - writes preserve every other line, comment and the line ending style.
module KerberusLegacy18
  module WinBridge
    module Ini
      LIMIT = 1024 * 1024
      @cache = {}

      def self.reset!
        @cache = {}
      end

      def self.windows_dir
        KerberusLegacy18.data_dir('Windows') || '.'
      end

      def self.path_for(filename)
        name = Buffers.null?(filename) ? 'win.ini' : Buffers.c_string(filename).to_s
        name = 'win.ini' if name.empty?
        unix = name.tr('\\', '/')
        return File.join(windows_dir, unix) unless unix.index('/')
        Paths.resolve(unix, true)
      end

      def self.load(path)
        return nil unless KerberusLegacy18.raw_file?(path)
        stat = File.stat(path)
        cached = @cache[path]
        return cached[2] if cached && cached[0] == stat.mtime.to_i && cached[1] == stat.size
        raise ArgumentError, 'INI excede 1 MiB: ' + path if stat.size > LIMIT
        data = parse(KerberusLegacy18.raw_read(path))
        @cache[path] = [stat.mtime.to_i, stat.size, data]
        data
      end

      # => { :newline, :pre => [raw], :sections => [[name, [[key|nil, value|nil, raw]]]] }
      def self.parse(bytes)
        bytes = bytes[3, bytes.length - 3] if bytes[0, 3] == "\xEF\xBB\xBF"
        newline = bytes.index("\r\n") ? "\r\n" : "\n"
        data = { :newline => newline, :pre => [], :sections => [] }
        current = nil
        rows = bytes.split(/\r?\n/, -1)
        rows.pop if rows.last == ''
        rows.each do |raw|
          line = raw.strip
          if line[0, 1] == '['
            close = line.index(']')
            name = close ? line[1, close - 1] : line[1, line.length - 1]
            current = [name.strip, []]
            data[:sections] << current
          elsif current.nil?
            data[:pre] << raw
          elsif line.empty? || line[0, 1] == ';'
            current[1] << [nil, nil, raw]
          elsif (eq = line.index('='))
            current[1] << [line[0, eq].strip, unquote(line[eq + 1, line.length - eq - 1].strip), raw]
          else
            current[1] << [line, '', raw]
          end
        end
        data
      end

      def self.unquote(value)
        if value.length >= 2 && ((value[0, 1] == '"' && value[-1, 1] == '"') ||
                                 (value[0, 1] == "'" && value[-1, 1] == "'"))
          value[1, value.length - 2]
        else
          value
        end
      end

      def self.section(data, name)
        wanted = name.downcase
        data[:sections].each { |entry| return entry if entry[0].downcase == wanted }
        nil
      end

      def self.value(data, section_name, key)
        entry = data && section(data, section_name)
        return nil unless entry
        wanted = key.downcase
        entry[1].each { |item| return item[1] if item[0] && item[0].downcase == wanted }
        nil
      end

      def self.section_names(data)
        data ? data[:sections].map { |entry| entry[0] } : []
      end

      def self.key_names(data, section_name)
        entry = data && section(data, section_name)
        entry ? entry[1].select { |item| item[0] }.map { |item| item[0] } : []
      end

      # GetPrivateProfileStringA(section, key, default, out, size, file)
      def self.read_string(section_arg, key_arg, default_arg, output, capacity, filename)
        capacity = capacity.to_i
        return WinBridge.success(0) if capacity <= 0
        Buffers.need(output, capacity, true, 'GetPrivateProfileString')
        data = load(path_for(filename))
        section_name = Buffers.c_string(section_arg)
        key = Buffers.c_string(key_arg)
        if section_name.nil? || key.nil?
          names = section_name.nil? ? section_names(data) : key_names(data, section_name)
          return write_list(output, capacity, names)
        end
        found = value(data, section_name, key)
        text = found.nil? ? (Buffers.c_string(default_arg) || '').sub(/\s+\z/, '') : found
        if text.length > capacity - 1
          Buffers.put(output, text[0, capacity - 1] + "\0", 0)
          return WinBridge.failure(ERROR_MORE_DATA, capacity - 1)
        end
        Buffers.put(output, text + "\0", 0)
        WinBridge.failure(found.nil? ? ERROR_FILE_NOT_FOUND : ERROR_SUCCESS, text.length)
      end

      # Double NUL terminated list; truncated lists return size - 2.
      def self.write_list(output, capacity, names)
        text = names.map { |name| name + "\0" }.join
        if text.length + 1 <= capacity
          Buffers.put(output, text + "\0", 0)
          return WinBridge.success(text.length)
        end
        if capacity < 2
          Buffers.put(output, "\0" * capacity, 0)
          return WinBridge.failure(ERROR_MORE_DATA, 0)
        end
        Buffers.put(output, text[0, capacity - 2] + "\0\0", 0)
        WinBridge.failure(ERROR_MORE_DATA, capacity - 2)
      end

      # GetPrivateProfileIntA(section, key, default, file)
      def self.read_int(section_arg, key_arg, default, filename)
        found = value(load(path_for(filename)), Buffers.c_string(section_arg).to_s, Buffers.c_string(key_arg).to_s)
        return default.to_i if found.nil?
        text = found.strip
        return 0 unless text =~ /\A(-?)(0[xX][0-9a-fA-F]+|\d+)/
        number = $2.downcase[0, 2] == '0x' ? $2.hex : $2.to_i
        number = -number unless $1.empty?
        number < 0 ? 0 : number
      end

      # GetPrivateProfileSectionA(section, out, size, file) -> "k=v\0k=v\0\0"
      def self.read_section(section_arg, output, capacity, filename)
        data = load(path_for(filename))
        entry = data && section(data, Buffers.c_string(section_arg).to_s)
        pairs = entry ? entry[1].select { |item| item[0] }.map { |item| item[0] + '=' + item[1].to_s } : []
        write_list(output, capacity.to_i, pairs)
      end

      # WritePrivateProfileStringA(section, key, value, file)
      def self.write_string(section_arg, key_arg, value_arg, filename)
        section_name = Buffers.c_string(section_arg)
        return WinBridge.failure(ERROR_INVALID_PARAMETER, 0) if section_name.nil?
        key = Buffers.c_string(key_arg)
        value = Buffers.c_string(value_arg)
        path = path_for(filename)
        directory = File.dirname(path)
        return WinBridge.failure(ERROR_PATH_NOT_FOUND, 0) unless KerberusLegacy18.raw_directory?(directory)
        data = load(path) || { :newline => "\r\n", :pre => [], :sections => [] }
        entry = section(data, section_name)
        if key.nil?
          data[:sections].delete(entry) if entry
        else
          unless entry
            return WinBridge.success(1) if value.nil?
            entry = [section_name, []]
            data[:sections] << entry
          end
          index = nil
          entry[1].each_with_index { |item, i| index = i if index.nil? && item[0] && item[0].downcase == key.downcase }
          if value.nil?
            entry[1].delete_at(index) if index
          elsif index
            entry[1][index] = [entry[1][index][0], value, entry[1][index][0] + '=' + value]
          else
            position = entry[1].length
            position -= 1 while position > 0 && entry[1][position - 1][0].nil? && entry[1][position - 1][2].strip.empty?
            entry[1].insert(position, [key, value, key + '=' + value])
          end
        end
        store(path, data)
        Paths.invalidate(path) if defined?(Paths)
        WinBridge.success(1)
      end

      def self.store(path, data)
        newline = data[:newline]
        lines = data[:pre].dup
        data[:sections].each do |entry|
          lines << '[' + entry[0] + ']'
          entry[1].each { |item| lines << item[2] }
        end
        text = lines.join(newline)
        text << newline unless text.empty?
        KerberusLegacy18.raw_write(path, text, 'wb')
        @cache.delete(path)
      end
    end
  end
end
