# Kerberus WinBridge - virtual Windows registry, one per game.
#
# Persisted in the private Kerberus directory of the game, never in the
# game folder and never in any system location. Seeded only with the keys
# that RGSS itself creates (PlayMusic/PlaySound).
module KerberusLegacy18
  module WinBridge
    module Registry
      ROOTS = {
        0x80000000 => 'HKEY_CLASSES_ROOT', 0x80000001 => 'HKEY_CURRENT_USER',
        0x80000002 => 'HKEY_LOCAL_MACHINE', 0x80000003 => 'HKEY_USERS',
        0x80000005 => 'HKEY_CURRENT_CONFIG'
      }
      REG_NONE = 0
      REG_SZ = 1
      REG_EXPAND_SZ = 2
      REG_BINARY = 3
      REG_DWORD = 4
      REG_MULTI_SZ = 7
      REG_QWORD = 11
      REG_CREATED_NEW_KEY = 1
      REG_OPENED_EXISTING_KEY = 2
      HANDLE_BASE = 0x00B00000
      MAX_HANDLES = 256
      SEED = [['HKEY_CURRENT_USER\\Software\\Enterbrain\\RGSS', 'PlayMusic', REG_DWORD, [1].pack('V')],
              ['HKEY_CURRENT_USER\\Software\\Enterbrain\\RGSS', 'PlaySound', REG_DWORD, [1].pack('V')]]

      @keys = nil
      @handles = {}
      @next = HANDLE_BASE

      def self.reset!
        @keys = nil
        @handles = {}
        @next = HANDLE_BASE
      end

      def self.store_path
        directory = KerberusLegacy18.data_dir
        directory ? File.join(directory, 'registry.dat') : nil
      end

      def self.keys
        return @keys if @keys
        @keys = {}
        path = store_path
        if path && KerberusLegacy18.raw_file?(path)
          loaded = Marshal.load(KerberusLegacy18.raw_read(path))
          @keys = loaded if loaded.is_a?(Hash)
        end
        SEED.each do |seed|
          entry = ensure_key(seed[0])
          entry[:values][seed[1].downcase] ||= [seed[1], seed[2], seed[3]]
        end
        @keys
      end

      def self.persist
        path = store_path
        KerberusLegacy18.raw_write(path, Marshal.dump(@keys), 'wb') if path
      end

      def self.normalize(path)
        path.to_s.tr('/', '\\').gsub(/\\+/, '\\').sub(/\A\\/, '').sub(/\\\z/, '')
      end

      def self.ensure_key(full)
        lower = full.downcase
        entry = @keys[lower]
        return entry if entry
        parent = full.rindex('\\')
        ensure_key(full[0, parent]) if parent
        @keys[lower] = { :name => full, :values => {} }
      end

      # Handle -> full key path (roots are valid handles too).
      def self.path_of(handle)
        handle = handle.to_i & 0xffffffff
        ROOTS[handle] || @handles[handle]
      end

      def self.join(base, subkey)
        sub = normalize(Buffers.c_string(subkey).to_s)
        sub.empty? ? base : base + '\\' + sub
      end

      def self.new_handle(full)
        return nil if @handles.size >= MAX_HANDLES
        handle = @next
        @next += 4
        @handles[handle] = full
        handle
      end

      def self.open(root, subkey, output)
        base = path_of(root)
        return ERROR_INVALID_HANDLE unless base
        full = join(base, subkey)
        entry = keys[full.downcase]
        return ERROR_FILE_NOT_FOUND unless entry
        handle = new_handle(entry[:name])
        return ERROR_NOT_ENOUGH_MEMORY unless handle
        Buffers.put_u32(output, handle, 0)
        ERROR_SUCCESS
      end

      def self.create(root, subkey, output, disposition)
        base = path_of(root)
        return ERROR_INVALID_HANDLE unless base
        full = join(base, subkey)
        existed = !keys[full.downcase].nil?
        entry = ensure_key(full)
        persist unless existed
        handle = new_handle(entry[:name])
        return ERROR_NOT_ENOUGH_MEMORY unless handle
        Buffers.put_u32(output, handle, 0)
        Buffers.put_u32(disposition, existed ? REG_OPENED_EXISTING_KEY : REG_CREATED_NEW_KEY, 0) unless Buffers.null?(disposition)
        ERROR_SUCCESS
      end

      # RegEnumKeyExA: index-th direct subkey (sorted by name), then
      # ERROR_NO_MORE_ITEMS; size_io is the buffer size in, name length out.
      def self.enum_key(handle, index, name_out, size_io)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        prefix = base.downcase + '\\'
        children = []
        keys.each_value do |entry|
          lower = entry[:name].downcase
          next unless lower.length > prefix.length && lower[0, prefix.length] == prefix
          rest = entry[:name][prefix.length..-1]
          children << rest unless rest.index('\\')
        end
        children = children.sort_by { |name| name.downcase }
        return ERROR_NO_MORE_ITEMS if index < 0 || index >= children.length
        name = children[index]
        return ERROR_MORE_DATA if Buffers.u32(size_io, 0) <= name.length
        Buffers.put(name_out, name + "\0", 0)
        Buffers.put_u32(size_io, name.length, 0)
        ERROR_SUCCESS
      end

      def self.close(handle)
        @handles.delete(handle.to_i & 0xffffffff) || ROOTS[handle.to_i & 0xffffffff] ? ERROR_SUCCESS : ERROR_INVALID_HANDLE
      end

      # RegQueryValueExA(key, name, reserved, type*, data*, size*)
      def self.query(handle, name, type_out, data_out, size_io)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        entry = keys[base.downcase]
        return ERROR_FILE_NOT_FOUND unless entry
        value = entry[:values][(Buffers.c_string(name) || '').downcase]
        return ERROR_FILE_NOT_FOUND unless value
        bytes = value[2]
        Buffers.put_u32(type_out, value[1], 0) unless Buffers.null?(type_out)
        return (Buffers.null?(data_out) ? ERROR_SUCCESS : ERROR_INVALID_PARAMETER) if Buffers.null?(size_io)
        capacity = Buffers.u32(size_io, 0)
        Buffers.put_u32(size_io, bytes.length, 0)
        return ERROR_SUCCESS if Buffers.null?(data_out)
        return ERROR_MORE_DATA if capacity < bytes.length
        Buffers.put(data_out, bytes, 0)
        ERROR_SUCCESS
      end

      # RegSetValueExA(key, name, reserved, type, data, size)
      def self.set(handle, name, type, data, size)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        entry = ensure_key(keys[base.downcase] ? keys[base.downcase][:name] : base)
        size = size.to_i
        bytes = if data.is_a?(String)
                  Buffers.need(data, size, false, 'RegSetValueEx')
                  data[0, size]
                elsif Buffers.null?(data)
                  ''
                else
                  Memory.read(data, size)
                end
        if (type == REG_SZ || type == REG_EXPAND_SZ) && (bytes.empty? || bytes[-1, 1] != "\0")
          bytes += "\0"
        end
        label = Buffers.c_string(name) || ''
        entry[:values][label.downcase] = [label, type.to_i, bytes]
        persist
        ERROR_SUCCESS
      end

      def self.delete_value(handle, name)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        entry = keys[base.downcase]
        return ERROR_FILE_NOT_FOUND unless entry && entry[:values].delete((Buffers.c_string(name) || '').downcase)
        persist
        ERROR_SUCCESS
      end

      def self.delete_key(handle, subkey)
        base = path_of(handle)
        return ERROR_INVALID_HANDLE unless base
        full = join(base, subkey).downcase
        return ERROR_FILE_NOT_FOUND unless keys[full]
        return ERROR_ACCESS_DENIED if keys.keys.any? { |key| key.index(full + '\\') == 0 }
        @keys.delete(full)
        persist
        ERROR_SUCCESS
      end
    end
  end
end
