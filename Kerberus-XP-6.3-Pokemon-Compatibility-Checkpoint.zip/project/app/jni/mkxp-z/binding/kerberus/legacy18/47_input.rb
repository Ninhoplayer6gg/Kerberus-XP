# Kerberus WinBridge - unified input.
#
# Touch controls, Android/physical keyboards and gamepads all reach mkxp-z
# as SDL events and update ONE logical state. RGSS Input.press?, the Win32
# key APIs and XInput below all read that same state through the native
# mkxp-z methods captured at boot, so a game gets identical answers no
# matter which API it uses.
module KerberusLegacy18
  module WinBridge
    module InputBridge
      VK_SHIFT = 0x10
      VK_CONTROL = 0x11
      VK_MENU = 0x12
      VK_CAPITAL = 0x14
      VK_NUMLOCK = 0x90
      VK_SCROLL = 0x91

      @async_reported = Array.new(256, -1)
      @bound = false

      def self.reset!
        @async_reported = Array.new(256, -1)
        @bound = false
      end

      # Hot path: GetAsyncKeyState can run thousands of times per second.
      # Native Method objects are resolved once; no allocation per call.
      def self.bind!
        @pressex = KerberusLegacy18.native_method('Input', :pressex?)
        @triggerex = KerberusLegacy18.native_method('Input', :triggerex?)
        @frame_count = KerberusLegacy18.native_method('Graphics', :frame_count)
        @focus = defined?(::KerberusNative) && ::KerberusNative.respond_to?(:focused?) ? ::KerberusNative.method(:focused?) : nil
        @bound = true
      end

      def self.frame
        bind! unless @bound
        @frame_count ? @frame_count.call : 0
      end

      def self.valid_key?(vk)
        vk.is_a?(Integer) && vk >= 0 && vk <= 255
      end

      def self.down?(vk)
        bind! unless @bound
        return false unless @pressex && valid_key?(vk)
        @pressex.call(vk) ? true : false
      end

      def self.triggered?(vk)
        bind! unless @bound
        return false unless @triggerex && valid_key?(vk)
        @triggerex.call(vk) ? true : false
      end

      # GetAsyncKeyState returns a SHORT. On 32-bit RGSS1 it reached Ruby
      # sign-extended: -32768 held, -32767 held and newly pressed, 0 up.
      # (mkxp-z "triggered" implies "held", so a released key is 0.)
      def self.async_key_state(vk)
        bind! unless @bound
        return 0 unless @pressex && vk.is_a?(Integer) && vk >= 0 && vk <= 255
        return 0 if @focus && !@focus.call
        return 0 unless @pressex.call(vk)
        if @triggerex && @triggerex.call(vk)
          now = @frame_count ? @frame_count.call : 0
          if @async_reported[vk] != now
            @async_reported[vk] = now
            return -32767
          end
        end
        -32768
      end

      # GetKeyState: high bit = down (0xFF80 = -128), low bit = toggle.
      # SDL does not expose lock-key toggles to mkxp-z, so toggles are 0.
      def self.key_state(vk)
        down?(vk) ? -128 : 0
      end

      def self.keyboard_state
        bind! unless @bound
        return "\0" * 256 if @pressex.nil? || (@focus && !@focus.call)
        bytes = "\0" * 256
        vk = 1
        while vk < 256
          bytes[vk] = 0x80 if @pressex.call(vk)
          vk += 1
        end
        bytes
      end

      def self.mouse
        x = KerberusLegacy18.native?('Input', :mouse_x) ? KerberusLegacy18.native('Input', :mouse_x).to_i : 0
        y = KerberusLegacy18.native?('Input', :mouse_y) ? KerberusLegacy18.native('Input', :mouse_y).to_i : 0
        [x, y]
      end

      def self.wheel_delta
        KerberusLegacy18.native?('Input', :scroll_v) ? KerberusLegacy18.native('Input', :scroll_v).to_i * 120 : 0
      end

      # ------------------------------------------------------------------
      # US keyboard layout tables (set-1 scan codes)
      # ------------------------------------------------------------------
      SCAN = {}
      [[0x1B, 0x01], [0x08, 0x0E], [0x09, 0x0F], [0x0D, 0x1C], [0x10, 0x2A], [0x11, 0x1D],
       [0x12, 0x38], [0x14, 0x3A], [0x20, 0x39], [0xA0, 0x2A], [0xA1, 0x36], [0xA2, 0x1D],
       [0xA4, 0x38], [0x90, 0x45], [0x91, 0x46], [0x2D, 0x52], [0x2E, 0x53], [0x24, 0x47],
       [0x23, 0x4F], [0x21, 0x49], [0x22, 0x51], [0x26, 0x48], [0x25, 0x4B], [0x27, 0x4D],
       [0x28, 0x50], [0xBA, 0x27], [0xBB, 0x0D], [0xBC, 0x33], [0xBD, 0x0C], [0xBE, 0x34],
       [0xBF, 0x35], [0xC0, 0x29], [0xDB, 0x1A], [0xDC, 0x2B], [0xDD, 0x1B], [0xDE, 0x28],
       [0x6A, 0x37], [0x6B, 0x4E], [0x6D, 0x4A], [0x6E, 0x53], [0x60, 0x52], [0x61, 0x4F],
       [0x62, 0x50], [0x63, 0x51], [0x64, 0x4B], [0x65, 0x4C], [0x66, 0x4D], [0x67, 0x47],
       [0x68, 0x48], [0x69, 0x49], [0x7A, 0x57], [0x7B, 0x58]].each { |pair| SCAN[pair[0]] = pair[1] }
      '1234567890'.split('').each_with_index { |char, index| SCAN[char[0]] = 0x02 + index }
      'QWERTYUIOP'.split('').each_with_index { |char, index| SCAN[char[0]] = 0x10 + index }
      'ASDFGHJKL'.split('').each_with_index { |char, index| SCAN[char[0]] = 0x1E + index }
      'ZXCVBNM'.split('').each_with_index { |char, index| SCAN[char[0]] = 0x2C + index }
      (0...10).each { |index| SCAN[0x70 + index] = 0x3B + index }
      # Scan -> VK prefers the main block (letters, digits, navigation).
      VK_FROM_SCAN = {}
      SCAN.keys.sort.reverse.each { |vk| VK_FROM_SCAN[SCAN[vk]] = vk unless vk >= 0x60 && vk <= 0x6F }
      VK_FROM_SCAN[0x2A] = 0x10
      VK_FROM_SCAN[0x36] = 0x10
      VK_FROM_SCAN[0x1D] = 0x11
      VK_FROM_SCAN[0x38] = 0x12

      UNSHIFTED = { 0x20 => ' ', 0xBA => ';', 0xBB => '=', 0xBC => ',', 0xBD => '-', 0xBE => '.',
                    0xBF => '/', 0xC0 => '`', 0xDB => '[', 0xDC => '\\', 0xDD => ']', 0xDE => "'",
                    0x6A => '*', 0x6B => '+', 0x6D => '-', 0x6E => '.', 0x6F => '/',
                    0x0D => "\r", 0x09 => "\t", 0x08 => "\b", 0x1B => "\e" }
      SHIFTED = { 0xBA => ':', 0xBB => '+', 0xBC => '<', 0xBD => '_', 0xBE => '>', 0xBF => '?',
                  0xC0 => '~', 0xDB => '{', 0xDC => '|', 0xDD => '}', 0xDE => '"' }
      SHIFTED_DIGITS = ')!@#$%^&*('

      def self.map_virtual_key(code, type)
        code = code.to_i
        case type.to_i
        when 0, 4 then SCAN[code] || 0
        when 1, 3 then VK_FROM_SCAN[code & 0xFF] || 0
        when 2
          return code if code >= 0x30 && code <= 0x39
          return code if code >= 0x41 && code <= 0x5A
          return (code - 0x60 + 0x30) if code >= 0x60 && code <= 0x69
          char = UNSHIFTED[code]
          char ? char[0] : 0
        else
          WinBridge.failure(ERROR_INVALID_PARAMETER, 0)
        end
      end

      # Character produced by vk with the given 256-byte keyboard state.
      def self.character(vk, state)
        state = state.is_a?(String) && state.length >= 256 ? state : "\0" * 256
        shift = (state[VK_SHIFT] & 0x80) != 0 || (state[0xA0] & 0x80) != 0 || (state[0xA1] & 0x80) != 0
        ctrl = (state[VK_CONTROL] & 0x80) != 0 || (state[0xA2] & 0x80) != 0 || (state[0xA3] & 0x80) != 0
        alt = (state[VK_MENU] & 0x80) != 0
        caps = (state[VK_CAPITAL] & 0x01) != 0
        numlock = (state[VK_NUMLOCK] & 0x01) != 0
        return nil if alt && !ctrl
        if vk >= 0x41 && vk <= 0x5A
          return (vk - 0x40).chr if ctrl
          upper = shift ^ caps
          return upper ? vk.chr : (vk + 32).chr
        end
        return nil if ctrl && !(vk == 0x0D || vk == 0x08 || vk == 0x1B)
        if vk >= 0x30 && vk <= 0x39
          return shift ? SHIFTED_DIGITS[vk - 0x30, 1] : vk.chr
        end
        if vk >= 0x60 && vk <= 0x69
          return numlock ? (vk - 0x60 + 0x30).chr : nil
        end
        return SHIFTED[vk] if shift && SHIFTED[vk]
        UNSHIFTED[vk]
      end

      # ToUnicode(vk, scan, state[256], buf, cch, flags) -> UTF-16 units written
      def self.to_unicode(vk, state, buffer, capacity)
        char = character(vk.to_i, state)
        return 0 if char.nil? || capacity.to_i < 1
        Buffers.put(buffer, Text.utf8_to_utf16le(char), 0)
        1
      end

      # ToAscii(vk, scan, state[256], WORD* out, flags) -> chars written
      def self.to_ascii(vk, state, buffer)
        char = character(vk.to_i, state)
        return 0 if char.nil?
        Buffers.put(buffer, char + "\0", 0)
        1
      end

      # ------------------------------------------------------------------
      # XInput over mkxp-z Input::Controller (player 0 only)
      # ------------------------------------------------------------------
      # SDL_GameControllerButton index -> XINPUT_GAMEPAD bit
      XINPUT_BUTTONS = [[0, 0x1000], [1, 0x2000], [2, 0x4000], [3, 0x8000], [4, 0x0020],
                        [6, 0x0010], [7, 0x0040], [8, 0x0080], [9, 0x0100], [10, 0x0200],
                        [11, 0x0001], [12, 0x0002], [13, 0x0004], [14, 0x0008]]
      @packet = 0
      @last_pad = nil

      def self.controller_connected?
        KerberusLegacy18.native?('Input::Controller', :connected?) &&
          KerberusLegacy18.native('Input::Controller', :connected?) ? true : false
      end

      def self.axis16(value, invert)
        number = (value.to_f * 32767.0).round
        number = -number if invert
        number = 32767 if number > 32767
        number = -32768 if number < -32768
        number
      end

      def self.xinput_pad
        buttons = 0
        states = KerberusLegacy18.native('Input::Controller', :raw_button_states)
        XINPUT_BUTTONS.each { |pair| buttons |= pair[1] if states[pair[0]] }
        axes = KerberusLegacy18.native('Input::Controller', :raw_axes)
        trigger = lambda { |value| v = (value.to_f * 255.0).round; v < 0 ? 0 : (v > 255 ? 255 : v) }
        [buttons, trigger.call(axes[4] || 0), trigger.call(axes[5] || 0),
         axis16(axes[0] || 0, false), axis16(axes[1] || 0, true),
         axis16(axes[2] || 0, false), axis16(axes[3] || 0, true)]
      end

      def self.xinput_get_state(index, buffer)
        Buffers.need(buffer, 16, true, 'XInputGetState')
        return ERROR_DEVICE_NOT_CONNECTED unless index.to_i == 0 && controller_connected?
        pad = xinput_pad
        @packet += 1 if pad != @last_pad
        @last_pad = pad
        Buffers.put(buffer, [@packet & 0xffffffff, pad[0], pad[1], pad[2], pad[3], pad[4], pad[5], pad[6]].pack('VvCCssss'), 0)
        ERROR_SUCCESS
      end

      def self.xinput_set_state(index, vibration)
        return ERROR_DEVICE_NOT_CONNECTED unless index.to_i == 0 && controller_connected?
        Buffers.need(vibration, 4, false, 'XInputSetState')
        low, high = vibration[0, 4].unpack('vv')
        if defined?(::KerberusNative) && ::KerberusNative.respond_to?(:controller_rumble)
          ::KerberusNative.controller_rumble(low, high, low == 0 && high == 0 ? 0 : 1000)
          ERROR_SUCCESS
        else
          KerberusLegacy18.event('LIMITED', 'xinput!XInputSetState', 'vibracao do controle nao exposta por este build')
          ERROR_SUCCESS
        end
      end

      def self.xinput_capabilities(index, buffer)
        Buffers.need(buffer, 20, true, 'XInputGetCapabilities')
        return ERROR_DEVICE_NOT_CONNECTED unless index.to_i == 0 && controller_connected?
        # Type GAMEPAD, SubType GAMEPAD, flags 0, all buttons, full ranges, rumble.
        Buffers.put(buffer, [1, 1, 0, 0xF3FF, 255, 255, 32767, 32767, 32767, 32767, 65535, 65535].pack('CCvvCCssssvv'), 0)
        ERROR_SUCCESS
      end

      def self.xinput_battery(index, buffer)
        Buffers.need(buffer, 2, true, 'XInputGetBatteryInformation')
        return ERROR_DEVICE_NOT_CONNECTED unless index.to_i == 0 && controller_connected?
        level = KerberusLegacy18.native?('Input::Controller', :power_level) ? KerberusLegacy18.native('Input::Controller', :power_level).to_s : 'UNKNOWN'
        pair = case level
               when 'WIRED' then [1, 3]
               when 'FULL', 'MAX' then [2, 3]
               when 'MEDIUM' then [2, 2]
               when 'LOW' then [2, 1]
               when 'EMPTY' then [2, 0]
               else [0xFF, 0]
               end
        Buffers.put(buffer, pair.pack('CC'), 0)
        ERROR_SUCCESS
      end
    end
  end
end
