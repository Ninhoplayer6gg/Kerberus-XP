# Kerberus WinBridge - single audio strategy.
#
# Every Windows audio path (FMOD through RGSS Linker, Essentials audio.dll
# AudioContext*, MCI, PlaySound) ends here and here only calls the native
# mkxp-z Audio methods captured at boot. One owner per channel means two
# backends can never play the same music at once.
module KerberusLegacy18
  module WinBridge
    module AudioBridge
      CHANNELS = [:bgm, :bgs, :me, :se]
      SEEKABLE = [:bgm, :bgs]
      @state = {}
      @fade_in = nil
      @profile_volume = false

      def self.reset!
        @state = {}
        @fade_in = nil
        @profile_volume = false
      end

      # Uranium/Essentials option menus store BGM/SE volume in $PokemonSystem.
      def self.use_profile_volume!
        @profile_volume = true
      end

      def self.scaled(channel, volume)
        value = volume.to_f
        value = 0.0 if value < 0
        value = 100.0 if value > 100
        if @profile_volume && defined?($PokemonSystem) && $PokemonSystem
          name = (channel == :bgm || channel == :me) ? :bgmvolume : :sevolume
          if $PokemonSystem.respond_to?(name)
            level = ($PokemonSystem.send(name) || 100).to_f
            level = 0.0 if level < 0
            level = 100.0 if level > 100
            value = value * level / 100.0
          end
        end
        value.round
      end

      def self.check_channel(channel)
        raise ArgumentError, 'canal de audio invalido: ' + channel.inspect unless CHANNELS.include?(channel)
      end

      def self.play(channel, name, volume, pitch, position)
        check_channel(channel)
        raise ArgumentError, 'nome de audio deve ser String' unless name.is_a?(String)
        return stop(channel) if name.empty?
        volume = 100 if volume.nil?
        pitch = 100 if pitch.nil?
        position = 0 if position.nil?
        actual = scaled(channel, volume)
        if SEEKABLE.include?(channel)
          KerberusLegacy18.native('Audio', (channel.to_s + '_play').to_sym, name, actual, pitch.to_i, position.to_f)
        else
          if position.to_f != 0
            KerberusLegacy18.event('LIMITED', 'Audio.' + channel.to_s + '_play(position)', 'canal nativo sem seek; tocando do inicio')
          end
          KerberusLegacy18.native('Audio', (channel.to_s + '_play').to_sym, name, actual, pitch.to_i)
        end
        @state[channel] = [name, volume.to_i, pitch.to_i]
        @fade_in = nil if channel == :bgm
        nil
      end

      def self.stop(channel)
        check_channel(channel)
        KerberusLegacy18.native('Audio', (channel.to_s + '_stop').to_sym)
        @state.delete(channel)
        @fade_in = nil if channel == :bgm
        nil
      end

      def self.fade(channel, ms)
        check_channel(channel)
        raise ArgumentError, 'fade invalido: ' + ms.inspect unless ms.is_a?(Numeric) && ms >= 0
        return stop(channel) if channel == :se
        KerberusLegacy18.native('Audio', (channel.to_s + '_fade').to_sym, ms.to_i)
        @state.delete(channel)
        @fade_in = nil if channel == :bgm
        nil
      end

      def self.position(channel)
        channel = :bgm if channel.nil?
        name = (channel.to_s + '_pos').to_sym
        KerberusLegacy18.native?('Audio', name) ? KerberusLegacy18.native('Audio', name) : 0
      end

      def self.info(channel)
        @state[channel]
      end

      def self.playing?(channel)
        !@state[channel].nil?
      end

      # mkxp AudioStream#play with the same file only changes the volume.
      def self.set_volume(channel, value)
        entry = @state[channel]
        return value unless entry
        level = value.to_f
        level = 0 if level < 0
        level = 100 if level > 100
        args = [entry[0], scaled(channel, level), entry[2]]
        args << position(channel).to_f if SEEKABLE.include?(channel)
        KerberusLegacy18.native('Audio', (channel.to_s + '_play').to_sym, *args)
        entry[1] = level.to_i
        value
      end

      def self.fade_in(ms)
        raise ArgumentError, 'fade invalido: ' + ms.inspect unless ms.is_a?(Numeric) && ms >= 0
        entry = @state[:bgm]
        return nil unless entry
        target = entry[1]
        return set_volume(:bgm, target) if ms == 0
        set_volume(:bgm, 0)
        entry[1] = target
        @fade_in = [KerberusLegacy18.uptime_ms, ms.to_f, target]
        nil
      end

      def self.fading_in?
        !@fade_in.nil?
      end

      # Called by the frame hook.
      def self.tick
        return unless @fade_in
        start, duration, target = @fade_in
        entry = @state[:bgm]
        if entry.nil?
          @fade_in = nil
          return
        end
        progress = (KerberusLegacy18.uptime_ms - start) / duration
        progress = 1.0 if progress > 1.0
        set_volume(:bgm, (target * progress).round)
        entry[1] = target
        @fade_in = nil if progress >= 1.0
      end

      # ------------------------------------------------------------------
      # winmm!PlaySoundA(sound, module, flags)
      # ------------------------------------------------------------------
      SND_ASYNC = 0x0001
      SND_LOOP = 0x0008
      SND_PURGE = 0x0040
      SND_ALIAS = 0x00010000
      SND_FILENAME = 0x00020000
      SND_RESOURCE = 0x00040004

      def self.play_sound(sound, flags)
        flags = flags.to_i
        name = Buffers.c_string(sound)
        if name.nil? || (flags & SND_PURGE) != 0
          stop(:se)
          stop(:bgs) if playing?(:bgs) && @state[:bgs][3] == :play_sound
          return 1
        end
        if (flags & SND_RESOURCE) == SND_RESOURCE || ((flags & SND_ALIAS) != 0 && (flags & SND_FILENAME) == 0)
          return WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
        end
        path = Paths.resolve(name.tr('\\', '/'), false)
        if (flags & SND_LOOP) != 0
          play(:bgs, path, 100, 100, 0)
          @state[:bgs][3] = :play_sound
        else
          play(:se, path, 100, 100, 0)
        end
        1
      end

      # ------------------------------------------------------------------
      # winmm!mciSendStringA - audio subset mapped to native channels
      # ------------------------------------------------------------------
      module MCI
        MCIERR_INVALID_DEVICE_ID = 257
        MCIERR_UNRECOGNIZED_COMMAND = 261
        MCIERR_UNSUPPORTED_FUNCTION = 274
        MCIERR_INVALID_DEVICE_NAME = 263
        MCIERR_FILE_NOT_FOUND = 275
        MESSAGES = {
          0 => 'The specified command was carried out.',
          257 => 'Invalid device ID.', 261 => 'Unknown command.',
          263 => 'The specified device is not open or is not recognized by MCI.',
          274 => 'The MCI device the system is using does not support the specified command.',
          275 => 'Cannot find the specified file.'
        }
        # "mpegvideo" is also the usual MCI device for MP3/OGG music, so the
        # file extension decides; only "avivideo" is always a video device.
        VIDEO_EXTENSIONS = /\.(avi|wmv|mpg|mpeg|mp4|mov|mkv)\z/i
        @devices = {}

        def self.reset!
          @devices = {}
        end

        def self.tokens(command)
          command.to_s.scan(/"[^"]*"|\S+/).map { |token| token[0, 1] == '"' ? token[1, token.length - 2] : token }
        end

        def self.reply(buffer, capacity, text)
          return if Buffers.null?(buffer) || capacity.to_i <= 0
          Buffers.copy_c_string(buffer, capacity.to_i, text)
        end

        def self.send_string(command, buffer, capacity)
          words = tokens(command)
          return MCIERR_UNRECOGNIZED_COMMAND if words.empty?
          verb = words.shift.downcase
          case verb
          when 'open' then open(words)
          when 'play' then play(words)
          when 'stop', 'pause' then stop(words)
          when 'resume' then resume(words)
          when 'close' then close(words)
          when 'setaudio' then set_audio(words)
          when 'status' then status(words, buffer, capacity)
          when 'seek' then seek(words)
          else
            KerberusLegacy18.event('LIMITED', 'winmm!mciSendString', 'comando MCI nao suportado: ' + verb)
            MCIERR_UNSUPPORTED_FUNCTION
          end
        end

        def self.open(words)
          file = words.shift
          return MCIERR_UNRECOGNIZED_COMMAND unless file
          type = nil
          alias_name = file
          while (word = words.shift)
            case word.downcase
            when 'type' then type = (words.shift || '').downcase
            when 'alias' then alias_name = words.shift || alias_name
            end
          end
          if type == 'avivideo' || file =~ VIDEO_EXTENSIONS
            KerberusLegacy18.event('LIMITED', 'winmm!mciSendString', 'video MCI (' + file.to_s + ') indisponivel; use Graphics.play_movie com OGV')
            return MCIERR_UNSUPPORTED_FUNCTION
          end
          path = Paths.resolve(file.tr('\\', '/'), false)
          return MCIERR_FILE_NOT_FOUND unless KerberusLegacy18.raw_file?(path)
          @devices[alias_name.downcase] = { :path => path, :channel => nil, :volume => 100, :mode => 'stopped' }
          0
        end

        def self.device(words)
          name = words.shift
          name && @devices[name.downcase]
        end

        def self.play(words)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          repeat = words.map { |word| word.downcase }.include?('repeat')
          # Looping MCI music is background music; one-shots are ME.
          channel = repeat ? :bgm : :me
          AudioBridge.play(channel, entry[:path], entry[:volume], 100, 0)
          entry[:channel] = channel
          entry[:mode] = 'playing'
          0
        end

        def self.stop(words)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          owned = entry[:channel] && AudioBridge.info(entry[:channel]) &&
                  AudioBridge.info(entry[:channel])[0] == entry[:path]
          AudioBridge.stop(entry[:channel]) if owned
          entry[:mode] = 'stopped'
          0
        end

        def self.resume(words)
          entry = device(words.dup)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          return 0 if entry[:mode] == 'playing'
          play(words + (entry[:channel] == :bgm ? ['repeat'] : []))
        end

        def self.close(words)
          name = words.first
          if name && name.downcase == 'all'
            @devices.keys.each { |key| stop([key]) }
            @devices.clear
            return 0
          end
          result = stop(words.dup)
          @devices.delete(name.downcase) if name
          result
        end

        def self.set_audio(words)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          index = words.map { |word| word.downcase }.index('volume')
          return MCIERR_UNSUPPORTED_FUNCTION unless index
          value = words[index + 1].to_s.downcase == 'to' ? words[index + 2] : words[index + 1]
          entry[:volume] = (value.to_i / 10.0).round
          AudioBridge.set_volume(entry[:channel], entry[:volume]) if entry[:channel] && AudioBridge.playing?(entry[:channel])
          0
        end

        def self.status(words, buffer, capacity)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          case (words.first || '').downcase
          when 'mode'
            playing = entry[:channel] && AudioBridge.playing?(entry[:channel])
            reply(buffer, capacity, playing && entry[:mode] == 'playing' ? 'playing' : 'stopped')
          when 'position'
            reply(buffer, capacity, entry[:channel] ? (AudioBridge.position(entry[:channel]).to_f * 1000).to_i.to_s : '0')
          else
            return MCIERR_UNSUPPORTED_FUNCTION
          end
          0
        end

        def self.seek(words)
          entry = device(words)
          return MCIERR_INVALID_DEVICE_NAME unless entry
          MCIERR_UNSUPPORTED_FUNCTION
        end

        def self.error_string(code, buffer, capacity)
          text = MESSAGES[code.to_i] || ('MCI error ' + code.to_i.to_s)
          return 0 if capacity.to_i <= 0
          Buffers.copy_c_string(buffer, capacity.to_i, text)
          1
        end
      end
    end
  end
end
