# Kerberus WinBridge - virtual window, locale and handle tables shared by
# several providers. Only locale/region, never personal data, is exposed.
module KerberusLegacy18
  module WinBridge
    module Window
      HWND = 1
      DESKTOP = 0x00010010
      DC = 0x0DC00001
      WS_POPUP_VISIBLE = 0x90000000
      @capture = 0
      @cursor = 0
      @styles = {}

      def self.reset!
        @capture = 0
        @cursor = 0
        @styles = {}
      end

      def self.handle?(value)
        value.to_i == HWND
      end

      def self.width
        KerberusLegacy18.native?('Graphics', :width) ? KerberusLegacy18.native('Graphics', :width) : 640
      end

      def self.height
        KerberusLegacy18.native?('Graphics', :height) ? KerberusLegacy18.native('Graphics', :height) : 480
      end

      def self.rect_bytes
        [0, 0, width, height].pack('l4')
      end

      def self.title
        if KerberusLegacy18.native?('System', :window_title)
          text = KerberusLegacy18.native('System', :window_title).to_s
          return text unless text.empty?
        end
        KerberusLegacy18.native?('System', :game_title) ? KerberusLegacy18.native('System', :game_title).to_s : ''
      end

      def self.captured
        @capture
      end

      def self.capture(value)
        previous = @capture
        @capture = value
        previous
      end

      def self.show_cursor(show)
        @cursor += (show.nil? || show == 0 || show == false) ? -1 : 1
        @cursor
      end

      def self.style(index)
        @styles[index.to_i] || (index.to_i == -16 ? WS_POPUP_VISIBLE : 0)
      end

      def self.set_style(index, value)
        previous = style(index)
        @styles[index.to_i] = value.to_i & 0xffffffff
        previous
      end

      def self.metric(index)
        case index.to_i
        when 0, 16, 61, 78 then width
        when 1, 17, 62, 79 then height
        when 19 then 1          # SM_MOUSEPRESENT (touch acts as mouse)
        when 43 then 3          # SM_CMOUSEBUTTONS
        when 80 then 1          # SM_CMONITORS
        when 4, 5, 6, 7, 8, 15, 23, 32, 33, 45, 46, 76, 77, 0x1000 then 0
        else
          KerberusLegacy18.event('LIMITED', 'user32!GetSystemMetrics(' + index.to_i.to_s + ')', 'metrica sem equivalente; 0 como no Windows para indice desconhecido')
          0
        end
      end
    end

    module Locale
      PRIMARY = { 'ar' => 0x01, 'bg' => 0x02, 'ca' => 0x03, 'zh' => 0x04, 'cs' => 0x05, 'da' => 0x06,
                  'de' => 0x07, 'el' => 0x08, 'en' => 0x09, 'es' => 0x0A, 'fi' => 0x0B, 'fr' => 0x0C,
                  'he' => 0x0D, 'hu' => 0x0E, 'is' => 0x0F, 'it' => 0x10, 'ja' => 0x11, 'ko' => 0x12,
                  'nl' => 0x13, 'nb' => 0x14, 'no' => 0x14, 'pl' => 0x15, 'pt' => 0x16, 'ro' => 0x18,
                  'ru' => 0x19, 'hr' => 0x1A, 'sk' => 0x1B, 'sv' => 0x1D, 'th' => 0x1E, 'tr' => 0x1F,
                  'id' => 0x21, 'uk' => 0x22, 'vi' => 0x2A }
      SPECIFIC = { 'en_US' => 0x0409, 'en_GB' => 0x0809, 'en_AU' => 0x0C09, 'en_CA' => 0x1009,
                   'pt_BR' => 0x0416, 'pt_PT' => 0x0816, 'es_ES' => 0x0C0A, 'es_MX' => 0x080A,
                   'es_AR' => 0x2C0A, 'es_US' => 0x540A, 'es_CL' => 0x340A, 'es_CO' => 0x240A,
                   'fr_FR' => 0x040C, 'fr_CA' => 0x0C0C, 'de_DE' => 0x0407, 'de_AT' => 0x0C07,
                   'de_CH' => 0x0807, 'it_IT' => 0x0410, 'ja_JP' => 0x0411, 'ko_KR' => 0x0412,
                   'zh_CN' => 0x0804, 'zh_TW' => 0x0404, 'zh_HK' => 0x0C04, 'ru_RU' => 0x0419,
                   'nl_NL' => 0x0413, 'pl_PL' => 0x0415, 'tr_TR' => 0x041F }
      GEO = { 'US' => 244, 'GB' => 242, 'BR' => 32, 'PT' => 193, 'ES' => 217, 'MX' => 166,
              'AR' => 11, 'FR' => 84, 'DE' => 94, 'IT' => 118, 'JP' => 122, 'KR' => 134,
              'CN' => 45, 'TW' => 237, 'RU' => 203, 'CA' => 39, 'AU' => 12, 'NL' => 176,
              'PL' => 191, 'TR' => 235, 'CL' => 46, 'CO' => 51, 'PE' => 187 }
      ANSI = { 'ja' => 932, 'ko' => 949, 'ru' => 1251, 'uk' => 1251, 'bg' => 1251,
               'pl' => 1250, 'cs' => 1250, 'hu' => 1250, 'sk' => 1250, 'hr' => 1250, 'ro' => 1250,
               'el' => 1253, 'tr' => 1254, 'he' => 1255, 'ar' => 1256, 'vi' => 1258, 'th' => 874 }

      def self.tag
        raw = KerberusLegacy18.native?('System', :user_language) ? KerberusLegacy18.native('System', :user_language).to_s : ''
        raw = 'en_US' if raw.empty?
        parts = raw.tr('-', '_').split(/[_.@]/)
        language = parts[0].to_s.downcase
        region = parts[1].to_s.upcase
        region.empty? ? language : language + '_' + region
      end

      def self.language
        tag.split('_')[0].to_s
      end

      def self.region
        tag.split('_')[1].to_s
      end

      def self.langid
        SPECIFIC[tag] || (PRIMARY[language] ? (0x0400 | PRIMARY[language]) : 0x0409)
      end

      def self.geoid
        GEO[region]
      end

      def self.ansi_codepage
        return 936 if tag == 'zh_CN'
        return 950 if language == 'zh'
        ANSI[language] || 1252
      end
    end

    # Virtual process environment: no Android variable (paths, user data)
    # is exposed. SetEnvironmentVariable changes only this table.
    module Env
      DEFAULTS = { 'USERNAME' => 'Player', 'COMPUTERNAME' => 'KERBERUS', 'OS' => 'Windows_NT' }
      @table = DEFAULTS.dup

      def self.reset!
        @table = DEFAULTS.dup
      end

      def self.get(name)
        @table[name.to_s.upcase]
      end

      def self.set(name, value)
        key = name.to_s.upcase
        value.nil? ? @table.delete(key) : @table[key] = value.to_s
      end
    end

    # Virtual kernel handles (files, find handles, console, modules).
    module Handles
      BASE = 0x00C00000
      @table = {}
      @next = BASE

      def self.reset!
        @table.values.each { |entry| entry[1].close if entry[0] == :file && !entry[1].closed? }
        @table = {}
        @next = BASE
      end

      def self.add(kind, object, writable = false)
        raise KerberusLegacy18::Error, 'tabela de handles virtuais cheia' if @table.size >= 512
        handle = @next
        @next += 4
        @table[handle] = [kind, object, writable]
        handle
      end

      def self.writable?(handle)
        entry = @table[handle.to_i & 0xffffffff]
        entry ? entry[2] : false
      end

      def self.get(handle, kind)
        entry = @table[handle.to_i & 0xffffffff]
        entry && (kind.nil? || entry[0] == kind) ? entry[1] : nil
      end

      def self.kind(handle)
        entry = @table[handle.to_i & 0xffffffff]
        entry ? entry[0] : nil
      end

      def self.close(handle)
        entry = @table.delete(handle.to_i & 0xffffffff)
        return false unless entry
        entry[1].close if entry[0] == :file && !entry[1].closed?
        true
      end
    end

    # Console APIs write to the Kerberus log instead of a Windows console.
    module Console
      STD_INPUT = 0x00C0FF10
      STD_OUTPUT = 0x00C0FF14
      STD_ERROR = 0x00C0FF18
      @allocated = false

      def self.reset!
        @allocated = false
      end

      def self.handle?(value)
        [STD_INPUT, STD_OUTPUT, STD_ERROR].include?(value.to_i & 0xffffffff) || Handles.kind(value) == :console
      end

      def self.alloc
        return WinBridge.failure(ERROR_ACCESS_DENIED, 0) if @allocated
        @allocated = true
        WinBridge.success(1)
      end

      def self.free
        @allocated = false
        1
      end

      def self.write(text)
        text.to_s.split(/\r?\n/).each do |line|
          System.puts('[console] ' + line) if defined?(System) && System.respond_to?(:puts)
        end
        text.to_s.length
      end
    end

    # Windows path argument -> Android path through the Windows-like layer.
    def self.native_path(value, create)
      text = Buffers.c_string(value)
      return nil if text.nil? || text.empty?
      unix = text.tr('\\', '/')
      return nil if unix =~ /\A[A-Za-z]:/
      Paths.resolve(unix, create)
    end

    def self.windows_path(path)
      File.expand_path(path.to_s).tr('/', '\\')
    end
  end
end
