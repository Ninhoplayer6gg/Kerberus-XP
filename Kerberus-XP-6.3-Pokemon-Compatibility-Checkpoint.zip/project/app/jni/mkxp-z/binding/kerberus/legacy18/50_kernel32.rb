# Kerberus WinBridge providers - kernel32 (and ntdll memory helpers).
module KerberusLegacy18
  module WinBridge
    SYSTEM_MESSAGES = {
      0 => 'The operation completed successfully.', 2 => 'The system cannot find the file specified.',
      3 => 'The system cannot find the path specified.', 5 => 'Access is denied.',
      6 => 'The handle is invalid.', 8 => 'Not enough memory resources are available to process this command.',
      87 => 'The parameter is incorrect.', 120 => 'This function is not supported on this system.',
      122 => 'The data area passed to a system call is too small.',
      126 => 'The specified module could not be found.', 127 => 'The specified procedure could not be found.',
      183 => 'Cannot create a file when that file already exists.', 234 => 'More data is available.',
      1167 => 'The device is not connected.'
    }
    INVALID_HANDLE = 0xffffffff
    VIRTUAL_MODULE_BASE = 0x10000000
    GAME_MODULE = 0x00400000

    def self.module_handle(name)
      return GAME_MODULE if name.nil?
      lib = library(name)
      return GAME_MODULE if lib == KerberusLegacy18.config[:exec_name].downcase || lib == 'game' || lib =~ /\.exe\z/
      return nil unless provides_library?(lib)
      VIRTUAL_MODULE_BASE + (lib.hash & 0x0FFF) * 0x10000
    end

    def self.filetime(time)
      value = (time.to_i + 11644473600) * 10000000
      Buffers.pack_u64(value)
    end

    def self.file_attributes(path)
      return nil unless path && File.exist?(path)
      File.directory?(path) ? 0x10 : 0x20
    end

    k = 'kernel32'

    # --- clocks -----------------------------------------------------------
    provide(k, 'GetTickCount', :native, 'CLOCK_BOOTTIME em ms (32 bits, reinicia como no Windows)', 0) { |a| KerberusLegacy18.uptime_ms & 0xffffffff }
    provide(k, 'GetTickCount64', :native, 'CLOCK_BOOTTIME em ms', 0) { |a| KerberusLegacy18.uptime_ms }
    provide(k, 'QueryPerformanceCounter', :native, 'CLOCK_BOOTTIME em ns', 1) do |a|
      Buffers.put(a[0], Buffers.pack_u64(KerberusLegacy18.monotonic_ns), 0)
      1
    end
    provide(k, 'QueryPerformanceFrequency', :native, '1 GHz (contador em ns)', 1) do |a|
      Buffers.put(a[0], Buffers.pack_u64(1000000000), 0)
      1
    end
    provide(k, 'Sleep', :native, 'suspende a thread Ruby como o Sleep do Windows', 1) do |a|
      ms = a[0].to_i & 0xffffffff
      if ms == 0xffffffff
        raise Unavailable, 'kernel32!Sleep(INFINITE) bloquearia o jogo para sempre'
      end
      ms == 0 ? Thread.pass : sleep(ms / 1000.0)
      0
    end

    # --- process / thread / errors ----------------------------------------
    provide(k, 'GetCurrentThreadId', :native, 'gettid do Android', 0) { |a| KerberusLegacy18.thread_id }
    provide(k, 'GetCurrentProcessId', :native, 'getpid do Android', 0) { |a| Process.pid }
    provide(k, 'GetCurrentProcess', :native, 'pseudo-handle -1 documentado', 0) { |a| -1 }
    provide(k, 'GetCurrentThread', :native, 'pseudo-handle -2 documentado', 0) { |a| -2 }
    provide(k, 'GetLastError', :native, 'ultimo erro definido pelos providers', 0) { |a| WinBridge.last_error }
    provide(k, 'SetLastError', :native, 'define o ultimo erro', 1) { |a| WinBridge.last_error = a[0]; 0 }
    provide(k, 'IsDebuggerPresent', :native, 'sem depurador', 0) { |a| 0 }
    provide(k, 'OutputDebugStringA', :native, 'texto enviado ao log do Kerberus', 1) do |a|
      KerberusLegacy18.event('DEBUG_STRING', Buffers.c_string(a[0]).to_s[0, 120], '')
      0
    end
    provide(k, 'FormatMessageA', :native, 'tabela de mensagens de sistema comuns; demais codigos falham como no Windows', 5) do |a|
      flags = a[0].to_i
      code = a[2].to_i & 0xffffffff
      text = (flags & 0x1000) != 0 ? SYSTEM_MESSAGES[code] : nil
      if text.nil?
        WinBridge.failure(317, 0)
      else
        text += "\r\n"
        if (flags & 0x100) != 0
          Buffers.put_u32(a[4], Memory.alloc(text + "\0"), 0)
        else
          capacity = a[5].to_i
          next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if capacity <= text.length
          Buffers.put(a[4], text + "\0", 0)
        end
        WinBridge.success(text.length)
      end
    end

    # --- INI ----------------------------------------------------------------
    provide(k, 'GetPrivateProfileStringA', :native, 'parser INI nativo (regras do Windows)', 6) { |a| Ini.read_string(a[0], a[1], a[2], a[3], a[4], a[5]) }
    provide(k, 'GetPrivateProfileIntA', :native, 'parser INI nativo', 4) { |a| Ini.read_int(a[0], a[1], a[2], a[3]) }
    provide(k, 'GetPrivateProfileSectionA', :native, 'parser INI nativo', 4) { |a| Ini.read_section(a[0], a[1], a[2], a[3]) }
    provide(k, 'GetPrivateProfileSectionNamesA', :native, 'parser INI nativo', 3) do |a|
      Ini.write_list(a[0], a[1].to_i, Ini.section_names(Ini.load(Ini.path_for(a[2]))))
    end
    provide(k, 'WritePrivateProfileStringA', :native, 'escrita INI preservando o arquivo', 4) { |a| Ini.write_string(a[0], a[1], a[2], a[3]) }
    provide(k, 'GetProfileStringA', :native, 'win.ini virtual do jogo', 5) { |a| Ini.read_string(a[0], a[1], a[2], a[3], a[4], 'win.ini') }
    provide(k, 'GetProfileIntA', :native, 'win.ini virtual do jogo', 3) { |a| Ini.read_int(a[0], a[1], a[2], 'win.ini') }
    provide(k, 'WriteProfileStringA', :native, 'win.ini virtual do jogo', 3) { |a| Ini.write_string(a[0], a[1], a[2], 'win.ini') }

    # --- memory (Ruby buffers and the virtual heap only) --------------------
    move = lambda do |a|
      length = a[2].to_i
      next 0 if length == 0
      Memory.write(a[0], Memory.read(a[1], length))
      0
    end
    provide(k, 'RtlMoveMemory', :native, 'copia entre buffers Ruby/heap virtual; enderecos reais rejeitados', 3, &move)
    provide('ntdll', 'RtlMoveMemory', :native, 'copia entre buffers Ruby/heap virtual; enderecos reais rejeitados', 3, &move)
    provide(k, 'RtlZeroMemory', :native, 'zera buffer Ruby/heap virtual', 2) { |a| Memory.write(a[0], "\0" * a[1].to_i); 0 }
    provide(k, 'RtlFillMemory', :native, 'preenche buffer Ruby/heap virtual', 3) { |a| Memory.write(a[0], (a[2].to_i & 0xff).chr * a[1].to_i); 0 }
    provide(k, 'lstrlenA', :native, 'strlen em buffer Ruby/heap virtual', 1) { |a| (Buffers.c_string(a[0]) || '').length }
    provide(k, 'lstrlenW', :native, 'wcslen em buffer Ruby/heap virtual', 1) do |a|
      next 0 if Buffers.null?(a[0])
      if a[0].is_a?(Integer)
        block, offset = Memory.fetch(a[0], 'lstrlenW')
        Text.until_wide_nul(block[offset, block.length - offset] || '').length / 2
      else
        Text.until_wide_nul(a[0].to_s).length / 2
      end
    end
    alloc = lambda do |a|
      size = a[1].to_i
      next WinBridge.failure(ERROR_NOT_ENOUGH_MEMORY, 0) if size < 0 || size > Memory::STEP
      WinBridge.success(Memory.alloc("\0" * size))
    end
    free = lambda { |a| Memory.free(a[0]) ? WinBridge.success(0) : WinBridge.failure(ERROR_INVALID_HANDLE, a[0]) }
    provide(k, 'GlobalAlloc', :native, 'heap virtual (ate 64 KiB por bloco)', 2, &alloc)
    provide(k, 'LocalAlloc', :native, 'heap virtual (ate 64 KiB por bloco)', 2, &alloc)
    provide(k, 'GlobalFree', :native, 'heap virtual', 1, &free)
    provide(k, 'LocalFree', :native, 'heap virtual', 1, &free)
    provide(k, 'GlobalLock', :native, 'bloco fixo do heap virtual', 1) { |a| Memory.owns?(a[0]) ? a[0] : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'GlobalUnlock', :native, 'bloco fixo do heap virtual', 1) { |a| WinBridge.success(0) }
    provide(k, 'GetProcessHeap', :native, 'heap virtual unico', 0) { |a| 0x00150000 }
    provide(k, 'HeapAlloc', :native, 'heap virtual', 3) { |a| alloc.call([0, a[2]]) }
    provide(k, 'HeapFree', :native, 'heap virtual', 3) { |a| Memory.free(a[2]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }

    # --- text conversion ------------------------------------------------------
    provide(k, 'MultiByteToWideChar', :native, 'UTF-8 (65001) e Windows-1252 (ACP) sem Encoding', 6) do |a|
      codepage = a[0].to_i
      length = a[3].to_i
      source = length < 0 ? Buffers.c_string(a[2]).to_s + "\0" : Memory.read(a[2], length)
      text = codepage == 65001 ? source : Text.cp1252_to_utf8(source)
      wide = Text.utf8_to_utf16le(text)
      units = wide.length / 2
      next WinBridge.success(units) if a[5].to_i == 0
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if a[5].to_i < units
      Memory.write(a[4], wide)
      WinBridge.success(units)
    end
    provide(k, 'WideCharToMultiByte', :native, 'UTF-16LE para UTF-8 (65001) ou Windows-1252', 6) do |a|
      codepage = a[0].to_i
      units = a[3].to_i
      bytes = units < 0 ? Text.utf8_to_utf16le(Buffers.wide_string(a[2]).to_s) + "\0\0" : Memory.read(a[2], units * 2)
      text = Text.utf16le_to_utf8(bytes)
      used = false
      if codepage != 65001
        default_char = Buffers.null?(a[6]) ? '?' : Buffers.c_string(a[6]).to_s[0, 1]
        text, used = Text.utf8_to_cp1252(text, default_char.empty? ? '?' : default_char)
      end
      Buffers.put_u32(a[7], used ? 1 : 0, 0) if a.length > 7 && !Buffers.null?(a[7])
      next WinBridge.success(text.length) if a[5].to_i == 0
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if a[5].to_i < text.length
      Memory.write(a[4], text)
      WinBridge.success(text.length)
    end

    # --- modules --------------------------------------------------------------
    provide(k, 'GetModuleHandleA', :native, 'modulo do jogo e DLLs com provider Kerberus', 1) do |a|
      handle = WinBridge.module_handle(Buffers.c_string(a[0]))
      handle ? WinBridge.success(handle) : WinBridge.failure(ERROR_MOD_NOT_FOUND, 0)
    end
    load_library = lambda do |a|
      name = Buffers.c_string(a[0]).to_s
      handle = WinBridge.module_handle(name)
      if handle
        WinBridge.success(handle)
      else
        KerberusLegacy18.event('LOADLIBRARY_MISSING', WinBridge.library(name), 'DLL sem provider/port; retornando NULL como um Windows sem a DLL')
        WinBridge.failure(ERROR_MOD_NOT_FOUND, 0)
      end
    end
    provide(k, 'LoadLibraryA', :native, 'sucesso apenas para DLLs com provider/port; demais = ERROR_MOD_NOT_FOUND', 1, &load_library)
    provide(k, 'LoadLibraryExA', :native, 'sucesso apenas para DLLs com provider/port', 1, &load_library)
    provide(k, 'FreeLibrary', :native, 'modulos virtuais', 1) { |a| a[0].to_i != 0 ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'GetProcAddress', :native, 'endereco virtual somente para funcoes com provider', 2) do |a|
      name = Buffers.c_string(a[1]).to_s
      found = WinBridge.providers.values.any? { |table| (table[name] || table[name + 'A']) && (table[name] || table[name + 'A']).kind != :unavailable }
      found ? WinBridge.success(0x20000000 + (name.hash & 0xFFFFFF)) : WinBridge.failure(ERROR_PROC_NOT_FOUND, 0)
    end
    provide(k, 'GetModuleFileNameA', :native, 'caminho real do jogo com separadores Windows', 3) do |a|
      path = WinBridge.windows_path(File.join(Dir.pwd, KerberusLegacy18.config[:exec_name] + '.exe'))
      capacity = a[2].to_i
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if capacity <= 0
      copied = Buffers.copy_c_string(a[1], capacity, path)
      copied < path.length ? WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, capacity) : WinBridge.success(copied)
    end

    # --- locale -----------------------------------------------------------------
    [['GetUserDefaultLangID', 0], ['GetSystemDefaultLangID', 0], ['GetUserDefaultUILanguage', 0],
     ['GetSystemDefaultUILanguage', 0], ['GetUserDefaultLCID', 0], ['GetSystemDefaultLCID', 0],
     ['GetThreadLocale', 0]].each do |pair|
      provide(k, pair[0], :native, 'idioma do Android convertido para LANGID', pair[1]) { |a| Locale.langid }
    end
    provide(k, 'GetUserGeoID', :native, 'regiao do Android convertida para GEOID', 1) do |a|
      geo = Locale.geoid
      if geo
        geo
      else
        KerberusLegacy18.event('LIMITED', 'kernel32!GetUserGeoID', 'regiao ' + Locale.region.inspect + ' sem tabela; GEOID_NOT_AVAILABLE')
        -1
      end
    end
    provide(k, 'GetACP', :native, 'code page ANSI do idioma do Android', 0) { |a| Locale.ansi_codepage }
    provide(k, 'GetOEMCP', :native, 'code page OEM', 0) { |a| Locale.language == 'ja' ? 932 : 437 }
    provide(k, 'GetLocaleInfoA', :limited, 'somente LOCALE_SISO639LANGNAME/SISO3166CTRYNAME/IDEFAULTANSICODEPAGE', 4) do |a|
      text = case a[1].to_i & 0xffff
             when 0x59 then Locale.language
             when 0x5A then Locale.region
             when 0x1004 then Locale.ansi_codepage.to_s
             end
      if text.nil?
        WinBridge.failure(1004, 0)
      elsif a[3].to_i == 0
        WinBridge.success(text.length + 1)
      elsif a[3].to_i <= text.length
        WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0)
      else
        Buffers.put(a[2], text + "\0", 0)
        WinBridge.success(text.length + 1)
      end
    end

    # --- system information -------------------------------------------------------
    provide(k, 'GetSystemPowerStatus', :native, 'bateria via SDL_GetPowerInfo', 1) do |a|
      Buffers.need(a[0], 12, true, 'SYSTEM_POWER_STATUS')
      state = KerberusLegacy18.native?('System', :power_state) ? KerberusLegacy18.native('System', :power_state) : {}
      percent = state[:percent]
      discharging = state[:discharging] ? true : false
      seconds = state[:seconds]
      ac = discharging ? 0 : (percent.nil? ? 255 : 1)
      flag = if percent.nil? then 128
             elsif percent > 66 then 1
             elsif percent < 5 then 4
             elsif percent < 33 then 2
             else 0
             end
      flag |= 8 if !discharging && !percent.nil? && percent < 100
      Buffers.put(a[0], [ac, flag, percent.nil? ? 255 : percent, 0, seconds.nil? ? 0xffffffff : seconds, 0xffffffff].pack('CCCCVV'), 0)
      1
    end
    memory_status = lambda do
      total = KerberusLegacy18.native?('System', :memory) ? KerberusLegacy18.native('System', :memory).to_i * 1024 * 1024 : 0
      available = total
      begin
        text = KerberusLegacy18.raw_read('/proc/meminfo')
        available = $1.to_i * 1024 if text =~ /^MemAvailable:\s+(\d+)/
      rescue SystemCallError, IOError
      end
      [total, available]
    end
    provide(k, 'GlobalMemoryStatusEx', :native, 'memoria total do SDL e MemAvailable do Linux', 1) do |a|
      Buffers.need(a[0], 64, true, 'MEMORYSTATUSEX')
      total, available = memory_status.call
      load = total > 0 ? 100 - (available * 100 / total) : 0
      virtual = 0x7FFE0000
      Buffers.put(a[0], [64, load].pack('VV') + Buffers.pack_u64(total) + Buffers.pack_u64(available) +
                        Buffers.pack_u64(total) + Buffers.pack_u64(available) + Buffers.pack_u64(virtual) +
                        Buffers.pack_u64(virtual) + Buffers.pack_u64(0), 0)
      1
    end
    provide(k, 'GlobalMemoryStatus', :native, 'memoria total do SDL e MemAvailable do Linux (limitada a 4 GiB)', 1) do |a|
      Buffers.need(a[0], 32, true, 'MEMORYSTATUS')
      total, available = memory_status.call
      cap = lambda { |value| value > 0xffffffff ? 0xffffffff : value }
      load = total > 0 ? 100 - (available * 100 / total) : 0
      Buffers.put(a[0], [32, load, cap.call(total), cap.call(available), cap.call(total), cap.call(available), 0x7FFE0000, 0x7FFE0000].pack('V8'), 0)
      0
    end
    system_info = lambda do |a|
      Buffers.need(a[0], 36, true, 'SYSTEM_INFO')
      cpus = KerberusLegacy18.native?('System', :nproc) ? KerberusLegacy18.native('System', :nproc).to_i : 1
      mask = cpus >= 32 ? 0xffffffff : (1 << cpus) - 1
      # A 32-bit RGSS player sees an x86 machine (PROCESSOR_ARCHITECTURE_INTEL).
      Buffers.put(a[0], [0, 0, 4096, 0x10000, 0x7FFEFFFF, mask, cpus, 586, 0x10000, 6, 0].pack('vvVVVVVVVvv'), 0)
      0
    end
    provide(k, 'GetSystemInfo', :limited, 'CPUs reais; arquitetura x86 como um RGSS 32 bits', 1, &system_info)
    provide(k, 'GetNativeSystemInfo', :limited, 'CPUs reais; arquitetura x86 como um RGSS 32 bits', 1, &system_info)
    provide(k, 'GetVersion', :limited, 'Windows 8 (6.2.9200), como o Windows 10 reporta a um jogo sem manifesto', 0) { |a| (9200 << 16) | (2 << 8) | 6 }
    provide(k, 'GetVersionExA', :limited, 'Windows 8 (6.2.9200), como o Windows 10 reporta a um jogo sem manifesto', 1) do |a|
      size = Buffers.u32(a[0], 0)
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) unless size == 148 || size == 156
      Buffers.need(a[0], size, true, 'OSVERSIONINFO')
      data = [size, 6, 2, 9200, 2].pack('V5') + "\0" * 128
      data += [0, 0, 0, 1, 0].pack('vvvCC') if size == 156
      Buffers.put(a[0], data, 0)
      1
    end
    provide(k, 'GetComputerNameA', :native, 'nome virtual KERBERUS (nenhum dado pessoal)', 2) do |a|
      name = 'KERBERUS'
      capacity = Buffers.u32(a[1], 0)
      if capacity <= name.length
        Buffers.put_u32(a[1], name.length + 1, 0)
        next WinBridge.failure(111, 0)
      end
      Buffers.put(a[0], name + "\0", 0)
      Buffers.put_u32(a[1], name.length, 0)
      1
    end
    provide(k, 'GetEnvironmentVariableA', :limited, 'ambiente virtual minimo; demais variaveis ausentes', 3) do |a|
      name = Buffers.c_string(a[0]).to_s.upcase
      value = { 'USERNAME' => 'Player', 'COMPUTERNAME' => 'KERBERUS', 'OS' => 'Windows_NT' }[name]
      if value.nil?
        WinBridge.failure(ERROR_ENVVAR_NOT_FOUND, 0)
      elsif a[2].to_i <= value.length
        WinBridge.success(value.length + 1)
      else
        Buffers.put(a[1], value + "\0", 0)
        WinBridge.success(value.length)
      end
    end

    # --- directories ---------------------------------------------------------------
    provide(k, 'GetCurrentDirectoryA', :native, 'Dir.pwd com separadores Windows', 2) do |a|
      path = WinBridge.windows_path(Dir.pwd)
      next WinBridge.success(path.length + 1) if a[0].to_i <= path.length
      Buffers.put(a[1], path + "\0", 0)
      WinBridge.success(path.length)
    end
    provide(k, 'SetCurrentDirectoryA', :native, 'Dir.chdir com resolucao estilo Windows', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      if path && File.directory?(path)
        Dir.chdir(path)
        WinBridge.success(1)
      else
        WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      end
    end
    directory_provider = lambda do |subdir|
      lambda do |a|
        path = WinBridge.windows_path(KerberusLegacy18.data_dir(subdir) || Dir.pwd)
        next WinBridge.success(path.length + 1) if a[1].to_i <= path.length
        Buffers.put(a[0], path + "\0", 0)
        WinBridge.success(path.length)
      end
    end
    provide(k, 'GetWindowsDirectoryA', :native, 'pasta Windows virtual por jogo (fora da pasta do jogo)', 2, &directory_provider.call('Windows'))
    provide(k, 'GetSystemDirectoryA', :native, 'pasta System32 virtual por jogo', 2, &directory_provider.call('Windows'))
    provide(k, 'GetTempPathA', :native, 'pasta temporaria virtual por jogo', 2) do |a|
      path = WinBridge.windows_path(KerberusLegacy18.data_dir('Temp') || Dir.pwd) + '\\'
      next WinBridge.success(path.length + 1) if a[0].to_i <= path.length
      Buffers.put(a[1], path + "\0", 0)
      WinBridge.success(path.length)
    end

    # --- files -------------------------------------------------------------------------
    provide(k, 'GetFileAttributesA', :native, 'atributos a partir do sistema de arquivos Android', 1) do |a|
      attributes = WinBridge.file_attributes(WinBridge.native_path(a[0], false))
      attributes ? WinBridge.success(attributes) : WinBridge.failure(ERROR_FILE_NOT_FOUND, -1)
    end
    provide(k, 'SetFileAttributesA', :limited, 'atributos Windows nao existem no Android; arquivo verificado', 2) do |a|
      WinBridge.file_attributes(WinBridge.native_path(a[0], false)) ? 1 : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(k, 'CreateDirectoryA', :native, 'Dir.mkdir com resolucao estilo Windows', 2) do |a|
      path = WinBridge.native_path(a[0], true)
      if path.nil? || !File.directory?(File.dirname(path))
        WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      elsif File.exist?(path)
        WinBridge.failure(ERROR_ALREADY_EXISTS, 0)
      else
        Dir.mkdir(path)
        WinBridge.success(1)
      end
    end
    provide(k, 'RemoveDirectoryA', :native, 'Dir.rmdir', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      begin
        path && File.directory?(path) ? (Dir.rmdir(path); WinBridge.success(1)) : WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      rescue SystemCallError
        WinBridge.failure(145, 0)
      end
    end
    provide(k, 'DeleteFileA', :native, 'File.delete', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      path && File.file?(path) ? (File.delete(path); WinBridge.success(1)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(k, 'CopyFileA', :native, 'copia binaria', 3) do |a|
      source = WinBridge.native_path(a[0], false)
      target = WinBridge.native_path(a[1], true)
      if source.nil? || !File.file?(source)
        WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
      elsif target.nil? || !File.directory?(File.dirname(target))
        WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      elsif a[2].to_i != 0 && File.exist?(target)
        WinBridge.failure(80, 0)
      else
        data = File.open(source, 'rb') { |file| file.read }
        File.open(target, 'wb') { |file| file.write(data) }
        WinBridge.success(1)
      end
    end
    move_file = lambda do |a|
      source = WinBridge.native_path(a[0], false)
      target = WinBridge.native_path(a[1], true)
      replace = a.length > 2 && (a[2].to_i & 1) != 0
      if source.nil? || !File.exist?(source)
        WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
      elsif target.nil?
        WinBridge.failure(ERROR_PATH_NOT_FOUND, 0)
      elsif File.exist?(target) && !replace
        WinBridge.failure(ERROR_ALREADY_EXISTS, 0)
      else
        File.rename(source, target)
        WinBridge.success(1)
      end
    end
    provide(k, 'MoveFileA', :native, 'File.rename', 2, &move_file)
    provide(k, 'MoveFileExA', :native, 'File.rename (MOVEFILE_REPLACE_EXISTING suportado)', 3, &move_file)

    provide(k, 'CreateFileA', :native, 'arquivos do jogo via File; console via log', 7) do |a|
      name = Buffers.c_string(a[0]).to_s
      if %w(con conout$ conin$).include?(name.downcase)
        next WinBridge.success(Handles.add(:console, name))
      end
      access = a[1].to_i & 0xffffffff
      disposition = a[4].to_i
      path = WinBridge.native_path(a[0], true)
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, INVALID_HANDLE) if path.nil? || !File.directory?(File.dirname(path))
      exists = File.file?(path)
      write = (access & 0x40000000) != 0 || (access & 0x10000000) != 0
      mode = nil
      case disposition
      when 1 then next WinBridge.failure(80, INVALID_HANDLE) if exists
                  mode = 'w+b'
      when 2 then mode = 'w+b'
      when 3 then next WinBridge.failure(ERROR_FILE_NOT_FOUND, INVALID_HANDLE) unless exists
                  mode = write ? 'r+b' : 'rb'
      when 4 then mode = exists ? (write ? 'r+b' : 'rb') : 'w+b'
      when 5 then next WinBridge.failure(ERROR_FILE_NOT_FOUND, INVALID_HANDLE) unless exists
                  mode = 'w+b'
      else next WinBridge.failure(ERROR_INVALID_PARAMETER, INVALID_HANDLE)
      end
      file = File.open(path, mode)
      Milestones.save_candidate(path) if mode != 'rb'
      WinBridge.failure(exists && (disposition == 2 || disposition == 4) ? ERROR_ALREADY_EXISTS : ERROR_SUCCESS,
                        Handles.add(:file, file, mode != 'rb'))
    end
    provide(k, 'ReadFile', :native, 'leitura binaria', 5) do |a|
      file = Handles.get(a[0], :file)
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless file
      data = file.read(a[2].to_i) || ''
      Buffers.put(a[1], data, 0) unless data.empty?
      Buffers.put_u32(a[3], data.length, 0) unless Buffers.null?(a[3])
      WinBridge.success(1)
    end
    provide(k, 'WriteFile', :native, 'escrita binaria; console vai para o log', 5) do |a|
      length = a[2].to_i
      data = Memory.read(a[1], length)
      if Console.handle?(a[0])
        Console.write(data)
      else
        file = Handles.get(a[0], :file)
        next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless file
        file.write(data)
      end
      Buffers.put_u32(a[3], length, 0) unless Buffers.null?(a[3])
      WinBridge.success(1)
    end
    provide(k, 'FlushFileBuffers', :native, 'IO#flush', 1) do |a|
      file = Handles.get(a[0], :file)
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless file
      next WinBridge.failure(ERROR_ACCESS_DENIED, 0) unless Handles.writable?(a[0])
      file.flush
      1
    end
    provide(k, 'GetFileSize', :native, 'tamanho do arquivo', 2) do |a|
      file = Handles.get(a[0], :file)
      next WinBridge.failure(ERROR_INVALID_HANDLE, -1) unless file
      file.flush if Handles.writable?(a[0])
      size = file.stat.size
      Buffers.put_u32(a[1], size >> 32, 0) unless Buffers.null?(a[1])
      size & 0xffffffff
    end
    provide(k, 'SetFilePointer', :native, 'seek (FILE_BEGIN/CURRENT/END)', 4) do |a|
      file = Handles.get(a[0], :file)
      next WinBridge.failure(ERROR_INVALID_HANDLE, -1) unless file
      distance = a[1].to_i & 0xffffffff
      distance -= 0x100000000 if distance >= 0x80000000
      whence = [IO::SEEK_SET, IO::SEEK_CUR, IO::SEEK_END][a[3].to_i]
      next WinBridge.failure(ERROR_INVALID_PARAMETER, -1) unless whence
      file.seek(distance, whence)
      file.pos & 0xffffffff
    end
    provide(k, 'CloseHandle', :native, 'handles virtuais', 1) do |a|
      Handles.close(a[0]) || Console.handle?(a[0]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_HANDLE, 0)
    end

    find_data = lambda do |directory, name|
      path = File.join(directory, name)
      stat = File.exist?(path) ? File.stat(path) : nil
      size = stat && stat.file? ? stat.size : 0
      time = stat ? WinBridge.filetime(stat.mtime) : "\0" * 8
      [stat && stat.directory? ? 0x10 : 0x20].pack('V') + time + time + time +
        [size >> 32, size & 0xffffffff, 0, 0].pack('V4') + (name[0, 259] + "\0").ljust(260, "\0") + "\0" * 16
    end
    provide(k, 'FindFirstFileA', :native, 'Dir com curinga sem diferenciar maiusculas', 2) do |a|
      pattern = Buffers.c_string(a[0]).to_s.tr('\\', '/')
      slash = pattern.rindex('/')
      directory = slash ? Paths.resolve(pattern[0, slash], false) : '.'
      mask = slash ? pattern[slash + 1, pattern.length] : pattern
      mask = '*' if mask == '*.*'
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, INVALID_HANDLE) unless File.directory?(directory)
      names = Dir.entries(directory).select { |entry| File.fnmatch(mask, entry, File::FNM_CASEFOLD | File::FNM_DOTMATCH) }
      next WinBridge.failure(ERROR_FILE_NOT_FOUND, INVALID_HANDLE) if names.empty?
      Buffers.put(a[1], find_data.call(directory, names.shift), 0)
      WinBridge.success(Handles.add(:find, [directory, names]))
    end
    provide(k, 'FindNextFileA', :native, 'Dir com curinga', 2) do |a|
      state = Handles.get(a[0], :find)
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless state
      next WinBridge.failure(18, 0) if state[1].empty?
      Buffers.put(a[1], find_data.call(state[0], state[1].shift), 0)
      WinBridge.success(1)
    end
    provide(k, 'FindClose', :native, 'handle de busca virtual', 1) { |a| Handles.close(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }

    # --- console ------------------------------------------------------------------------
    provide(k, 'AllocConsole', :native, 'console virtual escrito no log do Kerberus', 0) { |a| Console.alloc }
    provide(k, 'FreeConsole', :native, 'console virtual', 0) { |a| Console.free }
    provide(k, 'AttachConsole', :limited, 'sem console de processo pai no Android', 1) { |a| WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'GetConsoleWindow', :native, 'console virtual sem janela', 0) { |a| 0 }
    provide(k, 'GetStdHandle', :native, 'handles do console virtual', 1) do |a|
      case a[0].to_i & 0xffffffff
      when 0xFFFFFFF6 then Console::STD_INPUT
      when 0xFFFFFFF5 then Console::STD_OUTPUT
      when 0xFFFFFFF4 then Console::STD_ERROR
      else WinBridge.failure(ERROR_INVALID_HANDLE, -1)
      end
    end
    write_console = lambda do |wide|
      lambda do |a|
        next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless Console.handle?(a[0])
        count = a[2].to_i
        text = wide ? Text.utf16le_to_utf8(Memory.read(a[1], count * 2)) : Memory.read(a[1], count)
        Console.write(text)
        Buffers.put_u32(a[3], count, 0) unless Buffers.null?(a[3])
        WinBridge.success(1)
      end
    end
    provide(k, 'WriteConsoleA', :native, 'texto do console vai para o log', 4, &write_console.call(false))
    provide(k, 'WriteConsoleW', :native, 'texto do console vai para o log', 4, &write_console.call(true))
    provide(k, 'ReadConsoleA', :limited, 'sem entrada de console no Android', 4) { |a| WinBridge.failure(ERROR_CALL_NOT_IMPLEMENTED, 0) }
    provide(k, 'SetConsoleTitleA', :native, 'titulo registrado no log', 1) { |a| KerberusLegacy18.event('CONSOLE', 'title', Buffers.c_string(a[0]).to_s); 1 }
    provide(k, 'SetConsoleTextAttribute', :native, 'cores sem efeito em log de texto', 2) { |a| Console.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'CreateConsoleScreenBuffer', :native, 'buffer de console virtual', 5) { |a| WinBridge.success(Handles.add(:console, 'buffer')) }
    provide(k, 'SetConsoleActiveScreenBuffer', :native, 'buffer de console virtual', 1) { |a| Console.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(k, 'SetConsoleScreenBufferSize', :native, 'buffer de console virtual', 2) { |a| Console.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
  end
end
