# Kerberus WinBridge providers - user32 over SDL/mkxp-z.
#
# There is one logical top-level window (HWND 1) whose client area is the
# RGSS resolution. Screen, window and client coordinates are the same space,
# which is exactly what an undecorated fullscreen RGSS window reports.
module KerberusLegacy18
  module WinBridge
    u = 'user32'

    provide(u, 'GetAsyncKeyState', :native, 'estado SDL ao vivo (toque/teclado/controle/mouse); SHORT com sinal como no RGSS1', 1) { |a| InputBridge.async_key_state(a[0].to_i) }
    provide(u, 'GetKeyState', :native, 'estado SDL ao vivo; bits de toggle nao expostos pelo SDL', 1) { |a| InputBridge.key_state(a[0].to_i) }
    provide(u, 'GetKeyboardState', :native, '256 estados SDL ao vivo; bits de toggle 0', 1) do |a|
      Buffers.put(a[0], InputBridge.keyboard_state, 0)
      1
    end
    provide(u, 'MapVirtualKeyA', :native, 'tabela de scan codes US', 2) { |a| InputBridge.map_virtual_key(a[0], a[1]) }
    provide(u, 'MapVirtualKeyExA', :native, 'tabela de scan codes US', 2) { |a| InputBridge.map_virtual_key(a[0], a[1]) }
    provide(u, 'ToUnicode', :native, 'layout US com Shift/Ctrl/CapsLock do estado informado', 5) { |a| InputBridge.to_unicode(a[0], a[2], a[3], a[4]) }
    provide(u, 'ToUnicodeEx', :native, 'layout US com Shift/Ctrl/CapsLock do estado informado', 5) { |a| InputBridge.to_unicode(a[0], a[2], a[3], a[4]) }
    provide(u, 'ToAscii', :native, 'layout US com Shift/Ctrl/CapsLock do estado informado', 4) { |a| InputBridge.to_ascii(a[0], a[2], a[3]) }
    provide(u, 'ToAsciiEx', :native, 'layout US com Shift/Ctrl/CapsLock do estado informado', 4) { |a| InputBridge.to_ascii(a[0], a[2], a[3]) }
    provide(u, 'GetKeyboardLayout', :native, 'HKL US, coerente com ToUnicode', 1) { |a| 0x04090409 }
    provide(u, 'keybd_event', :limited, 'teclas sinteticas nao sao injetadas; Alt+Enter/fullscreen ja e gerenciado pelo Android', 4) do |a|
      KerberusLegacy18.event('LIMITED', 'user32!keybd_event', 'vk=' + a[0].to_i.to_s + ' ignorado (sem retorno no Windows)')
      0
    end
    provide(u, 'SendInput', :limited, 'eventos sinteticos nao sao injetados', 3) { |a| WinBridge.failure(ERROR_ACCESS_DENIED, 0) }

    provide(u, 'GetCursorPos', :native, 'mouse/toque SDL ao vivo em coordenadas do jogo', 1) do |a|
      Buffers.put(a[0], InputBridge.mouse.pack('l2'), 0)
      1
    end
    provide(u, 'SetCursorPos', :limited, 'Android nao permite mover o ponteiro de toque', 2) { |a| WinBridge.failure(ERROR_CALL_NOT_IMPLEMENTED, 0) }
    point_identity = lambda do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0]) || a[0].to_i == Window::DESKTOP || a[0].to_i == 0
      Buffers.need(a[1], 8, true, 'POINT')
      1
    end
    provide(u, 'ScreenToClient', :native, 'tela e cliente coincidem na janela logica', 2, &point_identity)
    provide(u, 'ClientToScreen', :native, 'tela e cliente coincidem na janela logica', 2, &point_identity)
    provide(u, 'ShowCursor', :native, 'contador de exibicao do cursor', 1) { |a| Window.show_cursor(a[0]) }
    provide(u, 'ClipCursor', :limited, 'sem cursor de hardware no Android; confinamento vazio', 1) { |a| 1 }
    provide(u, 'SetCapture', :native, 'captura logica da janela', 1) { |a| Window.handle?(a[0]) ? Window.capture(Window::HWND) : 0 }
    provide(u, 'ReleaseCapture', :native, 'captura logica da janela', 0) { |a| Window.capture(0); 1 }
    provide(u, 'GetCapture', :native, 'captura logica da janela', 0) { |a| Window.captured }
    provide(u, 'GetDoubleClickTime', :native, '500 ms, padrao do Windows', 0) { |a| 500 }

    rect = lambda do |a|
      Buffers.need(a[1], 16, true, 'RECT')
      if Window.handle?(a[0]) || a[0].to_i == Window::DESKTOP
        Buffers.put(a[1], Window.rect_bytes, 0)
        1
      else
        WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0)
      end
    end
    provide(u, 'GetClientRect', :native, 'resolucao logica do RGSS', 2, &rect)
    provide(u, 'GetWindowRect', :native, 'janela logica sem bordas', 2, &rect)
    provide(u, 'GetSystemMetrics', :native, 'desktop virtual = resolucao do jogo; bordas 0', 1) { |a| Window.metric(a[0]) }
    provide(u, 'AdjustWindowRect', :native, 'janela sem bordas: retangulo inalterado', 3) { |a| Buffers.need(a[0], 16, true, 'RECT'); 1 }
    provide(u, 'AdjustWindowRectEx', :native, 'janela sem bordas: retangulo inalterado', 4) { |a| Buffers.need(a[0], 16, true, 'RECT'); 1 }

    find_window = lambda do |klass, title|
      klass = Buffers.c_string(klass)
      title = Buffers.c_string(title)
      class_ok = klass.nil? || klass.empty? || klass == 'RGSS Player'
      title_ok = title.nil? || title.empty? || title == Window.title
      class_ok && title_ok ? WinBridge.success(Window::HWND) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(u, 'FindWindowA', :native, 'janela logica "RGSS Player"', 2) { |a| find_window.call(a[0], a[1]) }
    provide(u, 'FindWindowExA', :native, 'janela logica "RGSS Player"', 4) do |a|
      Buffers.null?(a[0]) && Buffers.null?(a[1]) ? find_window.call(a[2], a[3]) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    focus_window = lambda { |a| KerberusLegacy18.focused? ? Window::HWND : 0 }
    provide(u, 'GetActiveWindow', :native, 'janela logica quando o app tem foco', 0, &focus_window)
    provide(u, 'GetForegroundWindow', :native, 'janela logica quando o app tem foco', 0, &focus_window)
    provide(u, 'GetFocus', :native, 'janela logica quando o app tem foco', 0, &focus_window)
    provide(u, 'GetDesktopWindow', :native, 'desktop virtual', 0) { |a| Window::DESKTOP }
    provide(u, 'GetWindowThreadProcessId', :native, 'thread dona da janela e pid Android', 2) do |a|
      next 0 unless Window.handle?(a[0])
      Buffers.put_u32(a[1], Process.pid, 0) unless Buffers.null?(a[1])
      KerberusLegacy18.thread_id
    end
    provide(u, 'IsWindow', :native, 'janela logica', 1) { |a| Window.handle?(a[0]) || a[0].to_i == Window::DESKTOP ? 1 : 0 }
    provide(u, 'IsWindowVisible', :native, 'janela logica sempre visivel', 1) { |a| Window.handle?(a[0]) ? 1 : 0 }
    provide(u, 'IsIconic', :native, 'janela logica nunca minimizada', 1) { |a| 0 }
    provide(u, 'IsZoomed', :native, 'janela logica em tela cheia', 1) { |a| Window.handle?(a[0]) ? 1 : 0 }
    provide(u, 'SetWindowTextA', :native, 'titulo da janela SDL', 2) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      KerberusLegacy18.native('System', :set_window_title, Buffers.c_string(a[1]).to_s) if KerberusLegacy18.native?('System', :set_window_title)
      1
    end
    provide(u, 'GetWindowTextA', :native, 'titulo da janela SDL', 3) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      Buffers.copy_c_string(a[1], a[2].to_i, Window.title)
    end
    provide(u, 'GetWindowTextLengthA', :native, 'titulo da janela SDL', 1) { |a| Window.handle?(a[0]) ? Window.title.length : 0 }
    provide(u, 'GetClassNameA', :native, 'classe RGSS Player', 3) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      Buffers.copy_c_string(a[1], a[2].to_i, 'RGSS Player')
    end
    provide(u, 'GetWindowLongA', :native, 'estilos da janela logica', 2) { |a| Window.handle?(a[0]) ? Window.style(a[1]) : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) }
    geometry = 'superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada'
    provide(u, 'SetWindowLongA', :limited, geometry, 3) { |a| Window.handle?(a[0]) ? Window.set_style(a[1], a[2]) : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) }
    [['SetWindowPos', 7], ['MoveWindow', 6], ['ShowWindow', 2], ['SetForegroundWindow', 1],
     ['BringWindowToTop', 1], ['UpdateWindow', 1], ['InvalidateRect', 3], ['SetActiveWindow', 1],
     ['SetFocus', 1]].each do |pair|
      provide(u, pair[0], :limited, geometry, pair[1]) do |a|
        Window.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0)
      end
    end
    provide(u, 'GetDC', :native, 'DC virtual do jogo', 1) { |a| Window::DC }
    provide(u, 'GetWindowDC', :native, 'DC virtual do jogo', 1) { |a| Window::DC }
    provide(u, 'ReleaseDC', :native, 'DC virtual do jogo', 2) { |a| a[1].to_i == Window::DC ? 1 : 0 }

    provide(u, 'PeekMessageA', :native, 'fila Win32 vazia: eventos pertencem ao SDL', 5) { |a| 0 }
    provide(u, 'GetMessageA', :unavailable, 'bloquearia o jogo: a fila Win32 nao recebe eventos no Android', 4)
    message = lambda do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      msg = a[1].to_i
      if msg == 0x10 || (msg == 0x112 && (a[2].to_i & 0xFFF0) == 0xF060)
        KerberusLegacy18.event('WINDOW_CLOSE', 'user32 message', 'WM_CLOSE/SC_CLOSE para a janela do jogo: encerrando como no Windows', true)
        exit
      end
      KerberusLegacy18.event('LIMITED', 'user32 message 0x' + msg.to_s(16), 'mensagem Win32 sem efeito no Android')
      0
    end
    provide(u, 'SendMessageA', :limited, 'WM_CLOSE encerra o jogo; demais mensagens sem efeito', 4, &message)
    provide(u, 'PostMessageA', :limited, 'WM_CLOSE encerra o jogo; demais mensagens sem efeito', 4, &message)
    provide(u, 'RegisterHotKey', :limited, 'atalhos globais indisponiveis no Android', 4) { |a| WinBridge.failure(1409, 0) }
    provide(u, 'UnregisterHotKey', :limited, 'atalhos globais indisponiveis no Android', 2) { |a| WinBridge.failure(1419, 0) }
    provide(u, 'SystemParametersInfoA', :limited, 'parametros de desktop nao expostos', 4) { |a| WinBridge.failure(ERROR_CALL_NOT_IMPLEMENTED, 0) }
    provide(u, 'MessageBoxA', :limited, 'mensagem RGSS nativa; botoes Sim/Nao retornam a opcao segura', 4) do |a|
      text = Buffers.c_string(a[1]).to_s
      caption = Buffers.c_string(a[2]).to_s
      type = a[3].to_i & 0x0F
      KerberusLegacy18.native('Kernel', :print, caption.empty? ? text : caption + "\n\n" + text) if KerberusLegacy18.native?('Kernel', :print)
      answer = { 0 => 1, 1 => 2, 2 => 5, 3 => 2, 4 => 7, 5 => 2, 6 => 2 }[type] || 1
      KerberusLegacy18.event('LIMITED', 'user32!MessageBoxA', 'tipo ' + type.to_s + ' respondido com ' + answer.to_s) if type != 0
      answer
    end
  end
end
