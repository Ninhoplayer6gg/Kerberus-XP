# Kerberus WinBridge providers - advapi32 (virtual registry) and shell32.
module KerberusLegacy18
  module WinBridge
    r = 'advapi32'
    provide(r, 'RegOpenKeyExA', :native, 'registro virtual persistente por jogo', 5) { |a| Registry.open(a[0], a[1], a[4]) }
    provide(r, 'RegOpenKeyA', :native, 'registro virtual persistente por jogo', 3) { |a| Registry.open(a[0], a[1], a[2]) }
    provide(r, 'RegCreateKeyExA', :native, 'registro virtual persistente por jogo', 9) { |a| Registry.create(a[0], a[1], a[7], a[8]) }
    provide(r, 'RegCreateKeyA', :native, 'registro virtual persistente por jogo', 3) { |a| Registry.create(a[0], a[1], a[2], 0) }
    provide(r, 'RegQueryValueExA', :native, 'registro virtual persistente por jogo', 6) { |a| Registry.query(a[0], a[1], a[3], a[4], a[5]) }
    provide(r, 'RegSetValueExA', :native, 'registro virtual persistente por jogo', 6) { |a| Registry.set(a[0], a[1], a[3].to_i, a[4], a[5]) }
    provide(r, 'RegDeleteValueA', :native, 'registro virtual persistente por jogo', 2) { |a| Registry.delete_value(a[0], a[1]) }
    provide(r, 'RegDeleteKeyA', :native, 'registro virtual persistente por jogo', 2) { |a| Registry.delete_key(a[0], a[1]) }
    provide(r, 'RegCloseKey', :native, 'registro virtual persistente por jogo', 1) { |a| Registry.close(a[0]) }
    provide(r, 'RegFlushKey', :native, 'registro virtual persistido a cada escrita', 1) { |a| Registry.path_of(a[0]) ? 0 : ERROR_INVALID_HANDLE }
    provide(r, 'GetUserNameA', :native, 'nome virtual Player; nenhum dado pessoal do aparelho', 2) do |a|
      name = 'Player'
      capacity = Buffers.u32(a[1], 0)
      Buffers.put_u32(a[1], name.length + 1, 0)
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if capacity <= name.length
      Buffers.put(a[0], name + "\0", 0)
      1
    end

    s = 'shell32'
    # Known folders deliberately fail like on a system without that folder:
    # Essentials then keeps using its existing fallback (the game folder),
    # so saves made by earlier Kerberus versions stay where they are.
    saves = 'pasta especial indisponivel; o jogo usa o proprio fallback e os saves existentes continuam no mesmo lugar'
    provide(s, 'SHGetKnownFolderPath', :limited, saves, 4) do |a|
      Buffers.put_u32(a[3], 0, 0) unless Buffers.null?(a[3])
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0x80070002)
    end
    provide(s, 'SHGetSpecialFolderLocation', :limited, saves, 3) do |a|
      Buffers.put_u32(a[2], 0, 0) unless Buffers.null?(a[2])
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0x80004005)
    end
    provide(s, 'SHGetFolderPathA', :limited, saves, 5) do |a|
      Buffers.put(a[4], "\0", 0) unless Buffers.null?(a[4])
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0x80004005)
    end
    provide(s, 'SHGetSpecialFolderPathA', :limited, saves, 4) do |a|
      Buffers.put(a[1], "\0", 0) unless Buffers.null?(a[1])
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(s, 'SHGetPathFromIDListA', :native, 'nenhum PIDL e emitido; PIDL nulo falha como no Windows', 2) do |a|
      Buffers.put(a[1], "\0", 0) unless Buffers.null?(a[1])
      WinBridge.failure(ERROR_INVALID_PARAMETER, 0)
    end
    provide(s, 'ShellExecuteA', :limited, 'abrir programas/URLs externos indisponivel', 6) do |a|
      KerberusLegacy18.event('LIMITED', 'shell32!ShellExecuteA', Buffers.c_string(a[2]).to_s[0, 120])
      2
    end
    provide('ole32', 'CoTaskMemFree', :native, 'libera bloco do heap virtual', 1) { |a| Memory.free(a[0]); 0 }
    provide('ole32', 'CoTaskMemAlloc', :native, 'heap virtual', 1) do |a|
      size = a[0].to_i
      size < 0 || size > Memory::STEP ? 0 : Memory.alloc("\0" * size)
    end
    @com_initialized = false
    co_init = lambda do |a|
      result = @com_initialized ? 1 : 0
      @com_initialized = true
      result
    end
    provide('ole32', 'CoInitialize', :native, 'apartamento COM logico (S_OK/S_FALSE)', 1, &co_init)
    provide('ole32', 'CoInitializeEx', :native, 'apartamento COM logico (S_OK/S_FALSE)', 2, &co_init)
    provide('ole32', 'CoUninitialize', :native, 'apartamento COM logico', 0) { |a| @com_initialized = false; 0 }
    provide('ole32', 'CoCreateGuid', :native, 'GUID aleatorio versao 4', 1) do |a|
      bytes = Array.new(16) { rand(256) }
      bytes[7] = (bytes[7] & 0x0F) | 0x40
      bytes[8] = (bytes[8] & 0x3F) | 0x80
      Buffers.put(a[0], bytes.pack('C*'), 0)
      0
    end
    provide('ole32', 'CoCreateInstance', :unavailable, 'objetos COM do Windows nao existem no Android', 5)
  end
end
