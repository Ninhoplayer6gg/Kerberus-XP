# Kerberus WinBridge providers - winmm, gdi32, msvcrt, xinput, ws2_32 and
# fangame DLLs. Network and DLLs without a port report documented failures
# or precise WINBRIDGE_UNAVAILABLE errors, never fake success.
module KerberusLegacy18
  module WinBridge
    m = 'winmm'
    provide(m, 'timeGetTime', :native, 'CLOCK_BOOTTIME em ms (32 bits)', 0) { |a| KerberusLegacy18.uptime_ms & 0xffffffff }
    provide(m, 'timeBeginPeriod', :native, 'timers do Android ja tem resolucao de 1 ms (TIMERR_NOERROR)', 1) { |a| 0 }
    provide(m, 'timeEndPeriod', :native, 'timers do Android ja tem resolucao de 1 ms (TIMERR_NOERROR)', 1) { |a| 0 }
    provide(m, 'timeGetDevCaps', :native, 'periodo minimo 1 ms', 2) { |a| Buffers.put(a[0], [1, 1000000].pack('VV'), 0); 0 }
    provide(m, 'PlaySoundA', :native, 'arquivos via Audio nativo (SE ou BGS em loop)', 3) { |a| AudioBridge.play_sound(a[0], a[2]) }
    provide(m, 'sndPlaySoundA', :native, 'arquivos via Audio nativo', 2) { |a| AudioBridge.play_sound(a[0], (a[1].to_i & 0x0009) | AudioBridge::SND_FILENAME) }
    provide(m, 'mciSendStringA', :limited, 'open/play/stop/pause/resume/close/setaudio/status sobre canais nativos; video indisponivel', 4) do |a|
      AudioBridge::MCI.send_string(Buffers.c_string(a[0]), a[1], a[2])
    end
    provide(m, 'mciGetErrorStringA', :native, 'tabela de mensagens MCI', 3) { |a| AudioBridge::MCI.error_string(a[0], a[1], a[2]) }
    provide(m, 'waveOutGetNumDevs', :limited, 'nenhum dispositivo waveOut: o jogo deve usar o Audio nativo', 0) { |a| 0 }
    %w(waveOutOpen waveOutClose waveOutPrepareHeader waveOutUnprepareHeader waveOutWrite
       waveOutSetVolume waveOutGetVolume waveOutReset waveOutPause waveOutRestart
       midiOutOpen midiOutClose midiOutShortMsg midiOutGetNumDevs auxSetVolume auxGetVolume).each do |name|
      provide(m, name, :limited, 'saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED)', nil) do |a|
        name == 'midiOutGetNumDevs' ? 0 : 8
      end
    end

    g = 'gdi32'
    provide(g, 'AddFontResourceA', :native, 'fontes em Fonts/ ja sao carregadas pelo mkxp-z; outras pastas nao', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      if path.nil? || !File.file?(path)
        WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
      elsif File.expand_path(path).index(File.expand_path('Fonts') + '/') == 0
        1
      else
        KerberusLegacy18.event('LIMITED', 'gdi32!AddFontResourceA', File.basename(path) + ' fora de Fonts/ nao e registrada no mkxp-z')
        0
      end
    end
    provide(g, 'AddFontResourceExA', :native, 'fontes em Fonts/ ja sao carregadas pelo mkxp-z', 3) do |a|
      WinBridge.lookup('gdi32', 'AddFontResourceA').impl.call([a[0]])
    end
    provide(g, 'RemoveFontResourceA', :native, 'fonte continua indexada pelo mkxp-z', 1) { |a| WinBridge.native_path(a[0], false) ? 1 : 0 }
    provide(g, 'GetDeviceCaps', :native, 'DC virtual: 96 DPI, 32 bpp, resolucao do jogo', 2) do |a|
      case a[1].to_i
      when 8 then Window.width
      when 10 then Window.height
      when 12 then 32
      when 14 then 1
      when 88, 90 then 96
      when 116 then 60
      else 0
      end
    end
    provide(g, 'DeleteObject', :native, 'objetos GDI virtuais', 1) { |a| a[0].to_i != 0 ? 1 : 0 }
    %w(CreateFontA CreateFontIndirectA SelectObject GetTextExtentPoint32A TextOutA BitBlt
       StretchBlt CreateCompatibleDC CreateCompatibleBitmap GetDIBits SetDIBitsToDevice).each do |name|
      provide(g, name, :unavailable, 'desenho GDI sem superficie: use Bitmap do RGSS', nil)
    end

    c = 'msvcrt'
    provide(c, '_write', :native, 'stdout/stderr para o log do Kerberus', 3) do |a|
      descriptor = a[0].to_i
      next -1 unless descriptor == 1 || descriptor == 2
      Console.write(Memory.read(a[1], a[2].to_i))
      a[2].to_i
    end
    provide(c, '_read', :limited, 'sem stdin no Android (EBADF)', 3) { |a| -1 }

    x = 'xinput'
    provide(x, 'XInputGetState', :native, 'controle SDL ao vivo (jogador 0)', 2) { |a| InputBridge.xinput_get_state(a[0], a[1]) }
    provide(x, 'XInputSetState', :native, 'vibracao via SDL_GameControllerRumble', 2) { |a| InputBridge.xinput_set_state(a[0], a[1]) }
    provide(x, 'XInputGetCapabilities', :native, 'controle SDL como gamepad padrao', 3) { |a| InputBridge.xinput_capabilities(a[0], a[2]) }
    provide(x, 'XInputGetBatteryInformation', :native, 'nivel de energia SDL', 3) { |a| InputBridge.xinput_battery(a[0], a[2]) }
    provide(x, 'XInputEnable', :native, 'sem efeito colateral', 1) { |a| 0 }
    provide(x, 'XInputGetKeystroke', :limited, 'fila de teclas do XInput nao existe no SDL (ERROR_EMPTY)', 3) do |a|
      index = a[0].to_i
      index == 0 && InputBridge.controller_connected? ? 4306 : ERROR_DEVICE_NOT_CONNECTED
    end

    # Winsock: a machine without network. Documented error codes let games
    # disable online features instead of crashing.
    net = 'ws2_32'
    @wsa_error = 0
    net_down = lambda do |value, code|
      lambda do |a|
        @wsa_error = code
        value
      end
    end
    provide(net, 'WSAStartup', :limited, 'rede indisponivel: WSASYSNOTREADY', 2) { |a| @wsa_error = 10091; 10091 }
    provide(net, 'WSACleanup', :limited, 'rede indisponivel', 0) { |a| @wsa_error = 10093; -1 }
    provide(net, 'WSAGetLastError', :native, 'ultimo erro Winsock', 0) { |a| @wsa_error }
    provide(net, 'socket', :limited, 'rede indisponivel: INVALID_SOCKET/WSAENETDOWN', 3, &net_down.call(-1, 10050))
    %w(connect bind listen accept send recv sendto recvfrom select setsockopt getsockopt
       shutdown closesocket ioctlsocket).each do |name|
      provide(net, name, :limited, 'rede indisponivel: SOCKET_ERROR/WSAENOTSOCK', nil, &net_down.call(-1, 10038))
    end
    provide(net, 'gethostbyname', :limited, 'rede indisponivel: WSAHOST_NOT_FOUND', 1, &net_down.call(0, 11001))
    provide(net, 'gethostbyaddr', :limited, 'rede indisponivel: WSAHOST_NOT_FOUND', 3, &net_down.call(0, 11001))
    provide(net, 'getservbyname', :limited, 'rede indisponivel: WSANO_DATA', 2, &net_down.call(0, 11004))
    provide(net, 'gethostname', :native, 'nome virtual kerberus', 2) { |a| Buffers.copy_c_string(a[0], a[1].to_i, 'kerberus'); 0 }
    provide(net, 'htons', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffff].pack('n').unpack('v')[0] }
    provide(net, 'ntohs', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffff].pack('n').unpack('v')[0] }
    provide(net, 'htonl', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffffffff].pack('N').unpack('V')[0] }
    provide(net, 'ntohl', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffffffff].pack('N').unpack('V')[0] }
    provide(net, 'inet_addr', :native, 'conversao pura', 1) do |a|
      parts = Buffers.c_string(a[0]).to_s.split('.')
      if parts.length == 4 && parts.all? { |part| part =~ /\A\d{1,3}\z/ && part.to_i <= 255 }
        parts.map { |part| part.to_i }.pack('C4').unpack('V')[0]
      else
        0xffffffff
      end
    end
    provide(net, 'inet_ntoa', :native, 'conversao pura', 1) { |a| [a[0].to_i & 0xffffffff].pack('V').unpack('C4').join('.') }

    provide('rpg.net', 'InputGetWheelDelta', :native, 'roda do mouse via Input.scroll_v', 0) { |a| InputBridge.wheel_delta }

    # RGSS1 player DLL (RGSS102E.dll and friends).
    provide('rgss1', 'RGSSGetRTPPath', :native, 'sem RTP instalado: caminho vazio', 1) { |a| 0 }
    provide('rgss1', 'RGSSGetPathWithRTP', :native, 'sem RTP: caminho original', 1) { |a| Buffers.c_string(a[0]).to_s }

    # Fangame DLLs replaced by Kerberus Ports. Direct calls mean the port did
    # not recognise the script, so the diagnostic names what to port.
    [['kleinbitmap', 'KleinBitmap: o script original nao foi reconhecido pelo port klein_bitmap',
      %w(add_outline compare_bitmap modify_color modify_pallete save_pallete scroll_up scroll_down
         scroll_left scroll_right set_pattern to_negative to_retro version)],
     ['gif', 'gif.dll: o script GifBitmap nao foi reconhecido pelo port gif_dll',
      %w(GifToPngFiles GifToPngFilesInMemory CopyDataString FreeDataString)],
     ['audio', 'audio.dll: o script AudioContext nao foi reconhecido pelo port audio_dll',
      %w(AudioContextInitialize AudioContextFree AudioContextPlay AudioContextSEPlay AudioContextStop
         AudioContextFadeIn AudioContextFadeOut AudioContextGetPosition AudioContextIsActive AudioContextSetVolume)],
     ['rgss_fmodex', 'FMOD: carregado apenas via RGSS Linker pelo port uranium.rgss_linker', %w(Init_FmodEx)]].each do |entry|
      entry[2].each { |name| provide(entry[0], name, :unavailable, entry[1], nil) }
    end

    # MGC_Hmode7.dll (H-Mode7 v1.2.1, Pokemon Insurgence): the eight exports
    # run natively (binding/kerberus/hm7-core.h, checked byte for byte
    # against the DLL). The game passes its objects by __id__.
    module HM7Bridge
      def self.object(id, what)
        ObjectSpace._id2ref(id.to_i)
      rescue RangeError
        raise ArgumentError, 'MGC_Hmode7: ' + what + ' nao existe mais (__id__ ' + id.to_s + ')'
      end

      def self.call(name, *args)
        unless defined?(::KerberusNative) && ::KerberusNative.respond_to?(name)
          raise WinBridge::Unavailable, "WINBRIDGE_UNAVAILABLE\nMGC_Hmode7: renderizador nativo ausente neste build (KerberusNative." + name.to_s + ')'
        end
        ::KerberusNative.send(name, *args)
      end
    end

    h = 'mgc_hmode7'
    native = 'H-Mode7 nativo (kerberus/hm7-core.h), identico a DLL'
    provide(h, 'renderHM7', :port, native + '; devolve a altura alvo da camera', 3) do |a|
      HM7Bridge.call(:hm7_render, HM7Bridge.object(a[0], 'params'), HM7Bridge.object(a[1], 'vars'),
                     HM7Bridge.object(a[2], 'render_surfaces'))
    end
    provide(h, 'computeM7', :port, native, 3) do |a|
      HM7Bridge.call(:hm7_compute_m7, HM7Bridge.object(a[0], 'computetable'), HM7Bridge.object(a[1], 'rowsdata'),
                     HM7Bridge.object(a[2], 'parameters'))
    end
    provide(h, 'drawMapTileset', :port, native, 5) do |a|
      HM7Bridge.call(:hm7_draw_map_tileset, HM7Bridge.object(a[0], 'map_tileset'), HM7Bridge.object(a[1], 'tileset'),
                     HM7Bridge.object(a[2], 'heightset'), HM7Bridge.object(a[3], 'tilemap_hash'),
                     HM7Bridge.object(a[4], 'auto_tilesets'))
    end
    provide(h, 'refreshMapTileset', :port, native, 4) do |a|
      HM7Bridge.call(:hm7_refresh_map_tileset, HM7Bridge.object(a[0], 'map_tileset'), HM7Bridge.object(a[1], 'tileset'),
                     HM7Bridge.object(a[2], 'tilemap_hash'), HM7Bridge.object(a[3], 'auto_tilesets'))
    end
    provide(h, 'drawTextureset', :port, native, 3) do |a|
      HM7Bridge.call(:hm7_draw_textureset, HM7Bridge.object(a[0], 'textures'), HM7Bridge.object(a[1], 'textureset'),
                     HM7Bridge.object(a[2], 'texture_auto'))
    end
    provide(h, 'drawHeightmap', :port, native, 4) do |a|
      HM7Bridge.call(:hm7_draw_heightmap, HM7Bridge.object(a[0], 'heightmap'), HM7Bridge.object(a[1], 'heightpattern'),
                     HM7Bridge.object(a[2], 'map_tileset'), HM7Bridge.object(a[3], 'tiletable'))
    end
    provide(h, 'applyLighting', :port, native, 1) { |a| HM7Bridge.call(:hm7_apply_lighting, HM7Bridge.object(a[0], 'heightmap')) }
    provide(h, 'applyOpacity', :port, native, 2) { |a| HM7Bridge.call(:hm7_apply_opacity, HM7Bridge.object(a[0], 'bitmap'), a[1].to_i) }

    provide('rubyscreen', 'TakeScreenshot', :port, 'Graphics.snap_to_bitmap + Bitmap#to_file (PNG, JPG ou BMP pela extensao)', 1) do |a|
      path = WinBridge.native_path(a[0], true)
      next 0 if path.nil?
      bitmap = KerberusLegacy18.native('Graphics', :snap_to_bitmap)
      begin
        bitmap.to_file(path)
      ensure
        bitmap.dispose if bitmap && !bitmap.disposed?
      end
      1
    end
    provide('rubyscreen', 'SwapRgb', :port, 'troca R/B em buffer BGRA Ruby', 2) do |a|
      size = a[1].to_i
      Buffers.need(a[0], size, true, 'SwapRgb')
      raise ArgumentError, 'SwapRgb: tamanho deve ser multiplo de 4' unless size % 4 == 0
      data = a[0]
      index = 0
      while index < size
        red = data[index]
        data[index] = data[index + 2]
        data[index + 2] = red
        index += 4
      end
      0
    end
  end
end
