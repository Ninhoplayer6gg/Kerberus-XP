# Kerberus WinBridge 6.4 - Win32 functions common in RPG Maker XP scripts
# that 6.3 did not answer. A game that called one of them stopped with
# WINBRIDGE_UNAVAILABLE. Each provider below either does the real thing on
# Android (time, strings, memory, clipboard, controller, registry...) or
# returns the documented Windows failure for something Android does not
# allow (process priority, network, external programs). No false success.
module KerberusLegacy18
  module WinBridge
    ERROR_NOT_SUPPORTED = 50 unless const_defined?(:ERROR_NOT_SUPPORTED)
    ERROR_INVALID_ADDRESS = 487 unless const_defined?(:ERROR_INVALID_ADDRESS)
    ERROR_INVALID_MENU_HANDLE = 1401 unless const_defined?(:ERROR_INVALID_MENU_HANDLE)
    ERROR_CLIPBOARD_NOT_OPEN = 1418 unless const_defined?(:ERROR_CLIPBOARD_NOT_OPEN)
    ERROR_INTERNET_NAME_NOT_RESOLVED = 12007 unless const_defined?(:ERROR_INTERNET_NAME_NOT_RESOLVED)
    STILL_ACTIVE = 259 unless const_defined?(:STILL_ACTIVE)

    # Pointer-returning string functions return their destination. A Ruby
    # String buffer has no address, so a non-NULL token marks success there.
    def self.destination(value)
      value.is_a?(Integer) ? value : 1
    end

    # Named kernel objects of this process (single-instance checks).
    module Named
      @objects = {}

      def self.reset!
        @objects = {}
      end

      def self.handle_for(kind, name, create)
        key = name.nil? ? nil : kind.to_s + ':' + name.to_s.downcase
        if key && @objects[key] && Handles.get(@objects[key], kind)
          WinBridge.last_error = ERROR_ALREADY_EXISTS
          return Handles.add(kind, key)
        end
        return WinBridge.failure(ERROR_FILE_NOT_FOUND, 0) unless create
        handle = Handles.add(kind, key)
        @objects[key] = handle if key
        WinBridge.success(handle)
      end
    end

    # C runtime rand/srand: the exact MSVCRT generator.
    module CRand
      @state = 1
      def self.srand(seed)
        @state = seed.to_i & 0xffffffff
      end
      def self.rand
        @state = (@state * 214013 + 2531011) & 0xffffffff
        (@state >> 16) & 0x7fff
      end
    end

    module Format
      DAYS = { 'pt' => %w(domingo segunda-feira terca-feira quarta-feira quinta-feira sexta-feira sabado),
               'es' => %w(domingo lunes martes miercoles jueves viernes sabado),
               'en' => %w(Sunday Monday Tuesday Wednesday Thursday Friday Saturday) }
      MONTHS = { 'pt' => %w(janeiro fevereiro marco abril maio junho julho agosto setembro outubro novembro dezembro),
                 'es' => %w(enero febrero marzo abril mayo junio julio agosto septiembre octubre noviembre diciembre),
                 'en' => %w(January February March April May June July August September October November December) }
      SHORT_DATE = { 'en' => 'M/d/yyyy' }
      LONG_DATE = { 'pt' => "dddd, d' de 'MMMM' de 'yyyy", 'es' => "dddd, d' de 'MMMM' de 'yyyy", 'en' => 'dddd, MMMM d, yyyy' }
      TIME = { 'en' => 'h:mm:ss tt' }

      def self.language
        lang = Locale.language
        DAYS[lang] ? lang : 'en'
      end

      # SYSTEMTIME (16 bytes) or the current local time.
      def self.time_from(value)
        return Time.now if Buffers.null?(value)
        fields = Memory.read(value, 16).unpack('v8')
        Time.local(fields[0], fields[1], fields[3], fields[4], fields[5], fields[6])
      end

      def self.systemtime(time)
        [time.year, time.month, time.wday, time.day, time.hour, time.min, time.sec, (time.usec / 1000)].pack('v8')
      end

      # Windows date/time pictures; text between single quotes is literal.
      def self.render(picture, time, flags)
        lang = language
        out = ''
        i = 0
        while i < picture.length
          c = picture[i, 1]
          if c == "'"
            close = picture.index("'", i + 1) || picture.length
            out << picture[i + 1...close]
            i = close + 1
            next
          end
          run = 1
          run += 1 while picture[i + run, 1] == c
          token = c * run
          out << case c
                 when 'd'
                   case run
                   when 1 then time.day.to_s
                   when 2 then format('%02d', time.day)
                   when 3 then DAYS[lang][time.wday][0, 3]
                   else DAYS[lang][time.wday]
                   end
                 when 'M'
                   case run
                   when 1 then time.month.to_s
                   when 2 then format('%02d', time.month)
                   when 3 then MONTHS[lang][time.month - 1][0, 3]
                   else MONTHS[lang][time.month - 1]
                   end
                 when 'y'
                   run <= 2 ? format('%02d', time.year % 100) : time.year.to_s
                 when 'h'
                   hour = time.hour % 12
                   hour = 12 if hour == 0
                   run == 1 ? hour.to_s : format('%02d', hour)
                 when 'H'
                   run == 1 ? time.hour.to_s : format('%02d', time.hour)
                 when 'm'
                   run == 1 ? time.min.to_s : format('%02d', time.min)
                 when 's'
                   (flags & 2) != 0 ? '' : (run == 1 ? time.sec.to_s : format('%02d', time.sec))
                 when 't'
                   (flags & 4) != 0 ? '' : (time.hour < 12 ? 'AM' : 'PM')[0, run]
                 else token
                 end
          i += run
        end
        out
      end

      def self.date(value, flags, picture)
        lang = language
        picture ||= (flags & 2) != 0 ? LONG_DATE[lang] : (SHORT_DATE[lang] || 'dd/MM/yyyy')
        render(picture, time_from(value), 0)
      end

      def self.clock(value, flags, picture)
        picture ||= (flags & 8) != 0 ? 'HH:mm:ss' : (TIME[language] || 'HH:mm:ss')
        picture = picture.sub(/[:.]?s+/, '') if (flags & 2) != 0
        render(picture, time_from(value), flags).strip
      end

      # C printf / wsprintf format with the Win32API argument list.
      def self.printf(fmt, args)
        index = 0
        fmt.gsub(/%([-+ #0]*)(\d*|\*)(?:\.(\d+))?(?:hh|h|ll|l|I64|I32)?([diouxXcsSfFeEgGp%])/) do
          flags = $1
          width = $2
          precision = $3
          type = $4
          next '%' if type == '%'
          if width == '*'
            width = args[index].to_i.to_s
            index += 1
          end
          value = args[index]
          index += 1
          spec = '%' + flags + width.to_s + (precision ? '.' + precision : '')
          case type
          when 's', 'S' then format(spec + 's', Buffers.c_string(value).to_s)
          when 'c' then format(spec + 'c', value.to_i & 0xff)
          when 'u' then format(spec + 'd', value.to_i & 0xffffffff)
          when 'i' then format(spec + 'd', WinBridge.to_i32(value.to_i))
          when 'p' then format('%08X', value.to_i & 0xffffffff)
          when 'f', 'F', 'e', 'E', 'g', 'G' then format(spec + type.downcase, value.to_f)
          else format(spec + type, value.to_i)
          end
        end
      end
    end

    module Clipboard
      @open = false
      def self.reset!
        @open = false
      end
      def self.open?
        @open
      end
      def self.open!(value)
        @open = value
      end
      def self.text
        KerberusLegacy18.native?('Input', :clipboard) ? KerberusLegacy18.native('Input', :clipboard).to_s : ''
      end
      def self.text=(value)
        KerberusLegacy18.native('Input', :clipboard=, value.to_s) if KerberusLegacy18.native?('Input', :clipboard=)
      end
    end

    k = 'kernel32'
    priority = 'prioridade gerida pelo Android; pedido recusado com ERROR_ACCESS_DENIED'
    provide(k, 'SetPriorityClass', :limited, priority, 2) { |a| WinBridge.failure(ERROR_ACCESS_DENIED, 0) }
    provide(k, 'SetThreadPriority', :limited, priority, 2) { |a| WinBridge.failure(ERROR_ACCESS_DENIED, 0) }
    provide(k, 'GetPriorityClass', :native, 'NORMAL_PRIORITY_CLASS', 1) { |a| WinBridge.success(0x20) }
    provide(k, 'GetThreadPriority', :native, 'THREAD_PRIORITY_NORMAL', 1) { |a| WinBridge.success(0) }
    @command_line = nil
    provide(k, 'GetCommandLineA', :native, 'linha de comando do executavel do jogo, sem argumentos', 0) do |a|
      @command_line ||= Memory.alloc('"' + KerberusLegacy18.config[:exec_name].to_s + '.exe"' + "\0")
    end
    @command_line_w = nil
    provide(k, 'GetCommandLineW', :native, 'linha de comando do executavel do jogo, sem argumentos', 0) do |a|
      @command_line_w ||= Memory.alloc_wide('"' + KerberusLegacy18.config[:exec_name].to_s + '.exe"')
    end
    provide(k, 'SetEnvironmentVariableA', :native, 'ambiente virtual do jogo (lido por GetEnvironmentVariable)', 2) do |a|
      name = Buffers.c_string(a[0]).to_s
      next WinBridge.failure(ERROR_INVALID_PARAMETER, 0) if name.empty? || name.index('=')
      Env.set(name, Buffers.null?(a[1]) ? nil : Buffers.c_string(a[1]))
      WinBridge.success(1)
    end
    provide(k, 'CreateMutexA', :native, 'objetos nomeados deste processo; ERROR_ALREADY_EXISTS na segunda criacao', 3) do |a|
      Named.handle_for(:mutex, Buffers.c_string(a[2]), true)
    end
    provide(k, 'OpenMutexA', :native, 'objetos nomeados deste processo', 3) { |a| Named.handle_for(:mutex, Buffers.c_string(a[2]), false) }
    provide(k, 'ReleaseMutex', :native, 'objetos nomeados deste processo', 1) do |a|
      Handles.kind(a[0]) == :mutex ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_HANDLE, 0)
    end
    provide(k, 'GetDiskFreeSpaceExA', :native, 'statvfs da pasta pedida (ou da pasta do jogo)', 4) do |a|
      path = Buffers.null?(a[0]) ? Dir.pwd : WinBridge.native_path(a[0], false)
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, 0) if path.nil? || !File.directory?(path)
      next WinBridge.failure(ERROR_NOT_SUPPORTED, 0) unless defined?(::KerberusNative) && ::KerberusNative.respond_to?(:disk_space)
      space = ::KerberusNative.disk_space(path)
      next WinBridge.failure(ERROR_NOT_SUPPORTED, 0) unless space
      Buffers.put(a[1], Buffers.pack_u64(space[0]), 0) unless Buffers.null?(a[1])
      Buffers.put(a[2], Buffers.pack_u64(space[1]), 0) unless Buffers.null?(a[2])
      Buffers.put(a[3], Buffers.pack_u64(space[2]), 0) unless Buffers.null?(a[3])
      WinBridge.success(1)
    end
    provide(k, 'lstrcpyA', :native, 'copia em buffer Ruby/heap virtual', 2) do |a|
      Memory.write(a[0], Buffers.c_string(a[1]).to_s + "\0")
      WinBridge.destination(a[0])
    end
    provide(k, 'lstrcpynA', :native, 'copia limitada em buffer Ruby/heap virtual', 3) do |a|
      count = a[2].to_i
      next WinBridge.destination(a[0]) if count <= 0
      Memory.write(a[0], Buffers.c_string(a[1]).to_s[0, count - 1] + "\0")
      WinBridge.destination(a[0])
    end
    provide(k, 'lstrcatA', :native, 'concatena em buffer Ruby/heap virtual', 2) do |a|
      Memory.write(a[0], Buffers.c_string(a[0]).to_s + Buffers.c_string(a[1]).to_s + "\0")
      WinBridge.destination(a[0])
    end
    compare = lambda do |left, right|
      left = left.to_s
      right = right.to_s
      left < right ? -1 : (left > right ? 1 : 0)
    end
    provide(k, 'lstrcmpA', :native, 'comparacao de bytes', 2) { |a| compare.call(Buffers.c_string(a[0]), Buffers.c_string(a[1])) }
    provide(k, 'lstrcmpiA', :native, 'comparacao sem diferenciar maiusculas (ASCII)', 2) do |a|
      compare.call(Buffers.c_string(a[0]).to_s.downcase, Buffers.c_string(a[1]).to_s.downcase)
    end
    provide(k, 'lstrcmpW', :native, 'comparacao de texto UTF-16', 2) { |a| compare.call(Buffers.wide_string(a[0]), Buffers.wide_string(a[1])) }
    provide(k, 'lstrcmpiW', :native, 'comparacao sem diferenciar maiusculas (ASCII)', 2) do |a|
      compare.call(Buffers.wide_string(a[0]).to_s.downcase, Buffers.wide_string(a[1]).to_s.downcase)
    end
    copy_path = lambda do |buffer, capacity, text|
      next WinBridge.success(text.length + 1) if capacity.to_i <= text.length
      Buffers.put(buffer, text + "\0", 0)
      WinBridge.success(text.length)
    end
    provide(k, 'GetShortPathNameA', :native, 'sem nomes 8.3: o caminho curto e o proprio caminho', 3) do |a|
      text = Buffers.c_string(a[0]).to_s
      path = WinBridge.native_path(a[0], false)
      next WinBridge.failure(ERROR_FILE_NOT_FOUND, 0) if path.nil? || !File.exist?(path)
      copy_path.call(a[1], a[2], text)
    end
    provide(k, 'GetFullPathNameA', :native, 'caminho absoluto a partir da pasta atual, separadores Windows', 4) do |a|
      text = Buffers.c_string(a[0]).to_s
      next WinBridge.failure(ERROR_INVALID_PARAMETER, 0) if text.empty?
      full = text =~ /\A[A-Za-z]:/ ? text.tr('/', '\\') : WinBridge.windows_path(File.expand_path(text.tr('\\', '/')))
      result = copy_path.call(a[2], a[1], full)
      unless Buffers.null?(a[3]) || result > full.length
        Buffers.put_u32(a[3], 0, 0)
      end
      result
    end
    provide(k, 'GetTempFileNameA', :native, 'arquivo temporario unico na pasta pedida', 4) do |a|
      directory = WinBridge.native_path(a[0], false)
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, 0) if directory.nil? || !File.directory?(directory)
      prefix = Buffers.c_string(a[1]).to_s[0, 3]
      unique = a[2].to_i & 0xffff
      number = unique == 0 ? (Time.now.to_i & 0xffff) : unique
      name = nil
      65536.times do
        number = 1 if number == 0
        name = File.join(directory, prefix + format('%X', number) + '.tmp')
        break unless unique == 0 && File.exist?(name)
        number = (number + 1) & 0xffff
      end
      File.open(name, 'wb') { |file| file.write('') } if unique == 0
      Buffers.put(a[3], WinBridge.windows_path(name) + "\0", 0)
      WinBridge.success(number)
    end
    provide(k, 'Beep', :limited, 'sem alto-falante de sistema; falha documentada', 2) { |a| WinBridge.failure(ERROR_NOT_SUPPORTED, 0) }
    provide(k, 'GetLocalTime', :native, 'hora local do aparelho', 1) { |a| Buffers.put(a[0], Format.systemtime(Time.now), 0); 0 }
    provide(k, 'GetSystemTime', :native, 'hora UTC do aparelho', 1) { |a| Buffers.put(a[0], Format.systemtime(Time.now.utc), 0); 0 }
    provide(k, 'GetTimeZoneInformation', :native, 'fuso do aparelho (Bias); horario de verao nao informado', 1) do |a|
      bias = -(Time.now.utc_offset / 60)
      name = Text.utf8_to_utf16le(Time.now.zone.to_s)[0, 62]
      name += "\0" * (64 - name.length)
      data = [bias].pack('l') + name + "\0" * 16 + [0].pack('l') + name + "\0" * 16 + [0].pack('l')
      Buffers.put(a[0], data, 0)
      WinBridge.success(0)
    end
    provide(k, 'GetLogicalDrives', :native, 'unidade virtual C:', 0) { |a| WinBridge.success(0x4) }
    provide(k, 'GetDriveTypeA', :native, 'C: fixa; demais letras inexistentes', 1) do |a|
      root = Buffers.c_string(a[0]).to_s
      root.empty? || root =~ /\A[Cc]:/ || root !~ /\A[A-Za-z]:/ ? 3 : 1
    end
    provide(k, 'GetVolumeInformationA', :native, 'volume virtual KERBERUS em C:', 8) do |a|
      root = Buffers.c_string(a[0]).to_s
      next WinBridge.failure(ERROR_PATH_NOT_FOUND, 0) unless root.empty? || root =~ /\A[Cc]:/
      Buffers.copy_c_string(a[1], a[2].to_i, 'KERBERUS') unless Buffers.null?(a[1])
      Buffers.put_u32(a[3], 0x4B45524B, 0) unless Buffers.null?(a[3])
      Buffers.put_u32(a[4], 255, 0) unless Buffers.null?(a[4])
      Buffers.put_u32(a[5], 0x6, 0) unless Buffers.null?(a[5])
      Buffers.copy_c_string(a[6], a[7].to_i, 'NTFS') unless Buffers.null?(a[6])
      WinBridge.success(1)
    end
    provide(k, 'VirtualAlloc', :native, 'heap virtual (ate 64 KiB); endereco fixo pedido e recusado', 4) do |a|
      size = a[1].to_i
      next WinBridge.failure(ERROR_INVALID_ADDRESS, 0) unless Buffers.null?(a[0])
      next WinBridge.failure(ERROR_NOT_ENOUGH_MEMORY, 0) if size <= 0 || size > Memory::STEP
      WinBridge.success(Memory.alloc("\0" * size))
    end
    provide(k, 'VirtualFree', :native, 'heap virtual', 3) { |a| Memory.free(a[0]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_ADDRESS, 0) }
    provide(k, 'ExitProcess', :native, 'encerra o jogo', 1) do |a|
      KerberusLegacy18.event('EXIT', 'kernel32!ExitProcess', 'codigo ' + a[0].to_i.to_s, true)
      exit(a[0].to_i)
    end
    provide(k, 'TerminateProcess', :native, 'somente o proprio processo (pseudo-handle -1)', 2) do |a|
      next WinBridge.failure(ERROR_ACCESS_DENIED, 0) unless WinBridge.to_i32(a[0].to_i) == -1
      KerberusLegacy18.event('EXIT', 'kernel32!TerminateProcess', 'codigo ' + a[1].to_i.to_s, true)
      exit(a[1].to_i)
    end
    provide(k, 'GetExitCodeProcess', :native, 'proprio processo: STILL_ACTIVE', 2) do |a|
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless WinBridge.to_i32(a[0].to_i) == -1
      Buffers.put_u32(a[1], STILL_ACTIVE, 0)
      WinBridge.success(1)
    end
    date_or_time = lambda do |a, text|
      capacity = a[5].to_i
      next WinBridge.success(text.length + 1) if capacity == 0
      next WinBridge.failure(ERROR_INSUFFICIENT_BUFFER, 0) if capacity <= text.length
      Buffers.put(a[4], text + "\0", 0)
      WinBridge.success(text.length + 1)
    end
    provide(k, 'GetDateFormatA', :native, 'formatos de data do Windows no idioma do aparelho (pt/es/en)', 6) do |a|
      picture = Buffers.null?(a[3]) ? nil : Buffers.c_string(a[3])
      date_or_time.call(a, Format.date(a[2], a[1].to_i, picture))
    end
    provide(k, 'GetTimeFormatA', :native, 'formatos de hora do Windows no idioma do aparelho', 6) do |a|
      picture = Buffers.null?(a[3]) ? nil : Buffers.c_string(a[3])
      date_or_time.call(a, Format.clock(a[2], a[1].to_i, picture))
    end

    c = 'msvcrt'
    provide(c, 'memcpy', :native, 'copia entre buffers Ruby/heap virtual', 3) do |a|
      Memory.write(a[0], Memory.read(a[1], a[2].to_i))
      WinBridge.destination(a[0])
    end
    provide(c, 'memmove', :native, 'copia entre buffers Ruby/heap virtual', 3) do |a|
      Memory.write(a[0], Memory.read(a[1], a[2].to_i))
      WinBridge.destination(a[0])
    end
    provide(c, 'memset', :native, 'preenche buffer Ruby/heap virtual', 3) do |a|
      Memory.write(a[0], (a[1].to_i & 0xff).chr * a[2].to_i)
      WinBridge.destination(a[0])
    end
    provide(c, 'strlen', :native, 'strlen em buffer Ruby/heap virtual', 1) { |a| (Buffers.c_string(a[0]) || '').length }
    provide(c, 'sprintf', :native, 'formato C (d i u x X o c s f e g p)', 2) do |a|
      text = Format.printf(Buffers.c_string(a[1]).to_s, a[2..-1] || [])
      Memory.write(a[0], text + "\0")
      text.length
    end
    provide(c, 'rand', :native, 'gerador exato do MSVCRT', 0) { |a| CRand.rand }
    provide(c, 'srand', :native, 'gerador exato do MSVCRT', 1) { |a| CRand.srand(a[0]); 0 }
    provide(c, 'system', :limited, 'sem interpretador de comandos no Android', 1) { |a| Buffers.null?(a[0]) ? 0 : -1 }

    s = 'shell32'
    provide(s, 'ShellExecuteExA', :limited, 'abrir programas/URLs externos indisponivel', 1) do |a|
      Buffers.put_u32(a[0], 2, 32) if a[0].is_a?(String) && a[0].length >= 36
      WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(s, 'SHFileOperationA', :limited, 'estrutura com ponteiros reais; operacao recusada (DE_INVALIDFILES)', 1) { |a| 0x7C }
    provide(s, 'SHBrowseForFolderA', :limited, 'sem seletor de pastas: nenhuma pasta escolhida', 1) { |a| 0 }
    provide(s, 'DragAcceptFiles', :native, 'arrastar arquivos nao existe no Android', 2) { |a| 0 }
    provide(s, 'ExtractIconA', :limited, 'icones de executaveis nao sao extraidos', 3) { |a| 0 }

    u = 'user32'
    provide(u, 'MessageBoxW', :limited, 'mensagem RGSS nativa; botoes Sim/Nao retornam a opcao segura', 4) do |a|
      WinBridge.lookup('user32', 'MessageBoxA').impl.call([a[0], Buffers.wide_string(a[1]).to_s, Buffers.wide_string(a[2]).to_s, a[3]])
    end
    provide(u, 'EnumDisplaySettingsA', :native, 'um modo: resolucao do jogo, 32 bpp, 60 Hz', 3) do |a|
      mode = a[1].to_i & 0xffffffff
      next WinBridge.failure(ERROR_INVALID_PARAMETER, 0) unless mode == 0 || mode == 0xffffffff || mode == 0xfffffffe
      Buffers.need(a[2], 124, true, 'DEVMODE')
      Buffers.put(a[2], [156].pack('v'), 36)
      Buffers.put(a[2], [0x40000 | 0x80000 | 0x100000 | 0x400000].pack('V'), 40)
      Buffers.put(a[2], [32, Window.width, Window.height, 0, 60].pack('V5'), 104)
      WinBridge.success(1)
    end
    provide(u, 'ChangeDisplaySettingsA', :limited, 'apenas o modo atual (resolucao do jogo) e aceito', 2) do |a|
      next 0 if Buffers.null?(a[0])
      fields = Buffers.u32(a[0], 40)
      width = (fields & 0x80000) != 0 ? Buffers.u32(a[0], 108) : Window.width
      height = (fields & 0x100000) != 0 ? Buffers.u32(a[0], 112) : Window.height
      width == Window.width && height == Window.height ? 0 : -2
    end
    cursor = { :current => 0x00C1C000 }
    provide(u, 'LoadCursorA', :native, 'cursores do sistema como handles virtuais', 2) do |a|
      Buffers.null?(a[0]) && a[1].is_a?(Integer) ? WinBridge.success(0x00C1C000 + (a[1].to_i & 0xffff)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(u, 'LoadCursorFromFileA', :native, 'arquivo de cursor existente vira handle virtual', 1) do |a|
      path = WinBridge.native_path(a[0], false)
      path && File.file?(path) ? WinBridge.success(0x00C1D000 + (path.hash & 0xfff)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    provide(u, 'SetCursor', :limited, 'sem cursor visivel no Android; handle anterior devolvido', 1) do |a|
      previous = cursor[:current]
      cursor[:current] = a[0].to_i
      previous
    end
    provide(u, 'DestroyIcon', :native, 'handles virtuais', 1) { |a| WinBridge.success(1) }
    provide(u, 'LoadImageA', :native, 'arquivo existente ou recurso do sistema vira handle virtual', 6) do |a|
      if (a[5].to_i & 0x10) != 0
        path = WinBridge.native_path(a[1], false)
        next path && File.file?(path) ? WinBridge.success(0x00C1E000 + (path.hash & 0xfff)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
      end
      Buffers.null?(a[0]) && a[1].is_a?(Integer) ? WinBridge.success(0x00C1F000 + (a[1].to_i & 0xfff)) : WinBridge.failure(ERROR_FILE_NOT_FOUND, 0)
    end
    key_names = { 0x08 => 'Backspace', 0x09 => 'Tab', 0x0D => 'Enter', 0x10 => 'Shift', 0x11 => 'Ctrl', 0x12 => 'Alt',
                  0x14 => 'Caps Lock', 0x1B => 'Esc', 0x20 => 'Space', 0x21 => 'Page Up', 0x22 => 'Page Down',
                  0x23 => 'End', 0x24 => 'Home', 0x25 => 'Left', 0x26 => 'Up', 0x27 => 'Right', 0x28 => 'Down',
                  0x2D => 'Insert', 0x2E => 'Delete', 0x90 => 'Num Lock', 0x91 => 'Scroll Lock' }
    provide(u, 'GetKeyNameTextA', :native, 'nomes de teclas do layout US', 3) do |a|
      scan = (a[0].to_i >> 16) & 0xff
      vk = InputBridge::VK_FROM_SCAN[scan]
      name = vk.nil? ? '' : (key_names[vk] || (vk >= 0x70 && vk <= 0x7B ? 'F' + (vk - 0x6F).to_s : (vk >= 0x30 && vk <= 0x5A ? vk.chr : '')))
      name.empty? ? WinBridge.failure(ERROR_INVALID_PARAMETER, 0) : WinBridge.success(Buffers.copy_c_string(a[1], a[2].to_i, name))
    end
    provide(u, ['DefWindowProcA', 'CallWindowProcA'], :limited, 'sem procedimento de janela Win32', 4) { |a| 0 }
    provide(u, 'GetMenu', :native, 'a janela do jogo nao tem menu', 1) { |a| WinBridge.success(0) }
    provide(u, 'SetMenu', :native, 'a janela do jogo nao tem menu', 2) { |a| Buffers.null?(a[1]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_MENU_HANDLE, 0) }
    provide(u, 'DrawMenuBar', :native, 'a janela do jogo nao tem menu', 1) { |a| Window.handle?(a[0]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) }
    provide(u, 'GetSystemMenu', :native, 'a janela do jogo nao tem menu de sistema', 2) { |a| WinBridge.success(0) }
    provide(u, 'GetParent', :native, 'janela de nivel superior', 1) { |a| WinBridge.success(0) }
    provide(u, 'GetWindowPlacement', :native, 'janela logica normal na resolucao do jogo', 2) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      Buffers.put(a[1], [44, 0, 1, -1, -1, -1, -1, 0, 0, Window.width, Window.height].pack('V3l8'), 0)
      WinBridge.success(1)
    end
    provide(u, 'SetWindowPlacement', :limited, 'superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada', 2) do |a|
      Window.handle?(a[0]) ? 1 : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0)
    end
    sys_colors = [0xC8C8C8, 0x000000, 0xD1B499, 0xDBCDBF, 0xF0F0F0, 0xFFFFFF, 0x646464, 0x000000, 0x000000, 0x000000,
                  0xB4B4B4, 0xFCF7F4, 0xABABAB, 0xD77800, 0xFFFFFF, 0xF0F0F0, 0xA0A0A0, 0x6D6D6D, 0x000000, 0x000000,
                  0xFFFFFF, 0x696969, 0xE3E3E3, 0x000000, 0xE1FFFF, 0x000000, 0xCC6600, 0xEAD1B9, 0xF2E4D7, 0xFF9933, 0xF0F0F0]
    provide(u, 'GetSysColor', :native, 'cores padrao do Windows 10', 1) { |a| sys_colors[a[0].to_i] || 0 }
    provide(u, 'WindowFromPoint', :native, 'janela logica dentro da resolucao do jogo', 2) do |a|
      x = WinBridge.to_i32(a[0].to_i)
      y = WinBridge.to_i32(a[1].to_i)
      x >= 0 && y >= 0 && x < Window.width && y < Window.height ? Window::HWND : Window::DESKTOP
    end
    provide(u, ['TranslateMessage', 'DispatchMessageA'], :native, 'fila Win32 sempre vazia no Android', 1) { |a| 0 }
    enabled = { :value => true }
    provide(u, 'EnableWindow', :native, 'estado habilitado da janela logica', 2) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      was_disabled = !enabled[:value]
      enabled[:value] = !(a[1].nil? || a[1] == 0 || a[1] == false)
      was_disabled ? 1 : 0
    end
    provide(u, 'IsWindowEnabled', :native, 'estado habilitado da janela logica', 1) { |a| Window.handle?(a[0]) && enabled[:value] ? 1 : 0 }
    case_map = lambda do |a, method|
      value = a[0]
      if value.is_a?(Integer) && (value & 0xffff0000) == 0
        char = (value & 0xff).chr
        mapped = method == :upcase ? char.upcase : char.downcase
        next mapped[0]
      end
      text = Buffers.c_string(value).to_s
      Memory.write(value, (method == :upcase ? text.upcase : text.downcase))
      WinBridge.destination(value)
    end
    provide(u, 'CharUpperA', :native, 'maiusculas ASCII no buffer ou caractere', 1) { |a| case_map.call(a, :upcase) }
    provide(u, 'CharLowerA', :native, 'minusculas ASCII no buffer ou caractere', 1) { |a| case_map.call(a, :downcase) }
    provide(u, 'wsprintfA', :native, 'formato C (d i u x X c s p)', 2) do |a|
      text = Format.printf(Buffers.c_string(a[1]).to_s, a[2..-1] || [])[0, 1023]
      Memory.write(a[0], text + "\0")
      text.length
    end
    class_longs = { -12 => 0x00C1C000 + 32512 }
    provide(u, 'GetClassLongA', :native, 'dados de classe da janela logica', 2) do |a|
      Window.handle?(a[0]) ? (class_longs[WinBridge.to_i32(a[1].to_i)] || 0) : WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0)
    end
    provide(u, 'SetClassLongA', :native, 'dados de classe da janela logica', 3) do |a|
      next WinBridge.failure(ERROR_INVALID_WINDOW_HANDLE, 0) unless Window.handle?(a[0])
      index = WinBridge.to_i32(a[1].to_i)
      previous = class_longs[index] || 0
      class_longs[index] = a[2].to_i
      previous
    end
    provide(u, 'SetKeyboardState', :limited, 'o estado das teclas vem do SDL e nao pode ser escrito', 1) { |a| WinBridge.failure(ERROR_NOT_SUPPORTED, 0) }
    provide(u, 'OpenClipboard', :native, 'area de transferencia do Android', 1) { |a| Clipboard.open!(true); WinBridge.success(1) }
    provide(u, 'CloseClipboard', :native, 'area de transferencia do Android', 0) do |a|
      next WinBridge.failure(ERROR_CLIPBOARD_NOT_OPEN, 0) unless Clipboard.open?
      Clipboard.open!(false)
      WinBridge.success(1)
    end
    provide(u, 'EmptyClipboard', :native, 'area de transferencia do Android', 0) do |a|
      next WinBridge.failure(ERROR_CLIPBOARD_NOT_OPEN, 0) unless Clipboard.open?
      Clipboard.text = ''
      WinBridge.success(1)
    end
    provide(u, 'IsClipboardFormatAvailable', :native, 'texto da area de transferencia do Android', 1) do |a|
      [1, 7, 13].include?(a[0].to_i) && !Clipboard.text.empty? ? 1 : 0
    end
    provide(u, 'GetClipboardData', :native, 'CF_TEXT/CF_UNICODETEXT em bloco do heap virtual', 1) do |a|
      next WinBridge.failure(ERROR_CLIPBOARD_NOT_OPEN, 0) unless Clipboard.open?
      text = Clipboard.text
      case a[0].to_i
      when 1, 7 then WinBridge.success(Memory.alloc(Text.utf8_to_cp1252(text, '?')[0][0, Memory::STEP - 1] + "\0"))
      when 13 then WinBridge.success(Memory.alloc_wide(text[0, Memory::STEP / 2 - 1]))
      else WinBridge.failure(ERROR_NOT_SUPPORTED, 0)
      end
    end
    provide(u, 'SetClipboardData', :native, 'CF_TEXT/CF_UNICODETEXT de bloco do heap virtual', 2) do |a|
      next WinBridge.failure(ERROR_CLIPBOARD_NOT_OPEN, 0) unless Clipboard.open?
      case a[0].to_i
      when 1, 7 then Clipboard.text = Text.cp1252_to_utf8(Buffers.c_string(a[1]).to_s)
      when 13 then Clipboard.text = Buffers.wide_string(a[1]).to_s
      else next WinBridge.failure(ERROR_NOT_SUPPORTED, 0)
      end
      WinBridge.success(a[1])
    end
    provide(u, 'SetTimer', :limited, 'timers Win32 dependem de fila de mensagens; recusado', 4) { |a| WinBridge.failure(ERROR_NOT_SUPPORTED, 0) }
    provide(u, 'KillTimer', :limited, 'nenhum timer Win32 e criado', 2) { |a| WinBridge.failure(ERROR_INVALID_PARAMETER, 0) }
    provide(u, 'FlashWindow', :limited, 'a janela do jogo ja esta ativa; sem piscar', 2) { |a| Window.handle?(a[0]) ? 1 : 0 }
    provide(u, 'MessageBeep', :limited, 'sem sons de sistema; falha documentada', 1) { |a| WinBridge.failure(ERROR_NOT_SUPPORTED, 0) }

    g = 'gdi32'
    provide(g, 'GetStockObject', :native, 'objetos de estoque como handles virtuais', 1) do |a|
      index = a[0].to_i
      index >= 0 && index <= 19 ? WinBridge.success(0x01900000 + index) : WinBridge.failure(ERROR_INVALID_PARAMETER, 0)
    end
    provide(g, 'DeleteDC', :native, 'DCs virtuais', 1) { |a| Buffers.null?(a[0]) ? WinBridge.failure(ERROR_INVALID_HANDLE, 0) : WinBridge.success(1) }
    snapshot = { :frame => nil, :bitmap => nil }
    provide(g, 'GetPixel', :native, 'pixel da tela do jogo (Graphics.snap_to_bitmap, uma captura por quadro)', 3) do |a|
      x = WinBridge.to_i32(a[1].to_i)
      y = WinBridge.to_i32(a[2].to_i)
      next 0xffffffff unless a[0].to_i == Window::DC && x >= 0 && y >= 0 && x < Window.width && y < Window.height
      next 0xffffffff unless KerberusLegacy18.native?('Graphics', :snap_to_bitmap)
      frame = InputBridge.frame
      if snapshot[:frame] != frame || snapshot[:bitmap].nil? || snapshot[:bitmap].disposed?
        snapshot[:bitmap].dispose if snapshot[:bitmap] && !snapshot[:bitmap].disposed?
        snapshot[:bitmap] = KerberusLegacy18.native('Graphics', :snap_to_bitmap)
        snapshot[:frame] = frame
      end
      color = snapshot[:bitmap].get_pixel(x, y)
      color.red.to_i | (color.green.to_i << 8) | (color.blue.to_i << 16)
    end
    provide(g, 'SetPixel', :limited, 'a tela do jogo nao aceita desenho GDI; CLR_INVALID', 4) { |a| 0xffffffff }

    w = 'winmm'
    # JOYINFOEX from the SDL game controller mkxp-z opened (player 0).
    joy_buttons = [[0, 0x1], [1, 0x2], [2, 0x4], [3, 0x8], [9, 0x10], [10, 0x20], [4, 0x40], [6, 0x80], [7, 0x100], [8, 0x200]]
    joy_state = lambda do
      next nil unless InputBridge.controller_connected?
      pad = InputBridge.xinput_pad
      mask = 0
      bits = pad[0]
      xmap = { 0x1000 => 0, 0x2000 => 1, 0x4000 => 2, 0x8000 => 3, 0x0100 => 9, 0x0200 => 10, 0x0020 => 4, 0x0010 => 6, 0x0040 => 7, 0x0080 => 8 }
      xmap.each { |bit, sdl| mask |= (joy_buttons.assoc(sdl) || [0, 0])[1] if (bits & bit) != 0 }
      pov = 0xffff
      pov = 0 if (bits & 0x1) != 0
      pov = 9000 if (bits & 0x8) != 0
      pov = 18000 if (bits & 0x2) != 0
      pov = 27000 if (bits & 0x4) != 0
      axis = lambda { |value, invert| v = invert ? -value : value; ((v + 32768) & 0xffff) }
      [axis.call(pad[3], false), axis.call(pad[4], true), (pad[1] * 257) & 0xffff, axis.call(pad[5], false), axis.call(pad[6], true), (pad[2] * 257) & 0xffff, mask, pov]
    end
    provide(w, 'joyGetNumDevs', :native, '16 posicoes de joystick, como o driver do Windows', 0) { |a| 16 }
    provide(w, 'joyGetPosEx', :native, 'controle SDL do jogador 0', 2) do |a|
      next 165 unless a[0].to_i == 0
      state = joy_state.call
      next 167 if state.nil?
      Buffers.need(a[1], 52, true, 'JOYINFOEX')
      count = 0
      10.times { |bit| count += 1 if (state[6] >> bit) & 1 == 1 }
      Buffers.put(a[1], [state[0], state[1], state[2], state[3], state[4], state[5], state[6], count, state[7]].pack('V9'), 8)
      0
    end
    provide(w, 'joyGetPos', :native, 'controle SDL do jogador 0', 2) do |a|
      next 165 unless a[0].to_i == 0
      state = joy_state.call
      next 167 if state.nil?
      Buffers.put(a[1], [state[0], state[1], state[2], state[6] & 0xf].pack('V4'), 0)
      0
    end
    provide(w, 'joyGetDevCapsA', :native, 'controle SDL como gamepad de 10 botoes e 6 eixos', 3) do |a|
      next 165 unless a[0].to_i == 0
      next 167 unless InputBridge.controller_connected?
      name = 'Kerberus Gamepad'
      caps = [0x045E, 0x028E].pack('vv') + name + "\0" * (32 - name.length) +
             [0, 65535, 0, 65535, 0, 65535, 10, 10, 1000, 0, 65535, 0, 65535, 0, 65535, 0x1F, 6, 6, 10].pack('V19') + "\0" * 292
      Buffers.put(a[1], caps[0, [a[2].to_i, caps.length].min], 0)
      0
    end

    n = 'wininet'
    offline = 'rede desativada no Kerberus (mesma politica do Winsock): sem conexao'
    provide(n, 'InternetGetConnectedState', :limited, offline, 2) do |a|
      Buffers.put_u32(a[0], 0x20, 0) unless Buffers.null?(a[0])
      0
    end
    provide(n, 'InternetOpenA', :limited, offline, 5) { |a| WinBridge.success(Handles.add(:internet, nil)) }
    provide(n, 'InternetOpenUrlA', :limited, offline, 6) { |a| WinBridge.failure(ERROR_INTERNET_NAME_NOT_RESOLVED, 0) }
    provide(n, 'InternetReadFile', :limited, offline, 4) { |a| WinBridge.failure(ERROR_INVALID_HANDLE, 0) }
    provide(n, 'InternetCloseHandle', :limited, offline, 1) do |a|
      Handles.kind(a[0]) == :internet && Handles.close(a[0]) ? WinBridge.success(1) : WinBridge.failure(ERROR_INVALID_HANDLE, 0)
    end
    provide('urlmon', 'URLDownloadToFileA', :limited, offline, 5) { |a| WinBridge.to_i32(0x800C0005) }

    provide('ntdll', 'RtlZeroMemory', :native, 'zera buffer Ruby/heap virtual', 2) { |a| Memory.write(a[0], "\0" * a[1].to_i); 0 }
    provide('psapi', 'GetProcessMemoryInfo', :native, 'memoria real do processo (/proc/self/status)', 3) do |a|
      next WinBridge.failure(ERROR_INVALID_HANDLE, 0) unless WinBridge.to_i32(a[0].to_i) == -1
      status = KerberusLegacy18.raw_file?('/proc/self/status') ? KerberusLegacy18.raw_read('/proc/self/status') : ''
      field = lambda { |key| status =~ /^#{key}:\s+(\d+)\s+kB/ ? [$1.to_i * 1024, 0xffffffff].min : 0 }
      data = [40, 0, field.call('VmHWM'), field.call('VmRSS'), 0, 0, 0, 0, field.call('VmSize'), field.call('VmPeak')].pack('V10')
      Buffers.put(a[1], data[0, [a[2].to_i, 40].min], 0)
      WinBridge.success(1)
    end
    provide('advapi32', 'RegEnumKeyExA', :native, 'subchaves do registro virtual', 8) { |a| Registry.enum_key(a[0], a[1].to_i, a[2], a[3]) }
  end
end
