# Kerberus Paths - Windows-like path semantics for Ruby-level file APIs.
#
# mkxp-z already resolves RGSS loads (Bitmap, Audio, load_data, RGSSAD)
# through PhysFS. Scripts that use File/Dir/IO directly hit the Android
# filesystem, which is case-sensitive and does not know "\". Here:
#   * the exact path is always tried first (one stat on the fast path);
#   * only on a miss, "\" becomes "/" and every component is matched
#     case-insensitively against a cached directory index;
#   * writes to a name that exists with another case reuse that file,
#     like NTFS, instead of creating a duplicate.
# Game files are never renamed or copied.
module KerberusLegacy18
  module Paths
    MISS_LIMIT = 2048
    @dirs = {}
    @miss = {}
    @installed = false

    def self.reset!
      @dirs = {}
      @miss = {}
    end

    def self.installed?
      @installed
    end

    def self.raw_exist?(path)
      @installed ? File.kerberus_raw_exist?(path) : File.exist?(path)
    end

    def self.raw_directory?(path)
      @installed ? File.kerberus_raw_directory?(path) : File.directory?(path)
    end

    def self.raw_entries(path)
      @installed ? Dir.kerberus_raw_entries(path) : Dir.entries(path)
    end

    def self.invalidate(path)
      @miss.clear unless @miss.empty?
      return unless path.is_a?(String)
      directory = File.dirname(path.tr('\\', '/'))
      @dirs.delete(directory)
      @dirs.delete('.') if directory == '.'
    end

    def self.clear_misses
      @miss.clear unless @miss.empty?
    end

    def self.resolve(path, create)
      return path unless path.is_a?(String) && !path.empty?
      text = path.index('\\') ? path.tr('\\', '/') : path
      return text if raw_exist?(text)
      return text if !create && @miss[text]
      found = walk(text, create)
      return found if found
      @miss.clear if @miss.size >= MISS_LIMIT
      @miss[text] = true unless create
      text
    end

    def self.join(base, part)
      return part if base == '.'
      return '/' + part if base == '/'
      base + '/' + part
    end

    def self.walk(text, create)
      absolute = text[0, 1] == '/'
      parts = text.split('/').reject { |part| part.empty? }
      return nil if parts.empty?
      base = absolute ? '/' : '.'
      parts.each_with_index do |part, index|
        candidate = join(base, part)
        if part == '.' || part == '..' || raw_exist?(candidate)
          base = candidate
          next
        end
        actual = lookup(base, part)
        if actual
          base = join(base, actual)
        elsif create && index == parts.length - 1
          base = candidate
        else
          return nil
        end
      end
      base
    end

    def self.lookup(directory, name)
      index = directory_index(directory)
      index ? index[name.downcase] : nil
    end

    def self.directory_index(directory)
      return nil unless raw_directory?(directory)
      stamp = File.mtime(directory).to_i
      cached = @dirs[directory]
      return cached[1] if cached && cached[0] == stamp
      index = {}
      raw_entries(directory).sort.each do |entry|
        next if entry == '.' || entry == '..'
        key = entry.downcase
        index[key] = entry unless index.has_key?(key)
      end
      @dirs.clear if @dirs.size >= 256
      @dirs[directory] = [stamp, index]
      index
    end

    def self.write_mode?(mode)
      if mode.is_a?(String)
        mode.index('w') || mode.index('a') || mode.index('+') ? true : false
      elsif mode.is_a?(Integer)
        (mode & (File::WRONLY | File::RDWR | File::CREAT | File::APPEND)) != 0
      else
        false
      end
    end

    # A write to a save-like file is evidence for the SAVE milestone.
    def self.written(path)
      invalidate(path)
      Milestones.save_candidate(path) if defined?(Milestones)
    end

    # ------------------------------------------------------------------
    # Wrappers. Predicates retry only when the raw answer is negative;
    # raising methods retry only on ENOENT/ENOTDIR.
    # ------------------------------------------------------------------
    PREDICATES = %w(exist? exists? file? directory? readable? writable? executable? size? zero?)
    RAISING = %w(size mtime atime ctime stat lstat ftype readlines read foreach)
    MUTATING = %w(delete unlink)

    def self.raw_name(name)
      'kerberus_paths_' + name.sub('?', '').sub('[]', 'index') + (name[-1, 1] == '?' ? '?' : '')
    end

    def self.wrap_predicate(owner, name)
      raw = raw_name(name)
      return if owner.method_defined?(raw) || !owner.method_defined?(name)
      owner.send(:alias_method, raw, name)
      owner.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        def #{name}(path, *rest)
          value = #{raw}(path, *rest)
          return value if value || !path.is_a?(String)
          fixed = KerberusLegacy18::Paths.resolve(path, false)
          fixed == path ? value : #{raw}(fixed, *rest)
        end
      RUBY
    end

    def self.wrap_raising(owner, name, mutating)
      raw = raw_name(name)
      return if owner.method_defined?(raw) || !owner.method_defined?(name)
      owner.send(:alias_method, raw, name)
      after = mutating ? 'KerberusLegacy18::Paths.invalidate(path)' : ''
      owner.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        def #{name}(path, *rest, &block)
          begin
            result = #{raw}(path, *rest, &block)
            #{after}
            result
          rescue Errno::ENOENT, Errno::ENOTDIR
            raise unless path.is_a?(String)
            fixed = KerberusLegacy18::Paths.resolve(path, false)
            raise if fixed == path
            result = #{raw}(fixed, *rest, &block)
            #{mutating ? 'KerberusLegacy18::Paths.invalidate(fixed)' : ''}
            result
          end
        end
      RUBY
    end

    def self.install
      return false if @installed
      file_meta = KerberusLegacy18.meta(File)
      filetest_meta = KerberusLegacy18.meta(FileTest)
      io_meta = KerberusLegacy18.meta(IO)
      dir_meta = KerberusLegacy18.meta(Dir)

      # Raw helpers used by Kerberus itself (never resolved, never logged).
      file_meta.send(:alias_method, :kerberus_raw_exist?, :exist?)
      file_meta.send(:alias_method, :kerberus_raw_file?, :file?)
      file_meta.send(:alias_method, :kerberus_raw_directory?, :directory?)
      file_meta.send(:alias_method, :kerberus_raw_size, :size)
      dir_meta.send(:alias_method, :kerberus_raw_entries, :entries)

      PREDICATES.each do |name|
        wrap_predicate(file_meta, name)
        wrap_predicate(filetest_meta, name)
      end
      %w(size mtime atime ctime stat lstat ftype).each { |name| wrap_raising(file_meta, name, false) }
      wrap_raising(filetest_meta, 'size', false)
      %w(read readlines foreach).each { |name| wrap_raising(io_meta, name, false) }
      MUTATING.each { |name| wrap_raising(file_meta, name, true) }
      %w(entries foreach rmdir delete unlink).each { |name| wrap_raising(dir_meta, name, %w(rmdir delete unlink).include?(name)) }

      File.class_eval(<<-RUBY, 'Kerberus Paths', 1)
        alias_method :kerberus_raw_initialize, :initialize
        def initialize(path, *rest, &block)
          if path.is_a?(String)
            if KerberusLegacy18::Paths.write_mode?(rest[0])
              path = KerberusLegacy18::Paths.resolve(path, true)
              kerberus_raw_initialize(path, *rest, &block)
              KerberusLegacy18::Paths.written(path)
              return
            end
            # Ruby 1.8 cannot re-run File#initialize after a failed open
            # ("reinitializing File"), so resolve before opening.
            path = KerberusLegacy18::Paths.resolve(path, false) unless File.kerberus_raw_exist?(path)
          end
          kerberus_raw_initialize(path, *rest, &block)
        end
      RUBY
      file_meta.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        def kerberus_raw_open(path, mode)
          file = allocate
          file.send(:kerberus_raw_initialize, path, mode)
          file
        end

        alias_method :kerberus_raw_rename, :rename
        def rename(from, to)
          source = from.is_a?(String) ? KerberusLegacy18::Paths.resolve(from, false) : from
          target = to.is_a?(String) ? KerberusLegacy18::Paths.resolve(to, true) : to
          result = kerberus_raw_rename(source, target)
          KerberusLegacy18::Paths.invalidate(source)
          KerberusLegacy18::Paths.written(target)
          result
        end
      RUBY
      Dir.class_eval(<<-RUBY, 'Kerberus Paths', 1)
        alias_method :kerberus_raw_initialize, :initialize
        def initialize(path, *rest)
          path = KerberusLegacy18::Paths.resolve(path, false) if path.is_a?(String) && !File.kerberus_raw_directory?(path)
          kerberus_raw_initialize(path, *rest)
        end
      RUBY
      dir_meta.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        alias_method :kerberus_raw_mkdir, :mkdir
        def mkdir(path, *rest)
          target = path.is_a?(String) ? KerberusLegacy18::Paths.resolve(path, true) : path
          result = kerberus_raw_mkdir(target, *rest)
          KerberusLegacy18::Paths.invalidate(target)
          result
        end

        alias_method :kerberus_raw_chdir, :chdir
        def chdir(*args, &block)
          if args[0].is_a?(String) && !kerberus_raw_exist_dir?(args[0])
            args[0] = KerberusLegacy18::Paths.resolve(args[0], false)
          end
          # Caches hold relative paths: they belong to one working directory.
          KerberusLegacy18::Paths.reset!
          return kerberus_raw_chdir(*args) unless block
          begin
            kerberus_raw_chdir(*args) do |path|
              KerberusLegacy18::Paths.reset!
              block.call(path)
            end
          ensure
            KerberusLegacy18::Paths.reset!
          end
        end

        def kerberus_raw_exist_dir?(path)
          File.kerberus_raw_directory?(path)
        end

        alias_method :kerberus_raw_glob, :glob
        def glob(pattern, *rest, &block)
          result = kerberus_raw_glob(pattern, *rest)
          if result.empty? && pattern.is_a?(String)
            fixed = KerberusLegacy18::Paths.glob_pattern(pattern)
            flags = (rest[0] || 0) | File::FNM_CASEFOLD
            result = kerberus_raw_glob(fixed, flags) if fixed
          end
          return result unless block
          result.each { |item| block.call(item) }
          nil
        end

        alias_method :kerberus_raw_index, :[]
        def [](*patterns)
          result = []
          patterns.each { |pattern| result.concat(glob(pattern)) }
          result
        end
      RUBY
      Kernel.module_eval(<<-RUBY, 'Kerberus Paths', 1)
        alias_method :kerberus_raw_load, :load
        def load(path, *rest)
          begin
            kerberus_raw_load(path, *rest)
          rescue LoadError
            raise unless path.is_a?(String)
            fixed = KerberusLegacy18::Paths.resolve(path, false)
            raise if fixed == path
            kerberus_raw_load(fixed, *rest)
          end
        end
        module_function :load
      RUBY
      if Kernel.private_method_defined?(:save_data) || Kernel.method_defined?(:save_data)
        Kernel.module_eval(<<-RUBY, 'Kerberus Paths', 1)
          alias_method :kerberus_raw_save_data, :save_data
          def save_data(object, path)
            target = path.is_a?(String) ? KerberusLegacy18::Paths.resolve(path, true) : path
            result = kerberus_raw_save_data(object, target)
            KerberusLegacy18::Paths.written(target)
            result
          end
          module_function :save_data
        RUBY
      end
      @installed = true
      KerberusLegacy18.event('FILESYSTEM', 'Paths', 'caminhos estilo Windows (\\ e maiusculas/minusculas) para File/Dir/IO')
      true
    end

    # Resolves the literal directory prefix of a glob pattern.
    def self.glob_pattern(pattern)
      text = pattern.tr('\\', '/')
      wild = text.index(/[\*\?\[\{]/)
      return (text == pattern ? nil : text) unless wild
      slash = text.rindex('/', wild)
      return text == pattern ? nil : text unless slash
      prefix = resolve(text[0, slash], false)
      prefix + text[slash, text.length - slash]
    end
  end
end
