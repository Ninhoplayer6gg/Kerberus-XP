# Kerberus - Windows process environment and files created while the game
# runs (6.4.2).
#
# RGSS1 games run as Windows processes: ENV["TEMP"], ENV["APPDATA"] ... exist,
# and a file the game writes can be opened with Bitmap.new at once. On Android
# neither holds:
#  * ENV has no Windows variables. Pokemon Essentials v16/v17 builds paths
#    with ENV["TEMP"]+"\\tempscreen.bmp" (Sprite_Resizer, audio recording,
#    GIF frames), which stops the game with NoMethodError on nil (Pokemon
#    Uranium, title screen).
#  * mkxp-z resolves Bitmap.new through a path cache built when the game
#    starts; a file created later is "No such file or directory".
# WinEnv.install gives the process the Windows variables it lacks, pointing
# at real writable folders inside the game (.kerberus/...); a variable that
# already exists is never changed. Bitmap.new retries once, after reloading
# the engine's path cache, only when the file really exists on disk; a path
# inside the game folder given as absolute is retried as relative. A missing
# file still raises the original error.
module KerberusLegacy18
  module WinEnv
    FOLDERS = [['TEMP', 'temp'], ['TMP', 'temp'], ['APPDATA', 'appdata/Roaming'],
               ['LOCALAPPDATA', 'appdata/Local'], ['USERPROFILE', 'profile']]
    VALUES = [['USERNAME', 'Player'], ['COMPUTERNAME', 'KERBERUS'], ['OS', 'Windows_NT']]
    IMAGE_EXTENSIONS = ['', '.png', '.jpg', '.jpeg', '.bmp', '.gif']

    @installed = []
    @reloaded = {}
    class << self
      attr_reader :installed
    end

    def self.root
      File.join(Dir.pwd, '.kerberus')
    end

    def self.install
      return @installed unless @installed.empty?
      FOLDERS.each do |name, folder|
        next if present?(name)
        path = File.join(root, folder)
        begin
          KerberusLegacy18.ensure_dir(path)
        rescue SystemCallError => error
          KerberusLegacy18.event('WINENV_FAILED', name, path + ': ' + error.message, true)
          next
        end
        ENV[name] = path
        @installed << name
      end
      VALUES.each do |name, value|
        next if present?(name)
        ENV[name] = value
        @installed << name
      end
      @installed.each { |name| WinBridge::Env.set(name, ENV[name]) } if defined?(WinBridge::Env)
      unless @installed.empty?
        KerberusLegacy18.event('WINENV', 'ENV', 'variaveis do Windows criadas: ' + @installed.join(', ') +
                               ' (pastas reais em .kerberus/ dentro do jogo)', true)
      end
      install_bitmap_retry
      @installed
    end

    def self.present?(name)
      value = ENV[name]
      !value.nil? && !value.empty?
    end

    def self.install_bitmap_retry
      return false unless defined?(::Bitmap) && KerberusLegacy18.native?('System', :reload_cache)
      return false if ::Bitmap.method_defined?(:kerberus_env_initialize)
      ::Bitmap.class_eval(<<-RUBY, 'Kerberus WinEnv', 1)
        alias_method :kerberus_env_initialize, :initialize
        def initialize(*args)
          kerberus_env_initialize(*args)
        rescue Errno::ENOENT
          path = KerberusLegacy18::WinEnv.retry_path(args[0])
          raise unless path
          args[0] = path
          kerberus_env_initialize(*args)
        end
      RUBY
      true
    end

    # Path to retry with, or nil (then the original error stands).
    def self.retry_path(path)
      return nil unless path.is_a?(String) && !path.empty?
      text = path.tr('\\', '/')
      base = Dir.pwd + '/'
      relative = text.index(base) == 0 ? text[base.length..-1] : text
      return nil if relative =~ /\A\// || relative =~ /\A[A-Za-z]:/
      found = IMAGE_EXTENSIONS.find { |ext| Paths.raw_exist?(relative + ext) && !Paths.raw_directory?(relative + ext) }
      found ||= IMAGE_EXTENSIONS.find do |ext|
        resolved = Paths.resolve(relative + ext, false)
        Paths.raw_exist?(resolved) && !Paths.raw_directory?(resolved)
      end
      return nil unless found
      key = relative.downcase
      return nil if @reloaded[key]
      @reloaded[key] = true
      KerberusLegacy18.native('System', :reload_cache)
      KerberusLegacy18.event('RUNTIME_FILE', 'Bitmap.new', 'arquivo criado durante o jogo (' + relative +
                             '); cache de caminhos do mkxp-z recarregado', true)
      relative
    end

    def self.forget_reloads!
      @reloaded = {}
    end
  end
end
