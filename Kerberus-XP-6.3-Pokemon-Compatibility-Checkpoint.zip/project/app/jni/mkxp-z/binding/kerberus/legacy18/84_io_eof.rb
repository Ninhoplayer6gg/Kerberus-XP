# Kerberus - IO#eof? of the Ruby 1.8 on Android (6.4.3).
#
# Bionic hides the stdio FILE, so Ruby 1.8's IO#eof? could not see the
# buffer and trusted the EOF flag, which a seek clears: at the end of a file
# eof? answered false and the next read returned nil (Pokemon Uranium, OGG
# length at the title screen). The APK's interpreter carries the fix
# (scripts/patch-ruby18-io.py, IO.kerberus_eof_probe). An interpreter without
# it (an older Termux build) is checked once with a real file and, only when
# it gives the wrong answer, gets IO#eof? here: read one character and push it
# back, what the interpreter itself does after its buffer shortcut.
module KerberusLegacy18
  module IoEof
    @mode = nil
    class << self
      attr_reader :mode
    end

    def self.install
      return @mode if @mode
      if ::IO.respond_to?(:kerberus_eof_probe)
        @mode = :interpreter
        KerberusLegacy18.event('RUBY18_IO', 'IO#eof?', ::IO.kerberus_eof_probe ?
                               'interpretador le o arquivo (stdio do Android)' : 'interpretador le o buffer do stdio', true)
      elsif wrong_at_end?
        install_override
        @mode = :bootstrap
        KerberusLegacy18.event('RUBY18_IO', 'IO#eof?', 'interpretador sem o patch de IO: eof? por leitura no bootstrap', true)
      else
        @mode = :native
      end
      @mode
    end

    # Does eof? answer false at the end of a file after a seek?
    def self.wrong_at_end?
      path = File.join(Dir.pwd, '.kerberus', 'temp', 'kerberus-eof-check.bin')
      begin
        KerberusLegacy18.ensure_dir(File.dirname(path))
        File.open(path, 'wb') { |file| file.write('OggS') }
        File.open(path, 'rb') do |file|
          file.pos = 4
          return !file.eof?
        end
      rescue SystemCallError, IOError => error
        KerberusLegacy18.event('RUBY18_IO', 'IO#eof?', 'verificacao impossivel: ' + error.message, true)
        false
      ensure
        begin
          File.delete(path) if File.exist?(path)
        rescue SystemCallError
        end
      end
    end

    def self.install_override
      return false if ::IO.method_defined?(:kerberus_stdio_eof?)
      ::IO.class_eval(<<-RUBY, 'Kerberus IoEof', 1)
        alias_method :kerberus_stdio_eof?, :eof?
        def eof?
          byte = getc
          return true if byte.nil?
          ungetc(byte)
          false
        end
        alias_method :eof, :eof?
      RUBY
      true
    end
  end
end
