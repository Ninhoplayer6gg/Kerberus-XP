# Kerberus - RGSS1 class semantics (Ruby 1.8.1).
#
# RPG Maker XP runs game scripts on Ruby 1.8.1. When a script reopened a
# class with a DIFFERENT superclass, 1.8.1 defined a new class under that
# name (eval.c, NODE_CLASS, "goto override_class"). Ruby 1.8.2 and later
# raise "superclass mismatch for class X" instead, so games written against
# RGSS1 stop while loading (Pokemon Uranium: Window_PokemonBag).
#
# Since 6.3.3 the Kerberus Ruby 1.8 interpreter carries the 1.8.1 rule
# itself (scripts/patch-ruby18-rgss1.py). The bootstrap detects it with a
# probe and only installs the reporting hook. An interpreter without the
# patch (older build, stock 1.8.7) gets the previous fallback: every
# "class Name < ConstantPath" statement of the game scripts gets, on its
# own line (line numbers unchanged), a guard that removes Name first when
# its superclass differs. KERBERUS_RUBY181=transform forces the fallback.
module KerberusLegacy18
  module Ruby181
    PATH = '(?:::)?[A-Z][A-Za-z0-9_]*(?:::[A-Z][A-Za-z0-9_]*)*'
    CLASS_LINE = /\A([ \t]*)class[ \t]+(#{PATH})[ \t]*<[ \t]*(#{PATH})[ \t]*(?:;|#|\r?\z)/
    ANY_CLASS = /^[ \t]*class[ \t]+#{PATH}[ \t]*<[ \t]*#{PATH}/

    @overrides = []
    class << self
      attr_reader :overrides
    end

    # Runs in the game's scope right before its class statement (fallback).
    def self.reopen(scope, name, superclass, section, line)
      cbase = scope.is_a?(Module) ? scope : Object
      return nil unless superclass.is_a?(Class) && cbase.const_defined?(name)
      klass = cbase.const_get(name)
      return nil unless klass.is_a?(Class)
      previous = klass.superclass
      return nil if previous == superclass
      cbase.send(:remove_const, name)
      record(cbase, name, previous, superclass, format('Section%03d:%d', section, line))
      nil
    end

    def self.record(cbase, name, previous, superclass, where)
      prefix = cbase == Object || cbase.name.to_s.empty? ? '' : cbase.name.to_s + '::'
      label = prefix + name.to_s
      @overrides << [where, label, previous, superclass]
      KerberusLegacy18.event('RUBY181_CLASS_OVERRIDE', where,
                             label + ': superclasse ' + previous.to_s + ' -> ' + superclass.to_s +
                             ' (classe nova, como no Ruby 1.8.1 do RGSS1)', true)
      nil
    end

    def self.where(frames)
      frames.each { |frame| return $1 + ':' + $2 if frame =~ /\A(Section\d+):(\d+)/ }
      '?'
    end

    # Called by the patched eval.c (cbase, name, old and new superclass).
    HOOK = lambda do |cbase, name, previous, superclass|
      KerberusLegacy18::Ruby181.record(cbase, name, previous, superclass,
                                       KerberusLegacy18::Ruby181.where(caller(0)))
    end

    # True when the interpreter itself applies the 1.8.1 rule.
    def self.interpreter_rule?
      return @interpreter unless @interpreter.nil?
      probe = Module.new
      begin
        probe.module_eval("class ProbeBase; end\nclass Probe < ProbeBase; end\nclass Probe < Object; end\n",
                          'Kerberus RGSS1 probe', 1)
        @interpreter = probe.const_get(:Probe).superclass == Object
      rescue TypeError
        @interpreter = false
      end
      @interpreter
    end

    # [text, guarded statements]; the line count never changes.
    def self.transform(text, section)
      return [text, 0] unless text =~ ANY_CLASS
      lines = text.split("\n", -1)
      comment = false
      count = 0
      lines.each_with_index do |line, index|
        if comment
          comment = false if line =~ /\A=end(?:\s|\z)/
          next
        end
        if line =~ /\A=begin(?:\s|\z)/
          comment = true
          next
        end
        match = CLASS_LINE.match(line)
        next unless match
        path = match[2]
        cut = path.rindex('::')
        if cut
          scope = cut == 0 ? 'Object' : path[0, cut]
          name = path[cut + 2..-1]
        else
          scope = 'self'
          name = path
        end
        guard = 'KerberusLegacy18::Ruby181.reopen(' + scope + ', ' + name.inspect + ', ' + match[3] + ', ' +
                section.to_s + ', ' + (index + 1).to_s + ');'
        lines[index] = match[1] + guard + line[match[1].length..-1]
        count += 1
      end
      [lines.join("\n"), count]
    end

    def self.apply_all(scripts)
      return 0 unless scripts.is_a?(Array)
      if interpreter_rule? && ENV['KERBERUS_RUBY181'] != 'transform'
        $__kerberus_rgss1_class_override = HOOK
        KerberusLegacy18.event('RUBY181_CLASSES', 'RGSS1',
                               'regra de superclasse do Ruby 1.8.1 aplicada pelo interpretador (eval.c)', true)
        return 0
      end
      total = 0
      sections = 0
      scripts.each_with_index do |entry, index|
        next unless entry.is_a?(Array) && entry[3].is_a?(String)
        result, count = transform(entry[3], index)
        next if count == 0
        entry[3] = result
        total += count
        sections += 1
      end
      KerberusLegacy18.event('RUBY181_CLASSES', 'RGSS1',
                             total.to_s + " declaracoes 'class X < Y' em " + sections.to_s +
                             ' secoes seguem a regra de superclasse do Ruby 1.8.1 (bootstrap; interpretador sem o patch)', true)
      total
    end
  end
end
