# Kerberus - Zlib::Inflate.inflate on Android (6.6.1).
#
# On a phone, Pokemon Insurgence stopped at boot with Zlib::DataError
# ("invalid distance too far back") while inflating Data/Constants.rxdata.
# The same data inflates in the desktop build of this engine and under arm64
# emulation, and the Scripts.rxdata loader, which inflates with one zlib call
# in C, works on that phone. When the extension raises Zlib::DataError, the
# input is inflated again by KerberusNative.inflate on a private copy:
# - in 1024-byte steps, the extension's own calling pattern (diagnosis only);
# - in a single call, like the Scripts.rxdata loader.
# The single-call result is returned only when zlib reached the end of the
# stream, which includes zlib's Adler-32 check of the output. Each recovery or
# failure goes to the runtime report with the input's size and CRC-32. When
# the native inflate fails too, the original exception is raised unchanged.
#
# 6.6.2: the phone's report showed the cause. libSDL2_ttf.so exported
# inflateInit_ from FreeType's own zlib copy (Z_SOLO), which the engine bound
# instead of the system's, while inflate stayed in the system zlib. FreeType
# now uses the system zlib (scripts/patch-sdl-ttf-system-zlib.py). At boot one
# [ZLIB] line names the zlib in use and inflates a sample in steps, natively
# with zlib's own allocator (the call that failed with Z_STREAM_ERROR) and
# through Ruby's extension.
module KerberusLegacy18
  module ZlibGuard
    REPORT_LIMIT = 8
    @installed = false
    @reports = 0
    @recovered = 0
    class << self
      attr_reader :installed, :recovered
    end

    def self.available?
      defined?(::Zlib::Inflate) && defined?(::Zlib::DataError) &&
        defined?(::KerberusNative) && ::KerberusNative.respond_to?(:inflate)
    end

    def self.install
      return true if @installed
      return false unless available?
      singleton = class << ::Zlib::Inflate; self; end
      unless singleton.method_defined?(:kerberus_extension_inflate)
        singleton.class_eval(<<-RUBY, 'Kerberus ZlibGuard', 1)
          alias_method :kerberus_extension_inflate, :inflate
          def inflate(source)
            kerberus_extension_inflate(source)
          rescue ::Zlib::DataError => error
            KerberusLegacy18::ZlibGuard.recover(source, error)
          end
        RUBY
      end
      @installed = true
      self_check
      true
    end

    def self.self_check
      sample = ::Zlib::Deflate.deflate('Kerberus zlib ' * 300)
      expected = 'Kerberus zlib ' * 300
      native = ::KerberusNative.inflate(sample, 64)
      problems = []
      problems << 'nativo em partes: ' + describe_result(native) unless native == expected
      begin
        problems << 'extensao Ruby: resultado diferente' unless ::Zlib::Inflate.kerberus_extension_inflate(sample) == expected
      rescue ::Zlib::Error => error
        problems << 'extensao Ruby: ' + error.class.name + ': ' + error.message
      end
      @self_check = problems.empty? ? :ok : problems
      KerberusLegacy18.event('ZLIB', 'zlib ' + ::Zlib.zlib_version.to_s,
                             problems.empty? ? 'inflate em partes ok (nativo e extensao Ruby)' : 'FALHA: ' + problems.join('; '), true)
      @self_check
    end

    def self.self_check_result
      @self_check
    end

    def self.recover(source, error)
      data = source.to_str
      stepped = ::KerberusNative.inflate(data, 1024)
      single = ::KerberusNative.inflate(data, 0)
      recovered = single.is_a?(::String)
      @recovered += 1 if recovered
      report(data, error, stepped, single, recovered)
      raise error unless recovered
      single
    end

    def self.describe_input(data)
      head = data[0, 8].to_s.unpack('H*')[0]
      tail = data.length > 8 ? data[data.length - 8, 8].unpack('H*')[0] : head
      data.length.to_s + ' bytes crc32=' + format('%08x', ::Zlib.crc32(data)) +
        ' inicio=' + head + ' fim=' + tail
    end

    def self.describe_result(result)
      if result.is_a?(::String)
        'ok ' + result.length.to_s + ' bytes crc32=' + format('%08x', ::Zlib.crc32(result))
      else
        'falhou codigo=' + result[0].to_s + ' ' + result[1].to_s
      end
    end

    def self.report(data, error, stepped, single, recovered)
      @reports += 1
      return nil if @reports > REPORT_LIMIT
      where = KerberusLegacy18.location(caller(0))
      outcome = recovered ? 'dados entregues pelo inflate nativo de chamada unica (Adler-32 conferido pelo zlib)' :
                            'inflate nativo tambem falhou: erro original mantido'
      KerberusLegacy18.event('ZLIB_INFLATE', 'Zlib::Inflate.inflate',
                             (recovered ? 'recuperado' : 'falhou') + ' em ' + where[1] + ':' + where[2].to_s, true)
      KerberusLegacy18.runtime_block('ZLIB_INFLATE', [
        ['script', where[0]], ['section', where[1]], ['line', where[2]],
        ['erro', error.class.name + ': ' + error.message],
        ['entrada', describe_input(data)],
        ['zlib', 'biblioteca=' + ::Zlib.zlib_version.to_s + ' cabecalho=' + ::Zlib::ZLIB_VERSION.to_s],
        ['nativo_1024', describe_result(stepped)],
        ['nativo_unico', describe_result(single)],
        ['resultado', outcome]])
    end
  end
end
