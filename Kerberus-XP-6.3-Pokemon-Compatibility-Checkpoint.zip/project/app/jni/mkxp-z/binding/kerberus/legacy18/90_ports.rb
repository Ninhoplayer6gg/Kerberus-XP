# Kerberus Ports - in-memory replacement of Windows-only script systems.
#
# A port is declared with markers (every string must appear in the section),
# an optional whole-game condition and a transformation. Game files are
# never touched: only $RGSS_SCRIPTS[i][3], already decoded in memory, is
# replaced before the section runs. Ports that replace a section declare
# the names they provide; missing top-level names are reported (and block
# the port when it is strict) so an incomplete replacement never hides a
# NameError behind a successful boot.
module KerberusLegacy18
  module Ports
    class Port
      attr_reader :id, :title, :markers, :condition, :strict, :provides, :transform

      def initialize(id, title, markers, options, transform)
        @id = id
        @title = title
        @markers = markers
        @condition = options[:condition]
        @strict = options[:strict] ? true : false
        @provides = options[:provides] || []
        @transform = transform
      end

      def matches?(source)
        @markers.all? { |marker| source.index(marker) }
      end
    end

    @registry = []
    @applied = []

    def self.reset!
      @applied = []
    end

    def self.registry
      @registry
    end

    def self.applied
      @applied
    end

    def self.register(id, title, markers, options, &transform)
      @registry.delete_if { |port| port.id == id }
      @registry << Port.new(id, title, markers, options, transform)
    end

    def self.find(id)
      @registry.find { |port| port.id == id }
    end

    # ------------------------------------------------------------------
    # Source helpers (line-count preserving where it matters)
    # ------------------------------------------------------------------
    module Source
      TOP_DEF = /^def\s+(?:self\.)?([A-Za-z_]\w*[?!=]?)/
      TOP_TYPE = /^(?:class|module)\s+([A-Z]\w*(?:::[A-Z]\w*)*)/

      def self.definitions(text)
        names = []
        text.each_line do |line|
          names << $1 if line =~ TOP_DEF || line =~ TOP_TYPE
        end
        names.uniq
      end

      def self.lines(text)
        text.count("\n")
      end

      # Pads replacement with blank lines so later line numbers stay valid.
      def self.pad(original, replacement)
        missing = lines(original) - lines(replacement)
        missing > 0 ? replacement + "\n" * missing : replacement
      end

      def self.method_body(source, name, body)
        expression = /^([ \t]*)def #{Regexp.escape(name)}(?=[ \t(\n;])(?:\([^\n]*\)|[^\n]*)\n.*?^\1end\b/m
        matches = []
        source.scan(expression) { matches << $1 }
        raise ArgumentError, 'metodo ambiguo ou ausente: ' + name unless matches.length == 1
        source.sub(expression) do |old|
          indent = matches[0]
          head = old.split("\n")[0] + "\n"
          inner = body.split("\n").map { |line| indent + '  ' + line + "\n" }.join
          pad(old, head + inner + indent + 'end')
        end
      end
    end

    def self.disabled?(port)
      KerberusLegacy18.config[:ports_disabled].include?(port.id)
    end

    def self.apply_all(scripts)
      return 0 unless scripts.is_a?(Array)
      unless KerberusLegacy18.config[:ports]
        KerberusLegacy18.event('PORTS_DISABLED', 'Kerberus Ports', 'desativado pelo usuario (KERBERUS_COMPAT_MODE=off)', true)
        return 0
      end
      count = 0
      scripts.each_with_index do |entry, index|
        next unless entry.is_a?(Array) && entry[3].is_a?(String)
        @registry.each do |port|
          source = entry[3]
          next unless port.matches?(source)
          next if port.condition && !port.condition.call(scripts)
          label = format('Section%03d', index) + ' (' + (KerberusLegacy18.script_name(index) || '?') + ')'
          if disabled?(port)
            KerberusLegacy18.event('PORT_DISABLED', port.id, label, true)
            next
          end
          begin
            result = port.transform.call(source, index, scripts)
          rescue StandardError => error
            # A port that cannot parse this variant leaves the original
            # section untouched; the WinBridge still reports any API call.
            KerberusLegacy18.event('PORT_FAILED', port.id, label + ' ' + error.class.name + ': ' + error.message, true)
            next
          end
          next if result.nil? || result == source
          unless port.provides.empty? && !(result.length < source.length / 2)
            missing = Source.definitions(source) - Source.definitions(result) - port.provides
            unless missing.empty?
              text = 'nomes do script original sem equivalente: ' + missing.first(12).join(', ')
              if port.strict
                KerberusLegacy18.event('PORT_SKIPPED', port.id, label + ' ' + text, true)
                next
              end
              KerberusLegacy18.event('PORT_COVERAGE', port.id, label + ' ' + text, true)
            end
          end
          entry[3] = result
          @applied << [port.id, index]
          count += 1
          KerberusLegacy18.event('PORT_APPLIED', port.id + ' ' + label, port.title, true)
        end
      end
      count
    end

    # ==================================================================
    # Port implementations (installed when the replaced section runs)
    # ==================================================================
    module Linker
      def self.install
        Kernel.module_eval(<<-RUBY, 'Kerberus Ports', 1)
          def load_module(library, symbol)
            KerberusLegacy18::Ports::Linker.load(library, symbol)
          end
          module_function :load_module
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'rgss_linker', 'load_module nativo: RGSS FmodEx -> Audio nativo')
      end

      def self.load(library, symbol)
        name = KerberusLegacy18::WinBridge.library(library.to_s)
        if (name == 'rgss_fmodex' || name == 'fmodex' || name == 'rgss fmodex') && symbol.to_s == 'Init_FmodEx'
          EssentialsAudio.install(:fmod)
          return true
        end
        where = KerberusLegacy18.here
        KerberusLegacy18.runtime_block('WINBRIDGE', [['error', 'RGSS_LINKER_EXTENSION'], ['library', library.to_s],
                                                     ['symbol', symbol.to_s], ['script', where[0]],
                                                     ['section', where[1]], ['line', where[2]], ['runtime', RUNTIME]])
        raise KerberusLegacy18::WinBridge::Unavailable,
              "WINBRIDGE_UNAVAILABLE\nRGSS Linker: extensao x86 sem port: " + library.to_s + '!' + symbol.to_s
      end
    end

    # Essentials audio API over the single AudioBridge.
    module EssentialsAudio
      BRIDGE = KerberusLegacy18::WinBridge::AudioBridge
      @installed = {}

      def self.installed?(flavor)
        @installed[flavor] ? true : false
      end

      def self.install(flavor)
        return true if @installed[flavor]
        first = @installed.empty?
        @installed[flavor] = true
        BRIDGE.use_profile_volume! if flavor == :fmod
        if first
          Kernel.module_eval(<<-RUBY, 'Kerberus Ports', 1)
            def Audio_bgm_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:bgm, name, volume, pitch, position)
            end
            def Audio_bgm_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:bgm); end
            def Audio_bgm_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:bgm, ms); end
            def Audio_bgm_fadein(ms); KerberusLegacy18::WinBridge::AudioBridge.fade_in(ms); end
            def Audio_bgm_get_position; KerberusLegacy18::WinBridge::AudioBridge.position(:bgm); end
            def Audio_bgm_get_volume
              info = KerberusLegacy18::WinBridge::AudioBridge.info(:bgm)
              info ? info[1] : 0
            end
            def Audio_bgm_set_volume(volume); KerberusLegacy18::WinBridge::AudioBridge.set_volume(:bgm, volume); end
            def Audio_bgm_name
              info = KerberusLegacy18::WinBridge::AudioBridge.info(:bgm)
              info ? info[0] : ''
            end
            def Audio_bgm_pitch
              info = KerberusLegacy18::WinBridge::AudioBridge.info(:bgm)
              info ? info[2] : 100
            end
            def Audio_bgm_playing?; KerberusLegacy18::WinBridge::AudioBridge.playing?(:bgm); end
            def Audio_bgs_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:bgs, name, volume, pitch, position)
            end
            def Audio_bgs_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:bgs); end
            def Audio_bgs_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:bgs, ms); end
            def Audio_me_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:me, name, volume, pitch, position)
            end
            def Audio_me_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:me); end
            def Audio_me_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:me, ms); end
            def Audio_se_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:se, name, volume, pitch, position)
            end
            def Audio_se_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:se); end
            def audio_control_volume(volume); KerberusLegacy18::WinBridge::AudioBridge.set_volume(:bgm, volume); end
            def getPlayMusic; true; end
            def getPlaySound; true; end
            module_function :Audio_bgm_play, :Audio_bgm_stop, :Audio_bgm_fade, :Audio_bgm_fadein,
                            :Audio_bgm_get_position, :Audio_bgm_get_volume, :Audio_bgm_set_volume,
                            :Audio_bgm_name, :Audio_bgm_pitch, :Audio_bgm_playing?,
                            :Audio_bgs_play, :Audio_bgs_stop, :Audio_bgs_fade,
                            :Audio_me_play, :Audio_me_stop, :Audio_me_fade,
                            :Audio_se_play, :Audio_se_stop, :audio_control_volume,
                            :getPlayMusic, :getPlaySound
          RUBY
          # RGSS event commands call Audio.* directly; route them through the
          # same bridge so its state (name, volume, playing?) is always right.
          KerberusLegacy18.meta(::Audio).module_eval(<<-RUBY, 'Kerberus Ports', 1)
            def bgm_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:bgm, name, volume, pitch, position)
            end
            def bgm_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:bgm); end
            def bgm_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:bgm, ms); end
            def bgs_play(name, volume = 100, pitch = 100, position = 0)
              KerberusLegacy18::WinBridge::AudioBridge.play(:bgs, name, volume, pitch, position)
            end
            def bgs_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:bgs); end
            def bgs_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:bgs, ms); end
            def me_play(name, volume = 100, pitch = 100)
              KerberusLegacy18::WinBridge::AudioBridge.play(:me, name, volume, pitch, 0)
            end
            def me_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:me); end
            def me_fade(ms); KerberusLegacy18::WinBridge::AudioBridge.fade(:me, ms); end
            def se_play(name, volume = 100, pitch = 100)
              KerberusLegacy18::WinBridge::AudioBridge.play(:se, name, volume, pitch, 0)
            end
            def se_stop; KerberusLegacy18::WinBridge::AudioBridge.stop(:se); end
            def bgm_position; KerberusLegacy18::WinBridge::AudioBridge.position(:bgm); end
          RUBY
        end
        if flavor == :fmod
          # The Uranium FMOD section also defined this Essentials helper.
          Kernel.module_eval(<<-RUBY, 'Kerberus Ports', 1)
            def safeExists?(file); File.file?(file); end
            module_function :safeExists?
          RUBY
        end
        if flavor == :audio_dll && !Object.const_defined?(:AudioState)
          Object.const_set(:AudioState, Module.new)
          KerberusLegacy18.meta(::AudioState).module_eval(<<-RUBY, 'Kerberus Ports', 1)
            def update; KerberusLegacy18::WinBridge::AudioBridge.tick; end
            def bgmActive?; KerberusLegacy18::WinBridge::AudioBridge.playing?(:bgm); end
            def meActive?; KerberusLegacy18::WinBridge::AudioBridge.playing?(:me); end
            def method_missing(name, *args)
              raise KerberusLegacy18::WinBridge::Unavailable,
                    "WINBRIDGE_UNAVAILABLE\\nport audio_dll: AudioState." + name.to_s + ' ainda sem equivalente'
            end
          RUBY
        end
        KerberusLegacy18.event('PORT_INSTALLED', 'audio.' + flavor.to_s,
                               'BGM/BGS/ME/SE, volume, pitch, fade e fade-in via Audio nativo (canal unico)')
        true
      end
    end

    # KleinBitmap functions over Bitmap#raw_data (RGBA bytes).
    module Klein
      LIMIT = 16 * 1024 * 1024

      def self.bytes(bitmap)
        unless bitmap.is_a?(::Bitmap) && !bitmap.disposed?
          raise ArgumentError, 'KleinBitmap: Bitmap invalido ou descartado'
        end
        if bitmap.width * bitmap.height * 4 > LIMIT
          raise KerberusLegacy18::WinBridge::Unavailable, 'KleinBitmap: bitmap excede 16 MiB'
        end
        if bitmap.respond_to?(:animated?) && bitmap.animated?
          frame = bitmap.snap_to_bitmap
          begin
            return frame.raw_data
          ensure
            frame.dispose
          end
        end
        bitmap.raw_data
      end

      def self.channel(color, name)
        color.respond_to?(name) ? color.send(name).to_i : 0
      end

      def self.scroll(bitmap, dx, dy)
        return bitmap if bitmap.width == 0 || bitmap.height == 0
        dx %= bitmap.width
        dy %= bitmap.height
        temp = bitmap.clone
        begin
          bitmap.clear
          [dx, dx - bitmap.width].each do |x|
            [dy, dy - bitmap.height].each { |y| bitmap.blt(x, y, temp, temp.rect) }
          end
        ensure
          temp.dispose
        end
        bitmap
      end

      def self.negative(bitmap)
        data = bytes(bitmap)
        index = 0
        while index < data.length
          data[index] = 255 - data[index]
          data[index + 1] = 255 - data[index + 1]
          data[index + 2] = 255 - data[index + 2]
          index += 4
        end
        bitmap.raw_data = data
        bitmap
      end

      def self.modify_color(bitmap, from, to)
        data = bytes(bitmap)
        old = [channel(from, :red), channel(from, :green), channel(from, :blue)]
        replacement = [channel(to, :red), channel(to, :green), channel(to, :blue)]
        index = 0
        while index < data.length
          if data[index] == old[0] && data[index + 1] == old[1] && data[index + 2] == old[2]
            data[index] = replacement[0]
            data[index + 1] = replacement[1]
            data[index + 2] = replacement[2]
          end
          index += 4
        end
        bitmap.raw_data = data
        bitmap
      end

      # Documented: repaint using a 4-color palette, c1 darkest .. c4 brightest.
      def self.retro(bitmap, colors)
        raise ArgumentError, 'to_retro requer 4 cores' unless colors.length == 4
        palette = colors.map { |color| [channel(color, :red), channel(color, :green), channel(color, :blue)] }
        data = bytes(bitmap)
        index = 0
        while index < data.length
          if data[index + 3] > 0
            luma = (data[index] * 299 + data[index + 1] * 587 + data[index + 2] * 114) / 1000
            shade = palette[luma * 4 / 256]
            data[index] = shade[0]
            data[index + 1] = shade[1]
            data[index + 2] = shade[2]
          end
          index += 4
        end
        bitmap.raw_data = data
        bitmap
      end

      # Documented: add_outline(color, pixelsize) - colored outline around
      # opaque pixels (8-neighbour dilation, pixelsize times).
      def self.outline(bitmap, color, size)
        size = size.to_i
        return bitmap if size <= 0
        width = bitmap.width
        height = bitmap.height
        data = bytes(bitmap)
        rgba = [channel(color, :red), channel(color, :green), channel(color, :blue), color.respond_to?(:alpha) ? color.alpha.to_i : 255]
        solid = Array.new(width * height, false)
        (0...(width * height)).each { |pixel| solid[pixel] = data[pixel * 4 + 3] > 0 }
        size.times do
          grown = solid.dup
          (0...height).each do |y|
            (0...width).each do |x|
              pixel = y * width + x
              next if solid[pixel]
              hit = false
              (-1..1).each do |oy|
                (-1..1).each do |ox|
                  nx = x + ox
                  ny = y + oy
                  hit = true if !hit && nx >= 0 && ny >= 0 && nx < width && ny < height && solid[ny * width + nx]
                end
              end
              next unless hit
              grown[pixel] = true
              offset = pixel * 4
              data[offset] = rgba[0]
              data[offset + 1] = rgba[1]
              data[offset + 2] = rgba[2]
              data[offset + 3] = rgba[3]
            end
          end
          solid = grown
        end
        bitmap.raw_data = data
        bitmap
      end

      def self.unavailable(name)
        raise KerberusLegacy18::WinBridge::Unavailable,
              "WINBRIDGE_UNAVAILABLE\nKleinBitmap." + name + ': formato de paleta proprietario sem documentacao publica'
      end

      def self.install
        ::Bitmap.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          def scroll_up(speed = 1); KerberusLegacy18::Ports::Klein.scroll(self, 0, -Integer(speed)); end
          def scroll_down(speed = 1); KerberusLegacy18::Ports::Klein.scroll(self, 0, Integer(speed)); end
          def scroll_left(speed = 1); KerberusLegacy18::Ports::Klein.scroll(self, -Integer(speed), 0); end
          def scroll_right(speed = 1); KerberusLegacy18::Ports::Klein.scroll(self, Integer(speed), 0); end
          def to_negative; KerberusLegacy18::Ports::Klein.negative(self); end
          def modify_color(from, to); KerberusLegacy18::Ports::Klein.modify_color(self, from, to); end
          def to_retro(c1, c2, c3, c4); KerberusLegacy18::Ports::Klein.retro(self, [c1, c2, c3, c4]); end
          def add_outline(color, pixelsize = 1); KerberusLegacy18::Ports::Klein.outline(self, color, pixelsize); end
          def save_pallete(*args); KerberusLegacy18::Ports::Klein.unavailable('save_pallete'); end
          def modify_pallete(*args); KerberusLegacy18::Ports::Klein.unavailable('modify_pallete'); end
        RUBY
        ::Sprite.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          attr_accessor :kleinPatternBitmap
          def set_pattern(pattern, alpha, everyframe = false)
            KerberusLegacy18::Ports::Klein.set_pattern(self, pattern, alpha, everyframe)
          end
          def delete_pattern
            KerberusLegacy18::Ports::Klein.delete_pattern(self)
          end
          alias_method :kerberus_klein_dispose, :dispose unless method_defined?(:kerberus_klein_dispose)
          def dispose
            KerberusLegacy18::Ports::Klein.release_pattern(self)
            kerberus_klein_dispose
          end
        RUBY
        Object.const_set(:KLEIN_BFUNCS_WORKING, true) unless Object.const_defined?(:KLEIN_BFUNCS_WORKING)
        Kernel.module_eval(<<-RUBY, 'Kerberus Ports', 1)
          def compare_klein_bitmaps(a, b)
            a.width == b.width && a.height == b.height &&
              KerberusLegacy18::Ports::Klein.bytes(a) == KerberusLegacy18::Ports::Klein.bytes(b)
          end
          def klein_bitmap_version; 1; end
          def klein_dll(*args)
            raise KerberusLegacy18::WinBridge::Unavailable,
                  "WINBRIDGE_UNAVAILABLE\\nKleinBitmap: chamada direta a DLL (" + args.inspect + '); use os metodos Bitmap/Sprite do port'
          end
          module_function :compare_klein_bitmaps, :klein_bitmap_version, :klein_dll
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'klein_bitmap',
                               'scroll, negativo, modify_color, to_retro, add_outline, pattern e comparacao; paletas indisponiveis')
      end

      def self.set_pattern(sprite, pattern, alpha, everyframe)
        raise ArgumentError, 'set_pattern: alpha invalido' unless alpha.is_a?(Numeric)
        bitmap = sprite.bitmap
        source = sprite.instance_variable_get(:@kerberus_pattern_source)
        output = sprite.instance_variable_get(:@kerberus_pattern_output)
        if everyframe || !(output && bitmap.equal?(output))
          next_source = bitmap.respond_to?(:animated?) && bitmap.animated? ? bitmap.snap_to_bitmap : bitmap.clone
          next_output = next_source.clone
          source.dispose if source && !source.disposed?
          output.dispose if output && !output.disposed?
          source = next_source
          output = next_output
          sprite.instance_variable_set(:@kerberus_pattern_source, source)
          sprite.instance_variable_set(:@kerberus_pattern_output, output)
        end
        raise ArgumentError, 'set_pattern: pattern vazio' if pattern.width == 0 || pattern.height == 0
        target = bytes(source)
        pixels = bytes(pattern)
        opacity = alpha.to_f
        opacity = 0.0 if opacity < 0
        opacity = 255.0 if opacity > 255
        opacity /= 255.0
        width = source.width
        count = target.length / 4
        pixel = 0
        while pixel < count
          index = pixel * 4
          if target[index + 3] != 0
            offset = (((pixel / width) % pattern.height) * pattern.width + (pixel % width) % pattern.width) * 4
            mix = opacity * pixels[offset + 3] / 255.0
            3.times do |j|
              target[index + j] = (target[index + j] * (1 - mix) + pixels[offset + j] * mix).round
            end
          end
          pixel += 1
        end
        output.raw_data = target
        sprite.bitmap = output
      end

      def self.delete_pattern(sprite)
        source = sprite.instance_variable_get(:@kerberus_pattern_source)
        output = sprite.instance_variable_get(:@kerberus_pattern_output)
        return nil unless source
        if sprite.bitmap.equal?(output)
          sprite.bitmap = source
        elsif !source.disposed?
          source.dispose
        end
        output.dispose if output && !output.disposed?
        sprite.instance_variable_set(:@kerberus_pattern_source, nil)
        sprite.instance_variable_set(:@kerberus_pattern_output, nil)
        nil
      end

      def self.release_pattern(sprite)
        [:@kerberus_pattern_source, :@kerberus_pattern_output].each do |name|
          item = sprite.instance_variable_get(name)
          item.dispose if item && !item.disposed?
          sprite.instance_variable_set(name, nil)
        end
      end
    end

    # Essentials GifBitmap over mkxp-z animated Bitmap (libnsgif).
    module Gif
      def self.install
        return false unless Object.const_defined?(:GifBitmap)
        ::GifBitmap.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          def initialize(*args)
            file, hue = KerberusLegacy18::Ports::Gif.arguments(args)
            @kerberus_frames = {}
            if file.to_s.tr('\\\\', '/').sub(/\\/+\\z/, '') =~ /\\AGraphics\\/Autotiles\\z/i
              @kerberus_bitmap = Bitmap.new(32, 32)
              return
            end
            path = defined?(RTP) && RTP.respond_to?(:getImagePath) ? (RTP.getImagePath(file) || file) : file
            @kerberus_bitmap = KerberusLegacy18::Ports::Gif.load(path, hue)
          end
          def bitmap; @kerberus_bitmap; end
          def width; bitmap.width; end
          def height; bitmap.height; end
          def length; KerberusLegacy18::Ports::Gif.animated?(bitmap) ? bitmap.frame_count : 1; end
          def currentIndex; KerberusLegacy18::Ports::Gif.animated?(bitmap) ? bitmap.current_frame : 0; end
          def disposed?; bitmap.nil? || bitmap.disposed?; end
          def update; nil; end
          def totalFrames; length * frameDelay; end
          def frameDelay(index = nil)
            KerberusLegacy18::Ports::Gif.animated?(bitmap) && bitmap.frame_rate.to_f > 0 ? (40.0 / bitmap.frame_rate).round : 1
          end
          def deanimate
            if KerberusLegacy18::Ports::Gif.animated?(bitmap)
              original = bitmap
              original.goto_and_stop(0)
              @kerberus_bitmap = original.snap_to_bitmap
              original.dispose
              @kerberus_frames.each_value { |frame| frame.dispose unless frame.disposed? }
              @kerberus_frames.clear
            end
            bitmap
          end
          def [](index)
            KerberusLegacy18::Ports::Gif.frame(self, bitmap, @kerberus_frames, index)
          end
          def each
            length.times { |index| yield self[index] }
          end
          def dispose
            @kerberus_frames.each_value { |frame| frame.dispose unless frame.disposed? }
            @kerberus_frames.clear
            bitmap.dispose if bitmap && !bitmap.disposed?
          end
          def copy
            duplicate = clone
            duplicate.instance_variable_set(:@kerberus_bitmap, bitmap.clone)
            duplicate.instance_variable_set(:@kerberus_frames, {})
            duplicate
          end
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'gif_dll', 'GifBitmap via Bitmap animado nativo do mkxp-z')
        true
      end

      def self.arguments(args)
        if args.length >= 2 && args[1].is_a?(String)
          [File.join(args[0].to_s, args[1]), args[2] || 0]
        else
          [args[0], args[1] || 0]
        end
      end

      def self.animated?(bitmap)
        bitmap.respond_to?(:animated?) && bitmap.animated?
      end

      def self.load(path, hue)
        bitmap = ::Bitmap.new(path)
        return bitmap if hue.to_i == 0
        unless animated?(bitmap)
          bitmap.hue_change(hue)
          return bitmap
        end
        colored = nil
        begin
          bitmap.frame_count.times do |index|
            bitmap.goto_and_stop(index)
            frame = bitmap.snap_to_bitmap
            frame.hue_change(hue)
            if colored
              colored.add_frame(frame)
              frame.dispose
            else
              colored = frame
            end
          end
          colored.frame_rate = bitmap.frame_rate
          colored.looping = bitmap.looping
          colored.play
          colored
        ensure
          bitmap.dispose unless bitmap.disposed?
        end
      end

      def self.frame(owner, bitmap, cache, index)
        return nil unless index.is_a?(Integer) && index >= 0 && index < owner.length
        return bitmap if owner.length == 1
        return cache[index] if cache.has_key?(index)
        current = bitmap.current_frame
        playing = bitmap.playing
        begin
          bitmap.goto_and_stop(index)
          cache[index] = bitmap.snap_to_bitmap
        ensure
          bitmap.goto_and_stop(current)
          bitmap.play if playing
        end
        cache[index]
      end
    end

    # Bitmap memory helpers of old Essentials (RtlMoveMemory_pi on addresses).
    module BitmapMemory
      def self.swap(data)
        result = data.dup
        index = 0
        while index < result.length
          red = result[index]
          result[index] = result[index + 2]
          result[index + 2] = red
          index += 4
        end
        result
      end

      def self.install
        ::Bitmap.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          def getData
            KerberusLegacy18::Ports::BitmapMemory.swap(KerberusLegacy18::Ports::Klein.bytes(self))
          end
          def setData(data)
            size = width * height * 4
            KerberusLegacy18::WinBridge::Buffers.need(data, size, false, 'Bitmap#setData')
            self.raw_data = KerberusLegacy18::Ports::BitmapMemory.swap(data[0, size])
          end
          def asOpaque
            data = KerberusLegacy18::Ports::Klein.bytes(self)
            index = 3
            while index < data.length
              data[index] = 255
              index += 4
            end
            self.raw_data = data
            self
          end
          def saveToPng(file)
            to_file(KerberusLegacy18::Paths.resolve(file.to_s, true))
          end
          def address
            raise KerberusLegacy18::WinBridge::Unavailable,
                  "WINBRIDGE_UNAVAILABLE\\nBitmap#address: enderecos de objetos RGSS1 nao existem no mkxp-z; use raw_data"
          end
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'bitmap_memory', 'getData/setData/asOpaque/saveToPng via raw_data')
      end
    end

    module TextEntry
      def self.install
        return false unless Object.const_defined?(:Window_TextEntry_Keyboard)
        ::Window_TextEntry_Keyboard.class_eval(<<-RUBY, 'Kerberus Ports', 1)
          alias_method :kerberus_text_update, :update unless method_defined?(:kerberus_text_update)
          alias_method :kerberus_text_dispose, :dispose unless method_defined?(:kerberus_text_dispose)
          def update
            active_now = respond_to?(:active) ? (active ? true : false) : true
            if active_now != @kerberus_text_active
              @kerberus_text_active = active_now
              KerberusLegacy18.native('Input', :text_input=, active_now) if KerberusLegacy18.native?('Input', :text_input=)
            end
            kerberus_text_update
          end
          def dispose
            if @kerberus_text_active && KerberusLegacy18.native?('Input', :text_input=)
              KerberusLegacy18.native('Input', :text_input=, false)
            end
            @kerberus_text_active = false
            kerberus_text_dispose
          end
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'text_entry', 'teclado Android/IME via Input.gets')
        true
      end

      def self.incoming
        return '' unless KerberusLegacy18.native?('Input', :gets)
        text = KerberusLegacy18.native('Input', :gets).to_s
        result = []
        text.each_char { |char| result << char unless char =~ /\A[\x00-\x1f\x7f]\z/ }
        result
      end
    end

    module Movies
      def self.install
        native = KerberusLegacy18.native?('Graphics', :play_movie)
        KerberusLegacy18.meta(::Graphics).module_eval(<<-RUBY, 'Kerberus Ports', 1)
          def play_movie(filename, cancellable = true, fit = true)
            KerberusLegacy18::Ports::Movies.play(filename, cancellable)
          end
        RUBY
        KerberusLegacy18.event('PORT_INSTALLED', 'zeus_video', native ? 'Graphics.play_movie nativo (OGV/Theora)' : 'sem binding de video')
      end

      def self.play(filename, cancellable)
        base = filename.to_s.tr('\\', '/').sub(/\.[^.\/]+\z/, '')
        candidates = [filename.to_s.tr('\\', '/'), base + '.ogv', base + '.ogg']
        found = candidates.map { |path| KerberusLegacy18::Paths.resolve(path, false) }.find { |path| File.file?(path) && path =~ /\.og[gv]\z/i }
        unless found && KerberusLegacy18.native?('Graphics', :play_movie)
          KerberusLegacy18.event('LIMITED', 'Graphics.play_movie', filename.to_s + ': sem versao OGV/Theora; video pulado', true)
          return nil
        end
        KerberusLegacy18.native('Graphics', :play_movie, found, 100, cancellable ? true : false)
      end
    end

    # ==================================================================
    # Registry
    # ==================================================================
    register('rgss_linker', 'RGSS Linker: load_module nativo (FMOD -> Audio mkxp-z)',
             ['RGSSLinker_Initialize', 'def load_module'], :provides => %w(load_module RGSSLinker_Initialize)) do |source, index, scripts|
      Source.pad(source, "# Kerberus Ports: RGSS Linker substituido por adaptador nativo\nKerberusLegacy18::Ports::Linker.install\n")
    end

    register('fmodex_audio', 'FMOD Ex (RGSS Linker) -> Audio nativo do mkxp-z',
             ['Init_FmodEx', 'LOOP_TABLE', 'bgmvolume'],
             :provides => %w(Audio_bgm_play Audio_bgm_stop Audio_bgm_fade Audio_bgm_fadein Audio_bgm_get_position
                             Audio_bgm_get_volume Audio_bgm_set_volume Audio_bgm_name Audio_bgm_pitch Audio_bgm_playing?
                             Audio_bgs_play Audio_bgs_stop Audio_bgs_fade Audio_me_play Audio_me_stop Audio_me_fade
                             Audio_se_play Audio_se_stop audio_control_volume safeExists? getPlayMusic getPlaySound Audio)) do |source, index, scripts|
      table = source[/LOOP_TABLE\s*=\s*\[(.*?)\]/m, 1]
      entries = table ? table.split("\n").reject { |line| line.strip.empty? || line.strip[0, 1] == '#' }.length : 0
      if entries > 0
        KerberusLegacy18.event('LIMITED', 'FMOD LOOP_TABLE', entries.to_s + ' pontos de loop customizados; use tags LOOPSTART/LOOPLENGTH no OGG', true)
      end
      Source.pad(source, "# Kerberus Ports: FMOD substituido pelo Audio nativo\nKerberusLegacy18::Ports::EssentialsAudio.install(:fmod)\n")
    end

    register('audio_dll', 'Essentials audio.dll (AudioContext) -> Audio nativo',
             ['class AudioContext', 'AudioContextInitialize', 'module AudioState'],
             :provides => %w(AudioContext AudioState Audio Audio_bgm_play Audio_bgm_stop Audio_bgm_fade Audio_bgm_fadein
                             Audio_bgm_get_position Audio_bgm_get_volume Audio_bgm_set_volume Audio_bgm_name Audio_bgm_pitch
                             Audio_bgm_playing? Audio_bgs_play Audio_bgs_stop Audio_bgs_fade Audio_me_play Audio_me_stop
                             Audio_me_fade Audio_se_play Audio_se_stop audio_control_volume getPlayMusic getPlaySound)) do |source, index, scripts|
      Source.pad(source, "# Kerberus Ports: audio.dll substituida pelo Audio nativo\nKerberusLegacy18::Ports::EssentialsAudio.install(:audio_dll)\n")
    end

    register('gif_dll', 'Essentials gif.dll -> Bitmap animado nativo',
             ['module GifLibrary', 'class GifBitmap', 'GifToPngFilesInMemory'], {}) do |source, index, scripts|
      source.gsub(/safeExists\?\(\s*["']gif\.dll["']\s*\)/, 'false') + "\nKerberusLegacy18::Ports::Gif.install\n"
    end

    register('klein_bitmap', 'KleinBitmap.dll -> operacoes Bitmap/Sprite nativas',
             ['KLEIN_BFUNCS_DLL', 'def klein_dll', 'compare_klein_bitmaps'],
             :provides => %w(klein_dll compare_klein_bitmaps klein_bitmap_version Bitmap Sprite)) do |source, index, scripts|
      Source.pad(source, "# Kerberus Ports: KleinBitmap substituida\nKerberusLegacy18::Ports::Klein.install\n")
    end

    register('bitmap_memory', 'Bitmap via RtlMoveMemory -> raw_data; escala de janela gerenciada pelo Android',
             ['def pbSetResizeFactor2', 'RtlMoveMemory_pi', 'def saveToPng'], {}) do |source, index, scripts|
      text = source.sub(/^([ \t]*def pbSetResizeFactor2\(\s*factor\b[^\n)]*\))/) { $1 + '; factor = 1.0 # Kerberus: superficie Android' }
      text + "\nKerberusLegacy18::Ports::BitmapMemory.install\n"
    end

    register('font_installer', 'FontInstaller: fontes de Fonts/ ja indexadas pelo mkxp-z',
             ['FontInstaller', 'AddFontResource', 'WriteProfileString'], {}) do |source, index, scripts|
      source.gsub(/^([ \t]*)FontInstaller\.install\s*$/) { $1 + "KerberusLegacy18.event('PORT_INSTALLED', 'font_installer', 'instalacao no sistema ignorada; Fonts/ indexado pelo mkxp-z')" }
    end

    register('text_entry', 'Entrada de texto por teclado -> Input.gets (teclado Android/IME)',
             ['class Window_TextEntry_Keyboard', '@toUnicode', 'GetKeyboardState'], {}) do |source, index, scripts|
      start = source.index('    if !@toUnicode')
      finish = start && source.index("\n  end\nend", start)
      if start && finish
        replacement = "    KerberusLegacy18::Ports::TextEntry.incoming.each { |character| insert(character) }\n"
        source[0, start] + Source.pad(source[start, finish - start] + "\n", replacement).chomp + source[finish, source.length - finish] +
          "\nKerberusLegacy18::Ports::TextEntry.install\n"
      else
        KerberusLegacy18.event('PORT_SKIPPED', 'text_entry', 'estrutura do editor diferente; ToUnicode/GetKeyboardState genericos continuam ativos', true)
        nil
      end
    end

    register('unicode_pointer', 'Strings de ponteiro -> buffers Ruby/heap virtual',
             ['def getUnicodeStringFromAnsi(addr)', 'def getUnicodeString(addr)'], {}) do |source, index, scripts|
      text = Source.method_body(source, 'getUnicodeStringFromAnsi',
                                "return KerberusLegacy18::Ports.ansi_string(addr)")
      Source.method_body(text, 'getUnicodeString', "return KerberusLegacy18::Ports.wide_string(addr)")
    end

    register('zeus_video', 'Zeus Video Player (MCI/AVI) -> Graphics.play_movie',
             [':Zeus_Video_Player', 'MciSendString', 'ZVP_OldAviMode'], :provides => %w(Graphics)) do |source, index, scripts|
      Source.pad(source, "# Kerberus Ports: Zeus Video Player\nKerberusLegacy18::Ports::Movies.install\n")
    end

    def self.ansi_string(value)
      return '' if KerberusLegacy18::WinBridge::Buffers.null?(value)
      bytes = KerberusLegacy18::WinBridge::Buffers.c_string(value).to_s
      begin
        bytes.unpack('U*')
        bytes
      rescue ArgumentError
        KerberusLegacy18::WinBridge::Text.cp1252_to_utf8(bytes)
      end
    end

    def self.wide_string(value)
      KerberusLegacy18::WinBridge::Buffers.wide_string(value) || ''
    end
  end
end
