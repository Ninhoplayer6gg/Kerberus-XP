# Kerberus - "Salvar agora" from the Kerberus in-game menu (6.5).
#
# The request comes from Java through the engine (kerberus-session.h) and is
# served here, inside Graphics.update, by the game's own save routine: the
# same pbSave(), same file, same backups, as the Save option of the game's
# menu. Nothing is saved unless the game is at a safe point, where saving
# from the game's own menu would give the same result:
#   * the field (Scene_Map), with Graphics.update called straight from the
#     map loop (Scene_Map#main) - no menu, message, battle or other screen
#     running inside Scene_Map#update;
#   * the player standing still, no map event running, no transfer or
#     transition pending;
#   * not a new game started in this session: the game's menu confirms the
#     replacement of an existing save there, so the first save stays with it.
# Otherwise the reply names the reason (the launcher words it for the
# player) and nothing is written. Games without Pokemon Essentials' pbSave
# are told to save from their own menu.
# Replies: save:ok, save:fail, save:busy:<reason>, save:unsupported:<reason>.
module KerberusLegacy18
  module Session
    OWN_FILE = /\A(?:Kerberus|kerberus)/
    OWN_METHODS = %w(save_now serve)

    # Engine entry point (binding-mri.cpp): code 1 = save now.
    def self.serve(code, arg)
      return 'request:' + code.to_s + ':unsupported' unless code == 1
      save_now
    end

    def self.save_now
      reason = unsupported_reason
      return 'save:unsupported:' + reason if reason
      reason = busy_reason(caller(0))
      return 'save:busy:' + reason if reason
      ok = Object.new.send(:pbSave)
      KerberusLegacy18.runtime_trace('SESSAO', 'salvar agora (menu Kerberus): ' + (ok ? 'salvo pelo pbSave do jogo' : 'pbSave do jogo informou falha'))
      ok ? 'save:ok' : 'save:fail'
    end

    def self.unsupported_reason
      return 'no_pbsave' unless Object.private_method_defined?(:pbSave) || Object.method_defined?(:pbSave)
      return 'not_loaded' unless defined?(::Scene_Map) && $game_player && $game_map && $game_temp
      nil
    end

    def self.busy_reason(frames)
      return 'scene' unless $scene.is_a?(::Scene_Map)
      temp = $game_temp
      return 'battle' if flag?(temp, :in_battle)
      return 'message' if flag?(temp, :message_window_showing)
      return 'transfer' if flag?(temp, :player_transferring) || flag?(temp, :transition_processing)
      return 'menu' if flag?(temp, :menu_calling) || flag?(temp, :in_menu)
      return 'moving' if $game_player.respond_to?(:moving?) && $game_player.moving?
      return 'event' if interpreter_running?
      if defined?($PokemonTemp) && $PokemonTemp && $PokemonTemp.respond_to?(:begunNewGame) && $PokemonTemp.begunNewGame
        return 'newgame'
      end
      return 'screen' unless map_loop?(frames)
      nil
    end

    def self.flag?(object, name)
      object.respond_to?(name) && object.send(name) ? true : false
    end

    def self.interpreter_running?
      interpreter = if $game_map.respond_to?(:interpreter) then $game_map.interpreter
                    elsif $game_system && $game_system.respond_to?(:map_interpreter) then $game_system.map_interpreter
                    end
      interpreter && interpreter.respond_to?(:running?) && interpreter.running? ? true : false
    end

    # frames: caller(0) from save_now. Above the game's call are this module
    # and Graphics.update with its wrappers (Kerberus Frame, or a game's own
    # alias such as Uranium's update_KGC_SpecialTransition); the first frame
    # below them must be Scene_Map#main, and no method with update in its
    # name may be further down (menus, messages and battles run inside
    # Scene_Map#update). An unusual stack is refused, never guessed.
    def self.map_loop?(frames)
      names = frames.map { |frame| frame.to_s[/in `([^']*)'\z/, 1].to_s }
      index = 0
      index += 1 while index < names.length &&
                       (OWN_FILE =~ frames[index].to_s || OWN_METHODS.include?(names[index]) || names[index] =~ /update/i)
      return false unless index < names.length && names[index] =~ /main/
      names[(index + 1)..-1].each { |name| return false if name =~ /update/i }
      true
    end
  end
end
