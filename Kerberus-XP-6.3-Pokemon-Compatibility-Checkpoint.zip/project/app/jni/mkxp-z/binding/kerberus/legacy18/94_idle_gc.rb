# Kerberus - Ruby collections at idle moments (6.4.3).
#
# Ruby 1.8 collects with a full mark and sweep of every live object; a
# Pokemon Essentials game keeps over a million, so a collection while the
# player walks or battles is a visible hitch. Two moments hide it:
#  * scene transitions: RGSS games freeze the screen (Graphics.freeze ...
#    Graphics.transition) and a collection right before the transition is
#    not seen;
#  * a message on screen ($game_temp.message_window_showing, RMXP and
#    Essentials) for MESSAGE_FRAMES frames: the player is reading.
# There, when the process has already gone past a threshold of the way to
# its next collection (GC.kerberus_pressure, patched Ruby 1.8), the
# collection runs now instead of later during play. It changes when a
# collection happens, never what it frees.
#   KERBERUS_IDLE_GC=off        disabled
#   KERBERUS_IDLE_GC=<1..100>   threshold in percent (default 50)
module KerberusLegacy18
  module IdleGc
    DEFAULT_THRESHOLD = 50
    MESSAGE_FRAMES = 20
    @count = 0
    @total_ns = 0
    @frozen = false
    @message_frames = 0
    @installed = false
    @threshold = DEFAULT_THRESHOLD
    class << self
      attr_reader :count, :total_ns, :threshold
    end

    def self.installed?
      @installed
    end

    def self.install
      return false if @installed || !defined?(::Graphics)
      setting = KerberusLegacy18.config[:idle_gc]
      return false if setting == 'off'
      unless ::GC.respond_to?(:kerberus_pressure)
        KerberusLegacy18.event('IDLE_GC', 'GC', 'interpretador sem GC.kerberus_pressure: coleta em momentos ociosos desligada', true)
        return false
      end
      @threshold = setting.to_i.between?(1, 100) ? setting.to_i : DEFAULT_THRESHOLD
      @installed = true
      KerberusLegacy18.meta(::Graphics).module_eval(<<-RUBY, 'Kerberus IdleGc', 1)
        alias_method :kerberus_idle_gc_freeze, :freeze
        alias_method :kerberus_idle_gc_transition, :transition
        def freeze(*args)
          result = kerberus_idle_gc_freeze(*args)
          KerberusLegacy18::IdleGc.frozen!
          result
        end
        def transition(*args)
          KerberusLegacy18::IdleGc.transition!
          kerberus_idle_gc_transition(*args)
        end
      RUBY
      true
    end

    def self.frozen!
      @frozen = true
    end

    # Only while the screen is frozen: Graphics.transition without a
    # freeze returns at once and a collection there would be seen.
    def self.transition!
      frozen = @frozen
      @frozen = false
      frozen ? collect : false
    end

    # Once per message, after it has been on screen for MESSAGE_FRAMES.
    def self.tick
      return unless @installed
      temp = $game_temp
      if temp && temp.respond_to?(:message_window_showing) && temp.message_window_showing
        @message_frames += 1
        collect if @message_frames == MESSAGE_FRAMES
      else
        @message_frames = 0
      end
    end

    def self.collect
      return false if ::GC.kerberus_pressure < @threshold
      spent = ::GC.kerberus_stats[1]
      ::GC.start
      @total_ns += ::GC.kerberus_stats[1] - spent
      @count += 1
      true
    end
  end
end
