# Kerberus frame hook: one cheap call per Graphics.update.
# Audio fade-in is game behaviour and propagates its errors normally.
# Recorder/milestone polling and the performance report are diagnostics
# only: if they ever fail they are disabled and the failure is written to
# the runtime report.
#
# Performance report (6.4): wall time between Graphics.update calls, so it
# includes the engine's own frame pacing. Every perf_window frames one
# [PERF] line goes to the runtime log: frames per second, mean and worst
# frame, an upper bound for the 95th percentile, frames slower than 50 ms,
# and the Ruby collections of the window (GC.kerberus_stats, patched
# Ruby 1.8). No allocation per frame beyond the integer arithmetic.
module KerberusLegacy18
  module Frame
    @count = 0
    @diagnostics = true
    @installed = false

    # Upper bounds (ms) of the frame-time histogram used for the p95 bound.
    BUCKETS = [17, 25, 34, 50, 67, 100, 200, 500]

    def self.reset!
      @count = 0
      @diagnostics = true
      reset_window!
      @last_ns = nil
    end

    def self.reset_window!
      @window_frames = 0
      @window_start = nil
      @window_max = 0
      @window_slow = 0
      @histogram = Array.new(BUCKETS.length + 1, 0)
      @gc_start = gc_stats
    end

    def self.gc_stats
      defined?(::GC) && ::GC.respond_to?(:kerberus_stats) ? ::GC.kerberus_stats : nil
    end

    # RGSS1 skipped drawing frames when a game fell behind, so the game
    # kept its speed on slow machines; mkxp-z ships with this off.
    def self.enable_frameskip
      return false unless KerberusLegacy18.config[:frameskip]
      return false unless KerberusLegacy18.native?('Graphics', :frameskip=)
      KerberusLegacy18.native('Graphics', :frameskip=, true)
      KerberusLegacy18.event('FRAMESKIP', 'Graphics', 'pulo de quadros do RGSS1 ativo: o jogo mantem a velocidade quando o aparelho atrasa', true)
      true
    end

    def self.measure(now)
      if @last_ns
        ms = (now - @last_ns) / 1000000
        @window_frames += 1
        @window_max = ms if ms > @window_max
        @window_slow += 1 if ms > 50
        index = 0
        index += 1 while index < BUCKETS.length && ms > BUCKETS[index]
        @histogram[index] += 1
      else
        @window_start = now
      end
      @last_ns = now
      report(now) if @window_frames >= KerberusLegacy18.config[:perf_window]
    end

    def self.report(now)
      elapsed_ms = (now - @window_start) / 1000000.0
      fps = elapsed_ms > 0 ? @window_frames * 1000.0 / elapsed_ms : 0.0
      target = (@window_frames * 95 + 99) / 100
      seen = 0
      p95 = nil
      @histogram.each_with_index do |count, index|
        seen += count
        if seen >= target
          p95 = index < BUCKETS.length ? '<=' + BUCKETS[index].to_s : '>' + BUCKETS[-1].to_s
          break
        end
      end
      line = format('quadros=%d fps=%.1f quadro_medio=%.1fms p95%sms pior=%dms lentos(>50ms)=%d',
                    @window_frames, fps, elapsed_ms / @window_frames, p95.to_s, @window_max, @window_slow)
      now_gc = gc_stats
      if now_gc && @gc_start
        count = now_gc[0] - @gc_start[0]
        total = (now_gc[1] - @gc_start[1]) / 1000000.0
        line << format(' gc=%d (%.0fms no total, pior %.0fms, heap %d objetos)', count, total, now_gc[2] / 1000000.0, now_gc[3])
      end
      line << ' frameskip=' + (KerberusLegacy18.native?('Graphics', :frameskip) && KerberusLegacy18.native('Graphics', :frameskip) ? 'on' : 'off')
      KerberusLegacy18.runtime_trace('PERF', line)
      reset_window!
      @window_start = now
    end

    def self.install
      return false if @installed || !defined?(::Graphics)
      @installed = true
      KerberusLegacy18.meta(::Graphics).module_eval(<<-RUBY, 'Kerberus Frame', 1)
        alias_method :kerberus_frame_update, :update
        def update(*args)
          result = kerberus_frame_update(*args)
          KerberusLegacy18::Frame.tick
          result
        end
      RUBY
      true
    end

    def self.tick
      @count += 1
      WinBridge::AudioBridge.tick if WinBridge::AudioBridge.fading_in?
      return unless @diagnostics
      begin
        measure(KerberusLegacy18.monotonic_ns)
        Recorder.tick
        Paths.clear_misses if @count % 60 == 0
        Milestones.poll if @count % 30 == 0
      rescue StandardError => error
        @diagnostics = false
        KerberusLegacy18.runtime_block('KERBERUS_DIAGNOSTICS_DISABLED', KerberusLegacy18.describe_exception(error))
      end
    end

    @last_ns = nil
    reset_window!
  end
end
