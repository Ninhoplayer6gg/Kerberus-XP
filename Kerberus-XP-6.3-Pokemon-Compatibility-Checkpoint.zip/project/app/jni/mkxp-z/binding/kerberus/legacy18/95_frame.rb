# Kerberus frame hook: one cheap call per Graphics.update.
# Audio fade-in is game behaviour and propagates its errors normally.
# Recorder/milestone polling is diagnostics only: if it ever fails it is
# disabled and the failure is written to the runtime report.
module KerberusLegacy18
  module Frame
    @count = 0
    @diagnostics = true
    @installed = false

    def self.reset!
      @count = 0
      @diagnostics = true
    end

    def self.install
      return false if @installed || !defined?(::Graphics)
      @installed = true
      KerberusLegacy18.meta(::Graphics).module_eval(<<-RUBY, 'Kerberus Frame', 1)
        alias_method :kerberus_frame_update, :update
        def update(*args)
          result = kerberus_frame_update(*args)
          KerberusLegacy18::Frame.tick
          result
        end
      RUBY
      true
    end

    def self.tick
      @count += 1
      WinBridge::AudioBridge.tick if WinBridge::AudioBridge.fading_in?
      return unless @diagnostics
      begin
        Recorder.tick
        Paths.clear_misses if @count % 60 == 0
        Milestones.poll if @count % 30 == 0
      rescue StandardError => error
        @diagnostics = false
        KerberusLegacy18.runtime_block('KERBERUS_DIAGNOSTICS_DISABLED', KerberusLegacy18.describe_exception(error))
      end
    end
  end
end
