# Evidence-based profile detection. Profiles only label the game and add
# diagnostics; behaviour comes from generic WinBridge providers and Ports
# selected by script content, never by the game's name.
module KerberusLegacy18
  module Profiles
    RULES = [
      ['Pokemon Uranium', [['RGSSLinker_Initialize', 'Uranium.ini']]],
      ['Pokemon Insurgence', [['MGC_Hmode7', 'renderHM7'], ['Insurgence']]],
      ['Pokemon Xenoverse', [['Xenoverse']]],
      ['Pokemon Infinite Fusion', [['Infinite Fusion']]]
    ]

    def self.sources(scripts)
      (scripts || []).map { |entry| entry.is_a?(Array) ? entry[3].to_s : '' }
    end

    def self.detect(scripts)
      texts = sources(scripts)
      found = []
      RULES.each do |rule|
        ok = rule[1].all? { |markers| texts.any? { |text| markers.all? { |marker| text.index(marker) } } }
        found << rule[0] if ok
      end
      found
    end

    # "# Pokemon Essentials / # Version X" header, or an ESSENTIALS_VERSION constant.
    def self.essentials_version(scripts)
      sources(scripts).each do |text|
        return $1 if text =~ /^\s*#\s*Pok.mon Essentials\s*#?\s*\r?\n\s*#\s*Version\s+([0-9]+(?:\.[0-9]+){0,3})/i
        return $1 if text =~ /^\s*ESSENTIALS_VERSION\s*=\s*["']([^"']+)["']/
        return $1 if text =~ /^\s*ESSENTIALSVERSION\s*=\s*["']([^"']+)["']/
      end
      nil
    end

    def self.report(scripts)
      names = detect(scripts)
      version = essentials_version(scripts)
      detail = 'perfis=' + (names.empty? ? 'nenhum' : names.join(',')) +
               ' essentials=' + (version || 'nao identificado') +
               ' secoes=' + (scripts ? scripts.length : 0).to_s
      KerberusLegacy18.event('PROFILE', 'legacy18', detail, true)
      if names.include?('Pokemon Infinite Fusion')
        KerberusLegacy18.event('PROFILE_WARNING', 'Pokemon Infinite Fusion',
                               'o runtime validado para este jogo e modern31; verifique .kerberus-runtime', true)
      end
      names
    end
  end
end
