# Activation: runs once, after $RGSS_SCRIPTS is decoded, before Section000.
module KerberusLegacy18
  @activated = false

  def self.activated?
    @activated
  end

  def self.dump_scripts(scripts)
    directory = data_dir('scripts')
    return unless directory
    scripts.each_with_index do |entry, index|
      next unless entry.is_a?(Array) && entry[3].is_a?(String)
      name = format('%03d', index) + '-' + entry[1].to_s.gsub(/[^A-Za-z0-9_.-]+/, '_')[0, 40] + '.rb'
      raw_write(File.join(directory, name), entry[3], 'wb')
    end
  end

  def self.activate(scripts)
    return false if @activated
    @activated = true
    remember_native
    uranium = Profiles.sources(scripts).any? { |text| text.index('RGSSLinker_Initialize') && text.index('Uranium.ini') }
    Paths.install if config[:filesystem]
    WinBridge.install
    WinEnv.install
    IoEof.install
    ZlibGuard.install
    Recorder.scan_static(scripts)
    Profiles.report(scripts)
    applied = Ports.apply_all(scripts)
    Ruby181.apply_all(scripts)
    $KERBERUS_URANIUM_COMPAT_ACTIVE = true if uranium
    Frame.install
    Frame.enable_frameskip
    IdleGc.install
    dump_scripts(scripts) if config[:dump_scripts]
    at_exit { KerberusLegacy18::Recorder.flush('exit') }
    event('LEGACY18_READY', 'Kerberus ' + VERSION,
          'WinBridge ativo; ports aplicados=' + applied.to_s + '; filesystem=' + (config[:filesystem] ? 'windows' : 'nativo') +
          '; wintrace=' + trace_level, true)
    true
  end
end

KerberusLegacy18.activate($RGSS_SCRIPTS) if defined?($RGSS_SCRIPTS) && $RGSS_SCRIPTS
