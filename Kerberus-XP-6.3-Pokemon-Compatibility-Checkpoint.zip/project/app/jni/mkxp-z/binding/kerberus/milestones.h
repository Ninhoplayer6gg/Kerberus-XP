#ifndef KERBERUS_MILESTONES_H
#define KERBERUS_MILESTONES_H

#include <cstdio>
#include <ctime>
#include <string>
#include <SDL_stdinc.h>

// Kerberus 6.3: evidence for the per-game compatibility status shown by the
// launcher. Appends one line to milestones.log next to KERBERUS_COMPAT_LOG
// (private app storage, never the game folder). Bounded to 64 KiB.
static void kerberusMilestone(const char *name, const char *runtime, const char *detail)
{
    const char *log = SDL_getenv("KERBERUS_COMPAT_LOG");
    if (!log || !*log) return;
    std::string path(log);
    size_t slash = path.rfind('/');
    if (slash == std::string::npos) return;
    path = path.substr(0, slash + 1) + "milestones.log";
    std::FILE *file = std::fopen(path.c_str(), "a");
    if (!file) return;
    std::fseek(file, 0, SEEK_END);
    if (std::ftell(file) < 64 * 1024)
        std::fprintf(file, "MILESTONE\t%s\t%s\t%ld\t%.200s\n", name, runtime,
                     (long)std::time(nullptr), detail ? detail : "");
    std::fclose(file);
}

#endif
