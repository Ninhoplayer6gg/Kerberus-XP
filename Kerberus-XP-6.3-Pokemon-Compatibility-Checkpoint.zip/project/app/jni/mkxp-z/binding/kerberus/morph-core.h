#ifndef KERBERUS_MORPH_CORE_H
#define KERBERUS_MORPH_CORE_H
#include <array>
#include <algorithm>
#include <string>
#include <cstdint>
#include <ctime>
#include <cstdio>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/syscall.h>

// No renderer dependency, Ruby evaluation, game writes or per-frame allocations.
namespace kerberus { namespace morph {
enum Api { Unsupported=0, Tick32, Tick64, MultimediaTick, Counter, Frequency, CurrentThreadId, WindowThreadProcessId, ApiCount };
struct Rule { std::string id, provider; unsigned version=0; };
struct Plan {
    std::array<Rule,3> rules;
    unsigned size=0;
    bool parse(const std::string &text, int rgss) {
        size=0;
        if (text.size()>4096 || text.compare(0,5,"KMX1\n")!=0) return false;
        std::array<Rule,3> pending;
        unsigned count=0;
        for (size_t at=5; at<text.size();) {
            size_t end=text.find('\n',at), a=text.find('\t',at), b=text.find('\t',a==std::string::npos ? at : a+1);
            if (count==3 || end==std::string::npos || a>=end || b>=end || a==b
                    || text.find('\t',b+1)<end) return false;
            Rule r; r.id=text.substr(at,a-at); r.provider=text.substr(b+1,end-b-1);
            if (r.id.size()<17 || r.id.size()>21 || r.id.compare(0,13,"KERBERUS-FIX-")!=0) return false;
            for (size_t i=13;i<r.id.size();++i) if (r.id[i]<'0'||r.id[i]>'9') return false;
            if (b-a<2 || b-a>10) return false;
            for (size_t i=a+1;i<b;++i) {
                if (text[i]<'0'||text[i]>'9') return false;
                r.version=r.version*10+unsigned(text[i]-'0');
            }
            if (!r.version || (r.provider!="windows.uptime" && r.provider!="windows.performance_counter"
                    && r.provider!="windows.thread_identity")) return false;
            for (unsigned i=0;i<count;++i) if (pending[i].id==r.id || pending[i].provider==r.provider) return false;
            pending[count++]=r; at=end+1;
        }
        if (count && rgss!=1) return false;
        rules=pending; size=count; return true;
    }
    int ruleFor(Api api) const {
        const char *provider=api>=Tick32 && api<=MultimediaTick ? "windows.uptime"
                : api==Counter || api==Frequency ? "windows.performance_counter"
                : (api==CurrentThreadId || api==WindowThreadProcessId) ? "windows.thread_identity" : "";
        for (unsigned i=0;i<size;++i) if (rules[i].provider==provider) return int(i);
        return -1;
    }
};
inline Api identify(std::string library, const std::string &function) {
    if (library.size()>32 || library.find_first_of("/\\:")!=std::string::npos) return Unsupported;
    for (char &c:library) if (c>='A' && c<='Z') c+=32;
    if (library=="kernel32" || library=="kernel32.dll") {
        if (function=="GetTickCount") return Tick32;
        if (function=="GetTickCount64") return Tick64;
        if (function=="QueryPerformanceCounter") return Counter;
        if (function=="QueryPerformanceFrequency") return Frequency;
        if (function=="GetCurrentThreadId") return CurrentThreadId;
    }
    if ((library=="winmm" || library=="winmm.dll") && function=="timeGetTime") return MultimediaTick;
    if ((library=="user32" || library=="user32.dll") && function=="GetWindowThreadProcessId") return WindowThreadProcessId;
    return Unsupported;
}
inline uint64_t milliseconds(const timespec &time) {
    return uint64_t(time.tv_sec)*1000+uint64_t(time.tv_nsec)/1000000;
}
inline uint64_t tick(Api api, const timespec &time) {
    return api==Tick64 ? milliseconds(time) : milliseconds(time)&UINT32_MAX;
}
inline uint64_t currentThreadIdentity() {
#ifdef SYS_gettid
    long value=::syscall(SYS_gettid);
    return value>0 ? (uint64_t(value)&UINT32_MAX) : 0;
#else
    long value=::getpid();
    return value>0 ? (uint64_t(value)&UINT32_MAX) : 0;
#endif
}
inline uint64_t currentProcessIdentity() {
    long value=::getpid();
    return value>0 ? (uint64_t(value)&UINT32_MAX) : 0;
}
inline void littleEndian32(char *buffer, uint64_t value) {
    for (unsigned i=0;i<4;++i) buffer[i]=char((value>>(i*8))&255);
}
inline void littleEndian64(char *buffer, uint64_t value) {
    for (unsigned i=0;i<8;++i) buffer[i]=char((value>>(i*8))&255);
}
using ClockReader=int (*)(clockid_t,timespec*);
inline bool clockValue(Api api, uint64_t &value, ClockReader readClock=clock_gettime) {
    if (api==Frequency) { value=1000000000ULL; return true; }
    timespec time={};
    // Windows QPC includes suspended time too; CLOCK_MONOTONIC excludes it on Android.
    if (api<=Unsupported || api>=ApiCount || readClock(CLOCK_BOOTTIME,&time)!=0) return false;
    value=api==Counter ? uint64_t(time.tv_sec)*1000000000ULL+uint64_t(time.tv_nsec) : tick(api,time);
    return true;
}
inline std::string clean(const std::string &text, size_t limit=160) {
    std::string result;
    for (unsigned char c:text) {
        if (result.size()==limit) break;
        result+=c<32 || c==127 ? ' ' : char(c);
    }
    // Remove an incomplete UTF-8 suffix after bounding a field.
    if (result.size()<text.size()) {
        while (!result.empty() && (static_cast<unsigned char>(result.back())&0xc0)==0x80) result.pop_back();
        if (!result.empty() && static_cast<unsigned char>(result.back())>=0xc0) result.pop_back();
    }
    return result;
}
class EventLog {
    std::string path, session;
    std::array<std::string,64> seen;
    unsigned count=0;
public:
    static constexpr long Limit=64*1024;
    void open(const std::string &file, const std::string &id) { path=file; session=clean(id,64); count=0; }
    bool record(const char *type, const Rule *rule, const std::string &library, const std::string &function,
                const std::string &script, const std::string &parameters, const std::string &outcome) {
        if (path.empty() || count==seen.size()) return false;
        std::string key=std::string(type)+":"+clean(library)+":"+clean(function)+":"+(rule?rule->id:"");
        for (unsigned i=0;i<count;++i) if (seen[i]==key) return false;
        seen[count++]=key;
        timespec time={}; clock_gettime(CLOCK_REALTIME,&time);
        std::string line="1\t"+std::to_string(milliseconds(time))+"\t"+session+"\t"+clean(type,32)+"\t"
                +(rule?rule->id:"-")+"\t"+std::to_string(rule?rule->version:0)+"\t"+(rule?rule->provider:"-")
                +"\t"+clean(library)+"\t"+clean(function)+"\t"+clean(script)+"\t"+clean(parameters,256)+"\t"+clean(outcome,256)+"\n";
        struct stat info;
        if (stat(path.c_str(),&info)==0 && info.st_size+long(line.size())>Limit) {
            // POSIX rename replaces only our previous generated log, never a .kfix or game file.
            if (std::rename(path.c_str(),(path+".previous").c_str())!=0) return false;
        }
        std::FILE *file=std::fopen(path.c_str(),"a");
        if (!file) return false;
        bool ok=std::fwrite(line.data(),1,line.size(),file)==line.size();
        int closed=std::fclose(file); return ok && closed==0;
    }
};
}}
#endif
