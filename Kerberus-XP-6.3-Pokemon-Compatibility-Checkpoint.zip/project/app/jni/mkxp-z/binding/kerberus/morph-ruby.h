#ifndef KERBERUS_MORPH_RUBY_H
#define KERBERUS_MORPH_RUBY_H
#include "morph-core.h"
#include <cstdlib>
#include <cstring>

// Included only by MiniFFI on Android. Ruby's GVL serializes these callbacks.
namespace kerberus { namespace morph {
static Plan plan;
static EventLog events;
static ID apiId;
static uint64_t windowOwnerThread = 0;
static bool applied[ApiCount]={};
static const char *libraries[ApiCount]={"", "kernel32", "kernel32", "winmm", "kernel32", "kernel32", "kernel32", "user32"};
static const char *functions[ApiCount]={"", "GetTickCount", "GetTickCount64", "timeGetTime", "QueryPerformanceCounter", "QueryPerformanceFrequency", "GetCurrentThreadId", "GetWindowThreadProcessId"};

struct Source { char text[192]; };
#if RAPI_MAJOR < 2
// Ruby 1.8 has no caller_locations: parse Kernel#caller strings
// ("Section012:34:in `method'") and map the section to its script name.
static VALUE locateSource(VALUE raw) {
    Source *source=reinterpret_cast<Source*>(raw);
    VALUE stack=rb_funcall(rb_mKernel,rb_intern("caller"),1,INT2FIX(0));
    if (!RB_TYPE_P(stack,T_ARRAY)) return Qnil;
    VALUE scripts=rb_gv_get("$RGSS_SCRIPTS");
    for (long i=0;i<RARRAY_LEN(stack);++i) {
        VALUE frame=rb_ary_entry(stack,i);
        if (!RB_TYPE_P(frame,T_STRING)) continue;
        const char *text=RSTRING_PTR(frame); long len=RSTRING_LEN(frame);
        if (len<9 || std::memcmp(text,"Section",7)!=0) continue;
        long index=0, j=7;
        while (j<len && text[j]>='0' && text[j]<='9' && index<100000) index=index*10+(text[j++]-'0');
        if (j==7 || j>=len || text[j]!=':') continue;
        long line=0; ++j;
        while (j<len && text[j]>='0' && text[j]<='9' && line<10000000) line=line*10+(text[j++]-'0');
        VALUE entry=RB_TYPE_P(scripts,T_ARRAY) ? rb_ary_entry(scripts,index) : Qnil;
        VALUE name=RB_TYPE_P(entry,T_ARRAY) ? rb_ary_entry(entry,1) : Qnil;
        if (RB_TYPE_P(name,T_STRING))
            ::snprintf(source->text,sizeof(source->text),"%.*s:%ld",int(std::min(RSTRING_LEN(name),150L)),RSTRING_PTR(name),line);
        else
            ::snprintf(source->text,sizeof(source->text),"Section%03ld:%ld",index,line);
        return Qnil;
    }
    return Qnil;
}
#else
static VALUE locateSource(VALUE raw) {
    Source *source=reinterpret_cast<Source*>(raw);
    VALUE stack=rb_funcall(rb_mKernel,rb_intern("caller_locations"),2,INT2FIX(0),INT2FIX(8));
    if (!RB_TYPE_P(stack,T_ARRAY)) return Qnil;
    for (long i=0;i<RARRAY_LEN(stack);++i) {
        VALUE frame=rb_ary_entry(stack,i), path=rb_funcall(frame,rb_intern("path"),0);
        if (!RB_TYPE_P(path,T_STRING)) continue;
        const char *text=RSTRING_PTR(path); long len=RSTRING_LEN(path);
        if (len==0) continue;
        VALUE number=rb_funcall(frame,rb_intern("lineno"),0);
        int line=FIXNUM_P(number) ? FIX2INT(number) : 0;
        // Resolve mkxp's SectionNNN label through the existing script table.
        VALUE scripts=rb_gv_get("$RGSS_SCRIPTS");
        if (len>7 && len<20 && std::memcmp(text,"Section",7)==0 && RB_TYPE_P(scripts,T_ARRAY)) {
            long index=0; bool numeric=true;
            for (long j=7;j<len;++j) {
                if (text[j]<'0'||text[j]>'9' || index>100000) { numeric=false; break; }
                index=index*10+(text[j]-'0');
            }
            VALUE entry=numeric ? rb_ary_entry(scripts,index) : Qnil;
            VALUE name=RB_TYPE_P(entry,T_ARRAY) ? rb_ary_entry(entry,1) : Qnil;
            if (RB_TYPE_P(name,T_STRING)) { path=name; text=RSTRING_PTR(path); len=RSTRING_LEN(path); }
        }
        // No absolute paths or buffer contents in compatibility logs.
        long start=0;
        for (long j=0;j<len;++j) if (text[j]=='/'||text[j]=='\\') start=j+1;
        ::snprintf(source->text,sizeof(source->text),"%.*s:%d",int(std::min(len-start,150L)),text+start,line);
        return Qnil;
    }
    return Qnil;
}
#endif
static std::string source() {
    Source location={"script nao identificado"}; int state=0;
    VALUE previous=rb_errinfo();
    rb_protect(locateSource,reinterpret_cast<VALUE>(&location),&state);
    if (state) rb_set_errinfo(previous);
    return clean(location.text);
}
static std::string valueText(VALUE value) {
    if (!RB_TYPE_P(value,T_STRING)) return "tipo nao textual";
    return clean(std::string(RSTRING_PTR(value),size_t(std::min(RSTRING_LEN(value),256L))));
}
static bool signature(VALUE value, char *result) {
    std::string input;
    if (NIL_P(value) || (FIXNUM_P(value) && FIX2LONG(value)==0)) { result[0]=0; return true; }
    if (RB_TYPE_P(value,T_STRING)) {
        if (RSTRING_LEN(value)>128) return false;
        input.assign(RSTRING_PTR(value),size_t(RSTRING_LEN(value)));
    } else if (RB_TYPE_P(value,T_ARRAY)) {
        if (RARRAY_LEN(value)>16) return false;
        for (long i=0;i<RARRAY_LEN(value);++i) {
            VALUE item=rb_ary_entry(value,i);
            if (!RB_TYPE_P(item,T_STRING)||RSTRING_LEN(item)!=1) return false;
            input.push_back(RSTRING_PTR(item)[0]);
        }
    } else return false;
    for (char &ch:input) if (ch>='a' && ch<='z') ch-=32;
    if (input.size()>=4 && input.compare(0,3,"%W(")==0 && input.back()==')')
        input=input.substr(3,input.size()-4);
    size_t length=0;
    for (char ch:input) {
        if (ch==' ' || ch=='\t' || ch==',') continue;
        if (!std::strchr("PLNIV",ch) || length>=16) return false;
        result[length++]=ch;
    }
    result[length]=0; return true;
}
static void init(int rgss) {
    const char *log=std::getenv("KERBERUS_MORPH_LOG"), *session=std::getenv("KERBERUS_MORPH_SESSION"), *text=std::getenv("KERBERUS_MORPH_PLAN");
    events.open(log?log:"",session?session:"");
    apiId=rb_intern("_kerberus_morph_api");
    windowOwnerThread=currentThreadIdentity();
    for (bool &value:applied) value=false;
    if (!plan.parse(text?text:"KMX1\n",rgss)) {
        events.record("CONFIG_REJECTED",nullptr,"","","","","Plano invalido; nenhuma correcao ativada");
        kerberusTrace("MORPH","Plano rejeitado; jogo continua sem correcoes Morph.");
    }
    events.record("SESSION",nullptr,"","","","enabled="+std::to_string(plan.size),"Inicio da sessao; habilitar nao significa aplicar");
}
static bool bind(VALUE self, VALUE library, VALUE function, VALUE imports, VALUE exports) {
    // Called only AFTER normal library/symbol resolution has failed.
    Api api; int rule; bool valid=false;
    char in[17]={}, out[17]={};
    bool parsed=false;
    {
        std::string lib=valueText(library), fn=valueText(function);
        api=identify(lib,fn); rule=plan.ruleFor(api);

        parsed=signature(imports,in)&&signature(exports,out);
        bool numericResult=parsed && std::strlen(out)==1 && std::strchr("NLI",out[0]);
        bool noArguments=!*in || std::strcmp(in,"V")==0;
        valid=numericResult && (((api>=Tick32&&api<=MultimediaTick) || api==CurrentThreadId) ? noArguments
                : (api==Counter || api==Frequency) ? std::strcmp(in,"P")==0
                : api==WindowThreadProcessId && std::strlen(in)==2 && std::strchr("NLI",in[0]) && in[1]=='P');

        std::string parameters;
        if (api==CurrentThreadId)
            parameters="assinatura fixa normalizada: sem argumentos -> DWORD";
        else if (api==WindowThreadProcessId)
            parameters="assinatura fixa normalizada: HWND, LPDWORD -> DWORD";
        else
            parameters=parsed ? std::string("imports=")+in+"; exports="+out : "assinatura fora do formato suportado";

        const char *type=rule<0 ? "API_MISSING" : !valid ? "SIGNATURE_REJECTED" : "BOUND";
        std::string outcome=rule<0 ? (api==Unsupported ? "API ainda sem implementacao Morph" : "Correcao disponivel, mas desligada neste jogo")
                : !valid ? "Assinatura nao suportada; nenhuma substituicao"
                         : (api==CurrentThreadId || api==WindowThreadProcessId)
                               ? "Assinatura conhecida normalizada; aguardando chamada"
                               : "Fallback associado; aguardando chamada";
        bool logged=events.record(type,rule<0?nullptr:&plan.rules[rule],lib,fn,source(),parameters,outcome);
        // Always put the exact missing function in the existing copyable boot report too.
        if (logged && (rule<0 || !valid)) {
            std::string detail=lib+"!"+fn+"; "+parameters+"; "+outcome;
            kerberusTrace("MORPH",detail.c_str());
        }
    }
    if (rule<0 || !valid) return false;
    rb_ivar_set(self,apiId,INT2FIX(api));
    return true;
}
static void callEvent(const char *type, Api api, int argc, const VALUE *argv, const char *outcome) {
    int rule=plan.ruleFor(api);
    std::string parameters="argc="+std::to_string(argc);
    if (argc>0) {
        if (RB_TYPE_P(argv[0],T_STRING)) parameters+="; buffer_bytes="+std::to_string(RSTRING_LEN(argv[0]));
        else parameters+="; arg0_type="+std::to_string(TYPE(argv[0]));
    }
    events.record(type,rule<0?nullptr:&plan.rules[rule],libraries[api],functions[api],source(),parameters,outcome);
    if (std::strcmp(type,"APPLIED")==0 && rule>=0) {
        std::string message=plan.rules[rule].id+" v"+std::to_string(plan.rules[rule].version)+" aplicado: "+libraries[api]+"!"+functions[api];
        kerberusTrace("PATCH",message.c_str());
    }
}
static bool call(VALUE self, int argc, const VALUE *argv, VALUE *result) {
    if (!plan.size) return false;
    VALUE marker=rb_ivar_get(self,apiId);
    if (NIL_P(marker)) return false;
    if (!FIXNUM_P(marker)) rb_raise(rb_eRuntimeError,"Morph: identificador de chamada invalido");
    int number=FIX2INT(marker);
    if (number<=Unsupported || number>=ApiCount || plan.ruleFor(Api(number))<0)
        rb_raise(rb_eRuntimeError,"Morph: chamada fora do plano aprovado");
    Api api=Api(number);

    const char *failure=nullptr;

    if (api==WindowThreadProcessId) {
        if (argc!=2) {
            failure="Morph: GetWindowThreadProcessId requer HWND e LPDWORD";
        } else {
            bool hwndOk=NIL_P(argv[0]) || FIXNUM_P(argv[0]);
            bool processNull=NIL_P(argv[1]) || (FIXNUM_P(argv[1]) && FIX2LONG(argv[1])==0);
            bool processBuffer=RB_TYPE_P(argv[1],T_STRING) && RSTRING_LEN(argv[1])>=4 && !OBJ_FROZEN(argv[1]);
            if (!hwndOk)
                failure="Morph: HWND virtual deve ser inteiro ou nil";
            else if (!processNull && !processBuffer)
                failure="Morph: LPDWORD deve ser nil, 0 ou String Ruby gravavel de pelo menos 4 bytes";
        }
    } else {
        bool pointer=api==Counter||api==Frequency;
        if (argc!=(pointer?1:0)) failure="Morph: quantidade de argumentos incompativel";
        else if (pointer && (!RB_TYPE_P(argv[0],T_STRING) || RSTRING_LEN(argv[0])<8 || OBJ_FROZEN(argv[0])))
            failure="Morph: esta API requer String Ruby gravavel de pelo menos 8 bytes; ponteiros numericos nao sao aceitos";
    }

    if (failure) {
        callEvent("PARAMETER_REJECTED",api,argc,argv,failure);
        rb_raise(rb_eArgError,"%s",failure);
    }

    uint64_t value=0;

    if (api==CurrentThreadId) {
        value=currentThreadIdentity();
        if (!value) {
            callEvent("THREAD_ID_ERROR",api,argc,argv,"Identificador de thread do Android indisponivel");
            rb_raise(rb_eRuntimeError,"Morph: identificador de thread do Android indisponivel");
        }
        *result=ULL2NUM(value);
    } else if (api==WindowThreadProcessId) {
        if (NIL_P(argv[0]) || FIX2LONG(argv[0])!=1) { *result=INT2FIX(0); return true; }
        value=windowOwnerThread;
        uint64_t process=currentProcessIdentity();
        if (!value || !process) {
            callEvent("THREAD_ID_ERROR",api,argc,argv,"Identificador de thread/processo do Android indisponivel");
            rb_raise(rb_eRuntimeError,"Morph: identificador de thread/processo do Android indisponivel");
        }
        if (RB_TYPE_P(argv[1],T_STRING)) {
            rb_str_modify(argv[1]);
            littleEndian32(RSTRING_PTR(argv[1]),process);
        }
        *result=ULL2NUM(value);
    } else {
        if (!clockValue(api,value)) {
            callEvent("CLOCK_ERROR",api,argc,argv,"Relogio do Android indisponivel");
            rb_raise(rb_eRuntimeError,"Morph: relogio do Android indisponivel");
        }
        bool pointer=api==Counter||api==Frequency;
        if (pointer) {
            rb_str_modify(argv[0]);
            littleEndian64(RSTRING_PTR(argv[0]),value);
            *result=INT2FIX(1);
        } else {
            *result=ULL2NUM(value);
        }
    }

    if (!applied[api]) {
        applied[api]=true;
        callEvent("APPLIED",api,argc,argv,"Implementacao Android executada");
    }
    return true;
}
}}
#endif
