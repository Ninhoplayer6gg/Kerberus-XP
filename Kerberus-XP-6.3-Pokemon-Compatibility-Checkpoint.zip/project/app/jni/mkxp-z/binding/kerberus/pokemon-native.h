#ifndef KERBERUS_POKEMON_NATIVE_H
#define KERBERUS_POKEMON_NATIVE_H
#include <unistd.h>
#include <sys/syscall.h>
#include <SDL.h>
#if RAPI_MAJOR < 2
#include <stdint.h>
#include <time.h>
#include <sys/statvfs.h>
#include <unordered_map>
#include "sharedstate.h"
#include "eventthread.h"
// Win32 VK -> SDL scancode table that Input.pressex? uses (src/input/input.cpp).
extern std::unordered_map<int, int> vKeyToScancode;
#include "hm7-native.h"
#endif
// No pointers or Windows handles cross this boundary.
static VALUE kerberusPokemonThreadId(VALUE) {
    return LONG2NUM(::syscall(SYS_gettid));
}
static VALUE kerberusPokemonFocused(VALUE) {
    return SDL_GetKeyboardFocus() ? Qtrue : Qfalse;
}
#if RAPI_MAJOR < 2
// Kerberus 6.3 WinBridge (legacy18 only): Windows uptime/QPC semantics.
// CLOCK_BOOTTIME keeps counting while the device sleeps, like Windows.
static uint64_t kerberusBootNanoseconds() {
    timespec value = {};
    if (clock_gettime(CLOCK_BOOTTIME, &value) != 0 && clock_gettime(CLOCK_MONOTONIC, &value) != 0)
        return 0;
    return uint64_t(value.tv_sec) * 1000000000ULL + uint64_t(value.tv_nsec);
}
static VALUE kerberusNativeUptimeMs(VALUE) {
    return ULL2NUM(kerberusBootNanoseconds() / 1000000ULL);
}
static VALUE kerberusNativeMonotonicNs(VALUE) {
    return ULL2NUM(kerberusBootNanoseconds());
}
// XInputSetState -> SDL_GameControllerRumble on the controller mkxp-z owns.
static VALUE kerberusNativeControllerRumble(VALUE, VALUE low, VALUE high, VALUE ms) {
    SDL_GameController *controller = shState->eThread().controller();
    if (!controller)
        return Qfalse;
    Uint16 lowValue = Uint16(NUM2ULONG(low) & 0xffff);
    Uint16 highValue = Uint16(NUM2ULONG(high) & 0xffff);
    Uint32 duration = Uint32(NUM2ULONG(ms));
    return SDL_GameControllerRumble(controller, lowValue, highValue, duration) == 0 ? Qtrue : Qfalse;
}
// Live input for the Win32 key APIs (legacy18 only).
// Input.pressex?, mouse_x and Input::Controller read a copy that only the
// native Input.update refreshes. Essentials v15-v17 games replace
// Input.update with their own GetAsyncKeyState polling, so that copy never
// changes and every key reads as released. Windows answers these APIs from
// the live keyboard; the SDL event thread's arrays are the same thing here.
static bool kerberusScancodeDown(int scancode) {
    return scancode > SDL_SCANCODE_UNKNOWN && scancode < SDL_NUM_SCANCODES &&
           EventThread::keyStates[scancode];
}
static bool kerberusVirtualKeyDown(int vk) {
    const EventThread::MouseState &mouse = EventThread::mouseState;
    switch (vk) {
    case 0x01: return mouse.buttons[SDL_BUTTON_LEFT];
    case 0x02: return mouse.buttons[SDL_BUTTON_RIGHT];
    case 0x04: return mouse.buttons[SDL_BUTTON_MIDDLE];
    case 0x05: return mouse.buttons[SDL_BUTTON_X1];
    case 0x06: return mouse.buttons[SDL_BUTTON_X2];
    case 0x0D: return kerberusScancodeDown(SDL_SCANCODE_RETURN) || kerberusScancodeDown(SDL_SCANCODE_KP_ENTER);
    case 0x10: return kerberusScancodeDown(SDL_SCANCODE_LSHIFT) || kerberusScancodeDown(SDL_SCANCODE_RSHIFT);
    case 0x11: return kerberusScancodeDown(SDL_SCANCODE_LCTRL) || kerberusScancodeDown(SDL_SCANCODE_RCTRL);
    case 0x12: return kerberusScancodeDown(SDL_SCANCODE_LALT) || kerberusScancodeDown(SDL_SCANCODE_RALT);
    case 0xA0: return kerberusScancodeDown(SDL_SCANCODE_LSHIFT);
    case 0xA1: return kerberusScancodeDown(SDL_SCANCODE_RSHIFT);
    case 0xA2: return kerberusScancodeDown(SDL_SCANCODE_LCTRL);
    case 0xA3: return kerberusScancodeDown(SDL_SCANCODE_RCTRL);
    case 0xA4: return kerberusScancodeDown(SDL_SCANCODE_LALT);
    case 0xA5: return kerberusScancodeDown(SDL_SCANCODE_RALT);
    default: break;
    }
    // find(): operator[] would insert unknown codes into mkxp-z's table.
    std::unordered_map<int, int>::const_iterator entry = vKeyToScancode.find(vk);
    return entry != vKeyToScancode.end() && kerberusScancodeDown(entry->second);
}
static VALUE kerberusNativeKeyDown(VALUE, VALUE vk) {
    long code = NUM2LONG(vk);
    if (code < 0 || code > 255)
        return Qfalse;
    return kerberusVirtualKeyDown(int(code)) ? Qtrue : Qfalse;
}
// Same transform as Input::mouseX/mouseY, applied to the live pointer.
static VALUE kerberusNativeMousePosition(VALUE) {
    RGSSThreadData &rtData = shState->rtData();
    int x = (EventThread::mouseState.x - rtData.screenOffset.x) * rtData.sizeResoRatio.x;
    int y = (EventThread::mouseState.y - rtData.screenOffset.y) * rtData.sizeResoRatio.y;
    return rb_ary_new3(2, INT2NUM(x), INT2NUM(y));
}
// Bit i = SDL_GameControllerButton i held; nil when no controller is open.
static VALUE kerberusNativePadButtons(VALUE) {
    if (!shState->eThread().controller())
        return Qnil;
    long mask = 0;
    for (int button = 0; button < SDL_CONTROLLER_BUTTON_MAX && button < 30; ++button)
        if (EventThread::controllerState.buttons[button])
            mask |= 1L << button;
    return LONG2NUM(mask);
}
// Raw SDL axis value (-32768..32767; triggers 0..32767).
static VALUE kerberusNativePadAxis(VALUE, VALUE axis) {
    long index = NUM2LONG(axis);
    if (index < 0 || index >= SDL_CONTROLLER_AXIS_MAX || !shState->eThread().controller())
        return INT2FIX(0);
    return INT2NUM(EventThread::controllerState.axes[index]);
}
// GetDiskFreeSpaceExA: [bytes free for this app, total, free] of the
// filesystem holding PATH (statvfs); nil when it cannot be read.
static VALUE kerberusNativeDiskSpace(VALUE, VALUE path) {
    struct statvfs info;
    if (statvfs(StringValueCStr(path), &info) != 0)
        return Qnil;
    unsigned long long unit = info.f_frsize ? info.f_frsize : info.f_bsize;
    return rb_ary_new3(3, ULL2NUM(unit * info.f_bavail), ULL2NUM(unit * info.f_blocks),
                       ULL2NUM(unit * info.f_bfree));
}
#endif
static void kerberusPokemonNativeInit() {
    VALUE module = rb_define_module("KerberusNative");
    rb_define_singleton_method(module, "thread_id", RUBY_METHOD_FUNC(kerberusPokemonThreadId), 0);
    rb_define_singleton_method(module, "focused?", RUBY_METHOD_FUNC(kerberusPokemonFocused), 0);
#if RAPI_MAJOR < 2
    rb_define_singleton_method(module, "uptime_ms", RUBY_METHOD_FUNC(kerberusNativeUptimeMs), 0);
    rb_define_singleton_method(module, "monotonic_ns", RUBY_METHOD_FUNC(kerberusNativeMonotonicNs), 0);
    rb_define_singleton_method(module, "controller_rumble", RUBY_METHOD_FUNC(kerberusNativeControllerRumble), 3);
    rb_define_singleton_method(module, "key_down?", RUBY_METHOD_FUNC(kerberusNativeKeyDown), 1);
    rb_define_singleton_method(module, "mouse_position", RUBY_METHOD_FUNC(kerberusNativeMousePosition), 0);
    rb_define_singleton_method(module, "pad_buttons", RUBY_METHOD_FUNC(kerberusNativePadButtons), 0);
    rb_define_singleton_method(module, "pad_axis", RUBY_METHOD_FUNC(kerberusNativePadAxis), 1);
    rb_define_singleton_method(module, "disk_space", RUBY_METHOD_FUNC(kerberusNativeDiskSpace), 1);
    kerberusHm7NativeInit(module);
#endif
}
#endif
