#ifndef KERBERUS_POKEMON_NATIVE_H
#define KERBERUS_POKEMON_NATIVE_H
#include <unistd.h>
#include <sys/syscall.h>
#include <SDL.h>
#if RAPI_MAJOR < 2
#include <stdint.h>
#include <time.h>
#include "sharedstate.h"
#include "eventthread.h"
#endif
// No pointers or Windows handles cross this boundary.
static VALUE kerberusPokemonThreadId(VALUE) {
    return LONG2NUM(::syscall(SYS_gettid));
}
static VALUE kerberusPokemonFocused(VALUE) {
    return SDL_GetKeyboardFocus() ? Qtrue : Qfalse;
}
#if RAPI_MAJOR < 2
// Kerberus 6.3 WinBridge (legacy18 only): Windows uptime/QPC semantics.
// CLOCK_BOOTTIME keeps counting while the device sleeps, like Windows.
static uint64_t kerberusBootNanoseconds() {
    timespec value = {};
    if (clock_gettime(CLOCK_BOOTTIME, &value) != 0 && clock_gettime(CLOCK_MONOTONIC, &value) != 0)
        return 0;
    return uint64_t(value.tv_sec) * 1000000000ULL + uint64_t(value.tv_nsec);
}
static VALUE kerberusNativeUptimeMs(VALUE) {
    return ULL2NUM(kerberusBootNanoseconds() / 1000000ULL);
}
static VALUE kerberusNativeMonotonicNs(VALUE) {
    return ULL2NUM(kerberusBootNanoseconds());
}
// XInputSetState -> SDL_GameControllerRumble on the controller mkxp-z owns.
static VALUE kerberusNativeControllerRumble(VALUE, VALUE low, VALUE high, VALUE ms) {
    SDL_GameController *controller = shState->eThread().controller();
    if (!controller)
        return Qfalse;
    Uint16 lowValue = Uint16(NUM2ULONG(low) & 0xffff);
    Uint16 highValue = Uint16(NUM2ULONG(high) & 0xffff);
    Uint32 duration = Uint32(NUM2ULONG(ms));
    return SDL_GameControllerRumble(controller, lowValue, highValue, duration) == 0 ? Qtrue : Qfalse;
}
#endif
static void kerberusPokemonNativeInit() {
    VALUE module = rb_define_module("KerberusNative");
    rb_define_singleton_method(module, "thread_id", RUBY_METHOD_FUNC(kerberusPokemonThreadId), 0);
    rb_define_singleton_method(module, "focused?", RUBY_METHOD_FUNC(kerberusPokemonFocused), 0);
#if RAPI_MAJOR < 2
    rb_define_singleton_method(module, "uptime_ms", RUBY_METHOD_FUNC(kerberusNativeUptimeMs), 0);
    rb_define_singleton_method(module, "monotonic_ns", RUBY_METHOD_FUNC(kerberusNativeMonotonicNs), 0);
    rb_define_singleton_method(module, "controller_rumble", RUBY_METHOD_FUNC(kerberusNativeControllerRumble), 3);
#endif
}
#endif
