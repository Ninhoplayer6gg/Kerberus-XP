#ifndef KERBERUS_ZLIB_INFLATE_H
#define KERBERUS_ZLIB_INFLATE_H
// Kerberus (6.6.1): zlib inflate of a byte buffer, outside Ruby.
//
// Used by KerberusNative.inflate (legacy18) after Ruby's Zlib::Inflate.inflate
// raised Zlib::DataError. The caller passes a private copy of the input, so
// nothing here allocates Ruby objects or depends on the Ruby GC.
//   chunk > 0: several inflate() calls with CHUNK bytes of output each, the
//              calling pattern of Ruby's zlib extension (zstream_run).
//   chunk = 0: one uncompress() call with an output buffer doubled until it
//              fits, the pattern of the Scripts.rxdata loader (binding-mri.cpp).
// Z_OK means zlib reached the end of the stream, which includes its Adler-32
// check of the output. Otherwise the zlib code is returned with its message.
#include <zlib.h>
#include <string>
#include <vector>

static const size_t KERBERUS_INFLATE_LIMIT = 256u << 20;

static int kerberusInflateChunked(const std::vector<unsigned char> &input, size_t chunk,
                                  std::string &output, std::string &message) {
    z_stream stream = z_stream();
    int result = inflateInit(&stream);
    if (result != Z_OK) {
        message = stream.msg ? stream.msg : "inflateInit";
        return result;
    }
    stream.next_in = const_cast<Bytef *>(input.empty() ? 0 : &input[0]);
    stream.avail_in = (uInt) input.size();
    output.clear();
    for (;;) {
        if (output.size() + chunk > KERBERUS_INFLATE_LIMIT) {
            result = Z_MEM_ERROR;
            message = "saida maior que o limite";
            break;
        }
        size_t filled = output.size();
        output.resize(filled + chunk);
        stream.next_out = reinterpret_cast<Bytef *>(&output[filled]);
        stream.avail_out = (uInt) chunk;
        result = inflate(&stream, Z_NO_FLUSH);
        output.resize(filled + chunk - stream.avail_out);
        if (result == Z_STREAM_END) {
            result = Z_OK;
            break;
        }
        if (result == Z_OK)
            continue;
        if (result == Z_BUF_ERROR && stream.avail_in == 0)
            message = "fluxo incompleto";
        else
            message = stream.msg ? stream.msg : "inflate";
        break;
    }
    inflateEnd(&stream);
    return result;
}

static int kerberusInflateWhole(const std::vector<unsigned char> &input,
                                std::string &output, std::string &message) {
    size_t size = input.size() * 4 > 4096 ? input.size() * 4 : 4096;
    for (;;) {
        output.resize(size);
        uLongf length = (uLongf) size;
        int result = uncompress(reinterpret_cast<Bytef *>(&output[0]), &length,
                                input.empty() ? 0 : &input[0], (uLong) input.size());
        if (result == Z_OK) {
            output.resize(length);
            return Z_OK;
        }
        if (result != Z_BUF_ERROR || size * 2 > KERBERUS_INFLATE_LIMIT) {
            output.clear();
            message = result == Z_BUF_ERROR ? "fluxo incompleto ou saida maior que o limite" :
                      result == Z_DATA_ERROR ? "dados invalidos (uncompress)" : "uncompress";
            return result;
        }
        size *= 2;
    }
}

static int kerberusInflate(const std::vector<unsigned char> &input, size_t chunk,
                           std::string &output, std::string &message) {
    return chunk ? kerberusInflateChunked(input, chunk, output, message)
                 : kerberusInflateWhole(input, output, message);
}
#endif
