#ifndef KERBERUS_CPU_H
#define KERBERUS_CPU_H

// Kerberus 6.5: where the game thread runs on Android (both engines).
//  * The thread that runs the game scripts and draws (the one that builds
//    Graphics) is pinned to the fastest cores: those whose maximum clock is
//    at least 80% of the highest. On big.LITTLE phones (Snapdragon 685:
//    4x A73 2.8 GHz + 4x A53 1.9 GHz) a frame-paced thread is otherwise often
//    left on a little core, where the Ruby interpreter is about half as fast.
//  * Android 13+ Performance Hint (ADPF, libandroid.so looked up at run
//    time): the frame target and each frame's real work time are reported,
//    so the system raises the clock before frames are late.
// Both are hints to the system; if either is unavailable nothing changes.
#ifdef MKXPZ_BUILD_ANDROID
#include <cstdint>
#include <cstdio>
#include <dlfcn.h>
#include <sched.h>
#include <unistd.h>

struct APerformanceHintManager;
struct APerformanceHintSession;
typedef APerformanceHintManager *(*KerberusHintManagerFn)();
typedef APerformanceHintSession *(*KerberusHintCreateFn)(APerformanceHintManager *, const int32_t *, size_t, int64_t);
typedef int (*KerberusHintDurationFn)(APerformanceHintSession *, int64_t);

static APerformanceHintSession *kerberusHintSession = nullptr;
static KerberusHintDurationFn kerberusHintReport = nullptr;
static KerberusHintDurationFn kerberusHintTarget = nullptr;
static int64_t kerberusHintTargetNs = 0;

static long kerberusCpuMaxFreq(int cpu) {
    char path[96];
    snprintf(path, sizeof(path), "/sys/devices/system/cpu/cpu%d/cpufreq/cpuinfo_max_freq", cpu);
    FILE *file = fopen(path, "r");
    if (!file) return -1;
    long khz = -1;
    if (fscanf(file, "%ld", &khz) != 1) khz = -1;
    fclose(file);
    return khz;
}

static void kerberusCpuPin() {
    const int kMax = 64;
    long freq[kMax];
    int count = (int)sysconf(_SC_NPROCESSORS_CONF);
    if (count < 2) return;
    if (count > kMax) count = kMax;
    long best = 0;
    for (int cpu = 0; cpu < count; ++cpu) {
        freq[cpu] = kerberusCpuMaxFreq(cpu);
        if (freq[cpu] > best) best = freq[cpu];
    }
    if (best <= 0) return;
    cpu_set_t set;
    CPU_ZERO(&set);
    int chosen = 0, first = -1, last = -1;
    for (int cpu = 0; cpu < count; ++cpu) {
        if (freq[cpu] >= best * 8 / 10) {
            CPU_SET(cpu, &set);
            ++chosen;
            if (first < 0) first = cpu;
            last = cpu;
        }
    }
    char detail[160];
    if (chosen == 0 || chosen == count) {
        snprintf(detail, sizeof(detail), "%d nucleos iguais (%.2f GHz): sem fixacao", count, best / 1e6);
    } else if (sched_setaffinity(0, sizeof(set), &set) == 0) {
        snprintf(detail, sizeof(detail), "jogo nos %d nucleos mais rapidos (cpu%d-cpu%d, %.2f GHz) de %d",
                 chosen, first, last, best / 1e6, count);
    } else {
        snprintf(detail, sizeof(detail), "fixacao nos nucleos rapidos recusada pelo sistema");
    }
    kerberusTrace("CPU", detail);
}

static void kerberusCpuHint(int fps) {
    void *lib = dlopen("libandroid.so", RTLD_NOW);
    if (!lib) return;
    KerberusHintManagerFn manager = (KerberusHintManagerFn)dlsym(lib, "APerformanceHint_getManager");
    KerberusHintCreateFn create = (KerberusHintCreateFn)dlsym(lib, "APerformanceHint_createSession");
    kerberusHintReport = (KerberusHintDurationFn)dlsym(lib, "APerformanceHint_reportActualWorkDuration");
    kerberusHintTarget = (KerberusHintDurationFn)dlsym(lib, "APerformanceHint_updateTargetWorkDuration");
    if (!manager || !create || !kerberusHintReport || !kerberusHintTarget) {
        kerberusTrace("CPU", "dica de desempenho (Android 13+) indisponivel neste aparelho");
        return;
    }
    APerformanceHintManager *hints = manager();
    int32_t tid = (int32_t)gettid();
    kerberusHintTargetNs = 1000000000LL / (fps > 0 ? fps : 40);
    if (hints) kerberusHintSession = create(hints, &tid, 1, kerberusHintTargetNs);
    kerberusTrace("CPU", kerberusHintSession ? "dica de desempenho do Android ativa (tempo de cada quadro)"
                                             : "dica de desempenho do Android recusada");
}

// Called once on the game thread.
static void kerberusCpuSetup(int fps) {
    kerberusCpuPin();
    kerberusCpuHint(fps);
}

static void kerberusCpuFrameWork(int64_t ns) {
    if (kerberusHintSession && ns > 0) kerberusHintReport(kerberusHintSession, ns);
}

static void kerberusCpuFrameTarget(int fps) {
    if (!kerberusHintSession || fps <= 0) return;
    int64_t target = 1000000000LL / fps;
    if (target == kerberusHintTargetNs) return;
    kerberusHintTargetNs = target;
    kerberusHintTarget(kerberusHintSession, target);
}
#endif

#endif
