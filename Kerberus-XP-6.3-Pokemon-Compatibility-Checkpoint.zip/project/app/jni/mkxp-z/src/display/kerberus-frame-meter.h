#ifndef KERBERUS_FRAME_METER_H
#define KERBERUS_FRAME_METER_H

#include <cstdint>

// Called by the render thread after a completed presentation, not a Ruby update.
class KerberusFrameMeter {
    bool started = false;
    unsigned generation = 0;
    std::uint64_t start = 0;
    std::uint32_t frames = 0;
    std::uint32_t milliFps = 0;
public:
    bool present(std::uint64_t now, unsigned requestedGeneration) {
        if (!started || generation != requestedGeneration) {
            started = true;
            generation = requestedGeneration;
            start = now;
            frames = 0;
            milliFps = 0;
            return false;
        }
        ++frames;
        const std::uint64_t elapsed = now - start;
        if (elapsed < 1000) return false;
        milliFps = static_cast<std::uint32_t>(static_cast<std::uint64_t>(frames) * 1000000 / elapsed);
        start = now;
        frames = 0;
        return true;
    }
    std::uint32_t value() const { return milliFps; }
};

#endif
