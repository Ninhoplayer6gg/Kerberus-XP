#ifndef KERBERUS_RUNTIME_METRICS_H
#define KERBERUS_RUNTIME_METRICS_H

#include "kerberus-frame-meter.h"
#include <atomic>
#include <jni.h>
#include <SDL_timer.h>

// One translation unit (graphics.cpp). No allocation, file IO or JNI per frame.
static std::atomic<bool> kerberusMetricsEnabled(false);
static std::atomic<unsigned> kerberusMetricsGeneration(1);
static std::atomic<unsigned> kerberusPublishedGeneration(0);
static std::atomic<std::uint32_t> kerberusMilliFps(0);
static std::atomic<std::uint64_t> kerberusLastPresent(0);
static KerberusFrameMeter kerberusFrameMeter;

static void kerberusPresentedFrame() {
    if (!kerberusMetricsEnabled.load(std::memory_order_relaxed)) return;
    const auto now = SDL_GetTicks64();
    const auto generation = kerberusMetricsGeneration.load(std::memory_order_acquire);
    kerberusLastPresent.store(now, std::memory_order_relaxed);
    if (kerberusFrameMeter.present(now, generation)) {
        kerberusMilliFps.store(kerberusFrameMeter.value(), std::memory_order_relaxed);
        kerberusPublishedGeneration.store(generation, std::memory_order_release);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_kerberus_launcher_RuntimeMetrics_setEnabled(JNIEnv *, jclass, jboolean enabled) {
    const bool requested = enabled == JNI_TRUE;
    if (kerberusMetricsEnabled.exchange(requested, std::memory_order_relaxed) != requested)
        kerberusMetricsGeneration.fetch_add(1, std::memory_order_release);
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_kerberus_launcher_RuntimeMetrics_framesPerSecond(JNIEnv *, jclass) {
    if (!kerberusMetricsEnabled.load(std::memory_order_relaxed)) return -1;
    const unsigned requested = kerberusMetricsGeneration.load(std::memory_order_acquire);
    if (kerberusPublishedGeneration.load(std::memory_order_acquire) != requested) return -1;
    if (SDL_GetTicks64() - kerberusLastPresent.load(std::memory_order_relaxed) > 1500) return 0;
    return kerberusMilliFps.load(std::memory_order_relaxed) / 1000.0f;
}

#endif
