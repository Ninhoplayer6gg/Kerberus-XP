#ifndef KERBERUS_RUNTIME_METRICS_H
#define KERBERUS_RUNTIME_METRICS_H

#include "kerberus-frame-meter.h"
#include <atomic>
#include <jni.h>
#include <SDL_timer.h>

// One translation unit (graphics.cpp). No allocation, file IO or JNI per frame.
static std::atomic<bool> kerberusMetricsEnabled(false);
static std::atomic<unsigned> kerberusMetricsGeneration(1);
static std::atomic<unsigned> kerberusPublishedGeneration(0);
static std::atomic<std::uint32_t> kerberusMilliFps(0);
static std::atomic<std::uint64_t> kerberusLastPresent(0);
static KerberusFrameMeter kerberusFrameMeter;

struct KerberusPerf;
static void kerberusPerfPresented();

static void kerberusPresentedFrame() {
    if (!kerberusMetricsEnabled.load(std::memory_order_relaxed)) return;
    kerberusPerfPresented();
    const auto now = SDL_GetTicks64();
    const auto generation = kerberusMetricsGeneration.load(std::memory_order_acquire);
    kerberusLastPresent.store(now, std::memory_order_relaxed);
    if (kerberusFrameMeter.present(now, generation)) {
        kerberusMilliFps.store(kerberusFrameMeter.value(), std::memory_order_relaxed);
        kerberusPublishedGeneration.store(generation, std::memory_order_release);
    }
}

extern "C" JNIEXPORT void JNICALL
Java_com_kerberus_launcher_RuntimeMetrics_setEnabled(JNIEnv *, jclass, jboolean enabled) {
    const bool requested = enabled == JNI_TRUE;
    if (kerberusMetricsEnabled.exchange(requested, std::memory_order_relaxed) != requested)
        kerberusMetricsGeneration.fetch_add(1, std::memory_order_release);
}

extern "C" JNIEXPORT jfloat JNICALL
Java_com_kerberus_launcher_RuntimeMetrics_framesPerSecond(JNIEnv *, jclass) {
    if (!kerberusMetricsEnabled.load(std::memory_order_relaxed)) return -1;
    const unsigned requested = kerberusMetricsGeneration.load(std::memory_order_acquire);
    if (kerberusPublishedGeneration.load(std::memory_order_acquire) != requested) return -1;
    if (SDL_GetTicks64() - kerberusLastPresent.load(std::memory_order_relaxed) > 1500) return 0;
    return kerberusMilliFps.load(std::memory_order_relaxed) / 1000.0f;
}

// Kerberus 6.5: what each game frame costs, measured on the game thread and
// published once per second. Only the frame counter behind the turbo speed
// readout runs all the time; the rest runs while the performance panel is on.
//   speed  game frames per second / the game's own frame rate
//   logic  time the scripts ran between two Graphics.update calls
//   render time composing and scaling a frame before it is presented
//   worst  longest gap between two presented frames (a visible hitch)
//   gc     collections and their time in the Ruby engine (binding-mri.cpp)
extern "C" void kerberusGcSample(unsigned long *runs, unsigned long *usec);

enum {
    KERBERUS_PERF_UPDATES, KERBERUS_PERF_PRESENTS, KERBERUS_PERF_SPEED,
    KERBERUS_PERF_LOGIC, KERBERUS_PERF_LOGIC_MAX, KERBERUS_PERF_RENDER,
    KERBERUS_PERF_WORST, KERBERUS_PERF_GC_RUNS, KERBERUS_PERF_GC_MS, KERBERUS_PERF_FIELDS
};
static std::atomic<std::uint32_t> kerberusPerfValues[KERBERUS_PERF_FIELDS]; // x1000
static std::atomic<unsigned> kerberusPerfGeneration(0);
static std::atomic<std::uint64_t> kerberusPerfStamp(0);
static std::atomic<std::uint32_t> kerberusSpeedMilli(0);
static std::atomic<std::uint64_t> kerberusSpeedStamp(0);

struct KerberusPerf {
    std::uint64_t freq = 0, start = 0, lastReturn = 0, renderStart = 0, lastPresent = 0;
    std::uint64_t logicSum = 0, logicMax = 0, logicCount = 0, renderSum = 0, worst = 0;
    std::uint32_t frames = 0, updates = 0, presents = 0;
    unsigned long gcRuns = 0, gcUsec = 0;
    unsigned generation = 0;
    bool detail = false;

    double ms(std::uint64_t ticks) const { return ticks * 1000.0 / freq; }

    void restart(std::uint64_t now) {
        start = now; frames = updates = presents = 0;
        logicSum = logicMax = logicCount = renderSum = worst = 0;
    }

    // One game frame: a Graphics.update call or a frame of a transition.
    void frame(int baseFps, bool update) {
        const std::uint64_t now = SDL_GetPerformanceCounter();
        if (!freq) { freq = SDL_GetPerformanceFrequency(); restart(now); }
        const bool wanted = kerberusMetricsEnabled.load(std::memory_order_relaxed);
        const unsigned requested = kerberusMetricsGeneration.load(std::memory_order_acquire);
        if (wanted != detail || (wanted && requested != generation)) {
            detail = wanted; generation = requested; lastReturn = lastPresent = 0;
            if (detail) kerberusGcSample(&gcRuns, &gcUsec);
            restart(now);
        }
        ++frames;
        if (update) {
            ++updates;
            if (detail && lastReturn) {
                const std::uint64_t logic = now - lastReturn;
                logicSum += logic; ++logicCount;
                if (logic > logicMax) logicMax = logic;
            }
        }
        const std::uint64_t elapsed = now - start;
        if (elapsed < freq) return;
        const double seconds = (double)elapsed / freq;
        const std::uint32_t speed = baseFps > 0 ? (std::uint32_t)(frames / seconds / baseFps * 1000) : 0;
        kerberusSpeedMilli.store(speed, std::memory_order_relaxed);
        kerberusSpeedStamp.store(SDL_GetTicks64(), std::memory_order_relaxed);
        if (detail) {
            unsigned long runs = gcRuns, usec = gcUsec;
            kerberusGcSample(&gcRuns, &gcUsec);
            const double values[KERBERUS_PERF_FIELDS] = {
                updates / seconds, presents / seconds, speed / 1000.0,
                logicCount ? ms(logicSum) / logicCount : 0, ms(logicMax),
                presents ? ms(renderSum) / presents : 0, ms(worst),
                (double)(gcRuns - runs), (gcUsec - usec) / 1000.0};
            for (int i = 0; i < KERBERUS_PERF_FIELDS; ++i)
                kerberusPerfValues[i].store((std::uint32_t)(values[i] * 1000), std::memory_order_relaxed);
            kerberusPerfStamp.store(SDL_GetTicks64(), std::memory_order_relaxed);
            kerberusPerfGeneration.store(generation, std::memory_order_release);
        }
        restart(now);
    }

    void returned() { if (detail) lastReturn = SDL_GetPerformanceCounter(); }
    void renderBegin() { if (detail) renderStart = SDL_GetPerformanceCounter(); }
    void renderEnd() {
        if (!detail || !renderStart) return;
        const std::uint64_t now = SDL_GetPerformanceCounter();
        renderSum += now - renderStart; renderStart = 0;
    }
    void presented() {
        if (!detail || !freq) return;
        const std::uint64_t now = SDL_GetPerformanceCounter();
        ++presents;
        if (lastPresent && now - lastPresent > worst) worst = now - lastPresent;
        lastPresent = now;
    }
};
static KerberusPerf kerberusPerf;
static void kerberusPerfPresented() { kerberusPerf.presented(); }

extern "C" JNIEXPORT jfloatArray JNICALL
Java_com_kerberus_launcher_RuntimeMetrics_details(JNIEnv *env, jclass) {
    if (!kerberusMetricsEnabled.load(std::memory_order_relaxed)) return nullptr;
    if (kerberusPerfGeneration.load(std::memory_order_acquire) !=
        kerberusMetricsGeneration.load(std::memory_order_acquire)) return nullptr;
    if (SDL_GetTicks64() - kerberusPerfStamp.load(std::memory_order_relaxed) > 2500) return nullptr;
    jfloat values[KERBERUS_PERF_FIELDS];
    for (int i = 0; i < KERBERUS_PERF_FIELDS; ++i)
        values[i] = kerberusPerfValues[i].load(std::memory_order_relaxed) / 1000.0f;
    jfloatArray array = env->NewFloatArray(KERBERUS_PERF_FIELDS);
    if (array) env->SetFloatArrayRegion(array, 0, KERBERUS_PERF_FIELDS, values);
    return array;
}

// Measured turbo speed (1.0 = the game's own rate), or -1 without a recent sample.
extern "C" JNIEXPORT jfloat JNICALL
Java_com_kerberus_launcher_RuntimeSpeed_effectiveSpeed(JNIEnv *, jclass) {
    if (SDL_GetTicks64() - kerberusSpeedStamp.load(std::memory_order_relaxed) > 2500) return -1;
    return kerberusSpeedMilli.load(std::memory_order_relaxed) / 1000.0f;
}

#endif
