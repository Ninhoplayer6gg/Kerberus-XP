#ifndef KERBERUS_SESSION_H
#define KERBERUS_SESSION_H

// Kerberus 6.5: requests from the in-game Kerberus menu (Java). They are
// queued here and served on the game thread at the start of the next
// Graphics.update, where the scripts wait for the frame and the GL context is
// current. Each request gets one text reply that Java shows to the player:
//   save   the game's own save routine at a safe point (binding-mri.cpp)
//   debug  $DEBUG on/off for this session (binding-mri.cpp)
//   shot   PNG of the game screen at its own resolution (graphics.cpp)
//   filter image filter: 0 sharp pixels, 1 smooth, 2 sharp + smooth
// One translation unit (graphics.cpp). Nothing is done per frame unless a
// request is pending (one relaxed atomic load).
#include <atomic>
#include <deque>
#include <jni.h>
#include <mutex>
#include <string>

enum { KERBERUS_REQUEST_SAVE = 1, KERBERUS_REQUEST_DEBUG = 2, KERBERUS_REQUEST_SHOT = 3 };

// Served by the script binding; writes the reply and returns 1 if the request
// belongs to it.
extern "C" int kerberusSessionRuby(int code, int arg, char *reply, int size);

struct KerberusSessionRequest {
    int code;
    int arg;
    std::string path;
};

static std::mutex kerberusSessionLock;
static std::deque<KerberusSessionRequest> kerberusSessionQueue;
static std::deque<std::string> kerberusSessionReplies;
static std::atomic<bool> kerberusSessionPending(false);
static std::atomic<int> kerberusFilterWanted(-1);

// JNI NewStringUTF needs valid UTF-8; a message from the game may be in
// another encoding, so any byte that does not start a valid sequence becomes '?'.
static std::string kerberusValidUtf8(const std::string &text) {
    std::string out;
    const unsigned char *s = reinterpret_cast<const unsigned char *>(text.data());
    const size_t n = text.size();
    for (size_t i = 0; i < n && out.size() < 400;) {
        const unsigned char c = s[i];
        size_t len = c < 0x80 ? 1 : (c >= 0xC2 && c <= 0xDF) ? 2 : (c >= 0xE0 && c <= 0xEF) ? 3 : 0;
        bool ok = len > 0 && c != 0 && i + len <= n;
        for (size_t k = 1; ok && k < len; ++k) ok = (s[i + k] & 0xC0) == 0x80;
        if (ok && len == 3) ok = !(c == 0xE0 && s[i + 1] < 0xA0) && !(c == 0xED && s[i + 1] >= 0xA0);
        if (!ok) { out += '?'; ++i; continue; }
        out.append(text, i, len);
        i += len;
    }
    return out;
}

static void kerberusSessionReply(const std::string &text) {
    const std::string reply = kerberusValidUtf8(text);
    std::lock_guard<std::mutex> lock(kerberusSessionLock);
    if (kerberusSessionReplies.size() >= 16) kerberusSessionReplies.pop_front();
    kerberusSessionReplies.push_back(reply);
}

// The game thread clears kerberusSessionPending before it looks at the filter
// and the queue, so anything posted meanwhile raises it again.
static bool kerberusSessionTake(KerberusSessionRequest &request) {
    std::lock_guard<std::mutex> lock(kerberusSessionLock);
    if (kerberusSessionQueue.empty()) return false;
    request = kerberusSessionQueue.front();
    kerberusSessionQueue.pop_front();
    return true;
}

// false when the same request is already waiting for the game.
extern "C" JNIEXPORT jboolean JNICALL
Java_com_kerberus_launcher_RuntimeSession_request(JNIEnv *env, jclass, jint code, jint arg, jstring path) {
    KerberusSessionRequest request{code, arg, std::string()};
    if (path) {
        const char *chars = env->GetStringUTFChars(path, nullptr);
        if (!chars) return JNI_FALSE;
        request.path = chars;
        env->ReleaseStringUTFChars(path, chars);
    }
    std::lock_guard<std::mutex> lock(kerberusSessionLock);
    for (const KerberusSessionRequest &queued : kerberusSessionQueue)
        if (queued.code == code) return JNI_FALSE;
    if (kerberusSessionQueue.size() >= 8) return JNI_FALSE;
    kerberusSessionQueue.push_back(request);
    kerberusSessionPending.store(true, std::memory_order_relaxed);
    return JNI_TRUE;
}

// Next reply ("save:ok", "shot:error:...", ...) or null.
extern "C" JNIEXPORT jstring JNICALL
Java_com_kerberus_launcher_RuntimeSession_takeReply(JNIEnv *env, jclass) {
    std::string reply;
    {
        std::lock_guard<std::mutex> lock(kerberusSessionLock);
        if (kerberusSessionReplies.empty()) return nullptr;
        reply = kerberusSessionReplies.front();
        kerberusSessionReplies.pop_front();
    }
    return env->NewStringUTF(reply.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_com_kerberus_launcher_RuntimeSession_setFilter(JNIEnv *, jclass, jint mode) {
    kerberusFilterWanted.store(mode < 0 ? 0 : (mode > 2 ? 2 : mode), std::memory_order_relaxed);
    kerberusSessionPending.store(true, std::memory_order_relaxed);
}

#ifdef KERBERUS_DESKTOP_HARNESS
#include <cstdio>
#include <cstdlib>
// Desktop harness only: a request written to $KERBERUS_SESSION_FILE as
// "code arg [path]" is queued like one from Java; replies are appended to
// $KERBERUS_SESSION_FILE.reply. Checked every 20 updates.
static void kerberusHarnessSession() {
    static unsigned tick = 0;
    if (++tick % 20) return;
    const char *file = getenv("KERBERUS_SESSION_FILE");
    if (!file || !*file) return;
    std::string replies;
    {
        std::lock_guard<std::mutex> lock(kerberusSessionLock);
        while (!kerberusSessionReplies.empty()) {
            replies += kerberusSessionReplies.front() + "\n";
            kerberusSessionReplies.pop_front();
        }
    }
    if (!replies.empty()) {
        if (std::FILE *out = std::fopen((std::string(file) + ".reply").c_str(), "a")) {
            std::fputs(replies.c_str(), out);
            std::fclose(out);
        }
    }
    std::FILE *in = std::fopen(file, "r");
    if (!in) return;
    int code = 0, arg = 0;
    char path[512] = {0};
    const int fields = std::fscanf(in, "%d %d %511s", &code, &arg, path);
    std::fclose(in);
    std::remove(file);
    if (fields < 2) return;
    if (code == 9) {
        Java_com_kerberus_launcher_RuntimeSession_setFilter(nullptr, nullptr, arg);
        return;
    }
    if (code == 8) {  // performance panel on/off
        Java_com_kerberus_launcher_RuntimeMetrics_setEnabled(nullptr, nullptr, arg ? JNI_TRUE : JNI_FALSE);
        return;
    }
    if (code == 10) {  // last published panel values and the turbo speed readout
        char line[256];
        std::snprintf(line, sizeof(line), "perf:upd=%.1f fps=%.1f speed=%.2f logic=%.1f/%.1fms render=%.1fms worst=%.0fms gc=%.0f/%.1fms turbo=%.2f",
                      kerberusPerfValues[0] / 1000.0, kerberusPerfValues[1] / 1000.0, kerberusPerfValues[2] / 1000.0,
                      kerberusPerfValues[3] / 1000.0, kerberusPerfValues[4] / 1000.0, kerberusPerfValues[5] / 1000.0,
                      kerberusPerfValues[6] / 1000.0, kerberusPerfValues[7] / 1000.0, kerberusPerfValues[8] / 1000.0,
                      kerberusSpeedMilli.load() / 1000.0);
        kerberusSessionReply(line);
        return;
    }
    std::lock_guard<std::mutex> lock(kerberusSessionLock);
    kerberusSessionQueue.push_back(KerberusSessionRequest{code, arg, fields == 3 ? std::string(path) : std::string()});
    kerberusSessionPending.store(true, std::memory_order_relaxed);
}
#endif

#endif
