#ifndef KERBERUS_TURBO_H
#define KERBERUS_TURBO_H

// Kerberus 6.4.3 turbo: 2x/3x speed chosen by the player in the in-game
// toolbar. Java writes the factor through JNI; graphics.cpp reads it once
// per Graphics.update. Graphics.frame_rate seen by the game does not change:
// the frame limiter runs N updates in the time of one and draws one of them.
// One translation unit (graphics.cpp).
#include <atomic>
#include <cstdlib>
#include <jni.h>

static std::atomic<int> kerberusTurbo(1);

static void kerberusSetTurbo(int factor) {
    kerberusTurbo.store(factor < 1 ? 1 : (factor > 3 ? 3 : factor), std::memory_order_relaxed);
}

static int kerberusTurboFactor() { return kerberusTurbo.load(std::memory_order_relaxed); }

extern "C" JNIEXPORT void JNICALL
Java_com_kerberus_launcher_RuntimeSpeed_setTurbo(JNIEnv *, jclass, jint factor) {
    kerberusSetTurbo(factor);
}

#ifdef KERBERUS_DESKTOP_HARNESS
// Desktop harness: KERBERUS_TURBO=2|3 in the environment.
static void kerberusTurboFromEnv() {
    if (const char *value = getenv("KERBERUS_TURBO")) kerberusSetTurbo(atoi(value));
}
#endif

#endif
