# Kerberus XP 6.1 — prebuilt legacy Ruby core/extensions staged by the Termux builder.
LOCAL_PATH := $(call my-dir)
LOCAL_BUILD_PATH := $(call my-dir)/build-$(TARGET_ARCH_ABI)/ruby18

include $(CLEAR_VARS)
LOCAL_MODULE := ruby18core
LOCAL_SRC_FILES := $(LOCAL_BUILD_PATH)/lib/libruby18-static.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_BUILD_PATH)/include
include $(PREBUILT_STATIC_LIBRARY)

include $(CLEAR_VARS)
LOCAL_MODULE := ruby18ext
LOCAL_SRC_FILES := $(LOCAL_BUILD_PATH)/lib/libruby18-ext.a
LOCAL_EXPORT_C_INCLUDES := $(LOCAL_BUILD_PATH)/include
include $(PREBUILT_STATIC_LIBRARY)
