module Kerberus::Compatibility
  class << self
    def detect(scripts)
      sources = scripts.map { |entry| entry[3].to_s }
      matches = {uranium: Uranium, insurgence: Insurgence, xenoverse: Xenoverse}.select { |_k, v| v.detect?(sources) }.keys
      raise ArgumentError, "Perfis conflitantes: #{matches.join(', ')}" if matches.length > 1
      matches.first
    end
    def prepare(scripts)
      detected = detect(scripts)
      requested = ENV.fetch('KERBERUS_PROFILE', 'auto')
      selected = requested == 'auto' ? detected : requested.to_sym
      valid = [:uranium, :insurgence, :xenoverse, :modern, :classic]
      raise ArgumentError, 'Perfil desconhecido' if selected && !valid.include?(selected)
      if detected && selected && selected != detected && ![:modern, :classic].include?(selected)
        raise ArgumentError, "Perfil #{selected} conflita com scripts #{detected}"
      end
      # Unknown projects, including working Infinite Fusion versions, retain
      # upstream semantics. The classic profile can be selected explicitly.
      selected ||= :modern
      transformer = {uranium: Uranium, insurgence: Insurgence, xenoverse: Xenoverse}[selected]
      values, errors = [], []
      scripts.each_with_index do |entry, i|
        original = entry[3]
        raise ArgumentError, "Script #{i}: fonte ausente/grande" unless original.is_a?(String) && original.bytesize <= 4*1024*1024
        begin
          value = selected == :modern ? original.dup : ClassicCore520.transform(original)
          value = transformer.transform(value) if transformer
          value = Translation.instrument(value) if Translation.enabled?
          RubyVM::InstructionSequence.compile(value, "Section#{i.to_s.rjust(3,'0')}", nil, 1)
          values << value
        rescue SyntaxError, ArgumentError, Unavailable => error
          errors << "Section#{i.to_s.rjust(3,'0')}: #{error.message.lines.first.to_s.strip}"
        end
      end
      unless errors.empty?
        errors.first(32).each { |e| event('SYNTAX_REJECTED', selected.to_s, e) }
        raise SyntaxError, "Kerberus #{selected}: #{errors.length} scripts rejeitados; originais preservados.\n#{errors.first(8).join("\n")}"
      end
      [selected, values]
    end
    def activate(scripts)
      return if @activated
      Translation.configure
      if ENV['KERBERUS_COMPAT_MODE'] == 'off'
        event('PROFILE_DISABLED','Compatibility','Desativado pelo usuario')
        return
      end
      expanded = ExternalScripts.expand(scripts)
      selected, values = prepare(expanded)
      report = Doctor.scan(expanded, selected)
      Doctor.guard_stdlib(report)
      @profile = selected
      unless selected == :modern
        remember_native
        Ruby18.install(true)
        Win32.install
      end
      expanded.each_with_index { |entry, i| entry[3] = values[i] }
      scripts.replace(expanded) unless scripts.equal?(expanded)
      @activated = true
      $KERBERUS_URANIUM_COMPAT_ACTIVE = selected == :uranium
      event('STATIC_OK',selected.to_s,"#{scripts.size} sections compiladas. Jogabilidade e campanha ainda precisam de teste.")
    end
  end
end
