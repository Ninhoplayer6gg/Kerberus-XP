# Kerberus Shared Compatibility. No game file is edited by these modules.
module Kerberus
  module Compatibility
    VERSION = '6.1.0-test'
    class Unavailable < StandardError; end
    class InvalidParameter < ArgumentError; end
    @seen = {}
    @events = []
    @native = {}
    class << self
      attr_reader :events, :profile, :native
      def event(state, api, detail = '')
        key = [state, api]
        return if @seen[key] || @seen.length >= 512
        @seen[key] = true
        origin = caller_locations(1, 12).find { |f| f.path.to_s.match?(/Section\d+|\.rxdata/) }
        location = origin ? "#{File.basename(origin.path)}:#{origin.lineno}" : 'compatibility'
        if origin && (section = origin.path.match(/Section(\d+)/)) && defined?($RGSS_SCRIPTS) && $RGSS_SCRIPTS
          entry = $RGSS_SCRIPTS[section[1].to_i]
          location = "#{entry[1].to_s[0,120]}:#{origin.lineno}" if entry.is_a?(Array)
        end
        line = "[#{state}] #{api} #{location} #{detail}".gsub(/[\r\n\t]/, ' ')[0, 512]
        @events << line
        @events.shift if @events.length > 128
        System.puts(line) if defined?(System) && System.respond_to?(:puts)
        path = ENV['KERBERUS_COMPAT_LOG']
        if path && !path.empty?
          begin
            File.rename(path, path + '.previous') if File.file?(path) && File.size(path) >= 65536
            File.open(path, 'ab') { |file| file.write(line + "\n") }
          rescue SystemCallError, IOError
            # A full diagnostic partition must not change the game's result.
          end
        end
      end
      def unavailable(api, reason = 'Recurso ainda sem equivalente seguro no Android')
        event('API_MISSING', api, reason)
        raise Unavailable, "Kerberus: #{api}: #{reason}"
      end
      def remember_native
        {Input => [:update, :press?, :trigger?, :repeat?, :release?, :count,
                   :pressex?, :triggerex?, :repeatex?, :releaseex?, :repeatcount,
                   :mouse_x, :mouse_y, :scroll_v, :gets, :text_input=],
         Audio => [:bgm_play, :bgm_stop, :bgm_fade, :bgm_pos, :bgs_play, :bgs_stop,
                   :bgs_fade, :bgs_pos, :me_play, :me_stop, :me_fade, :se_play, :se_stop],
         Graphics => [:width, :height, :snap_to_bitmap, :resize_screen]}.each do |mod, names|
          names.each { |name| @native[[mod.name, name]] ||= mod.method(name) if mod.respond_to?(name) }
        end
      end
      def call_native(mod, name, *args)
        method = @native[[mod, name]]
        unavailable("#{mod}.#{name}", 'Binding nativo ausente') unless method
        method.call(*args)
      end
      def buffer(value, size, writable = true)
        unless size.is_a?(Integer) && size.between?(0, 16 * 1024 * 1024) &&
               value.is_a?(String) && value.bytesize >= size && (!writable || !value.frozen?)
          raise InvalidParameter, "Buffer Ruby #{writable ? 'gravavel' : 'legivel'} de #{size} bytes necessario; ponteiros numericos rejeitados"
        end
        value
      end
      def put(buffer, data)
        self.buffer(buffer, data.bytesize)
        original_encoding = buffer.encoding
        buffer.force_encoding('ASCII-8BIT')
        buffer[0, data.bytesize] = data.b
        buffer.force_encoding(original_encoding)
        data.bytesize
      end
      def null?(value); value.nil? || value == 0; end
      def string(value)
        raise InvalidParameter, 'String necessaria' unless value.is_a?(String)
        value.split("\0", 2).first.to_s
      end
      def relative_file(path)
        value = string(path).tr('\\', '/')
        full = File.expand_path(value, Dir.pwd)
        base = File.realpath(Dir.pwd) + '/'
        raise InvalidParameter, 'Caminho fora do jogo' unless full.start_with?(base)
        parent = full
        parent = File.dirname(parent) until File.exist?(parent) || File.symlink?(parent)
        resolved = File.realpath(parent)
        raise InvalidParameter, 'Link fora do jogo' unless resolved == base.delete_suffix('/') || resolved.start_with?(base)
        full
      end
    end
  end
end
