module Kerberus::Compatibility
  module Insurgence
    def self.detect?(sources)
      sources.any? { |s| Source.signature(s, 'MGC_Hmode7', 'renderHM7', 'drawMapTileset') } &&
        sources.any? { |s| s.b.include?('Insurgence') || s.b.include?('INSURGENCE') }
    end
    def self.transform(source)
      text = LegacySweep511.transform(Essentials.transform(source))
      if Source.signature(text, 'def update_command', '@cmdCult', 'array[int]')
        # The cancellation branch was a break outside any loop. Return to the
        # existing command window without changing quest/story state.
        pattern = /(if array\[int\]=="\(Cancel\)"\s*\n\s*)break\b/
        text = text.sub(pattern, '\\1return')
      end
      if Source.signature(text, 'def battle', 'return tradeorbattle')
        text = text.gsub(/(return tradeorbattle\s*\n)(\s*)break\s*\n/, '\\1\\2# unreachable legacy break removed' + "\n")
      end
      if Source.signature(text, 'module Keys', '@getKeyboardState', 'glitch_input_keys_update')
        text += "\nKerberus::Compatibility::InputAdapter.install_keys\n"
      end
      # HMode7 and network constructors are classified but deferred by Win32.
      # No map, battle, or online code is removed to make a syntax test pass.
      text
    end
  end
end
