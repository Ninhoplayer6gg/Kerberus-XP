module Kerberus::Compatibility
  module Uranium
    def self.detect?(sources)
      sources.any? { |s| Source.signature(s, 'RGSSLinker_Initialize', 'Uranium.ini') } &&
        sources.any? { |s| Source.signature(s, 'Init_FmodEx', 'LOOP_TABLE', 'bgmvolume') }
    end
    def self.transform(source)
      text = DisposeTrace513.transform(PlaneLifecycle514.transform(AudioByteSemantics515.transform(LegacySweep511.transform(Essentials.transform(source)))))
      if Source.signature(text, 'RGSSLinker_Initialize', 'def load_module')
        return "Kerberus::Compatibility::Uranium.install_loader\n"
      end
      if Source.signature(text, 'Init_FmodEx', 'LOOP_TABLE', 'bgmvolume')
        loop_text = text[/LOOP_TABLE\s*=\s*\[(.*?)\]/m, 1]
        unless loop_text && loop_text.lines.all? { |line| line.strip.empty? || line.strip.start_with?('#') }
          raise Unavailable, 'FMOD LOOP_TABLE personalizada: precisa de suporte a pontos de loop antes de executar'
        end
        return "Kerberus::Compatibility::AudioAdapter.install(true)\n"
      end
      if Source.signature(text, 'KLEIN_BFUNCS_DLL', 'def klein_dll', 'compare_klein_bitmaps')
        return "Kerberus::Compatibility::BitmapAdapter.install_klein\n"
      end
      text
    end
    def self.install_loader
      Kernel.send(:define_method, :load_module) do |library, symbol|
        if Win32.library(library) == 'rgss fmodex' && symbol == 'Init_FmodEx'
          AudioAdapter.install(true)
          Kerberus::Compatibility.event('PROFILE_REPLACED', 'RGSS Linker', 'Audio nativo; nao carrega ABI Ruby 1.8')
          true
        else
          Kerberus::Compatibility.unavailable("#{library}!#{symbol}", 'Extensao RGSS Linker nao classificada')
        end
      end
      Kernel.send(:module_function, :load_module)
    end
  end
end
