module Kerberus::Compatibility
  module Xenoverse
    def self.detect?(sources)
      sources.any? { |s| s.b.include?('Xenoverse - Per Aspera Ad Astra') } &&
        sources.any? { |s| Source.signature(s.b, 'KLEIN_BFUNCS_DLL', 'compare_klein_bitmaps') }
    end
    def self.transform(source)
      text = PlaneLifecycle514.transform(LegacySweep511.transform(Essentials.transform(source)))
      if Source.signature(text, 'KLEIN_BFUNCS_DLL', 'def klein_dll', 'compare_klein_bitmaps')
        return "Kerberus::Compatibility::BitmapAdapter.install_klein\n"
      end
      if Source.signature(text, ':Zeus_Video_Player', 'MciSendString', 'ZVP_OldAviMode')
        return "Kerberus::Compatibility::Xenoverse.install_movies\n"
      end
      # Ruby 1.8 tolerated begin/else without rescue; modern Ruby rejects it.
      # Add an explicit re-raise clause so the else branch runs only after a
      # normal return, preserving break/return/exception behavior.
      if Source.signature(text, 'class Connection', 'def updateExp(', 'Unconsumed input:')
        text = text.gsub(/^(        )else\n(?=          print ProtocolError\.new\("Unconsumed input:)/) do
          "#{Regexp.last_match(1)}rescue Exception\n#{Regexp.last_match(1)}  raise\n#{Regexp.last_match(1)}else\n"
        end
      end
      text
    end
    def self.install_movies
      return if @movies_installed
      native = Graphics.method(:play_movie) if Graphics.respond_to?(:play_movie)
      Graphics.define_singleton_method(:play_movie) do |filename, cancellable = true, fit = true|
        Kerberus::Compatibility.unavailable('Graphics.play_movie', 'Binding de video ausente') unless native
        native.call(filename, 100, cancellable)
      end
      @movies_installed = true
      Kerberus::Compatibility.event('PROFILE_REPLACED', 'Zeus Video', 'Player nativo; AVI exige codec/conversao compativel.')
    end
  end
end
