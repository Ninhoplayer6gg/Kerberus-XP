module Kerberus::Compatibility
  module AudioAdapter
    @channels = {}
    @profile_volume = false
    class << self
      def volume_for(channel, value)
        volume = [[value.to_f, 0].max, 100].min
        if @profile_volume && defined?($PokemonSystem) && $PokemonSystem
          method = [:bgm, :me].include?(channel) ? :bgmvolume : :sevolume
          volume *= [[($PokemonSystem.public_send(method) || 100).to_f, 0].max, 100].min / 100.0 if $PokemonSystem.respond_to?(method)
        end
        volume.to_i
      end
      def play(channel, name, volume = 100, pitch = 100, position = 0)
        raise ArgumentError, 'Nome de audio deve ser String' unless name.is_a?(String)
        return stop(channel) if name.empty?
        raise ArgumentError, 'Posicao de audio invalida' unless position.nil? || (position.is_a?(Numeric) && position.finite? && position >= 0)
        position ||= 0
        if [:me, :se].include?(channel) && position != 0
          Kerberus::Compatibility.unavailable("Audio.#{channel}_play(position)", 'Este canal nativo nao oferece seek')
        end
        actual_volume = volume_for(channel, volume)
        args = [name, actual_volume, pitch]
        args << position.to_f if [:bgm, :bgs].include?(channel)
        Kerberus::Compatibility.call_native('Audio', "#{channel}_play".to_sym, *args)
        @channels[channel] = [name, actual_volume, pitch]
        @fade_in = nil if channel == :bgm
        nil
      end
      def stop(channel)
        Kerberus::Compatibility.call_native('Audio', "#{channel}_stop".to_sym)
        @channels.delete(channel)
        @fade_in = nil if channel == :bgm
        nil
      end
      def fade(channel, ms)
        raise ArgumentError, 'Duracao de fade invalida' unless ms.is_a?(Numeric) && ms.finite? && ms >= 0
        Kerberus::Compatibility.call_native('Audio', "#{channel}_fade".to_sym, ms.to_i)
        @fade_in = nil if channel == :bgm
      end
      def position(channel = :bgm)
        Kerberus::Compatibility.call_native('Audio', "#{channel}_pos".to_sym)
      end
      def info(channel = :bgm); @channels[channel]; end
      def volume=(value)
        return unless @channels[:bgm]
        state = @channels[:bgm]
        level = [[value.to_f, 0].max, 100].min.to_i
        # mkxp AudioStream::play changes volume without restarting this file.
        Kerberus::Compatibility.call_native('Audio', :bgm_play, state[0], level, state[2], position)
        state[1] = level
      end
      def fade_in(ms)
        raise ArgumentError, 'Duracao de fade invalida' unless ms.is_a?(Numeric) && ms.finite? && ms >= 0
        return unless @channels[:bgm]
        target = @channels[:bgm][1]
        return self.volume = target if ms == 0
        self.volume = 0
        @fade_in = [Process.clock_gettime(Process::CLOCK_MONOTONIC), ms / 1000.0, target]
      end
      def tick
        return unless @fade_in
        start, duration, target = @fade_in
        progress = [(Process.clock_gettime(Process::CLOCK_MONOTONIC) - start) / duration, 1.0].min
        value = (target * progress).round
        self.volume = value if @channels[:bgm] && value != @channels[:bgm][1]
        @fade_in = nil if progress >= 1
      end
      def install(profile_volume = false)
        @profile_volume ||= profile_volume
        return if @installed
        @installed = true
        [:bgm, :bgs, :me, :se].each do |channel|
          Audio.define_singleton_method("#{channel}_play") { |name, vol = 100, pitch = 100, pos = 0| AudioAdapter.play(channel, name, vol, pitch, pos) }
          Audio.define_singleton_method("#{channel}_stop") { AudioAdapter.stop(channel) }
          Audio.define_singleton_method("#{channel}_fade") { |ms| AudioAdapter.fade(channel, ms) } unless channel == :se
          Kernel.send(:define_method, "Audio_#{channel}_play") { |name, vol = 100, pitch = 100, pos = 0| AudioAdapter.play(channel, name, vol, pitch, pos) }
          Kernel.send(:define_method, "Audio_#{channel}_stop") { AudioAdapter.stop(channel) }
          Kernel.send(:module_function, "Audio_#{channel}_play", "Audio_#{channel}_stop")
          unless channel == :se
            Kernel.send(:define_method, "Audio_#{channel}_fade") { |ms| AudioAdapter.fade(channel, ms) }
            Kernel.send(:module_function, "Audio_#{channel}_fade")
          end
        end
        helpers = {
          Audio_bgm_get_position: proc { AudioAdapter.position },
          Audio_bgm_get_volume: proc { AudioAdapter.info ? AudioAdapter.info[1] : 0 },
          Audio_bgm_set_volume: proc { |v| AudioAdapter.volume = v },
          Audio_bgm_name: proc { AudioAdapter.info ? AudioAdapter.info[0] : '' },
          Audio_bgm_pitch: proc { AudioAdapter.info ? AudioAdapter.info[2] : 100 },
          Audio_bgm_playing?: proc { !AudioAdapter.info.nil? },
          Audio_bgm_fadein: proc { |ms| AudioAdapter.fade_in(ms) },
          audio_control_volume: proc { |v| AudioAdapter.volume = v },
          safeExists?: proc { |file| File.file?(file) },
          getPlayMusic: proc { true }, getPlaySound: proc { true }
        }
        helpers.each { |name, body| Kernel.send(:define_method, name, &body); Kernel.send(:module_function, name) }
        Audio.define_singleton_method(:bgm_position) { AudioAdapter.position }
        Audio.define_singleton_method(:update) { AudioAdapter.tick }
        Kerberus::Compatibility.event('APPLIED', 'AUDIO_NATIVE', 'BGM/BGS/ME/SE, volume, pitch, fade, posicao em segundos; loop pelo mkxp')
      end
    end
  end
end
