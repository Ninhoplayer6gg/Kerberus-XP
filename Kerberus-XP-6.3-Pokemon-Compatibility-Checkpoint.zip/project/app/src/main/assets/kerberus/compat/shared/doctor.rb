module Kerberus::Compatibility
  module Doctor
    MAX_FINDINGS = 256
    RULES = [
      ['R18_HASH_INDEX', /\.index\s*\([^\n)]*\)/, 'Hash#index pode exigir semantica Ruby 1.8; shim global instalado'],
      ['R18_STRING_BYTES', /(?:getbyte|setbyte|byteslice|\.unpack\s*\()/, 'script manipula bytes; String byte shim ativo'],
      ['R18_THREAD', /Thread\.(?:critical|exclusive)/, 'API antiga de Thread; shim instalado'],
      ['R18_FIXNUM', /\b(?:Fixnum|Bignum)\b/, 'constante numerica legada detectada'],
      ['IO_MARSHAL', /Marshal\.load|load_data|pbRgssOpen/, 'IO/Marshal deve ser validado em runtime'],
      ['ENCODING_CJK', /WordRegexp|requireCJKFont|FullWidthLatin/, 'regex CJK passa por normalizacao UTF-8'],
      ['WIN32', /Win32API\.new|Win32API\s*\(/, 'Win32API passa pelo Morph'],
      ['ZLIB', /\bZlib::|require\s*[\( ]*[\"\']zlib/, 'Zlib requerido pelo jogo'],
      ['KLEIN', /KLEIN_BFUNCS|klein_(?:dll|bitmap_version)|compare_klein_bitmaps/, 'KleinBitmap usa provider nativo parcial'],
      ['HMODE7', /MGC_Hmode7|renderHM7|drawMapTileset/, 'HMode7 continua bloqueio nativo quando executado'],
      ['NETWORK', /(?:Win32API.*ws2_32|WSAGetLastError|\bsocket\b)/i, 'rede WinSock continua limitada']
    ].freeze

    def self.scan(scripts, profile)
      counts = Hash.new(0)
      sections = Hash.new { |h, k| h[k] = [] }
      scripts.each_with_index do |entry, index|
        source = entry[3].to_s
        RULES.each do |id, regex, _detail|
          next unless source.match?(regex)
          counts[id] += source.scan(regex).length
          sections[id] << index if sections[id].length < 16
        end
      end
      RULES.each do |id, _regex, detail|
        next unless counts[id] > 0
        Kerberus::Compatibility.event('DOCTOR', id, "count=#{counts[id]} sections=#{sections[id].join(',')} #{detail}")
      end
      hard = []
      hard << 'HMODE7' if counts['HMODE7'] > 0
      report = { profile: profile, scripts: scripts.length, counts: counts, sections: sections, hard: hard }
      $KERBERUS_DOCTOR_REPORT = report
      report
    end

    def self.guard_stdlib(report)
      return unless report
      if report[:counts]['ZLIB'] > 0 && !defined?(::Zlib)
        begin
          require 'zlib'
          Kerberus::Compatibility.event('DOCTOR_FIX', 'ZLIB', 'stdlib carregada antes dos scripts')
        rescue LoadError => error
          Kerberus::Compatibility.event('DOCTOR_WARN', 'ZLIB', error.message)
        end
      end
    end
  end
end
