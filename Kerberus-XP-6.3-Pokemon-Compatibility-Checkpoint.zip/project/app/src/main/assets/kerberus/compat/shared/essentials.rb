module Kerberus::Compatibility
  module Essentials
    def self.transform(source)
      text = Source.syntax(source)
      # KERBERUS_AUDIO_DIRECT_FIX_516
      # Old Essentials/Ruby 1.8 binary parsers expect String#[index] to return
      # an Integer byte. Ruby 3 returns a one-character String instead.
      #
      # Keep this local to the legacy AudioUtilities parser. Do not change
      # String#[] globally.
      if Source.signature(text, 'def getOggPage', 'def oggfiletime', 'def getPlayTime2')
        audio_before = text.dup

        # OGG and MP3 byte-at-a-time reads.
        text = text.gsub(/\b([A-Za-z_][A-Za-z0-9_]*)\.read\(1\)\[0\]/) do
          "Kerberus::Compatibility::Ruby18.byte_at(#{Regexp.last_match(1)}.read(1), 0)"
        end

        # rstr is the 3-byte MP3 frame header. Every numeric index here is a
        # byte access under the Ruby 1.8 semantics expected by this parser.
        text = text.gsub(/\brstr\[(\d+)\]/) do
          "Kerberus::Compatibility::Ruby18.byte_at(rstr, #{Regexp.last_match(1)})"
        end

        if text != audio_before
          text << "\n# KERBERUS_AUDIO_DIRECT_FIX_516_APPLIED\n"
          Kerberus::Compatibility.event(
            'RUBY18_AUDIO_BYTES',
            'AudioUtilities direct',
            'Essentials.transform converted legacy binary String byte indexing to getbyte'
          )
        else
          Kerberus::Compatibility.event(
            'RUBY18_AUDIO_BYTES',
            'AudioUtilities direct',
            'legacy parser detected but no byte-index expression required conversion'
          )
        end
      end
      if Source.signature(text, 'class AudioContext', 'AudioContextInitialize', 'module AudioState')
        return "Kerberus::Compatibility::AudioAdapter.install\n"
      end
      if Source.signature(text, 'def self.buttonToKey', 'def self.updateKeyState', 'GetAsyncKeyState')
        text += "\nKerberus::Compatibility::InputAdapter.install\n"
      end
      if Source.signature(text, 'class Window_TextEntry_Keyboard', '@toUnicode', 'GetKeyboardState') &&
         !Source.signature(text, 'if !$MKXP', 'Input.text_input = true', 'Input.gets')
        start = text.index('    if !@toUnicode')
        finish = start && text.index("\n  end\nend", start)
        raise ArgumentError, 'Editor de texto alterado; adaptacao cancelada' unless start && finish
        text[start...finish] = "    incoming = Kerberus::Compatibility.call_native('Input', :gets)\n    incoming.each_char { |character| insert(character) unless character.match?(/[\\x00-\\x1f\\x7f]/) }\n"
        text += "\nKerberus::Compatibility::InputAdapter.install_text\n"
      end
      if Source.signature(text, 'def pbSetResizeFactor2', 'RtlMoveMemory_pi', 'def saveToPng')
        # Desktop scaling duplicates the SDL viewport on Android. Keep logical
        # dimensions and the existing sprite classes; SDL fits the game to screen.
        text = text.sub(/(def pbSetResizeFactor2\([^\n]*\)\n)/, "\\1  factor = 1.0 # Android viewport owns presentation scaling\n")
        text += "\nKerberus::Compatibility::BitmapAdapter.install_legacy\n"
      end
      if Source.signature(text, 'module GifLibrary', 'class GifBitmap', 'GifToPngFilesInMemory')
        text = text.sub('if safeExists?("gif.dll")', 'if Kerberus::Compatibility::Essentials.windows_gif_decoder?')
        text += "\nKerberus::Compatibility::BitmapAdapter.install_gif\n"
      end
      if Source.signature(text, 'def getUnicodeStringFromAnsi(addr)', 'def getUnicodeString(addr)')
        text = Source.method_body(text, 'getUnicodeStringFromAnsi', "return Kerberus::Compatibility::Essentials.ansi_string(addr)\n")
        text = Source.method_body(text, 'getUnicodeString', "return Kerberus::Compatibility::Essentials.utf16_string(addr)\n")
      end
      if Source.signature(text, 'FontInstaller', 'AddFontResource', 'WriteProfileString')
        text = text.gsub(/^([ \t]*)FontInstaller\.install\s*$/, "\\1Kerberus::Compatibility.event('PROFILE_REPLACED', 'FontInstaller', 'Fonts/ e indexado pelo mkxp; nao instala fontes no sistema')")
      end
      if Source.signature(text, 'def Thread.exclusive', 'Thread.critical')
        text = Source.method_body(text, 'Thread.exclusive', "Kerberus::Compatibility::Ruby18.exclusive { yield }\n")
      end
      if Source.signature(text, 'TakeScreenshot', 'capturefile')
        text = text.gsub(/capturefile && safeExists\?\("rubyscreen.dll"\)/, 'capturefile')
        text = text.gsub(/(capture%[^\"]*)\.bmp/, '\\1.png')
      end
      text
    end
    def self.windows_gif_decoder?
      Kerberus::Compatibility.event('PROFILE_REPLACED', 'gif.dll', 'Bitmap animado nativo; nenhum ponteiro Windows')
      false
    end
    def self.ansi_string(value)
      raise InvalidParameter, 'Endereco de memoria nao suportado' unless value.is_a?(String)
      bytes = value.b.split("\0", 2).first.to_s
      utf8 = bytes.dup.force_encoding('UTF-8')
      utf8.valid_encoding? ? utf8 : bytes.force_encoding('ISO-8859-1').encode('UTF-8')
    end
    def self.utf16_string(value)
      return '' if value == 0
      raise InvalidParameter, 'Endereco de memoria nao suportado' unless value.is_a?(String) && value.bytesize.even?
      units = value.b.unpack('v*').take_while { |unit| unit != 0 }
      units.pack('v*').force_encoding('UTF-16LE').encode('UTF-8')
    end
  end
end
