module Kerberus::Compatibility
  # Recognizes the exact extracted-script loader supplied in the user's XenoVerse.
  # It expands the pack BEFORE profile selection, in the same files-first/depth-first
  # order as that loader. It does not change Kernel.eval globally.
  module ExternalScripts
    def self.expand(scripts)
      return scripts unless scripts.size == 1 && scripts[0].is_a?(Array)
      source = scripts[0][3].to_s
      return scripts unless Source.signature(source, 'def load_scripts_from_folder(path)', 'def traceback_report', 'folders.sort!')
      return scripts unless source.lines.any? { |l| l.strip == 'load_scripts_from_folder("Data/Scripts")' }
      root = File.realpath('Data/Scripts')
      boundary = File.realpath(Dir.pwd) + '/'
      raise ArgumentError, 'Scripts externos fora do jogo' unless root.start_with?(boundary)
      result, bytes, seen = [], 0, {}
      walk = lambda do |dir, depth|
        raise ArgumentError, 'Pasta de scripts profunda demais' if depth > 8
        real = File.realpath(dir)
        raise ArgumentError, 'Link externo/ciclo de scripts' unless (real == root || real.start_with?(root+'/')) && !seen[real]
        seen[real] = true
        files, dirs = Dir.children(dir).sort.partition { |name| !File.directory?(File.join(dir,name)) }
        files.each do |name|
          path=File.join(dir,name)
          raise ArgumentError, 'Arquivo de script inesperado' unless name.end_with?('.rb') && File.realpath(path).start_with?(root+'/')
          size=File.size(path);bytes+=size
          raise ArgumentError, 'Scripts excedem limite de memoria' if size>4*1024*1024 || bytes>64*1024*1024 || result.size>=4096
          text=File.binread(path).force_encoding('UTF-8')
          raise ArgumentError, "Script sem UTF-8: #{name}" unless text.valid_encoding?
          result << [result.size,path.delete_prefix(root+'/'),nil,text]
        end
        dirs.each { |name| walk.call(File.join(dir,name),depth+1) }
      end
      walk.call(root,0)
      raise ArgumentError, 'Pasta de scripts vazia' if result.empty?
      Kerberus::Compatibility.event('EXTERNAL_SCRIPTS','Loader',"#{result.size} scripts externos; ordem original preservada")
      result
    end
  end
end
