module Kerberus::Compatibility
  module BitmapAdapter
    LIMIT = 16 * 1024 * 1024
    def self.bytes(bitmap)
      raise InvalidParameter, 'Bitmap invalido/descartado' unless bitmap.is_a?(Bitmap) && !bitmap.disposed?
      Kerberus::Compatibility.unavailable('Bitmap.raw_data', 'Efeito excede limite de 16 MiB') if bitmap.width * bitmap.height * 4 > LIMIT
      if bitmap.animated?
        frame = bitmap.snap_to_bitmap
        begin; return frame.raw_data.b; ensure; frame.dispose; end
      end
      bitmap.raw_data.b
    end
    def self.swap(data)
      result = data.dup
      (0...result.bytesize).step(4) do |i|
        red = result.getbyte(i); result.setbyte(i, result.getbyte(i + 2)); result.setbyte(i + 2, red)
      end
      result
    end
    def self.install_legacy
      Bitmap.class_eval do
        define_method(:getData) { BitmapAdapter.swap(BitmapAdapter.bytes(self)) }
        define_method(:setData) do |data|
          Kerberus::Compatibility.buffer(data, width * height * 4, false)
          self.raw_data = BitmapAdapter.swap(data.byteslice(0, width * height * 4))
        end
        define_method(:asOpaque) do
          data = BitmapAdapter.bytes(self)
          (3...data.bytesize).step(4) { |i| data.setbyte(i, 255) }
          self.raw_data = data
          self
        end
        define_method(:saveToPng) { |file| to_file(Kerberus::Compatibility.relative_file(file)) }
        define_method(:address) { Kerberus::Compatibility.unavailable('Bitmap.address', 'Endereco RGSS1 nao existe no mkxp-z; use raw_data') }
      end
      Graphics.define_singleton_method(:snap_to_bitmap) { Kerberus::Compatibility.call_native('Graphics', :snap_to_bitmap) }
    end
    module KleinBitmap
      def kerberus_scroll(dx, dy)
        return self if width == 0 || height == 0
        dx %= width; dy %= height
        temp = clone
        begin
          clear
          [dx, dx - width].each { |x| [dy, dy - height].each { |y| blt(x, y, temp, temp.rect) } }
        ensure
          temp.dispose
        end
        self
      end
      def scroll_up(speed = 1); kerberus_scroll(0, -Integer(speed)); end
      def scroll_down(speed = 1); kerberus_scroll(0, Integer(speed)); end
      def scroll_left(speed = 1); kerberus_scroll(-Integer(speed), 0); end
      def scroll_right(speed = 1); kerberus_scroll(Integer(speed), 0); end
      def to_negative
        data = BitmapAdapter.bytes(self)
        (0...data.bytesize).step(4) { |i| 3.times { |j| data.setbyte(i + j, 255 - data.getbyte(i + j)) } }
        self.raw_data = data
        self
      end
      def modify_color(from, to)
        data = BitmapAdapter.bytes(self)
        old = [from.red, from.green, from.blue].map(&:to_i)
        replacement = [to.red, to.green, to.blue].map(&:to_i)
        (0...data.bytesize).step(4) do |i|
          next unless 3.times.all? { |j| data.getbyte(i + j) == old[j] }
          3.times { |j| data.setbyte(i + j, replacement[j]) }
        end
        self.raw_data = data
        self
      end
      [:save_pallete, :modify_pallete, :to_retro, :add_outline].each do |name|
        define_method(name) { |*args| Kerberus::Compatibility.unavailable("KleinBitmap.#{name}", 'Algoritmo/formato proprietario ainda nao reproduzido') }
      end
    end
    module KleinSprite
      attr_accessor :kleinPatternBitmap
      def set_pattern(pattern, alpha, everyframe = false)
        raise ArgumentError, 'Alpha invalido' unless alpha.is_a?(Numeric) && alpha.finite?
        Kerberus::Compatibility.unavailable('KleinBitmap.set_pattern', 'Efeito excede limite de 16 MiB') if bitmap.width * bitmap.height * 4 > BitmapAdapter::LIMIT
        if everyframe || !(@kerberus_pattern_output && bitmap.equal?(@kerberus_pattern_output))
          next_source = bitmap.animated? ? bitmap.snap_to_bitmap : bitmap.clone
          begin; next_output = next_source.clone; rescue Exception; next_source.dispose; raise; end
          @kerberus_pattern_source.dispose if @kerberus_pattern_source && !@kerberus_pattern_source.disposed?
          @kerberus_pattern_output.dispose if @kerberus_pattern_output && !@kerberus_pattern_output.disposed?
          @kerberus_pattern_source = next_source
          @kerberus_pattern_output = next_output
        end
        target = BitmapAdapter.bytes(@kerberus_pattern_source)
        pixels = BitmapAdapter.bytes(pattern)
        raise ArgumentError, 'Pattern vazio' if pattern.width == 0 || pattern.height == 0
        opacity = [[alpha.to_f, 0].max, 255].min / 255.0
        w = @kerberus_pattern_source.width
        (0...(target.bytesize / 4)).each do |pixel|
          i = pixel * 4
          next if target.getbyte(i + 3) == 0
          offset = (((pixel / w) % pattern.height) * pattern.width + (pixel % w) % pattern.width) * 4
          mix = opacity * pixels.getbyte(offset + 3) / 255.0
          3.times { |j| target.setbyte(i + j, (target.getbyte(i + j) * (1 - mix) + pixels.getbyte(offset + j) * mix).round) }
        end
        @kerberus_pattern_output.raw_data = target
        self.bitmap = @kerberus_pattern_output
      end
      def delete_pattern
        return unless @kerberus_pattern_source
        if bitmap.equal?(@kerberus_pattern_output)
          self.bitmap = @kerberus_pattern_source
        elsif !@kerberus_pattern_source.disposed?
          @kerberus_pattern_source.dispose
        end
        @kerberus_pattern_output.dispose unless @kerberus_pattern_output.disposed?
        @kerberus_pattern_output = @kerberus_pattern_source = nil
      end
      def dispose
        [@kerberus_pattern_source, @kerberus_pattern_output].compact.each { |item| item.dispose unless item.disposed? }
        @kerberus_pattern_source = @kerberus_pattern_output = nil
        super
      end
    end
    def self.install_klein
      Bitmap.prepend(KleinBitmap) unless Bitmap.ancestors.include?(KleinBitmap)
      Sprite.prepend(KleinSprite) unless Sprite.ancestors.include?(KleinSprite)
      Object.const_set(:KLEIN_BFUNCS_WORKING, true) unless defined?(::KLEIN_BFUNCS_WORKING)
      Kernel.send(:define_method, :compare_klein_bitmaps) do |a, b|
        a.width == b.width && a.height == b.height && BitmapAdapter.bytes(a) == BitmapAdapter.bytes(b)
      end
      Kernel.send(:define_method, :klein_bitmap_version) { 1 }
      Kernel.send(:define_method, :klein_dll) { |*args| Kerberus::Compatibility.unavailable('KleinBitmap direct DLL', 'Use os metodos Bitmap/Sprite adaptados') }
      Kernel.send(:module_function, :compare_klein_bitmaps, :klein_bitmap_version, :klein_dll)
      Kerberus::Compatibility.event('APPLIED', 'BITMAP_NATIVE', 'Scroll, cores, negativo, pattern e comparacao de pixels; paletas/retro/outline indisponiveis')
    end
    module Gif
      def initialize(file, hue = 0)
        # KERBERUS_URANIUM_EMPTY_AUTOTILE_FIX_6001
        normalized = file.to_s.tr('\\', '/')
        if normalized.sub(%r{/+\z}, '') == 'Graphics/Autotiles'
          @kerberus_bitmap = Bitmap.new(32, 32)
          @kerberus_frames = {}
          Kerberus::Compatibility.event('PROFILE_REPLACED','empty autotile','transparent Bitmap 32x32')
          return
        end
        path = defined?(RTP) ? RTP.getImagePath(file) : file
        @kerberus_bitmap = Bitmap.new(path)
        @kerberus_frames = {}
        begin
          if hue != 0 && bitmap.animated?
            # mkxp rejects hue_change on animated bitmaps. Rebuild through its
            # native frame API, once, without Windows object addresses.
            if bitmap.frame_count * width * height * 4 > BitmapAdapter::LIMIT
              Kerberus::Compatibility.unavailable('GIF hue', 'Animacao colorida excede limite de 16 MiB')
            end
            original, colored = bitmap, nil
            begin
              original.frame_count.times do |index|
                original.goto_and_stop(index)
                frame = original.snap_to_bitmap
                begin
                  frame.hue_change(hue)
                  colored ? colored.add_frame(frame) : colored = frame
                ensure
                  frame.dispose unless frame.equal?(colored) || frame.disposed?
                end
              end
              colored.frame_rate = original.frame_rate
              colored.looping = original.looping
              @kerberus_bitmap = colored
            rescue Exception
              colored.dispose if colored && !colored.disposed?
              raise
            ensure
              original.dispose unless original.disposed?
            end
          elsif hue != 0
            bitmap.hue_change(hue)
          end
        rescue Exception
          bitmap.dispose unless bitmap.disposed?
          raise
        end
        @kerberus_bitmap.play if @kerberus_bitmap.animated?
      end
      def bitmap; @kerberus_bitmap; end
      def width; bitmap.width; end
      def height; bitmap.height; end
      def length; bitmap.animated? ? bitmap.frame_count : 1; end
      def currentIndex; bitmap.animated? ? bitmap.current_frame : 0; end
      def disposed?; bitmap.disposed?; end
      def update; nil; end # animated Bitmap advances inside mkxp's renderer
      def deanimate
        if bitmap.animated?
          original = bitmap
          original.goto_and_stop(0)
          @kerberus_bitmap = original.snap_to_bitmap
          original.dispose
          @kerberus_frames.each_value { |frame| frame.dispose unless frame.disposed? }
          @kerberus_frames.clear
        end
        bitmap
      end
      def totalFrames; length * frameDelay; end
      def frameDelay(index = currentIndex)
        Kerberus::Compatibility.event('FALLBACK', 'GifBitmap.frameDelay', 'Duracao media; timing real e mantido pelo decoder nativo')
        bitmap.animated? ? Graphics.frame_rate.to_f / bitmap.frame_rate : 1
      end
      def [](index)
        return nil unless index.is_a?(Integer) && index.between?(0, length - 1)
        return bitmap if length == 1
        return @kerberus_frames[index] if @kerberus_frames.key?(index)
        Kerberus::Compatibility.unavailable('GIF frame cache', 'Frames extraidos excedem 16 MiB') if (1 + @kerberus_frames.size) * width * height * 4 > BitmapAdapter::LIMIT
        frame, playing = bitmap.current_frame, bitmap.playing
        begin
          bitmap.goto_and_stop(index)
          @kerberus_frames[index] = bitmap.snap_to_bitmap
        ensure
          bitmap.goto_and_stop(frame)
          bitmap.play if playing
        end
        @kerberus_frames[index]
      end
      def each; length.times { |index| yield self[index] }; end
      def dispose
        @kerberus_frames.each_value { |frame| frame.dispose unless frame.disposed? }
        @kerberus_frames.clear
        bitmap.dispose unless bitmap.disposed?
      end
      def copy
        duplicate = clone
        duplicate.instance_variable_set(:@kerberus_bitmap, bitmap.clone)
        duplicate.instance_variable_set(:@kerberus_frames, {})
        duplicate
      end
    end
    def self.install_gif
      ::GifBitmap.prepend(Gif) unless ::GifBitmap.ancestors.include?(Gif)
    end
  end
end

module Kerberus::Compatibility
  module PlaneLifecycle514
    MARKER = 'KERBERUS_LARGEPLANE_LIFECYCLE_FIX_514'

    def self.event(rule, detail)
      Kerberus::Compatibility.event('RGSS1_LIFECYCLE_FIX', rule, detail)
    rescue Exception
    end

    def self.transform(source)
      text = source.dup
      return text if text.include?(MARKER)
      return text unless text.include?('class LargePlane < Plane')
      return text unless text.include?('@__sprite=Sprite.new(viewport)') ||
                         text.include?('@__sprite = Sprite.new(viewport)')

      start = text.index('class LargePlane < Plane')
      return text unless start

      finish = text.index(/\nclass\s+\w+\s*<\s*LargePlane\b/, start + 1)
      finish ||= text.length
      segment = text[start...finish]

      # LargePlane is a pure Ruby facade over @__sprite. It deliberately does
      # not call Plane#initialize, therefore calling Plane#dispose is invalid in
      # mkxp-z, whose native backing object is created by initialize.
      # There is exactly one bare `super` in the LargePlane body: dispose.
      supers = segment.scan(/^([ \t]*)super[ \t]*\r?$/)
      unless supers.length == 1
        event('LargePlane', "patch skipped: expected 1 bare super, found #{supers.length}")
        return text
      end

      segment2 = segment.sub(/^([ \t]*)super[ \t]*\r?$/) do
        indent = Regexp.last_match(1)
        "#{indent}# #{MARKER}: Plane#initialize was never called; do not call Plane#dispose"
      end

      return text if segment2 == segment

      text = text[0...start] + segment2 + text[finish..-1].to_s
      event('LargePlane', 'removed invalid native Plane#dispose call; @__sprite cleanup preserved')
      text
    end
  end
end
