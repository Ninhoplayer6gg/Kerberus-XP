module Kerberus::Compatibility
  module InputAdapter
    def self.install
      # Retain the game's buttonToKey and later remapping screens. Native logical
      # input is ORed with these bindings, so touch and controllers remain usable.
      [:pressex?, :triggerex?, :repeatex?, :releaseex?, :repeatcount].each do |name|
        Input.define_singleton_method(name) { |key| Kerberus::Compatibility.call_native('Input', name, key) }
      end
      [:press?, :trigger?, :repeat?, :release?].each do |name|
        extended = "#{name.to_s.delete_suffix('?')}ex?".to_sym
        Input.define_singleton_method(name) do |button|
          Kerberus::Compatibility.call_native('Input', name, button) ||
            buttonToKey(button).any? { |key| Kerberus::Compatibility.call_native('Input', extended, key) }
        end
      end
      Input.define_singleton_method(:count) do |button|
        native = Kerberus::Compatibility.call_native('Input', :count, button)
        buttonToKey(button).inject(native) { |value, key| [value, Kerberus::Compatibility.call_native('Input', :repeatcount, key)].max }
      end
      Input.define_singleton_method(:update) do
        Kerberus::Compatibility.call_native('Input', :update)
        AudioAdapter.tick
      end
      if defined?(::Mouse)
        ::Mouse.define_singleton_method(:getMouseGlobalPos) { [Input.mouse_x, Input.mouse_y] }
        ::Mouse.define_singleton_method(:getMousePos) do |anywhere = false|
          x, y = Input.mouse_x, Input.mouse_y
          anywhere || (x >= 0 && y >= 0 && x < Graphics.width && y < Graphics.height) ? [x, y] : nil
        end
      end
      Kerberus::Compatibility.event('APPLIED', 'INPUT_NATIVE', 'SDL teclado/touch/gamepad; mapeamento do jogo preservado')
    end
    def self.install_keys
      # The Insurgence Keys module still exports all constants, without allocating
      # or scanning 256 Win32 key states on every update.
      ::Keys.define_singleton_method(:update) { nil }
      {press?: :pressex?, trigger?: :triggerex?, repeat?: :repeatex?, release?: :releaseex?}.each do |name, native|
        ::Keys.define_singleton_method(name) { |key| Kerberus::Compatibility.call_native('Input', native, key) }
      end
    end
    module TextEntry
      def update
        # The surrounding scene already owns Enter/Esc, cursor and deletion.
        was_active = @kerberus_text_active
        @kerberus_text_active = !!active
        if @kerberus_text_active != was_active
          Kerberus::Compatibility.call_native('Input', :text_input=, @kerberus_text_active)
        end
        super
      end
      def dispose
        Kerberus::Compatibility.call_native('Input', :text_input=, false) if @kerberus_text_active
        super
      end
    end
    def self.install_text
      return unless defined?(::Window_TextEntry_Keyboard)
      ::Window_TextEntry_Keyboard.prepend(TextEntry) unless ::Window_TextEntry_Keyboard.ancestors.include?(TextEntry)
    end
  end
end
