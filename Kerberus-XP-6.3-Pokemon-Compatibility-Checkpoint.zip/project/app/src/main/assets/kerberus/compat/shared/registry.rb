module Kerberus::Compatibility
  module Registry
    @handles = {}
    @next_handle = 0x10000
    # Read-only virtual values actually referenced by Essentials. Missing RTPs
    # are not fabricated. Games keep their existing local save-folder fallback.
    VALUES = { [0x80000001, 'software\\enterbrain\\rgss'] =>
               {'playmusic' => [4, [1].pack('V')], 'playsound' => [4, [1].pack('V')]} }.freeze
    def self.open(root, subkey, reserved, access, output)
      Kerberus::Compatibility.buffer(output, 4)
      return 87 unless reserved == 0 && access.is_a?(Integer)
      key = [root & 0xffffffff, Kerberus::Compatibility.string(subkey).tr('/', '\\').downcase]
      return 2 unless VALUES.key?(key)
      return 8 if @handles.size >= 64
      handle = @next_handle
      @next_handle += 1
      @handles[handle] = key
      Kerberus::Compatibility.put(output, [handle].pack('V'))
      0
    end
    def self.close(handle); @handles.delete(handle) ? 0 : 6; end
    def self.query(handle, name, reserved, type, data, size)
      Kerberus::Compatibility.buffer(size, 4)
      Kerberus::Compatibility.buffer(type, 4) unless Kerberus::Compatibility.null?(type)
      return 87 unless Kerberus::Compatibility.null?(reserved)
      key = @handles[handle]
      return 6 unless key
      value = VALUES[key][Kerberus::Compatibility.string(name).downcase]
      return 2 unless value
      kind, bytes = value
      capacity = size.unpack('V')[0]
      unless Kerberus::Compatibility.null?(data)
        Kerberus::Compatibility.buffer(data, capacity)
      end
      Kerberus::Compatibility.put(size, [bytes.bytesize].pack('V'))
      Kerberus::Compatibility.put(type, [kind].pack('V')) unless Kerberus::Compatibility.null?(type)
      return 0 if Kerberus::Compatibility.null?(data)
      return 234 if capacity < bytes.bytesize
      Kerberus::Compatibility.put(data, bytes)
      0
    end
  end
  module Ini
    def self.read(section, key, default, output, capacity, filename)
      Kerberus::Compatibility.buffer(output, capacity)
      return 0 if capacity == 0
      path = Kerberus::Compatibility.relative_file(filename)
      values = {}
      if File.file?(path)
        raise InvalidParameter, 'INI excede 64 KiB' if File.size(path) > 65536
        current = ''
        File.binread(path).force_encoding('UTF-8').scrub.each_line do |line|
          line = line.strip
          if line.match?(/\A\[[^\]]+\]\z/)
            current = line[1...-1].downcase
            values[current] ||= {}
          elsif !line.start_with?(';', '#') && line.include?('=')
            k, v = line.split('=', 2)
            (values[current] ||= {})[k.strip.downcase] = v.strip
          end
        end
      end
      list = Kerberus::Compatibility.null?(section) || Kerberus::Compatibility.null?(key)
      value = if Kerberus::Compatibility.null?(section)
        values.keys.join("\0") + "\0"
      elsif Kerberus::Compatibility.null?(key)
        (values[Kerberus::Compatibility.string(section).downcase] || {}).keys.join("\0") + "\0"
      else
        fallback = Kerberus::Compatibility.null?(default) ? '' : Kerberus::Compatibility.string(default)
        (values[Kerberus::Compatibility.string(section).downcase] || {}).fetch(Kerberus::Compatibility.string(key).downcase, fallback)
      end
      suffix = list && capacity >= 2 ? "\0\0" : "\0"
      bytes = value.b.byteslice(0, [capacity - suffix.bytesize, 0].max)
      Kerberus::Compatibility.put(output, bytes + suffix)
      bytes.bytesize
    end
  end
end
