module Kerberus::Compatibility
  # Pure syntax transformations are staged and all sections are compiled before
  # any section is committed. Names in the RPG Maker editor are never selectors.
  module Source
    def self.method_body(source, name, body)
      expression = /^([ \t]*)def #{Regexp.escape(name)}(?=[ \t(\n;])(?:\([^\n]*\)|[^\n]*)\n.*?^\1end\b/m
      matches = source.scan(expression)
      raise ArgumentError, "Metodo ambiguo/ausente: #{name}" unless matches.length == 1
      source.sub(expression) { |old| old.lines.first + body.lines.map { |l| matches[0][0] + '  ' + l }.join + matches[0][0] + 'end' }
    end
    def self.signature(source, *markers); markers.all? { |marker| source.include?(marker) }; end

    def self.normalize_cjk_wordregexp(text)
      return [text, false] unless text.include?('module WordRegexp') &&
                                  text.include?('WesternLatinWord') &&
                                  text.include?('def self.requireCJKFont?')

      lines = text.lines
      start_index = nil
      indent = nil

      lines.each_with_index do |line, index|
        match = line.match(/^([ \t]*)module WordRegexp\s*$/)
        next unless match
        start_index = index
        indent = match[1]
        break
      end
      return [text, false] unless start_index

      end_index = nil
      ((start_index + 1)...lines.length).each do |index|
        if lines[index].match?(/^#{Regexp.escape(indent)}end\s*$/)
          tail = lines[(index + 1)..-1].to_a
          next_code = tail.find { |candidate| !candidate.strip.empty? }
          if next_code && next_code.match?(/^#{Regexp.escape(indent)}def self\.requireCJKFont\?/)
            end_index = index
            break
          end
        end
      end
      return [text, false] unless end_index

      inner = indent + '  '
      replacement = [
        "#{indent}module WordRegexp\n",
        "#{inner}HanZi = /[\\u3400-\\u4DBF\\u4E00-\\u9FFF]/u\n",
        "#{inner}Kana = /[\\u3041-\\u309F\\u30A1-\\u30FA\\u30FC]/u\n",
        "#{inner}CJ = /(?:#{'#{'}HanZi}|#{'#{'}Kana})/u\n",
        "#{inner}LatinCharSet = /\\p{Latin}/u\n",
        "#{inner}FullWidthLatin = /[\\uFF21-\\uFF3A\\uFF41-\\uFF5A]/u\n",
        "#{inner}FullWidthNumber = /[\\uFF10-\\uFF19]/u\n",
        "#{inner}GreekCharSet = /\\p{Greek}/u\n",
        "#{inner}WesternLatinWord = /(?:#{'#{'}LatinCharSet}|#{'#{'}GreekCharSet}|#{'#{'}FullWidthLatin}|[0-9]|#{'#{'}FullWidthNumber})+\\-?/u\n",
        "#{inner}NotAllowedAtStartSet = /[\\)\\]\\}>\\.,\\!?;:\\-~\\\"\\'%]/u\n",
        "#{inner}NotAllowedAtStartFullWidth = /[\\u2019\\u201D\\u2026\\u203A\\u3001\\u3002\\u3009\\u300B\\u300D\\u300F\\u3011\\u3015\\u3017\\uFE5E\\uFF01\\uFF09\\uFF0C\\uFF0D\\uFF1A\\uFF1B\\uFF1E\\uFF1F\\uFF3D\\uFF5E]/u\n",
        "#{inner}NotAllowedAtStart = /(?:#{'#{'}NotAllowedAtStartSet}|#{'#{'}NotAllowedAtStartFullWidth})/u\n",
        "#{inner}NotAllowedAtEndSet = /[\\(\\[\\{<\\$@]/u\n",
        "#{inner}NotAllowedAtEndFullWidth = /[\\uFE64\\uFE5D\\uFF08\\uFF1C\\u3010\\u300A\\u3016\\u3008\\u3014\\u300C\\u300E\\u201C\\u2018\\u2039]/u\n",
        "#{inner}NotAllowedAtEnd = /(?:#{'#{'}NotAllowedAtEndSet}|#{'#{'}NotAllowedAtEndFullWidth})/u\n",
        "#{inner}WordRegexp = /#{'#{'}NotAllowedAtEnd}*(#{'#{'}HanZi}|#{'#{'}Kana}|#{'#{'}WesternLatinWord}|\\S)#{'#{'}NotAllowedAtStart}*/u\n",
        "#{indent}end\n"
      ]

      lines[start_index..end_index] = replacement
      [lines.join, true]
    end

    def self.syntax(source)
      # Scripts.rxdata commonly yields ASCII-8BIT strings even when their bytes
      # are valid UTF-8. Ruby 3 then creates binary regexes from literal CJK/
      # Latin text while \u escapes create UTF-8 regexes, and interpolation
      # raises RegexpError. Promote only byte sequences that are valid UTF-8.
      bytes = source.b
      utf8 = bytes.dup.force_encoding(Encoding::UTF_8)
      source = utf8.valid_encoding? ? utf8 : bytes
      text = source.gsub("\r\n", "\n").gsub("\r", "\n")
      text, cjk_module_replaced = normalize_cjk_wordregexp(text)
      if cjk_module_replaced
        Kerberus::Compatibility.event(
          'RUBY3_PATCH',
          'CJK WordRegexp',
          'legacy byte-regexp module replaced by UTF-8-safe implementation'
        )
      else
        # Fallback for a repack that keeps the constants but changes the module
        # structure. These replacements are intentionally unconditional by
        # constant name; they do not rely on a minimum marker count.
        values = {
          'HanZi' => '[\u3400-\u4DBF\u4E00-\u9FFF]',
          'Kana' => '[\u3041-\u309F\u30A1-\u30FA\u30FC]',
          'FullWidthLatin' => '[\uFF21-\uFF3A\uFF41-\uFF5A]',
          'FullWidthNumber' => '[\uFF10-\uFF19]',
          'NotAllowedAtStartFullWidth' => '[\u2019\u201D\u2026\u203A\u3001\u3002\u3009\u300B\u300D\u300F\u3011\u3015\u3017\uFE5E\uFF01\uFF09\uFF0C\uFF0D\uFF1A\uFF1B\uFF1E\uFF1F\uFF3D\uFF5E]',
          'NotAllowedAtEndFullWidth' => '[\uFE64\uFE5D\uFF08\uFF1C\u3010\u300A\u3016\u3008\u3014\u300C\u300E\u201C\u2018\u2039]'
        }
        changed = []
        lines = text.lines.map do |line|
          key = values.keys.find { |name| line.match?(/^\s*#{Regexp.escape(name)}\s*=/) }
          if key
            indent = line[/^\s*/].to_s
            changed << key
            "#{indent}#{key} = /#{values[key]}/u\n"
          elsif line.match?(/^\s*(?:CJ|WordRegexp)\s*=.*\/n\s*(?:#.*)?$/)
            changed << 'dynamic'
            line.sub(/\/n(\s*(?:#.*)?)$/, '/u\1')
          else
            line
          end
        end
        text = lines.join
        unless changed.empty?
          Kerberus::Compatibility.event(
            'RUBY3_PATCH',
            'CJK WordRegexp fallback',
            "regex encoding normalized: #{changed.uniq.join(',')}"
          )
        end
      end
      # KERBERUS_CJK_DRAWTEXT_ENCODING_FIX_5203
      if text.include?('def getLineBrokenChunks') &&
         text.include?('CJKUtils::WordRegexp::WordRegexp')
        old_cjk_drawtext = 'textmsg.slice!(/(?:\\n|[ \\r\\t\\f]+|#{CJKUtils::WordRegexp::WordRegexp}[ \\r\\t\\f]*)/n)'
        new_cjk_drawtext = 'textmsg.slice!(/(?:\\n|[ \\r\\t\\f]+|#{CJKUtils::WordRegexp::WordRegexp}[ \\r\\t\\f]*)/u)'
        if text.include?(old_cjk_drawtext)
          text = text.sub(old_cjk_drawtext, new_cjk_drawtext)
          Kerberus::Compatibility.event('RUBY3_PATCH','CJK DrawText','outer regexp /n -> /u')
        end
      end

      # JSON grammar's C1 exclusion is Unicode, not an incomplete UTF-8 byte.
      if signature(text, 'stringLiterals', '\\x7f-\\x9f')
        text = text.lines.map { |line| line.include?('stringLiterals=') ? line.gsub('\\x7f-\\x9f', '\\u007f-\\u009f') : line }.join
      end
      # Ruby 1.8's obsolete numeric case delimiter. Only a numeric when clause.
      text = text.gsub(/^(\s*when\s+[+-]?\d+)\s*:(?=\s|$)/, '\\1 then')
      text
    end
  end
  module Ruby18
    ORIGINAL_STRING_INDEX = String.instance_method(:index)
    # Capture Ruby 3 byte primitives before any RGSS1 script can alias or
    # redefine them. All Kerberus byte adapters call these UnboundMethods
    # directly, so game monkey patches cannot change their return types.
    ORIGINAL_STRING_GETBYTE = String.instance_method(:getbyte)
    ORIGINAL_STRING_SETBYTE = String.instance_method(:setbyte)
    ORIGINAL_STRING_BYTESLICE = String.instance_method(:byteslice)
    ORIGINAL_STRING_BYTESIZE = String.instance_method(:bytesize)

    # KERBERUS_COMPAT_INDEX_NATIVE_510
    # ORIGINAL_STRING_INDEX foi capturado antes de qualquer String.prepend.
    # Chamar o UnboundMethod diretamente evita redispatch para GlobalStringBytes
    # e elimina a recursao infinita.
    def self.compat_index(string, needle, offset = 0)
      offset = Integer(offset)

      case needle
      when Integer
        byte = [needle & 255].pack('C')
        binary = string.b
        ORIGINAL_STRING_INDEX.bind(binary).call(byte, offset)

      when String
        binary = string.b
        target = needle.b
        ORIGINAL_STRING_INDEX.bind(binary).call(target, offset)

      else
        # Regexp e outros tipos usam diretamente o String#index original.
        ORIGINAL_STRING_INDEX.bind(string).call(needle, offset)
      end
    end

    def self.byte_at(string, index)
      raise TypeError, 'String necessaria para leitura de byte' unless string.is_a?(String)
      ORIGINAL_STRING_GETBYTE.bind(string).call(Integer(index))
    end

    def self.byte_slice(string, *args)
      raise TypeError, 'String necessaria para byteslice' unless string.is_a?(String)
      ORIGINAL_STRING_BYTESLICE.bind(string).call(*args)
    end

    def self.byte_size(string)
      raise TypeError, 'String necessaria para bytesize' unless string.is_a?(String)
      ORIGINAL_STRING_BYTESIZE.bind(string).call
    end

    def self.set_byte(string, index, value)
      raise TypeError, 'String necessaria para setbyte' unless string.is_a?(String)
      ORIGINAL_STRING_SETBYTE.bind(string).call(Integer(index), Integer(value) & 255)
    end

    # Ruby 1.8 treats String offsets as bytes. These adapters deliberately avoid
    # calling String#index, String#[]= or String#slice! internally after
    # String.prepend, because Ruby 3.1 can redispatch them through this module
    # and recurse indefinitely.
    def self.byte_index(string, needle, offset = 0)
      needle = [needle & 255].pack('C') if needle.is_a?(Integer)
      return nil unless needle.is_a?(String)

      hay_size = string.bytesize
      sub = needle.b
      sub_size = sub.bytesize
      start = Integer(offset)
      start += hay_size if start < 0
      return nil if start < 0 || start > hay_size
      return start if sub_size == 0
      return nil if sub_size > hay_size || start > hay_size - sub_size

      first = byte_at(sub, 0)
      limit = hay_size - sub_size
      i = start
      while i <= limit
        if byte_at(string, i) == first
          same = true
          j = 1
          while j < sub_size
            if byte_at(string, i + j) != byte_at(sub, j)
              same = false
              break
            end
            j += 1
          end
          return i if same
        end
        i += 1
      end
      nil
    end

    def self.replacement_bytes(value)
      return [value & 255] if value.is_a?(Integer)
      value = value.to_str unless value.is_a?(String)
      value.b.bytes
    end

    def self.byte_assign(string, *args)
      encoding = string.encoding
      bytes = string.b.bytes

      case args.length
      when 2
        selector, value = args
        if selector.is_a?(Integer) && value.is_a?(Integer)
          set_byte(string, selector, value & 255)
          return value
        end

        replacement = replacement_bytes(value)
        if selector.is_a?(Integer)
          bytes[selector, 1] = replacement
        elsif selector.is_a?(Range)
          bytes[selector] = replacement
        else
          return :kerberus_super
        end

        string.replace(bytes.pack('C*').force_encoding(encoding))
        value
      when 3
        first, length, value = args
        return :kerberus_super unless first.is_a?(Integer) && length.is_a?(Integer)
        bytes[first, length] = replacement_bytes(value)
        string.replace(bytes.pack('C*').force_encoding(encoding))
        value
      else
        :kerberus_super
      end
    end

    def self.byte_slice_bang(string, *args)
      encoding = string.encoding
      bytes = string.b.bytes

      removed =
        if args.length == 1 && (args[0].is_a?(Integer) || args[0].is_a?(Range))
          bytes.slice!(args[0])
        elsif args.length == 2 && args.all? { |value| value.is_a?(Integer) }
          bytes.slice!(args[0], args[1])
        else
          return :kerberus_super
        end

      return nil if removed.nil?
      removed = [removed] if removed.is_a?(Integer)
      string.replace(bytes.pack('C*').force_encoding(encoding))

      # The old adapter operated on String#b, so slice! returned an
      # ASCII-8BIT byte string. Preserve that behavior for legacy scripts.
      removed.pack('C*')
    end

    module StringBytes
      refine Array do
        def nitems; count { |item| !item.nil? }; end
      end

      refine String do
        def [](*args)
          if args.length == 1 && args[0].is_a?(Integer)
            Ruby18.byte_at(self, args[0])
          elsif (args.length == 2 && args.all? { |v| v.is_a?(Integer) }) ||
                (args.length == 1 && args[0].is_a?(Range))
            byteslice(*args)
          else
            super
          end
        end

        def []=(*args)
          value = Ruby18.byte_assign(self, *args)
          value == :kerberus_super ? super : value
        end

        def slice(*args); self[*args]; end

        def slice!(*args)
          value = Ruby18.byte_slice_bang(self, *args)
          value == :kerberus_super ? super : value
        end

        def length; bytesize; end
        def size; bytesize; end

        def index(needle, offset = 0)
          Ruby18.compat_index(self, needle, offset)
        end
      end
    end

    module GlobalHashIndex
      # Ruby 1.8 Hash#index(value) returned the matching key. Ruby 3 removed it.
      def index(value)
        key(value)
      end
    end

    module GlobalArrayNitems
      def nitems; count { |item| !item.nil? }; end
    end

    module GlobalStringBytes
      def [](*args)
        if args.length == 1 && args[0].is_a?(Integer)
          getbyte(args[0])
        elsif (args.length == 2 && args.all? { |v| v.is_a?(Integer) }) ||
              (args.length == 1 && args[0].is_a?(Range))
          byteslice(*args)
        else
          super
        end
      end

      def []=(*args)
        value = Ruby18.byte_assign(self, *args)
        value == :kerberus_super ? super : value
      end

      def slice(*args); self[*args]; end

      def slice!(*args)
        value = Ruby18.byte_slice_bang(self, *args)
        value == :kerberus_super ? super : value
      end

      def length; bytesize; end
      def size; bytesize; end

      # KERBERUS_DISABLE_GLOBAL_STRING_INDEX_510
      # String#index permanece nativo no Ruby 3.
      # O antigo override causava redispatch/recursao infinita.
    end

    @mutex = Mutex.new
    @global_bytes_installed = false

    def self.exclusive
      return yield if @mutex.owned?
      @mutex.synchronize { yield }
    end

    def self.install(global_bytes = false)
      if global_bytes && !@global_bytes_installed
        Array.prepend(GlobalArrayNitems) unless Array.ancestors.include?(GlobalArrayNitems)
        Hash.prepend(GlobalHashIndex) unless Hash.ancestors.include?(GlobalHashIndex)
        # KERBERUS_DISABLE_GLOBAL_STRING_BYTES_510
        # Global String monkeypatch desativado no Ruby 3.
        # Refinements/profile-specific transforms continuam ativos.
        # String.prepend(GlobalStringBytes) intentionally disabled.
        @global_bytes_installed = true
      end

      Thread.define_singleton_method(:exclusive) { |&block| Ruby18.exclusive(&block) }

      mutex = @mutex
      Thread.define_singleton_method(:critical) { mutex.owned? }
      Thread.define_singleton_method(:critical=) do |value|
        if value
          mutex.lock unless mutex.owned?
        elsif mutex.owned?
          mutex.unlock
        end
        value
      end

      unless String.method_defined?(:each)
        String.class_eval { alias_method :each, :each_line }
      end
    end
  end
end

module Kerberus::Compatibility
  # Generic RGSS1/Ruby 1.8 compatibility pass. This is deliberately separate
  # from game profiles: every RGSS1 project gets the language/runtime fixes,
  # while Uranium/Insurgence profiles only handle their game-specific APIs.
  module ClassicCore520
    MARKER = 'KERBERUS_CLASSIC_CORE_520'

    LEGACY_STRING_ALIASES = [
      [/^(\s*)alias\s+getbyte\s+\[\]\s*$/, :getbyte],
      [/^(\s*)alias\s+setbyte\s+\[\]=\s*$/, :setbyte],
      [/^(\s*)alias\s+bytesize\s+size\s*$/, :bytesize],
      [/^(\s*)alias_method\s*:getbyte\s*,\s*:\[\]\s*$/, :getbyte],
      [/^(\s*)alias_method\s*:setbyte\s*,\s*:\[\]=\s*$/, :setbyte],
      [/^(\s*)alias_method\s*:bytesize\s*,\s*:size\s*$/, :bytesize],
      [/^(\s*)alias_method\s*\(\s*:getbyte\s*,\s*:\[\]\s*\)\s*$/, :getbyte],
      [/^(\s*)alias_method\s*\(\s*:setbyte\s*,\s*:\[\]=\s*\)\s*$/, :setbyte],
      [/^(\s*)alias_method\s*\(\s*:bytesize\s*,\s*:size\s*\)\s*$/, :bytesize]
    ].freeze

    def self.transform(source)
      text = Source.syntax(source)
      return text if text.include?(MARKER)
      changes = []

      # A common XP/VX compatibility shim aliases Ruby 1.8's String#[] to
      # getbyte. On Ruby 3 that DESTROYS the native Integer-returning getbyte
      # and turns it back into a one-character String. Keep Ruby 3's native
      # getbyte/setbyte/bytesize instead.
      if text.include?('class String')
        LEGACY_STRING_ALIASES.each do |pattern, name|
          before = text
          text = text.gsub(pattern) do
            indent = Regexp.last_match(1)
            "#{indent}# #{MARKER}: keep native String##{name}"
          end
          changes << "String##{name}" if text != before
        end
      end

      # Ruby 1.8: String#[Integer] => byte Integer.
      # Ruby 3:   String#[Integer] => one-character String.
      # One-byte binary reads are unambiguous and safe to convert globally for
      # RGSS1. Use our captured native method, not String#getbyte dispatch,
      # because old game scripts may redefine getbyte later.
      before = text
      text = text.gsub(/\b([A-Za-z_@][A-Za-z0-9_@.]*)\.read\s*\(\s*1\s*\)\s*\[\s*0\s*\]/) do
        "Kerberus::Compatibility::Ruby18.byte_at(#{Regexp.last_match(1)}.read(1), 0)"
      end
      changes << 'read(1)[0]' if text != before

      unless changes.empty?
        Kerberus::Compatibility.event('RUBY18_CORE', 'ClassicCore520', "normalized #{changes.uniq.join(',')}")
      end

      text << "\n# #{MARKER}\n"
      text
    end
  end
end

module Kerberus::Compatibility
  module LegacySweep511
    MARKER = 'KERBERUS_RGSS1_SWEEP_511'

    def self.event(rule, detail)
      Kerberus::Compatibility.event('RUBY18_SWEEP', rule, detail)
    rescue StandardError
    end

    def self.transform(source)
      text = source.dup

      # Ruby >= 3 removed deprecated aliases still used by Essentials v17.
      if text.include?('File.exists?(')
        text = text.gsub('File.exists?(', 'File.exist?(')
        event('File.exists?', 'File.exist?')
      end
      if text.include?('Dir.exists?(')
        text = text.gsub('Dir.exists?(', 'Dir.exist?(')
        event('Dir.exists?', 'Dir.exist?')
      end

      # Ruby 1.8 Hash#index(value) returned the matching key.
      if text.include?('CONTROLSLIST.index(keyCode)')
        text = text.gsub('CONTROLSLIST.index(keyCode)', 'CONTROLSLIST.key(keyCode)')
        event('Hash#index', 'CONTROLSLIST usa Hash#key no Ruby moderno')
      end

      # Essentials v17 FileInputMixin assumes each_byte always yields Integer.
      # Some Uranium StringInput implementations delegate to getc, which yields
      # a one-byte String in modern Ruby.
      if text.include?('module FileInputMixin') &&
         text.include?('def fgetdw') &&
         text.include?('class StringInput < IO')
        before = text
        text = text.gsub(/(each_byte do \|i\|\r?\n)([ \t]*)/) do
          head = Regexp.last_match(1)
          indent = Regexp.last_match(2)
          guard = "#{indent}i = i.ord if i.is_a?(String)\n"
          head + indent + guard
        end
        event('FileInputMixin', 'fgetb/fgetw/fgetdw normalizam byte String -> Integer') if text != before
      end

      # Ruby 1.8 String#[n] returned a byte integer. Restrict the rewrite to
      # comparisons against hexadecimal byte literals, avoiding Array accesses.
      before = text
      text = text.gsub(/\b([A-Za-z_][A-Za-z0-9_]*)\[(\d+)\](\s*(?:==|!=)\s*0x[0-9A-Fa-f]+)/) do
        "Kerberus::Compatibility::Ruby18.byte_at(#{Regexp.last_match(1)}, #{Regexp.last_match(2)})#{Regexp.last_match(3)}"
      end
      event('String byte index', 'comparacoes binaria usam String#getbyte') if text != before

      # Uranium ships a StringInput < IO implemented entirely in Ruby. In Ruby
      # 3, inherited IO#getbyte/binmode attempt to access an uninitialized native
      # stream. Override only this game class; do not monkey-patch String globally.
      if text.include?('class StringInput') &&
         text.include?('module ::Marshal') &&
         text.include?('def pbRgssOpen') &&
         !text.include?(MARKER)
        text = text.gsub('@string.each(&block)', '@string.each_line(&block)')
        text << <<~'RUBY'

          # KERBERUS_RGSS1_SWEEP_511
          class StringInput
            def binmode
              self
            end

            def pos
              raise IOError, 'closed stream' if @closed
              [@pos, @string.bytesize].min
            end

            def seek(offset, whence = IO::SEEK_SET)
              raise IOError, 'closed stream' if @closed
              case whence
              when IO::SEEK_SET
                @pos = offset
              when IO::SEEK_CUR
                @pos += offset
              when IO::SEEK_END
                @pos = @string.bytesize - offset
              else
                raise ArgumentError, "unknown seek flag: #{whence}"
              end
              @pos = 0 if @pos < 0
              @pos = [@pos, @string.bytesize + 1].min
              offset
            end

            def eof?
              raise IOError, 'closed stream' if @closed
              @pos >= @string.bytesize
            end

            def getbyte
              raise IOError, 'closed stream' if @closed
              return nil if @pos >= @string.bytesize
              byte = Kerberus::Compatibility::Ruby18.byte_at(@string, @pos)
              @pos += 1
              byte
            end

            def getc
              byte = getbyte
              byte.nil? ? nil : byte.chr(Encoding::BINARY)
            end

            def each_byte
              return enum_for(:each_byte) unless block_given?
              while (byte = getbyte)
                yield byte
              end
              self
            end

            def read(len = nil, outbuf = nil)
              raise IOError, 'closed stream' if @closed
              if len.nil?
                data = @string.byteslice(@pos, @string.bytesize - @pos) || ''.b
                @pos = @string.bytesize
              else
                len = Integer(len)
                raise ArgumentError, 'negative length' if len < 0
                data = ''.b if len == 0
                if len > 0
                  data = @string.byteslice(@pos, len)
                  return nil if data.nil?
                  @pos += data.bytesize
                end
              end
              if outbuf
                outbuf.replace(data)
                outbuf
              else
                data
              end
            end

            def gets
              raise IOError, 'closed stream' if @closed
              return nil if @pos >= @string.bytesize
              binary = @string.b
              idx = binary.index("\n".b, @pos)
              if idx
                finish = idx + 1
                line = @string.byteslice(@pos, finish - @pos)
                @pos = finish
              else
                line = @string.byteslice(@pos, @string.bytesize - @pos)
                @pos = @string.bytesize
              end
              @lineno += 1
              line
            end
          end
        RUBY
        event('StringInput', 'IO binario/Marshal em bytes sem stream nativo')
      end

      text
    end
  end
end

# KERBERUS_EACH_BYTE_INTEGER_FIX_511
# Ruby 1.8/RGSS1 expects String#each_byte to yield Integer values.
# Use bytesize/getbyte directly so no older String shim can turn bytes into 1-char Strings.
module Kerberus
  module Compatibility
    module Ruby18
      module EachByteIntegerFix511
        def each_byte
          return enum_for(:each_byte) unless block_given?
          i = 0
          n = bytesize
          while i < n
            yield Ruby18.byte_at(self, i)
            i += 1
          end
          self
        end
      end
    end
  end
end

unless String.ancestors.include?(Kerberus::Compatibility::Ruby18::EachByteIntegerFix511)
  String.prepend(Kerberus::Compatibility::Ruby18::EachByteIntegerFix511)
end

# KERBERUS_BYTE_SEMANTICS_FIX_512
module Kerberus
  module Compatibility
    module Ruby18
      def self.integer_byte(value)
        return value if value.is_a?(Integer)
        return value.ord if value.is_a?(String) && value.bytesize == 1
        value
      end
    end
  end
end

module Kerberus::Compatibility
  module DisposeTrace513
    MARKER = 'KERBERUS_DISPOSE_TRACE_513'

    def self.event(stage, detail)
      Kerberus::Compatibility.event('DISPOSE_TRACE', stage, detail)
    rescue Exception
      begin
        warn("[KERBERUS][DISPOSE_TRACE][#{stage}] #{detail}")
      rescue Exception
      end
    end

    def self.transform(source)
      text = source.dup

      # Instrument only the Essentials helper script that owns both disposal
      # helpers. We append wrappers instead of replacing the original methods.
      if text.include?('def pbDisposeSpriteHash') &&
         text.include?('def pbDisposeSprite') &&
         !text.include?(MARKER)
        text << <<~'RUBY'

          # KERBERUS_DISPOSE_TRACE_513
          module KerberusDisposeTrace513
            def self.safe(label)
              value = yield
              "#{label}=#{value.inspect}"
            rescue Exception => e
              "#{label}=<#{e.class}: #{e.message}>"
            end

            def self.describe(obj)
              return 'object=nil' if obj.nil?

              parts = []
              parts << safe('class') { obj.class.name || obj.class.to_s }
              parts << safe('object_id') { obj.object_id }
              parts << safe('ivars') { obj.instance_variables }
              parts << safe('ancestors') do
                obj.class.ancestors[0, 12].map { |c| c.respond_to?(:name) && c.name ? c.name : c.to_s }
              end
              parts << safe('initialize_owner') { obj.class.instance_method(:initialize).owner.to_s }
              parts << safe('initialize_source') { obj.class.instance_method(:initialize).source_location }
              parts << safe('dispose_owner') { obj.class.instance_method(:dispose).owner.to_s }
              parts << safe('dispose_source') { obj.class.instance_method(:dispose).source_location }
              parts << safe('responds_disposed') { obj.respond_to?(:disposed?) }
              if begin obj.respond_to?(:disposed?) rescue false end
                parts << safe('disposed?') { obj.disposed? }
              end
              parts.join(' ')
            end

            def self.hash_info(hash)
              parts = []
              parts << safe('hash_class') { hash.class.name || hash.class.to_s }
              parts << safe('hash_object_id') { hash.object_id }
              parts << safe('size') { hash.respond_to?(:size) ? hash.size : nil }
              parts << safe('keys') do
                if hash.respond_to?(:keys)
                  ks = hash.keys
                  ks.length > 64 ? (ks[0, 64] + [:'...truncated...']) : ks
                else
                  nil
                end
              end
              parts.join(' ')
            end

            def self.log(stage, detail)
              Kerberus::Compatibility.event('DISPOSE_TRACE', stage, detail)
            rescue Exception
              begin
                warn("[KERBERUS][DISPOSE_TRACE][#{stage}] #{detail}")
              rescue Exception
              end
            end
          end

          unless Object.private_method_defined?(:__kerberus_pbDisposeSprite_513)
            Object.class_eval do
              alias_method :__kerberus_pbDisposeSprite_513, :pbDisposeSprite
              alias_method :__kerberus_pbDisposeSpriteHash_513, :pbDisposeSpriteHash
            end
          end

          def pbDisposeSprite(sprites, id)
            obj = nil
            lookup_error = nil
            begin
              obj = sprites[id]
            rescue Exception => e
              lookup_error = "#{e.class}: #{e.message}"
            end

            KerberusDisposeTrace513.log(
              'SPRITE_BEFORE',
              "key=#{id.inspect} lookup_error=#{lookup_error.inspect} " +
              KerberusDisposeTrace513.describe(obj)
            )

            begin
              result = __kerberus_pbDisposeSprite_513(sprites, id)
              KerberusDisposeTrace513.log(
                'SPRITE_AFTER',
                "key=#{id.inspect} result=#{result.inspect}"
              )
              result
            rescue Exception => e
              KerberusDisposeTrace513.log(
                'SPRITE_FAIL',
                "key=#{id.inspect} error=#{e.class}: #{e.message} " +
                KerberusDisposeTrace513.describe(obj) +
                " caller=#{caller(0, 12).join(' <- ')}"
              )
              raise
            end
          end

          def pbDisposeSpriteHash(sprites)
            KerberusDisposeTrace513.log(
              'HASH_BEGIN',
              KerberusDisposeTrace513.hash_info(sprites)
            )
            begin
              result = __kerberus_pbDisposeSpriteHash_513(sprites)
              KerberusDisposeTrace513.log(
                'HASH_END',
                KerberusDisposeTrace513.hash_info(sprites)
              )
              result
            rescue Exception => e
              KerberusDisposeTrace513.log(
                'HASH_FAIL',
                "error=#{e.class}: #{e.message} " +
                KerberusDisposeTrace513.hash_info(sprites) +
                " caller=#{caller(0, 12).join(' <- ')}"
              )
              raise
            end
          end
        RUBY
        event('INSTALL', 'wrappers de pbDisposeSprite/pbDisposeSpriteHash adicionados ao script em memoria')
      end

      text
    end
  end
end

module Kerberus::Compatibility
  module AudioByteSemantics515
    MARKER = 'KERBERUS_AUDIO_BYTE_SEMANTICS_FIX_515'

    def self.event(rule, detail)
      Kerberus::Compatibility.event('RUBY18_AUDIO_BYTES', rule, detail)
    rescue Exception
    end

    def self.transform(source)
      text = source.dup
      return text if text.include?(MARKER)

      # Restrict this compatibility rewrite to the old Essentials/Uranium
      # binary audio parser. Do not alter String#[] globally.
      return text unless text.include?('def getOggPage')
      return text unless text.include?('def oggfiletime')
      return text unless text.include?('def getPlayTime2')

      changed = 0

      # Ruby 1.8: "abc"[0] => Integer.
      # Ruby 3.x: "abc"[0] => one-character String.
      before = text
      text = text.gsub(/file\.read\(1\)\[0\]/, 'Kerberus::Compatibility::Ruby18.byte_at(file.read(1), 0)')
      changed += 1 if text != before

      # The MP3 frame parser reads a 3-byte String into rstr and performs
      # integer comparisons/bit shifts on rstr[0] and rstr[1].
      before = text
      text = text.gsub(/\brstr\[0\](?=\s*==\s*0x[0-9A-Fa-f]+)/, 'rstr.getbyte(0)')
      changed += 1 if text != before

      before = text
      text = text.gsub(/\brstr\[1\](?=\s*>>)/, 'rstr.getbyte(1)')
      changed += 1 if text != before

      if changed > 0
        text << "\n# #{MARKER}\n"
        event(
          'AudioUtilities',
          'binary String byte indexing converted to String#getbyte for OGG/MP3 parser'
        )
      else
        event(
          'AudioUtilities',
          'parser detected but no old Ruby 1.8 byte-index patterns were found'
        )
      end

      text
    end
  end
end
