# Whole-string translations. No eval, script rewriting, substring replacement or
# network request is performed by the render thread. Game/save files stay intact.
module Kerberus::Compatibility
  module Translation
    TOKEN = /\\(?:[A-Za-z]+(?:\[[^\]\r\n]*\])?|[.!|^><$\\])|\{\d+\}|%(?:\d+\$)?[-+0-9.]*[sdif]|<\/?[A-Za-z][^>]*>|\r?\n/
    MAX_ENTRIES = 20000
    def self.tokens(text); text.scan(TOKEN); end
    def self.enabled?; @enabled == true; end
    def self.configure
      @enabled = ENV['KERBERUS_TRANSLATION'] == '1'
      @capture = ENV['KERBERUS_CAPTURE_TEXT'] == '1'
      @seen, @dictionary, @translated = {}, {}, {}
      return unless enabled?
      require 'json'
      path = ENV['KERBERUS_TRANSLATION_PACK']
      return unless path && File.file?(path)
      raise ArgumentError, 'Pacote de traducao excede 8 MiB' if File.size(path) > 8*1024*1024
      pack = JSON.parse(File.binread(path).force_encoding('UTF-8'))
      raise ArgumentError, 'Pacote de traducao incompativel' unless pack['schema'] == 1 && pack['language'] == 'pt-BR' && pack['entries'].is_a?(Array)
      raise ArgumentError, 'Muitas traducoes' if pack['entries'].size > MAX_ENTRIES
      protected = pack.fetch('protected_terms', [])
      raise ArgumentError, 'Glossario invalido' unless protected.is_a?(Array) && protected.all? { |s| s.is_a?(String) }
      pack['entries'].each do |row|
        raise ArgumentError, 'Entrada invalida' unless row.is_a?(Hash)
        src, dst, kind = row.values_at('source','target','kind')
        raise ArgumentError, 'Texto invalido' unless src.is_a?(String) && dst.is_a?(String) && src.bytesize.between?(1,16384) && dst.bytesize <= 16384
        raise ArgumentError, 'Categoria protegida' unless %w[dialogue ui].include?(kind)
        next if dst.empty? || src == dst
        raise ArgumentError, 'Codigos da fala alterados' unless tokens(src) == tokens(dst)
        raise ArgumentError, 'Termo protegido alterado' if protected.any? { |p| src.scan(Regexp.new(Regexp.escape(p))).size != dst.scan(Regexp.new(Regexp.escape(p))).size }
        raise ArgumentError, 'Frase duplicada' if @dictionary.key?(src)
        @dictionary[src] = dst.freeze
        @translated[dst] = true
      end
      Kerberus::Compatibility.event('TRANSLATION_READY','pt-BR',"#{@dictionary.size} frases; nomes/golpes somente se explicitamente mapeados como UI")
    rescue StandardError => e
      @enabled = false
      @dictionary = {}
      Kerberus::Compatibility.event('TRANSLATION_REJECTED','pack',e.message)
    end
    def self.lookup(text, kind = 'dialogue', capture = true)
      return text unless enabled? && text.is_a?(String)
      value = @dictionary[text]
      return value.dup if value
      return text if @translated[text]
      if @capture && capture && text.bytesize.between?(2,16384) && !@seen[text] && @seen.size < 5000
        @seen[text] = true
        path = ENV['KERBERUS_TRANSLATION_CAPTURE']
        begin
          if path && (!File.exist?(path) || File.size(path) < 8*1024*1024)
            File.open(path,'ab') { |f| f.write(JSON.generate({'source'=>text,'target'=>'','kind'=>kind}) + "\n") }
          end
        rescue IOError, SystemCallError
          @capture = false
        end
      end
      text
    end
    def self.instrument(source)
      # Install only at the end of definitions, before Main starts its loop.
      return source unless source.match?(/def\s+(?:(?:Kernel\.)?pbMessage\b|_MAPINTL\b|_INTL\b)/)
      source + "\nKerberus::Compatibility::Translation.install_hooks\n"
    end
    def self.install_hooks
      return unless enabled?
      [Object, Kernel, Kernel.singleton_class].each do |owner|
        registry = (@hooks ||= {})
        next if registry[owner]
        layer = Module.new
        # _INTL does not capture arbitrary gameplay names. Only explicit pack
        # entries apply there; dialogue capture occurs at message boundaries.
        if owner.method_defined?(:_INTL) || owner.private_method_defined?(:_INTL)
          layer.send(:define_method, :_INTL) { |text, *a| super(Translation.lookup(text,'ui',false),*a) }
        end
        if owner.method_defined?(:_MAPINTL) || owner.private_method_defined?(:_MAPINTL)
          layer.send(:define_method, :_MAPINTL) { |map, text, *a| super(map,Translation.lookup(text),*a) }
        end
        if owner.method_defined?(:pbMessage) || owner.private_method_defined?(:pbMessage)
          layer.send(:define_method, :pbMessage) { |text, *a, &b| super(Translation.lookup(text),*a,&b) }
        end
        next if layer.instance_methods(false).empty?
        layer.instance_methods(false).each { |m| layer.send(:private,m) if owner.private_method_defined?(m) }
        owner.prepend(layer)
        # Record individual installed methods so later sections may add more.
        registry[owner] = layer.instance_methods(false) + layer.private_instance_methods(false)
      end
      # A second definition section may introduce pbMessage after _INTL.
      (@hooks || {}).keys.each do |owner|
        next if @hooks[owner].include?(:pbMessage)
        next unless owner.method_defined?(:pbMessage) || owner.private_method_defined?(:pbMessage)
        layer = Module.new do
          define_method(:pbMessage) { |text,*a,&b| super(Translation.lookup(text),*a,&b) }
        end
        layer.send(:private,:pbMessage) if owner.private_method_defined?(:pbMessage)
        owner.prepend(layer)
        @hooks[owner] << :pbMessage
      end
    end
  end
end
