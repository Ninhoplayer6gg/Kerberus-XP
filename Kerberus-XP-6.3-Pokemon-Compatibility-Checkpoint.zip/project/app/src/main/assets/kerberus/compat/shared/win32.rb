module Kerberus::Compatibility
  module Win32
    # The only HWND is a managed token. It is never passed to FFI/dereferenced.
    WINDOW = 1
    @capture = 0
    @cursor = 0
    class << self
      def normalize(value)
        value = value.join if value.is_a?(Array) && value.all? { |x| x.is_a?(String) && x.length == 1 }
        return '' if value.nil? || value == 0
        raise InvalidParameter, 'Assinatura deve ser String/Array' unless value.is_a?(String) && value.bytesize <= 128
        text = value.upcase.strip
        text = text[3...-1] if text.start_with?('%W(') && text.end_with?(')')
        text = text.gsub(/[\s,]/, '')
        return '' if text.empty? || text == 'V'
        raise InvalidParameter, 'Tipo de assinatura desconhecido' unless text.match?(/\A[PLINS]+\z/)
        text.tr('LNS', 'III')
      end
      def library(value)
        raise InvalidParameter, 'DLL deve ser String' unless value.is_a?(String) && value.bytesize <= 256
        value.tr('\\', '/').split('/').last.to_s.downcase.sub(/\.dll\z/, '')
      end
      def install
        return if @installed
        @installed = true
        @owner_thread = thread_id
        original = ::Win32API.method(:new)
        ::Win32API.define_singleton_method(:new) do |dll, function, imports = '', exports = '', *extra, &constructor_block|
          key = [Win32.library(dll), function]
          descriptor = API_CATALOG[key]
          if descriptor
            begin
              input, output = Win32.normalize(imports), Win32.normalize(exports)
              signature = input + ':' + (output.empty? ? 'V' : output)
              raise InvalidParameter, 'Convencao adicional nao suportada' unless extra.empty?
              unless descriptor[0].include?(signature)
              # Kerberus 5.1: RGSS1/Win32API antigo usa variantes P/I para o
              # mesmo ABI. Como este provider executa uma funcao Ruby pelo
              # nome da API (nao chama a DLL Windows), uma variante pode ser
              # aceita com seguranca quando preserva aridade e retorno.
              requested_in, requested_out = signature.split(':', 2)

              compatible_signature = descriptor[0].find do |known_signature|
                known_in, known_out = known_signature.split(':', 2)

                known_in.to_s.length == requested_in.to_s.length &&
                  known_out.to_s == requested_out.to_s
              end

              if compatible_signature
                Kerberus::Compatibility.event(
                  'SIGNATURE_ADAPTED',
                  key.join('!'),
                  "#{signature} -> #{compatible_signature}; Ruby provider"
                )
              else
                raise InvalidParameter,
                  "#{key.join('!')} assinatura nao classificada: #{signature}; "                   "aceitas=#{descriptor[0].join(',')}"
              end
            end
              call = Call.new(key, input, output, descriptor)
              Kerberus::Compatibility.event('BOUND', key.join('!'), "#{signature}; #{descriptor[1]}")
              constructor_block.call(call) if constructor_block
              call
            rescue ArgumentError => error
              Kerberus::Compatibility.event('SIGNATURE_REJECTED', key.join('!'), error.message)
              raise
            end
          elsif dll.to_s.downcase.end_with?('.so')
            original.call(dll, function, imports, exports, *extra, &constructor_block)
          else
            Kerberus::Compatibility.unavailable(key.join('!'), 'API Windows nao classificada; MiniFFI nao sera chamado')
          end
        end
      end
      def thread_id
        return KerberusNative.thread_id if defined?(KerberusNative)
        Thread.current.native_thread_id
      end
      def focused?
        defined?(KerberusNative) ? KerberusNative.focused? : true
      end
      def key_pressed?(key)
        raise InvalidParameter, 'Virtual key fora de 0..255' unless key.between?(0, 255)
        Kerberus::Compatibility.call_native('Input', :pressex?, key)
      end
      def tick
        clock = Process.const_defined?(:CLOCK_BOOTTIME) ? Process::CLOCK_BOOTTIME : Process::CLOCK_MONOTONIC
        Process.clock_gettime(clock, :millisecond)
      end
      def fallback(function, result, reason)
        Thread.current[:kerberus_win32_error] = 120 # ERROR_CALL_NOT_IMPLEMENTED, never fake success.
        Kerberus::Compatibility.event('UNAVAILABLE', function, reason)
        result
      end
      def dispatch(dll, fn, a)
        case fn
        when 'GetCurrentThreadId' then thread_id
        when 'GetWindowThreadProcessId'
          Kerberus::Compatibility.buffer(a[1], 4) unless Kerberus::Compatibility.null?(a[1])
          return 0 unless a[0] == WINDOW
          Kerberus::Compatibility.put(a[1], [Process.pid].pack('V')) unless Kerberus::Compatibility.null?(a[1])
          @owner_thread
        when 'GetCurrentProcess' then -1 # documented pseudo handle, never dereferenced
        when 'FindWindowEx'
          return 0 unless Kerberus::Compatibility.null?(a[1])
          klass = Kerberus::Compatibility.null?(a[2]) ? '' : Kerberus::Compatibility.string(a[2])
          title = Kerberus::Compatibility.null?(a[3]) ? '' : Kerberus::Compatibility.string(a[3])
          return 0 unless klass.empty? || %w[RGSS Player].include?(klass) || klass == 'RGSS Player' || klass == 'Game.exe'
          return 0 if !title.empty? && defined?(System) && System.respond_to?(:window_title) && title != System.window_title
          WINDOW
        when 'GetForegroundWindow' then focused? ? WINDOW : 0
        when 'GetClientRect', 'GetWindowRect'
          Kerberus::Compatibility.buffer(a[1], 16)
          return 0 unless a[0] == WINDOW
          Kerberus::Compatibility.put(a[1], [0, 0, Graphics.width, Graphics.height].pack('l<4')); 1
        when 'GetSystemMetrics'
          return Graphics.width if [0, 16, 78].include?(a[0])
          return Graphics.height if [1, 17, 79].include?(a[0])
          fallback(fn, 0, 'Metrica de desktop indisponivel')
        when 'GetCursorPos'
          Kerberus::Compatibility.put(a[0], [Kerberus::Compatibility.call_native('Input', :mouse_x), Kerberus::Compatibility.call_native('Input', :mouse_y)].pack('l<2')); 1
        when 'ScreenToClient'
          Kerberus::Compatibility.buffer(a[1], 8)
          a[0] == WINDOW ? 1 : 0 # both coordinates are in the logical game viewport
        when 'GetAsyncKeyState', 'GetKeyState' then focused? && key_pressed?(a[0]) ? 0x8000 : 0
        when 'GetKeyboardState'
          Kerberus::Compatibility.buffer(a[0], 256)
          256.times { |i| a[0].setbyte(i, focused? && key_pressed?(i) ? 0x80 : 0) }
          1
        when 'SetWindowTextA'
          return 0 unless a[0] == WINDOW
          System.set_window_title(Kerberus::Compatibility.string(a[1])); 1
        when 'SetCapture'
          return 0 unless a[0] == WINDOW
          previous = @capture; @capture = WINDOW; previous
        when 'ReleaseCapture' then previous = @capture; @capture = 0; previous == 0 ? 0 : 1
        when 'ShowCursor'
          @cursor += a[0] == 0 ? -1 : 1
          if defined?(Input) && Input.respond_to?(:mouse_visible=)
            Input.mouse_visible = @cursor >= 0
          else
            Kerberus::Compatibility.event('UNAVAILABLE', fn, 'Cursor de hardware nao exposto pelo binding')
          end
          @cursor
        when 'GetTickCount', 'timeGetTime' then tick & 0xffffffff
        when 'GetTickCount64' then tick
        when 'QueryPerformanceCounter'
          Kerberus::Compatibility.put(a[0], [Process.clock_gettime(Process::CLOCK_MONOTONIC, :nanosecond)].pack('Q<')); 1
        when 'QueryPerformanceFrequency' then Kerberus::Compatibility.put(a[0], [1_000_000_000].pack('Q<')); 1
        when 'RegOpenKeyExA' then Registry.open(*a)
        when 'RegQueryValueExA' then Registry.query(*a)
        when 'RegCloseKey' then Registry.close(*a)
        when 'GetPrivateProfileString' then Ini.read(*a)
        when 'RtlMoveMemory'
          Kerberus::Compatibility.buffer(a[0], a[2]); Kerberus::Compatibility.buffer(a[1], a[2], false)
          Kerberus::Compatibility.put(a[0], a[1].byteslice(0, a[2])); 0
        when 'SwapRgb'
          Kerberus::Compatibility.buffer(a[0], a[1])
          raise InvalidParameter, 'Pixels BGRA incompletos' unless a[1] % 4 == 0
          (0...a[1]).step(4) do |i|
            red = a[0].getbyte(i); a[0].setbyte(i, a[0].getbyte(i + 2)); a[0].setbyte(i + 2, red)
          end
          0
        when 'GetLastError' then Thread.current[:kerberus_win32_error] || 0
        when 'FormatMessageA'
          Kerberus::Compatibility.buffer(a[4], a[5])
          message = "Kerberus: erro #{a[2]}".b.byteslice(0, [a[5] - 1, 0].max)
          return 0 if a[5] <= 0
          Kerberus::Compatibility.put(a[4], message + "\0"); message.bytesize
        when 'GetUserName'
          Kerberus::Compatibility.buffer(a[1], 4)
          capacity = a[1].unpack('V')[0]; Kerberus::Compatibility.buffer(a[0], capacity)
          Kerberus::Compatibility.put(a[1], [7].pack('V'))
          return 0 if capacity < 7
          Kerberus::Compatibility.put(a[0], "Player\0"); 1
        when 'GetUserDefaultLangID' then fallback(fn, 0x0409, 'Idioma neutro en-US; Android nao expoe LANGID Win32')
        when 'GetUserGeoID' then fallback(fn, -1, 'GEOID_NOT_AVAILABLE')
        when 'GetSystemPowerStatus'
          Kerberus::Compatibility.buffer(a[0], 12)
          fallback(fn, 0, 'Status de bateria indisponivel por este provider')
        when 'SHGetKnownFolderPath'
          Kerberus::Compatibility.buffer(a[3], 4)
          Kerberus::Compatibility.put(a[3], [0].pack('V'))
          fallback(fn, 0x80004001, 'E_NOTIMPL: use a pasta de saves local existente')
        when 'SHGetSpecialFolderLocation'
          Kerberus::Compatibility.put(a[2], [0].pack('V'))
          fallback(fn, 0x80004001, 'E_NOTIMPL')
        when 'SHGetPathFromIDList' then fallback(fn, 0, 'Nenhum PIDL Windows foi alocado')
        when 'CoTaskMemFree'
          raise InvalidParameter, 'Ponteiro COM nao pertence ao Kerberus' unless Kerberus::Compatibility.null?(a[0])
          0
        when 'InputGetWheelDelta' then Kerberus::Compatibility.call_native('Input', :scroll_v).to_i * 120
        when 'waveOutGetNumDevs' then fallback(fn, 0, 'waveOut sem backend; Audio nativo continua disponivel')
        when /^waveOut/ then fallback(fn, 8, 'MMSYSERR_NOTSUPPORTED: PCM direto nao implementado')
        when 'mciSendString' then fallback(fn, 274, 'MCIERR_UNSUPPORTED_FUNCTION: gravacao/video MCI indisponivel')
        when 'mciGetErrorString'
          Kerberus::Compatibility.buffer(a[1], a[2]); return 0 if a[2] == 0
          bytes = 'MCI indisponivel no Android'.b.byteslice(0, a[2] - 1)
          Kerberus::Compatibility.put(a[1], bytes + "\0"); 1
        when 'PeekMessage' then fallback(fn, 0, 'Sem fila Win32; texto vem de SDL Input.gets')
        when 'MapVirtualKey', 'ToUnicode' then fallback(fn, 0, 'Conversao Win32 indisponivel; editor usa SDL Input.gets')
        when 'WSAGetLastError' then 10045 # WSAEOPNOTSUPP; network provider is disabled
        when 'htons' then [a[0] & 0xffff].pack('n').unpack('v')[0]
        when 'htonl' then [a[0] & 0xffffffff].pack('N').unpack('V')[0]
        when 'inet_addr'
          parts = Kerberus::Compatibility.string(a[0]).split('.')
          return 0xffffffff unless parts.size == 4 && parts.all? { |p| p.match?(/\A\d{1,3}\z/) && p.to_i <= 255 }
          parts.map(&:to_i).pack('C4').unpack('V')[0]
        when 'TakeScreenshot'
          path = Kerberus::Compatibility.relative_file(a[0])
          Kerberus::Compatibility.unavailable(fn, 'Use PNG para exportar captura') unless path.downcase.end_with?('.png')
          bitmap = Kerberus::Compatibility.call_native('Graphics', :snap_to_bitmap)
          begin; bitmap.to_file(path); ensure; bitmap.dispose; end
          1
        when 'LoadLibrary', 'FreeLibrary', 'RegisterHotKey', 'SetPriorityClass', 'SetWindowPos',
             'SetWindowLong', 'ShowWindow', 'PostMessage', 'SendMessage', 'AddFontResource', 'WriteProfileString'
          fallback(fn, 0, 'Operacao de desktop indisponivel; falha explicita')
        else Kerberus::Compatibility.unavailable("#{dll}!#{fn}", API_CATALOG[[dll, fn]][2])
        end
      end
    end
    class Call
      def initialize(key, imports, exports, descriptor)
        @key, @imports, @exports, @descriptor = key, imports, exports, descriptor
        @applied = false
      end
      def call(*args)
        raise InvalidParameter, "#{@key.join('!')} espera #{@imports.length} argumentos; recebeu #{args.length}" unless args.length == @imports.length
        @imports.chars.each_with_index do |type, i|
          arg = args[i]
          if type == 'I'
            raise InvalidParameter, "Argumento #{i}: inteiro necessario" unless arg.is_a?(Integer)
          elsif !arg.is_a?(String) && !arg.is_a?(Integer) && !arg.nil?
            raise InvalidParameter, "Argumento #{i}: buffer/handle necessario"
          end
        end
        result = Win32.dispatch(*@key, args)
        unless @applied
          parameters = args.map { |value| value.is_a?(String) ? "buffer(#{value.bytesize})" : value.nil? ? 'NULL' : value.to_s }.join(',')
          Kerberus::Compatibility.event('APPLIED', @key.join('!'), "args=[#{parameters}]; #{@descriptor[1]}; retorno=#{result.is_a?(Numeric) ? result : result.class}")
          @applied = true
        end
        @exports.empty? ? nil : result
      rescue ArgumentError => error
        Kerberus::Compatibility.event('PARAMETER_REJECTED', @key.join('!'), error.message)
        raise
      end
      alias Call call
    end
  end
end
