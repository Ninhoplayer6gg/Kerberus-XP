# Backwards-compatible entry point; Android embeds the same ordered modules.
base = File.join(File.dirname(__FILE__), 'compat')
load File.join(base, 'core.rb')
catalog = {}
File.foreach(File.join(base, 'api-catalog.tsv')) do |line|
  next if line.start_with?('#') || line.strip.empty?
  dll, api, signatures, provider, description = line.chomp.split("\t", 5)
  catalog[[dll, api]] = [signatures.split('|'), provider, description]
end
Kerberus::Compatibility.const_set(:API_CATALOG, catalog.freeze)
%w[shared/ruby18.rb shared/registry.rb shared/win32.rb shared/audio.rb shared/input.rb shared/graphics.rb shared/essentials.rb profiles/uranium.rb profiles/insurgence.rb bootstrap.rb].each { |file| load File.join(base, file) }
Kerberus::Compatibility.activate($RGSS_SCRIPTS) if defined?($RGSS_SCRIPTS) && $RGSS_SCRIPTS
