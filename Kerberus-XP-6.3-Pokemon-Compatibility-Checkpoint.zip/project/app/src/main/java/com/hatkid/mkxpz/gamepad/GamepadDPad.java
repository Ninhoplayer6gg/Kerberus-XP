package com.hatkid.mkxpz.gamepad;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.util.AttributeSet;

import com.hatkid.mkxpz.utils.DirectionUtils;
import com.hatkid.mkxpz.utils.DirectionUtils.Direction;

public class GamepadDPad extends GamepadButton
{
    private Direction angle = Direction.UNKNOWN;
    public Boolean isDiagonal = false;
    private int mPointer = -1;

    private OnKeyDownListener mOnKeyDownListener = key -> {};
    private OnKeyUpListener mOnKeyUpListener = key -> {};

    public void setOnKeyDownListener(OnKeyDownListener onKeyDownListener)
    {
        mOnKeyDownListener = onKeyDownListener;
    }

    public void setOnKeyUpListener(OnKeyUpListener onKeyUpListener)
    {
        mOnKeyUpListener = onKeyUpListener;
    }

    public GamepadDPad(Context context)
    {
        super(context);
    }

    public GamepadDPad(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }

    public GamepadDPad(Context context, AttributeSet attrs, int defStyleAttr)
    {
        super(context, attrs, defStyleAttr);
    }

    public GamepadDPad(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes)
    {
        super(context, attrs, defStyleAttr, defStyleRes);
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouchEvent(MotionEvent evt)
    {
        float initX = this.getWidth() / 2f;
        float initY = this.getHeight() / 2f;
        float posX;
        float posY;

        switch (evt.getActionMasked())
        {
            case MotionEvent.ACTION_DOWN:
                mPointer = evt.getPointerId(0);
                updateDirection(evt.getX(), evt.getY(), initX, initY);
                break;

            case MotionEvent.ACTION_POINTER_DOWN:
                // Extra fingers on the D-Pad must not steal direction control.
                break;

            case MotionEvent.ACTION_MOVE: {
                if (mPointer < 0)
                    break;

                int index = evt.findPointerIndex(mPointer);
                if (index < 0) {
                    releaseDirection();
                    break;
                }

                updateDirection(evt.getX(index), evt.getY(index), initX, initY);
                break;
            }

            case MotionEvent.ACTION_POINTER_UP:
                if (evt.getPointerId(evt.getActionIndex()) == mPointer) {
                    releaseDirection();
                }
                break;

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_OUTSIDE:
                releaseDirection();
                break;
        }

        return true;
    }

    private void updateDirection(float posX, float posY, float initX, float initY)
    {
        Direction nAngle = DirectionUtils.getAngle(initX, posX, initY, posY, isDiagonal);

        if (angle == nAngle) {
            return;
        }

        releaseKeys(angle);
        angle = nAngle;
        pressKeys(angle);
    }

    private void releaseDirection()
    {
        releaseKeys(angle);
        angle = Direction.UNKNOWN;
        mPointer = -1;
    }

    private void pressKeys(Direction direction)
    {
        switch (direction)
        {
            case UP:
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_UP);
                break;

            case UP_RIGHT:
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_UP);
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_RIGHT);
                break;

            case UP_LEFT:
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_UP);
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_LEFT);
                break;

            case DOWN:
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_DOWN);
                break;

            case DOWN_RIGHT:
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_DOWN);
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_RIGHT);
                break;

            case DOWN_LEFT:
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_DOWN);
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_LEFT);
                break;

            case RIGHT:
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_RIGHT);
                break;

            case LEFT:
                mOnKeyDownListener.onKeyDown(KeyEvent.KEYCODE_DPAD_LEFT);
                break;
        }
    }

    private void releaseKeys(Direction direction)
    {
        switch (direction)
        {
            case UP:
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_UP);
                break;

            case UP_RIGHT:
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_UP);
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_RIGHT);
                break;

            case UP_LEFT:
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_UP);
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_LEFT);
                break;

            case DOWN:
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_DOWN);
                break;

            case DOWN_RIGHT:
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_DOWN);
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_RIGHT);
                break;

            case DOWN_LEFT:
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_DOWN);
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_LEFT);
                break;

            case RIGHT:
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_RIGHT);
                break;

            case LEFT:
                mOnKeyUpListener.onKeyUp(KeyEvent.KEYCODE_DPAD_LEFT);
                break;
        }
    }
}