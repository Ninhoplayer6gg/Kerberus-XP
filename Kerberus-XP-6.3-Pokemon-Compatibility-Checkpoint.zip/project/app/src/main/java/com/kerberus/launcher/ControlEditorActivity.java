package com.kerberus.launcher;
import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
/** Shares the runtime process and preference owner, without loading any native engine. */
public final class ControlEditorActivity extends Activity {
 private RuntimeControls controls;
 @Override public void onCreate(Bundle state){super.onCreate(state);String path=getIntent().getStringExtra("kerberus_game_path");if(path==null){finish();return;}KerberusUi.immersive(this);FrameLayout root=new FrameLayout(this);root.setBackgroundColor(KerberusUi.BG);TextView label=KerberusUi.text(this,"CONTROL STUDIO\nPrévia do layout · nenhum jogo em execução",20,KerberusUi.MUTED,true);label.setGravity(Gravity.CENTER);root.addView(label,new FrameLayout.LayoutParams(-1,-1));setContentView(root);controls=new RuntimeControls(this,root,new ControlInput.Sink(){public void down(int k){}public void up(int k){}},()->Toast.makeText(this,"Teclado Android disponível durante o jogo.",Toast.LENGTH_SHORT).show(),path);controls.setPreview();}
 @Override protected void onResume(){super.onResume();if(controls!=null)controls.resume();}
 @Override protected void onPause(){if(controls!=null)controls.pause();super.onPause();}
 @Override protected void onDestroy(){if(controls!=null)controls.close();super.onDestroy();}
 @Override public void onBackPressed(){finish();}
}
