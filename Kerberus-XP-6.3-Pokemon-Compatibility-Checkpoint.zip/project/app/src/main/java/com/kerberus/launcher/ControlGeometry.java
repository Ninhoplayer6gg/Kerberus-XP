package com.kerberus.launcher;

public final class ControlGeometry {
    public static final int UP = 1, RIGHT = 2, DOWN = 4, LEFT = 8;
    private ControlGeometry() {}

    public static float unit(float value) {
        if (Float.isNaN(value) || Float.isInfinite(value)) return 0.5f;
        return Math.max(0, Math.min(1, value));
    }

    public static float position(float normalized, float start, float end) {
        return start + unit(normalized) * Math.max(0, end - start);
    }

    public static float normalized(float position, float start, float end) {
        return end <= start ? 0 : unit((position - start) / (end - start));
    }

    /** Coordinates run from -1 to 1 around the center of the directional pad. */
    public static int direction(float x, float y, boolean diagonal) {
        if (x*x + y*y < 0.18f*0.18f) return 0;
        float ax = Math.abs(x), ay = Math.abs(y);
        if (!diagonal) return ax > ay ? (x > 0 ? RIGHT : LEFT) : (y > 0 ? DOWN : UP);
        int result = 0;
        if (ax >= ay * 0.414214f) result |= x > 0 ? RIGHT : LEFT;
        if (ay >= ax * 0.414214f) result |= y > 0 ? DOWN : UP;
        return result;
    }
}
