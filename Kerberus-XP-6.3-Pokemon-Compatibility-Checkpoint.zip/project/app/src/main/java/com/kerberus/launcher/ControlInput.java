package com.kerberus.launcher;

import java.util.HashMap;
import java.util.Map;

/** Shared keys stay pressed until every touch source using them is released. */
public final class ControlInput {
    public interface Sink { void down(int key); void up(int key); }
    private final Sink sink;
    private final Map<String, int[]> sources = new HashMap<>();
    private final Map<Integer, Integer> counts = new HashMap<>();

    public ControlInput(Sink sink) { this.sink = sink; }

    public void set(String source, int first, int second) {
        if (second == first) second = 0;
        int[] old = sources.get(source);
        if (old != null && old[0] == first && old[1] == second) return;
        if (old != null) {
            for (int key : old) if (key != first && key != second) release(key);
        }
        if (first != 0 && (old == null || (first != old[0] && first != old[1]))) press(first);
        if (second != 0 && (old == null || (second != old[0] && second != old[1]))) press(second);
        if (first == 0 && second == 0) sources.remove(source);
        else sources.put(source, new int[]{first, second});
    }

    public void release(String source) { set(source, 0, 0); }

    public void releaseAll() {
        for (int key : counts.keySet()) sink.up(key);
        sources.clear();
        counts.clear();
    }

    private void press(int key) {
        int count = counts.containsKey(key) ? counts.get(key) : 0;
        counts.put(key, count + 1);
        if (count == 0) sink.down(key);
    }

    private void release(int key) {
        if (key == 0 || !counts.containsKey(key)) return;
        int count = counts.get(key) - 1;
        if (count == 0) { counts.remove(key); sink.up(key); }
        else counts.put(key, count);
    }
}
