package com.kerberus.launcher;

import java.util.HashMap;
import java.util.Map;

/** Shared keys stay pressed until every touch source using them is released. */
public final class ControlInput {
    public interface Sink { void down(int key); void up(int key); }
    private final Sink sink;
    private final Map<String, int[]> sources = new HashMap<>();
    private final Map<Integer, Integer> counts = new HashMap<>();

    public ControlInput(Sink sink) { this.sink = sink; }

    public void set(String source, int first, int second) {
        if (second == first) second = 0;
        int[] old = sources.get(source);
        if (old != null && old[0] == first && old[1] == second) return;

        // Phase 1: press the new keys first, so a swapped-in key already counts as held.
        boolean firstNew = first != 0 && (old == null || (first != old[0] && first != old[1]));
        boolean secondNew = second != 0 && (old == null || (second != old[0] && second != old[1]));
        if (firstNew) press(first);
        if (secondNew) press(second);

        // Phase 2: detach the old keys and flush key-up immediately. Keys still
        // held by another source (or re-pressed above) stay down without bouncing.
        if (old != null) {
            for (int key : old) {
                if (key == first || key == second) continue;
                Integer count = counts.get(key);
                if (count != null && count <= 1) {
                    counts.remove(key);
                    sink.up(key);
                }
            }
        }

        // Phase 3: release the old hold counts; shared keys keep the count of the
        // other source and must not be released again here.
        if (old != null) {
            for (int key : old) if (key != first && key != second) uncount(key);
        }

        if (first == 0 && second == 0) sources.remove(source);
        else sources.put(source, new int[]{first, second});
    }

    public void release(String source) { set(source, 0, 0); }

    public void releaseAll() {
        for (int key : counts.keySet()) sink.up(key);
        sources.clear();
        counts.clear();
    }

    private void press(int key) {
        Integer count = counts.get(key);
        int held = count == null ? 0 : count;
        counts.put(key, held + 1);
        if (held == 0) sink.down(key);
    }

    private void release(int key) {
        Integer count = counts.get(key);
        if (key == 0 || count == null) return;
        if (count <= 1) { counts.remove(key); sink.up(key); }
        else counts.put(key, count - 1);
    }

    /** Decrement the hold count without notifying the sink. */
    private void uncount(int key) {
        Integer count = counts.get(key);
        if (key == 0 || count == null) return;
        if (count <= 1) counts.remove(key);
        else counts.put(key, count - 1);
    }

    /** Emit key-up only when the key is no longer held by any source. */
    private void flush(int key) {
        if (key == 0 || counts.containsKey(key)) return;
        for (int[] held : sources.values()) if (held[0] == key || held[1] == key) return;
        sink.up(key);
    }
}
