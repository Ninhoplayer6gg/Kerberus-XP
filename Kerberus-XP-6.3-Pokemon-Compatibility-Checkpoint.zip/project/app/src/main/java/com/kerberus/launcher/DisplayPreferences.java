package com.kerberus.launcher;
import android.app.*;
import android.content.*;
import android.widget.*;
import java.io.File;
/** Presentation-only preferences, separate from game files, Ruby and save storage. */
public final class DisplayPreferences {
 private DisplayPreferences(){}
 public static SharedPreferences open(Context c,String path){return c.getSharedPreferences("kerberus_display_"+GameIdentity.of(new File(path)),Context.MODE_PRIVATE);}
 public static void show(Activity a,String path){SharedPreferences p=open(a,path);LinearLayout col=KerberusUi.column(a);col.setPadding(24,12,24,12);
 String[] names={"Original · configuração do jogo","Ajustar","Preencher","Inteiro","Pixel Perfect"};Spinner modes=new Spinner(a);modes.setAdapter(new ArrayAdapter<>(a,android.R.layout.simple_spinner_dropdown_item,names));modes.setSelection(p.getInt("mode",1));col.addView(modes);
 CheckBox aspect=new CheckBox(a);aspect.setText("Manter proporção");aspect.setChecked(p.getBoolean("aspect",true));col.addView(aspect);
 CheckBox filter=new CheckBox(a);filter.setText("Filtro suave de imagem");filter.setChecked(p.getBoolean("filter",false));col.addView(filter);
 CheckBox integer=new CheckBox(a);integer.setText("Integer scaling");integer.setChecked(p.getBoolean("integer",false));col.addView(integer);
 CheckBox full=new CheckBox(a);full.setText("Fullscreen");full.setChecked(p.getBoolean("fullscreen",true));col.addView(full);
 TextView note=KerberusUi.text(a,"Escala e filtro são aplicados na próxima abertura do jogo. Pixel Perfect usa pixels inteiros e filtro desligado. Preencher pode distorcer a imagem quando Manter proporção estiver desmarcado.",14,KerberusUi.MUTED,false);col.addView(note);
 new AlertDialog.Builder(a).setTitle("Tela / escala").setView(col).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->p.edit().putInt("mode",modes.getSelectedItemPosition()).putBoolean("aspect",aspect.isChecked()).putBoolean("filter",filter.isChecked()).putBoolean("integer",integer.isChecked()).putBoolean("fullscreen",full.isChecked()).apply()).show();
 }
 public static void apply(Activity a,String path){SharedPreferences p=open(a,path);int mode=p.getInt("mode",1);org.libsdl.app.SDLActivity.nativeSetenv("KERBERUS_UI_SCALE",Integer.toString(mode));org.libsdl.app.SDLActivity.nativeSetenv("KERBERUS_UI_ASPECT",p.getBoolean("aspect",true)?"1":"0");org.libsdl.app.SDLActivity.nativeSetenv("KERBERUS_UI_FILTER",p.getBoolean("filter",false)?"1":"0");org.libsdl.app.SDLActivity.nativeSetenv("KERBERUS_UI_INTEGER",p.getBoolean("integer",false)?"1":"0");if(p.getBoolean("fullscreen",true))KerberusUi.immersive(a);}
}
