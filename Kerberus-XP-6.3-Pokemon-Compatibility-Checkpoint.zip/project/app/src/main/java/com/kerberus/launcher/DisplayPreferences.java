package com.kerberus.launcher;
import android.app.*;
import android.content.*;
import android.widget.*;
import java.io.File;
/** Presentation-only preferences, separate from game files, Ruby and save storage. */
public final class DisplayPreferences {
 private DisplayPreferences(){}
 // 6.5: image filter, also changed live from the in-game menu (RuntimeSession.setFilter).
 // "filter" (smooth on/off) from earlier versions is read as Suave / Pixels nítidos.
 public static final String[] FILTER_NAMES={"Pixels nítidos","Suave","Nítido + suave"};
 public static int filterMode(SharedPreferences p){return Math.max(0,Math.min(2,p.getInt("filter_mode",p.getBoolean("filter",false)?1:0)));}
 public static void setFilterMode(SharedPreferences p,int mode){p.edit().putInt("filter_mode",mode).putBoolean("filter",mode!=0).apply();}
 public static SharedPreferences open(Context c,String path){return c.getSharedPreferences("kerberus_display_"+GameIdentity.of(new File(path)),Context.MODE_PRIVATE);}
 public static void show(Activity a,String path){SharedPreferences p=open(a,path);LinearLayout col=KerberusUi.column(a);col.setPadding(24,12,24,12);
 String[] names={"Original · configuração do jogo","Ajustar","Preencher","Inteiro","Pixel Perfect"};Spinner modes=new Spinner(a);modes.setAdapter(new ArrayAdapter<>(a,android.R.layout.simple_spinner_dropdown_item,names));modes.setSelection(p.getInt("mode",1));col.addView(modes);
 CheckBox aspect=new CheckBox(a);aspect.setText("Manter proporção");aspect.setChecked(p.getBoolean("aspect",true));col.addView(aspect);
 col.addView(KerberusUi.text(a,"Filtro de imagem",14,KerberusUi.MUTED,false));Spinner filter=new Spinner(a);filter.setAdapter(new ArrayAdapter<>(a,android.R.layout.simple_spinner_dropdown_item,FILTER_NAMES));filter.setSelection(filterMode(p));col.addView(filter);
 CheckBox integer=new CheckBox(a);integer.setText("Integer scaling");integer.setChecked(p.getBoolean("integer",false));col.addView(integer);
 CheckBox full=new CheckBox(a);full.setText("Fullscreen");full.setChecked(p.getBoolean("fullscreen",true));col.addView(full);
 TextView note=KerberusUi.text(a,"A escala vale na próxima abertura do jogo; o filtro também pode ser trocado durante o jogo no menu KERBERUS. Nítido + suave amplia os pixels por um múltiplo inteiro e suaviza só o ajuste final: pixels nítidos sem serrilhado. Inteiro e Pixel Perfect usam múltiplos inteiros (podem deixar bordas). Preencher pode distorcer a imagem quando Manter proporção estiver desmarcado.",14,KerberusUi.MUTED,false);col.addView(note);
 new AlertDialog.Builder(a).setTitle("Tela / escala").setView(col).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{p.edit().putInt("mode",modes.getSelectedItemPosition()).putBoolean("aspect",aspect.isChecked()).putInt("filter_mode",filter.getSelectedItemPosition()).putBoolean("filter",filter.getSelectedItemPosition()!=0).putBoolean("integer",integer.isChecked()).putBoolean("fullscreen",full.isChecked()).apply();
  // inside a running game the filter changes now; the scale at the next opening
  if(a instanceof org.libsdl.app.SDLActivity)try{RuntimeSession.setFilter(filter.getSelectedItemPosition());}catch(UnsatisfiedLinkError ignored){}}).show();
 }
 public static void apply(Activity a,String path){SharedPreferences p=open(a,path);int mode=p.getInt("mode",1);org.libsdl.app.SDLActivity.nativeSetenv("KERBERUS_UI_SCALE",Integer.toString(mode));org.libsdl.app.SDLActivity.nativeSetenv("KERBERUS_UI_ASPECT",p.getBoolean("aspect",true)?"1":"0");int filter=filterMode(p);org.libsdl.app.SDLActivity.nativeSetenv("KERBERUS_UI_FILTER",filter!=0?"1":"0");if(mode!=0&&filter==2)try{RuntimeSession.setFilter(2);}catch(UnsatisfiedLinkError ignored){}org.libsdl.app.SDLActivity.nativeSetenv("KERBERUS_UI_INTEGER",p.getBoolean("integer",false)?"1":"0");if(p.getBoolean("fullscreen",true))KerberusUi.immersive(a);}
}
