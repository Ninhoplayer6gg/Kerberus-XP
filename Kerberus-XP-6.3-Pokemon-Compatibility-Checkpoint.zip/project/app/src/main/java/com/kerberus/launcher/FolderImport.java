package com.kerberus.launcher;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.DocumentsContract;
import java.io.*;
import java.util.*;
import java.util.zip.*;
/** SAF folders enter the same transactional, validated importer as ZIPs. */
final class FolderImport {
 private static final class Item {Uri uri;String name;long size;Item(Uri u,String n,long s){uri=u;name=n;size=s;}}
 static void run(Context app,Uri tree,ProjectLibrary library){File zip=null;try{
  List<Item> files=new ArrayList<>();collect(app,tree,DocumentsContract.getTreeDocumentId(tree),"",files,new HashSet<>(),0);
  zip=File.createTempFile("kerberus-folder-",".zip",app.getCacheDir());long total=0;int count=0;long last=0;
  try(ZipOutputStream out=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(zip)))){out.setLevel(0);byte[] buffer=new byte[32768];for(Item item:files){out.putNextEntry(new ZipEntry(item.name));try(InputStream in=app.getContentResolver().openInputStream(item.uri)){if(in==null)throw new IOException("Não foi possível ler "+item.name);int n;while((n=in.read(buffer))!=-1){if(Thread.currentThread().isInterrupted())throw new IOException("Importação cancelada.");total+=n;if(total>ProjectArchiveCore.MAX_ARCHIVE_BYTES)throw new IOException("Pasta excede o limite de 4 GiB.");out.write(buffer,0,n);}}out.closeEntry();count++;long now=System.nanoTime();if(now-last>500000000L||count==files.size()){last=now;library.saveReport("IMPORTAÇÃO EM ANDAMENTO\nCopiando pasta…\n"+count+" / "+files.size()+" arquivos · "+(count*100/Math.max(1,files.size()))+"%",true);}}}
  final File staged=zip;new ImportTask(library,app.getCacheDir(),new File(app.getFilesDir(),"games")).run(new ImportTask.Source(){public String name(){return "Pasta selecionada.zip";}public long size(){return staged.length();}public InputStream open()throws IOException{return new FileInputStream(staged);}});
 }catch(Exception x){library.saveReport("FALHA NA IMPORTAÇÃO\n"+x.getMessage(),false);}finally{if(zip!=null)zip.delete();}}
 private static void collect(Context app,Uri tree,String id,String prefix,List<Item> files,Set<String> visited,int depth)throws IOException{
  if(depth>48||!visited.add(id))throw new IOException("Árvore de pastas inválida ou profunda demais.");
  Uri children=DocumentsContract.buildChildDocumentsUriUsingTree(tree,id);
  try(Cursor c=app.getContentResolver().query(children,new String[]{DocumentsContract.Document.COLUMN_DOCUMENT_ID,DocumentsContract.Document.COLUMN_DISPLAY_NAME,DocumentsContract.Document.COLUMN_MIME_TYPE,DocumentsContract.Document.COLUMN_SIZE},null,null,null)){
   if(c==null)throw new IOException("Não foi possível listar a pasta.");while(c.moveToNext()){if(Thread.currentThread().isInterrupted())throw new IOException("Importação cancelada.");String child=c.getString(0),name=c.getString(1);if(name==null||name.equals(".")||name.equals("..")||name.contains("/")||name.contains("\\"))throw new IOException("Nome inválido na pasta.");String path=prefix+name;if(DocumentsContract.Document.MIME_TYPE_DIR.equals(c.getString(2)))collect(app,tree,child,path+"/",files,visited,depth+1);else{if(files.size()>=200000)throw new IOException("Mais de 200.000 arquivos.");files.add(new Item(DocumentsContract.buildDocumentUriUsingTree(tree,child),path,c.isNull(3)?-1:c.getLong(3)));}}
  }catch(SecurityException e){throw new IOException("Permissão de acesso à pasta expirou.",e);}
 }
}
