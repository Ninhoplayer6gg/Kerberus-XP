package com.kerberus.launcher;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

/** Versioned metadata outside game directories. Writes never touch scripts or saves. */
public final class GameCatalog {
    private static final Object LOCK = new Object();
    private static final int SCHEMA = 1;
    private static final long MAX_PROFILE_BYTES = 131072;
    private final File games;
    private final File profiles;

    public static final class Entry {
        public final File game;
        public final String id;
        private final Properties values;
        private Entry(File game, Properties values) {
            this.game = game; id = GameIdentity.of(game); this.values = values;
        }
        public String get(String key, String fallback) { return values.getProperty(key, fallback); }
        public String title() { return get("name", "Jogo importado"); }
        public String engine() { return get("engine_label", "Engine não identificada"); }
        public long lastLaunchRequest() {
            try { return Long.parseLong(get("last_launch_request", "0")); }
            catch (NumberFormatException error) { return 0; }
        }
        public String report() {
            String error = get("profile_error", "");
            return title() + "\n" + engine()
                    + "\nPokémon Essentials: " + get("essentials", "Não confirmado")
                    + "\nVersão do Essentials: " + get("essentials_version", "Não identificada")
                    + "\n\nCompatibilidade: Experimental — sem validação completa."
                    + "\nControles: layout independente para este jogo."
                    + "\n\nEvidências:\n" + get("evidence", "Análise ainda não concluída.")
                    + "\n\nObservações:\n" + get("warnings", "")
                    + (error.isEmpty() ? "" : "\n" + error);
        }
    }

    private static final class NewerSchema extends IOException {
        NewerSchema() { super("Perfil criado por uma versão mais nova; os dados foram preservados."); }
    }

    public GameCatalog(File filesDirectory) {
        games = new File(filesDirectory, "games");
        profiles = new File(filesDirectory, "game-profiles");
    }

    public Entry load(File game) throws IOException {
        synchronized (LOCK) {
            File managed = managed(game);
            File file = profile(managed);
            if (!file.exists() && !backup(file).exists()) return analyze(managed);
            return new Entry(managed, read(file));
        }
    }

    public Entry analyze(File game) throws IOException {
        synchronized (LOCK) {
            File managed = managed(game);
            File file = profile(managed);
            Properties values = file.exists() || backup(file).exists() ? read(file) : new Properties();
            GameIntelligence.Result info = GameIntelligence.inspect(managed);
            values.setProperty("schema", Integer.toString(SCHEMA));
            values.setProperty("id", GameIdentity.of(managed));
            values.setProperty("name", info.title);
            values.setProperty("engine", info.engine.name());
            values.setProperty("engine_label", info.engine.label);
            values.setProperty("rgss", Integer.toString(info.engine.rgss));
            values.setProperty("essentials", info.essentials);
            values.setProperty("essentials_version", info.essentialsVersion);
            values.setProperty("scripts", info.scripts);
            values.setProperty("evidence", lines(info.evidence));
            values.setProperty("warnings", lines(info.warnings));
            values.setProperty("detector_version", Integer.toString(GameIntelligence.DETECTOR_VERSION));
            values.setProperty("detected_at", Long.toString(System.currentTimeMillis()));
            write(file, values);
            return new Entry(managed, values);
        }
    }

    public void recordLaunchRequest(File game, long time) throws IOException {
        synchronized (LOCK) {
            Entry entry = load(game);
            entry.values.setProperty("last_launch_request", Long.toString(time));
            write(profile(entry.game), entry.values);
        }
    }

    /** Recover all complete imports made by previous releases, without reimporting. */
    public List<Entry> list() throws IOException {
        List<Entry> entries = new ArrayList<>();
        if (!games.exists()) return entries;
        File[] children = games.listFiles(file -> file.isDirectory() && !file.getName().startsWith("."));
        if (children == null) throw new IOException("Não foi possível ler a biblioteca de jogos.");
        for (File game : children) {
            if (Thread.currentThread().isInterrupted()) throw new IOException("Leitura da biblioteca interrompida.");
            File valid;
            try { valid = managed(game); }
            catch (IOException error) { continue; }
            try { entries.add(load(valid)); }
            catch (IOException error) {
                // A damaged/newer metadata file must not hide or delete an existing game.
                Properties fallback = new Properties();
                fallback.setProperty("profile_error", "Perfil indisponível: " + error.getMessage());
                entries.add(new Entry(valid, fallback));
            }
        }
        Collections.sort(entries, (a, b) -> {
            int recent = Long.compare(b.lastLaunchRequest(), a.lastLaunchRequest());
            if (recent != 0) return recent;
            int name = a.title().compareToIgnoreCase(b.title());
            return name != 0 ? name : a.id.compareTo(b.id);
        });
        return entries;
    }

    private static String lines(List<String> values) {
        StringBuilder text = new StringBuilder();
        for (String value : values) { if (text.length() > 0) text.append('\n'); text.append(value); }
        return text.toString();
    }

    private File managed(File game) throws IOException {
        File canonical = game.getCanonicalFile();
        if (!canonical.isDirectory() || !games.getCanonicalFile().equals(canonical.getParentFile())
                || canonical.getName().startsWith(".")) throw new IOException("Jogo fora da biblioteca ou importação incompleta.");
        return canonical;
    }

    private File profile(File game) { return new File(profiles, GameIdentity.of(game) + ".properties"); }
    private static File backup(File file) { return new File(file.getPath() + ".bak"); }

    private static Properties read(File file) throws IOException {
        IOException failure;
        try { return readOne(file); }
        catch (NewerSchema error) { throw error; }
        catch (IOException error) { failure = error; }
        if (backup(file).isFile()) return readOne(backup(file));
        throw failure;
    }

    private static Properties readOne(File file) throws IOException {
        if (!file.isFile() || file.length() > MAX_PROFILE_BYTES) throw new IOException("Metadados ausentes ou grandes demais.");
        Properties values = new Properties();
        try (FileInputStream in = new FileInputStream(file)) { values.load(in); }
        catch (IllegalArgumentException error) { throw new IOException("Metadados inválidos.", error); }
        int schema;
        try { schema = Integer.parseInt(values.getProperty("schema", "0")); }
        catch (NumberFormatException error) { throw new IOException("Versão de metadados inválida."); }
        if (schema > SCHEMA) throw new NewerSchema();
        if (schema != SCHEMA) throw new IOException("Formato de metadados inválido.");
        return values;
    }

    private static void write(File target, Properties values) throws IOException {
        File directory = target.getParentFile();
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Não foi possível salvar o perfil.");
        File temporary = File.createTempFile(".profile-", ".tmp", directory);
        File previous = backup(target);
        try {
            try (FileOutputStream out = new FileOutputStream(temporary)) {
                values.store(out, "Kerberus game metadata; original game files are not modified");
                out.getFD().sync();
            }
            if (temporary.length() > MAX_PROFILE_BYTES) throw new IOException("Perfil excedeu o limite de tamanho.");
            if (!previous.exists() && target.exists() && !target.renameTo(previous))
                throw new IOException("Não foi possível preservar o perfil anterior.");
            if (!temporary.renameTo(target)) throw new IOException("Não foi possível concluir a gravação do perfil.");
            previous.delete();
        } finally { temporary.delete(); }
    }
}
