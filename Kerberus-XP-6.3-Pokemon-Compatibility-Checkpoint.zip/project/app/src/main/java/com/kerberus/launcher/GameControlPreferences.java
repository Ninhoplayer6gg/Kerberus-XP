package com.kerberus.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Only the runtime process owns these preferences; the launcher passes game identity. */
public final class GameControlPreferences {
    public static final String INITIALIZED = "layout_initialized";
    private GameControlPreferences() {}

    public static SharedPreferences open(Context context, String path) {
        SharedPreferences legacy = context.getSharedPreferences("kerberus_controls", Context.MODE_PRIVATE);
        if (path == null || path.isEmpty()) return legacy;
        SharedPreferences game = context.getSharedPreferences("kerberus_controls_" + GameIdentity.of(new File(path)), Context.MODE_PRIVATE);
        migrate(game, legacy);
        return game;
    }

    /** Copy the old layout once. Never overwrite already edited game-specific values. */
    public static void migrate(SharedPreferences game, SharedPreferences legacy) {
        if (game.getBoolean(INITIALIZED, false)) return;
        SharedPreferences.Editor editor = game.edit();
        for (Map.Entry<String, ?> item : legacy.getAll().entrySet()) {
            if (game.contains(item.getKey())) continue;
            Object value = item.getValue(); String key = item.getKey();
            if (value instanceof Boolean) editor.putBoolean(key, (Boolean)value);
            else if (value instanceof Integer) editor.putInt(key, (Integer)value);
            else if (value instanceof Float) editor.putFloat(key, (Float)value);
            else if (value instanceof Long) editor.putLong(key, (Long)value);
            else if (value instanceof String) editor.putString(key, (String)value);
            else if (value instanceof Set) {
                Set<String> strings = new HashSet<>();
                for (Object member : (Set<?>)value) if (member instanceof String) strings.add((String)member);
                editor.putStringSet(key, strings);
            }
        }
        editor.putBoolean(INITIALIZED, true).apply();
    }
}
