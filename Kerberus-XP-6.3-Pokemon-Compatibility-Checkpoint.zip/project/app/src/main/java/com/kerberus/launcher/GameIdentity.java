package com.kerberus.launcher;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Independent of a game's title: two imports with the same name remain separate. */
public final class GameIdentity {
    private GameIdentity() {}

    public static String of(File game) {
        String path;
        try { path = game.getCanonicalPath(); }
        catch (IOException error) { path = game.getAbsolutePath(); }
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(path.getBytes(StandardCharsets.UTF_8));
            StringBuilder id = new StringBuilder(64);
            for (byte value : digest) {
                id.append(Character.forDigit((value >>> 4) & 15, 16));
                id.append(Character.forDigit(value & 15, 16));
            }
            return id.toString();
        } catch (NoSuchAlgorithmException error) { throw new AssertionError(error); }
    }
}
