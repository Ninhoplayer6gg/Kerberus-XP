package com.kerberus.launcher;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.Locale;

/** Bounded game configuration reader, shared by import and runtime boot. */
public final class GameIni {
    public final String name, baseName, scripts, library;
    public final int engine;
    private GameIni(String name, Map<String,String> values) {
        this.name = name; baseName = name.substring(0, name.length()-4);
        scripts = values.containsKey("scripts") ? values.get("scripts").replace('\\', '/') : "";
        library = values.containsKey("library") ? values.get("library") : "";
        int detected = GameIntelligence.fromScriptName(scripts).rgss;
        if (detected == 0) {
            String dll = library.replace('\\', '/').toLowerCase(Locale.ROOT);
            dll = dll.substring(dll.lastIndexOf('/')+1);
            if (dll.matches("rgss1[0-9a-z]*\\.dll")) detected = 1;
            else if (dll.matches("rgss2[0-9a-z]*\\.dll")) detected = 2;
            else if (dll.matches("rgss3[0-9a-z]*\\.dll")) detected = 3;
        }
        engine = detected;
    }

    public static GameIni read(String name, InputStream in) throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        byte[] buffer = new byte[4096]; int count;
        while ((count = in.read(buffer)) != -1) {
            if (bytes.size() + count > 65536) throw new IOException("Configuração excede 64 KiB: " + name);
            bytes.write(buffer, 0, count);
        }
        return new GameIni(name, GameIntelligence.gameSection(GameIntelligence.decodeText(bytes.toByteArray())));
    }

    public static GameIni find(File game) throws IOException {
        File standard = GameIntelligence.resolve(game, "Game.ini");
        if (standard != null && standard.isFile()) {
            try (InputStream in = new FileInputStream(standard)) { return read(standard.getName(), in); }
        }
        File[] files = game.listFiles((dir, name) -> name.toLowerCase(Locale.ROOT).endsWith(".ini"));
        GameIni found = null;
        if (files != null) {
            if (files.length > 256) throw new IOException("Muitas configurações na pasta do jogo.");
            for (File file : files) {
                File safe = GameIntelligence.resolve(game, file.getName());
                if (safe == null || !safe.isFile() || safe.length() > 65536) continue;
                try (InputStream in = new FileInputStream(safe)) {
                    GameIni candidate = read(file.getName(), in);
                    if (candidate.engine == 0) continue;
                    File script = GameIntelligence.resolve(game, candidate.scripts);
                    if ((script == null || !script.isFile()) && candidate.archiveName(game).isEmpty()) continue;
                    if (found != null) throw new IOException("Mais de uma configuração de jogo encontrada.");
                    found = candidate;
                }
            }
        }
        if (found == null) throw new IOException("Configuração de jogo (.ini) não encontrada.");
        return found;
    }

    public String archiveName(File game) throws IOException {
        String extension = engine == 3 ? ".rgss3a" : engine == 2 ? ".rgss2a" : ".rgssad";
        File archive = GameIntelligence.resolve(game, baseName + extension);
        return archive != null && archive.isFile() ? archive.getName() : "";
    }

    public static boolean safeRelative(String path) {
        if (path == null || path.isEmpty() || path.startsWith("/") || path.indexOf(':') >= 0) return false;
        for (int i=0; i<path.length(); i++) if (Character.isISOControl(path.charAt(i))) return false;
        for (String part : path.replace('\\', '/').split("/", -1))
            if (part.isEmpty() || part.equals(".") || part.equals("..")) return false;
        return true;
    }

    public static boolean rgss1Header(InputStream in) throws IOException {
        int[] header = {'R','G','S','S','A','D',0,1};
        for (int value : header) if (in.read() != value) return false;
        return true;
    }
}
