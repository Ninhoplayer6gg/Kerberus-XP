package com.kerberus.launcher;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Read-only, bounded inspection. Never evaluates Ruby or loads a game's DLLs. */
public final class GameIntelligence {
    public static final int DETECTOR_VERSION = 2;
    private static final int TEXT_LIMIT = 65536;
    private static final Pattern ESSENTIALS_HEADER = Pattern.compile(
            "(?im)^\\s*#\\s*Pok[eé]mon Essentials\\s*#?\\s*\\r?\\n\\s*#\\s*Version\\s+([0-9]+(?:\\.[0-9]+){0,3})\\b");

    public enum Engine {
        XP("RPG Maker XP / RGSS1", 1), VX("RPG Maker VX / RGSS2", 2),
        VX_ACE("RPG Maker VX Ace / RGSS3", 3), UNKNOWN("Engine não identificada", 0);
        public final String label;
        public final int rgss;
        Engine(String label, int rgss) { this.label = label; this.rgss = rgss; }
    }

    public static final class Result {
        public String title = "Jogo importado";
        public Engine engine = Engine.UNKNOWN;
        public String scripts = "";
        public String essentials = "Não confirmado";
        public String essentialsVersion = "Não identificada";
        public final List<String> evidence = new ArrayList<>();
        public final List<String> warnings = new ArrayList<>();
    }

    private GameIntelligence() {}

    public static Result inspect(File game) throws IOException {
        if (!game.isDirectory()) throw new IOException("A pasta do jogo não foi encontrada.");
        Result result = new Result();
        Map<String, String> ini = new LinkedHashMap<>();
        GameIni launch = null;
        File iniFile = resolve(game, "Game.ini");
        try { launch = GameIni.find(game); iniFile = resolve(game, launch.name); }
        catch (IOException error) { result.warnings.add(error.getMessage()); }
        if (iniFile != null && iniFile.isFile()) {
            try { ini = gameSection(readText(iniFile)); result.evidence.add(iniFile.getName() + " encontrado"); }
            catch (IOException error) { result.warnings.add(iniFile.getName() + " não pôde ser analisado: " + error.getMessage()); }
        } else result.warnings.add("Configuração de jogo (.ini) não encontrada.");
        String title = clean(ini.get("title"));
        if (!title.isEmpty()) result.title = title;
        result.scripts = clean(ini.get("scripts")).replace('\\', '/');
        Engine declared = fromScriptName(result.scripts);
        Engine library = fromLibrary(ini.get("library"));
        Engine files = Engine.UNKNOWN;
        int archives = 0;
        for (String name : new String[]{"Data/Scripts.rxdata", "Data/Scripts.rvdata", "Data/Scripts.rvdata2"}) {
            File script = resolve(game, name);
            if (script != null && script.isFile()) {
                files = fromScriptName(name); archives++;
                result.evidence.add(name + " encontrado");
            }
        }
        // The runtime chooses the engine using the Scripts extension in Game.ini.
        result.engine = declared != Engine.UNKNOWN ? declared : archives == 1 ? files : library;
        if (declared != Engine.UNKNOWN) result.evidence.add("Scripts da configuração: " + result.scripts);
        if (library != Engine.UNKNOWN) result.evidence.add("Biblioteca declarada: " + library.label);
        if (archives > 1 || (library != Engine.UNKNOWN && library != result.engine))
            result.warnings.add("Há sinais de engines diferentes; confira a configuração do jogo.");
        boolean packed = false;
        if (launch != null && !launch.archiveName(game).isEmpty()) {
            File archive = resolve(game, launch.archiveName(game));
            if (archive != null && result.engine == Engine.XP) {
                try (FileInputStream in = new FileInputStream(archive)) { packed = GameIni.rgss1Header(in); }
                if (packed) result.evidence.add(archive.getName() + ": pacote RGSSAD v1; cabeçalho reconhecido; conteúdo será lido pelo núcleo");
                else result.warnings.add("Pacote RGSSAD com cabeçalho inválido ou versão não suportada.");
            }
        }
        if (!result.scripts.isEmpty()) {
            File scripts = resolve(game, result.scripts);
            if (!packed && (scripts == null || !scripts.isFile())) result.warnings.add("Arquivo de scripts declarado não encontrado dentro do jogo.");
        } else result.warnings.add("A configuração não declara o arquivo de scripts.");
        if (result.engine == Engine.VX || result.engine == Engine.VX_ACE)
            result.warnings.add("Engine identificada, mas esta versão do Kerberus prioriza execução de XP/RGSS1.");

        // Source-layout evidence documented in the upstream Pokémon Essentials project.
        // A game's GAME_VERSION constant is deliberately not an Essentials version.
        for (String name : new String[]{"Data/Scripts/001_Settings.rb", "Scripts/001_Settings.rb"}) {
            File settings = resolve(game, name);
            if (settings == null || !settings.isFile()) continue;
            try {
                Matcher match = ESSENTIALS_HEADER.matcher(readText(settings));
                if (match.find()) {
                    result.essentials = "Identificado em metadados de script";
                    result.essentialsVersion = match.group(1);
                    result.evidence.add("Cabeçalho Pokémon Essentials em " + name);
                    break;
                }
            } catch (IOException error) { result.warnings.add("Script externo excede o limite de análise ou não pôde ser lido."); }
        }
        if (result.essentials.equals("Não confirmado") && result.engine == Engine.XP) {
            int pbs = 0;
            for (String name : new String[]{"pokemon.txt", "moves.txt", "types.txt", "abilities.txt"}) {
                File data = resolve(game, "PBS/" + name);
                if (data != null && data.isFile()) pbs++;
            }
            if (pbs >= 3) {
                result.essentials = "Provável (estrutura PBS; requer confirmação)";
                result.evidence.add("Conjunto de arquivos PBS associado a projetos Pokémon");
            }
        }
        File[] dlls = game.listFiles((dir, name) -> name.toLowerCase(Locale.ROOT).endsWith(".dll")
                && !name.toLowerCase(Locale.ROOT).startsWith("rgss"));
        if (dlls != null && dlls.length > 0)
            result.warnings.add("Bibliotecas DLL adicionais presentes. A análise não determina se são usadas ou necessárias.");
        result.warnings.add("Detectar a engine não confirma que mapas, batalhas, áudio e saves funcionem.");
        return result;
    }

    public static Engine fromScriptName(String name) {
        if (name == null) return Engine.UNKNOWN;
        String lower = name.trim().toLowerCase(Locale.ROOT);
        if (lower.endsWith(".rvdata2")) return Engine.VX_ACE;
        if (lower.endsWith(".rvdata")) return Engine.VX;
        if (lower.endsWith(".rxdata")) return Engine.XP;
        return Engine.UNKNOWN;
    }

    private static Engine fromLibrary(String name) {
        if (name == null) return Engine.UNKNOWN;
        String lower = name.replace('\\', '/').toLowerCase(Locale.ROOT);
        lower = lower.substring(lower.lastIndexOf('/') + 1);
        if (lower.matches("rgss3[0-9a-z]*\\.dll")) return Engine.VX_ACE;
        if (lower.matches("rgss2[0-9a-z]*\\.dll")) return Engine.VX;
        if (lower.matches("rgss1[0-9a-z]*\\.dll")) return Engine.XP;
        return Engine.UNKNOWN;
    }

    static Map<String, String> gameSection(String text) {
        Map<String, String> values = new LinkedHashMap<>();
        boolean game = false;
        for (String line : text.split("\\r?\\n")) {
            line = line.trim();
            if (line.startsWith(";") || line.startsWith("#") || line.isEmpty()) continue;
            if (line.startsWith("[") && line.endsWith("]")) {
                game = line.equalsIgnoreCase("[Game]"); continue;
            }
            int equals = line.indexOf('=');
            if (game && equals > 0) values.put(line.substring(0, equals).trim().toLowerCase(Locale.ROOT), line.substring(equals+1).trim());
        }
        return values;
    }

    static String readText(File file) throws IOException {
        if (file.length() > TEXT_LIMIT) throw new IOException("limite de 64 KiB por arquivo de metadados");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[4096]; int count;
            while ((count = in.read(buffer)) != -1) {
                if (bytes.size() + count > TEXT_LIMIT) throw new IOException("limite de análise excedido");
                bytes.write(buffer, 0, count);
            }
        }
        return decodeText(bytes.toByteArray());
    }

    static String decodeText(byte[] raw) {
        if (raw.length >= 2 && raw[0] == (byte)0xff && raw[1] == (byte)0xfe)
            return new String(raw, 2, raw.length-2, StandardCharsets.UTF_16LE);
        if (raw.length >= 2 && raw[0] == (byte)0xfe && raw[1] == (byte)0xff)
            return new String(raw, 2, raw.length-2, StandardCharsets.UTF_16BE);
        String text = new String(raw, StandardCharsets.UTF_8);
        if (text.indexOf('\ufffd') >= 0) text = new String(raw, Charset.forName("windows-1252"));
        return text.startsWith("\ufeff") ? text.substring(1) : text;
    }

    /** Resolve case variations without permitting absolute, parent or symlink escapes. */
    public static File resolve(File root, String relative) throws IOException {
        String name = relative.replace('\\', '/');
        if (name.isEmpty() || name.startsWith("/") || name.indexOf(':') >= 0) return null;
        File current = root;
        String boundary = root.getCanonicalPath() + File.separator;
        for (String part : name.split("/", -1)) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) return null;
            File next = new File(current, part);
            if (!next.exists()) {
                File[] matches = current.listFiles((dir, candidate) -> candidate.equalsIgnoreCase(part));
                if (matches == null || matches.length != 1) return null;
                next = matches[0];
            }
            if (!next.getCanonicalPath().startsWith(boundary)) return null;
            current = next;
        }
        return current;
    }

    static String clean(String text) {
        if (text == null) return "";
        String value = text.replaceAll("[\\p{Cntrl}]", " ").trim();
        return value.substring(0, Math.min(value.length(), 240));
    }
}
