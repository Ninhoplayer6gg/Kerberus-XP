package com.kerberus.launcher;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** One worker per launcher process. Never retains an Activity or a View. */
public final class ImportManager {
    private static ImportManager instance;
    private final Context app;
    private final ProjectLibrary library;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean busy;

    private ImportManager(Context context) {
        app = context.getApplicationContext();
        library = new ProjectLibrary(app);
        ImportTask.recoverInterrupted(library);
        // Same single worker as the imports, so this finishes before the first
        // import of this process creates its own staging folder or ZIP copy.
        File cache = app.getCacheDir();
        File games = new File(app.getFilesDir(), "games");
        worker.execute(() -> ImportTask.removeLeftovers(cache, games));
    }

    public static synchronized ImportManager get(Context context) {
        if (instance == null) instance = new ImportManager(context);
        return instance;
    }

    public boolean isBusy() {
        return busy;
    }

    public synchronized void startFolder(Uri uri) {
        if(busy)return;busy=true;library.beginImport();
        worker.execute(()->{try{FolderImport.run(app,uri,library);}finally{busy=false;}});
    }

    public synchronized void start(Uri uri) {
        if (busy) return;
        busy = true;
        library.beginImport();
        worker.execute(() -> {
            try {
                new ImportTask(library, app.getCacheDir(), new File(app.getFilesDir(), "games"))
                        .run(new ImportTask.Source() {
                            private String displayName;
                            private long length = -1;

                            @Override
                            public String name() {
                                try (Cursor cursor = app.getContentResolver().query(uri,
                                        new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE},
                                        null, null, null)) {
                                    if (cursor != null && cursor.moveToFirst()) {
                                        int nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                                        int sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE);
                                        if (nameIndex >= 0) displayName = cursor.getString(nameIndex);
                                        if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) length = cursor.getLong(sizeIndex);
                                    }
                                } catch (RuntimeException ignored) {
                                    // Providers may omit metadata; stream copying still works.
                                }
                                return displayName;
                            }

                            @Override
                            public long size() { return length; }

                            @Override
                            public InputStream open() throws IOException {
                                return app.getContentResolver().openInputStream(uri);
                            }
                        });
            } finally {
                busy = false;
            }
        });
    }
}
