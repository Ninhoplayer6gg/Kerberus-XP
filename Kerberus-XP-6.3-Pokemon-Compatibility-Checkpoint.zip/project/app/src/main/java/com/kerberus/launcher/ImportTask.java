package com.kerberus.launcher;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.zip.ZipException;

/** Import work and durable reporting, independent of the Android screen lifecycle. */
public final class ImportTask {
    public interface Source {
        String name();
        long size();
        InputStream open() throws IOException;
    }

    public interface Store {
        void saveReport(String report, boolean active);
        void saveLastGame(String path, String report);
        boolean importWasActive();
        String lastReport();
    }

    private final Store store;
    private final File cache;
    private final File games;
    private String name = "Arquivo selecionado";
    private String phase = "Abrindo arquivo";
    private String lastPhase = "";
    private long lastUpdate;

    public ImportTask(Store store, File cache, File games) {
        this.store = store;
        this.cache = cache;
        this.games = games;
    }

    public static void recoverInterrupted(Store store) {
        if (store.importWasActive()) {
            store.saveReport("IMPORTAÇÃO INTERROMPIDA\nA tentativa anterior não terminou. "
                    + "Selecione o ZIP novamente e mantenha o Kerberus aberto.\n\nÚltimo registro:\n"
                    + store.lastReport(), false);
        }
    }

    public void run(Source source) {
        File temp = null;
        try {
            update("Abrindo arquivo", "");
            name = cleanName(source.name());
            long size = source.size();
            if (size > ProjectArchiveCore.MAX_ARCHIVE_BYTES) throw new IOException("O ZIP excede 4 GiB, limite desta versão.");
            if (!cache.isDirectory() && !cache.mkdirs()) throw new IOException("Não foi possível preparar o armazenamento temporário.");
            long free = cache.getUsableSpace();
            if (size > 0 && free > 0 && size > free) throw new IOException("Espaço interno insuficiente para copiar o ZIP.");
            temp = File.createTempFile("kerberus-import-", ".zip", cache);
            progress("Copiando ZIP", 0, size, true, true);
            try (InputStream input = source.open(); FileOutputStream out = new FileOutputStream(temp)) {
                if (input == null) throw new IOException("O seletor de arquivos não permitiu ler o ZIP. Selecione o arquivo novamente.");
                byte[] buffer = new byte[32768];
                long copied = 0;
                int count;
                while ((count = input.read(buffer)) != -1) {
                    if (Thread.currentThread().isInterrupted()) throw new IOException("Importação cancelada.");
                    copied += count;
                    if (copied > ProjectArchiveCore.MAX_ARCHIVE_BYTES) throw new IOException("O ZIP excede 4 GiB, limite desta versão.");
                    out.write(buffer, 0, count);
                    progress("Copiando ZIP", copied, size, true, false);
                }
                progress("Copiando ZIP", copied, size, true, true);
                if (copied == 0) throw new IOException("O arquivo selecionado está vazio.");
            }

            // Opening ZipFile itself can fail before the first progress callback.
            update("Verificando ZIP", "Abrindo o conteúdo do arquivo");
            ProjectArchiveCore.ImportResult imported = ProjectArchiveCore.importArchive(temp, games,
                    (stage, done, total) -> progress(
                            stage == ProjectArchiveCore.Stage.INSPECT ? "Verificando ZIP" : "Descompactando jogo",
                            done, total, stage == ProjectArchiveCore.Stage.EXTRACT, done == 0));
            store.saveLastGame(imported.gameDirectory.getAbsolutePath(),
                    "IMPORTAÇÃO CONCLUÍDA\nArquivo: " + name
                    + "\nArquivos extraídos: " + imported.extractedFiles
                    + "\n\nToque em Jogar último projeto para abrir o jogo.");
        } catch (Exception error) {
            String detail;
            if (error instanceof ZipException) {
                detail = "Não foi possível ler o ZIP. Ele pode estar incompleto, corrompido ou usar um formato não aceito."
                        + "\nDetalhe técnico: " + error.getMessage();
            } else if (error instanceof SecurityException) {
                detail = "O Android não permitiu ler esse arquivo. Selecione o ZIP novamente pelo botão Importar jogo.";
            } else {
                detail = error.getMessage();
                if (detail == null || detail.trim().isEmpty()) detail = error.getClass().getSimpleName();
            }
            if (detail.length() > 2000) detail = detail.substring(0, 2000);
            store.saveReport("FALHA NA IMPORTAÇÃO\nArquivo: " + name + "\nEtapa: " + phase
                    + "\n\n" + detail + "\n\nCopie este diagnóstico para analisarmos a falha.", false);
        } finally {
            if (temp != null) temp.delete();
        }
    }

    private void progress(String nextPhase, long done, long total, boolean inBytes, boolean force) {
        phase = nextPhase;
        // Bound preference writes, formatting and UI work for very large archives.
        if (!force && nextPhase.equals(lastPhase) && System.nanoTime() - lastUpdate < 1000000000L) return;
        String detail;
        if (inBytes) {
            detail = String.format(Locale.forLanguageTag("pt-BR"), "%.1f MiB", done / 1048576.0);
            if (total > 0) detail += String.format(Locale.forLanguageTag("pt-BR"), " de %.1f MiB (%d%%)",
                    total / 1048576.0, Math.min(100, done * 100 / total));
        } else {
            detail = done + " de " + total + " entradas";
        }
        update(nextPhase, detail);
    }

    private void update(String nextPhase, String detail) {
        phase = nextPhase;
        lastPhase = nextPhase;
        lastUpdate = System.nanoTime();
        store.saveReport("IMPORTAÇÃO EM ANDAMENTO\nArquivo: " + name + "\nEtapa: " + phase
                + (detail.isEmpty() ? "" : "\n" + detail)
                + "\n\nMantenha o Kerberus aberto até terminar.", true);
    }

    private static String cleanName(String value) {
        if (value == null || value.trim().isEmpty()) return "Arquivo selecionado";
        String clean = value.replaceAll("[\\p{Cntrl}]", " ");
        return clean.substring(0, Math.min(clean.length(), 200));
    }
}
