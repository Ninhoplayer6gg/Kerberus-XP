package com.kerberus.launcher;
import com.kerberus.x.compat.CompatibilityService;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Launcher and native runtime use separate processes. */
public final class KerberusLauncherActivity extends Activity {
    private static final int PICK_PROJECT = 4101;
    private static final String RUNTIME_CLASS = "com.hatkid.mkxpz.MainActivity";
    private static final String EXTRA_GAME_PATH = "kerberus_game_path";
    private static final String EXTRA_RUBY_RUNTIME = "kerberus_ruby_runtime";
    private static final String EXTRA_RUBY_REASON = "kerberus_ruby_reason";
    public static final String EXTRA_RESTART_PATH = "kerberus_restart_path";
    private ImportManager importer;
    private String compatibilityReport = "";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable refreshProgress = new Runnable() {
        @Override public void run() {
            boolean wasBusy = importer.isBusy();
            refreshLibraryState();
            // Always perform a final refresh if the worker finishes during this refresh.
            if (wasBusy) handler.postDelayed(this, 750);
        }
    };
    private ProjectLibrary library;
    private GameCatalog catalog;
    private final ExecutorService catalogWorker = Executors.newSingleThreadExecutor();
    private GameCatalog.Entry selectedEntry;
    private String profilePath;
    private boolean loadingGames;
    private TextView status;
    private TextView selectedSummary;
    private TextView selectedEngine;
    private TextView importSummary;
    private ProgressBar importProgress;
    private LinearLayout diagnosticBody;
    private Button diagnosticButton;
    private String displayedFailure = "";
    private boolean diagnosticOpen;
    private static final int BACKGROUND = Color.rgb(9, 10, 12);
    private static final int SURFACE = Color.rgb(22, 23, 27);
    private static final int BORDER = Color.rgb(49, 49, 54);
    private static final int GOLD = Color.rgb(255, 180, 65);
    private static final int MUTED = Color.rgb(173, 174, 184);
    private Button playButton;
    private Button importButton;
    private Button gamesButton;
    private Button profileButton;
    private Button kerberusXButton;
    private String pendingRestartPath;
    private int restartChecks;
    private final Runnable restartRunner = new Runnable() {
        @Override public void run() {
            String path = pendingRestartPath;
            if (path == null || isFinishing() || isDestroyed()) return;
            File game = new File(path);
            try {
                if (com.kerberus.toolkit.SessionLock.isLocked(game)) {
                    if (++restartChecks < 30) { handler.postDelayed(this, 150); return; }
                    pendingRestartPath = null;
                    Toast.makeText(KerberusLauncherActivity.this,
                            "A sessão anterior ainda está encerrando. Toque em Jogar novamente.", Toast.LENGTH_LONG).show();
                    return;
                }
            } catch (IOException error) {
                pendingRestartPath = null;
                library.saveLaunchError("Não foi possível confirmar o reinício: " + error.getMessage());
                refreshLibraryState();
                return;
            }
            pendingRestartPath = null;
            restartChecks = 0;
            library.selectGame(path);
            refreshLibraryState();
            launchLastGame();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        library = new ProjectLibrary(this);
        catalog = new GameCatalog(getFilesDir());
        importer = ImportManager.get(this);
        diagnosticOpen = savedInstanceState != null && savedInstanceState.getBoolean("diagnostic_open");
        setTitle("Kerberus XP");
        setContentView(buildUi());
        refreshLibraryState();
        queueRestartIfRequested(getIntent());
    }


    private void queueRestartIfRequested(Intent intent) {
        if (intent == null) return;
        String path = intent.getStringExtra(EXTRA_RESTART_PATH);
        if (path == null || path.isEmpty()) return;
        intent.removeExtra(EXTRA_RESTART_PATH);
        if (!isManagedGamePath(path)) {
            library.saveLaunchError("Pedido de reinício ignorado: jogo fora da biblioteca do Kerberus.");
            refreshLibraryState();
            return;
        }
        pendingRestartPath = path;
        restartChecks = 0;
        library.selectGame(path);
        refreshLibraryState();
        handler.removeCallbacks(restartRunner);
        handler.post(restartRunner);
    }

    private boolean isManagedGamePath(String path) {
        try {
            File game = new File(path).getCanonicalFile();
            File games = new File(getFilesDir(), "games").getCanonicalFile();
            return game.isDirectory() && games.equals(game.getParentFile()) && !game.getName().startsWith(".");
        } catch (IOException error) {
            return false;
        }
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        queueRestartIfRequested(intent);
    }

    private LinearLayout shelves, recentShelf, information, navigation;
    private FrameLayout pages;
    private final java.util.Map<String,View> pageViews=new java.util.LinkedHashMap<>();
    private String page="Biblioteca";
    private TextView runtimeText, countText;
    private ImageView selectedCover;
    private boolean shelfLoading;
    private View buildUi() {
        KerberusUi.immersive(this);
        LinearLayout shell=new LinearLayout(this);shell.setBackgroundColor(BACKGROUND);KerberusUi.safeArea(shell);
        boolean compact=getResources().getDisplayMetrics().widthPixels/getResources().getDisplayMetrics().density<800;
        ScrollView railScroll=new ScrollView(this);railScroll.setFillViewport(true);railScroll.setVerticalScrollBarEnabled(false);
        LinearLayout rail=KerberusUi.column(this);rail.setPadding(dp(12),dp(14),dp(12),dp(12));rail.setBackgroundColor(0xff101114);railScroll.addView(rail);
        ImageView logo=new ImageView(this);logo.setImageResource(com.hatkid.mkxpz.R.mipmap.ic_launcher);logo.setScaleType(ImageView.ScaleType.FIT_CENTER);logo.setContentDescription("Kerberus de três cabeças");rail.addView(logo,new LinearLayout.LayoutParams(dp(48),dp(48)));
        KerberusUi.add(rail,label("KERBERUS XP",15,true,GOLD),-2);KerberusUi.add(rail,label("6.1.2 / MULTI-RUNTIME",10,false,MUTED),-2);
        navigation=KerberusUi.column(this);rail.addView(navigation);
        shell.addView(railScroll,new LinearLayout.LayoutParams(dp(compact?138:160),-1));
        pages=new FrameLayout(this);shell.addView(pages,new LinearLayout.LayoutParams(0,-1,1));
        ScrollView infoScroll=new ScrollView(this);information=KerberusUi.column(this);information.setPadding(dp(16),dp(20),dp(12),dp(12));information.setBackgroundColor(0xff101114);infoScroll.addView(information);shell.addView(infoScroll,new LinearLayout.LayoutParams(dp(compact?176:208),-1));
        LinearLayout home=pageColumn("Biblioteca");
        Button resume=action("↻  Continuar último jogo",v->continueRecent());home.addView(resume);
        LinearLayout hero=card(home);hero.addView(label("SELECIONADO / SUA PRÓXIMA AVENTURA",10,true,GOLD));
        LinearLayout feature=new LinearLayout(this);feature.setGravity(Gravity.CENTER_VERTICAL);selectedCover=new ImageView(this);selectedCover.setImageResource(com.hatkid.mkxpz.R.mipmap.ic_launcher);selectedCover.setScaleType(ImageView.ScaleType.FIT_CENTER);feature.addView(selectedCover,new LinearLayout.LayoutParams(dp(76),dp(96)));
        LinearLayout copy=KerberusUi.column(this);copy.setPadding(dp(14),dp(10),0,dp(10));selectedSummary=label("Sua biblioteca começa aqui",24,true,Color.WHITE);copy.addView(selectedSummary);selectedEngine=label("Importe seu primeiro RPG Maker XP.",13,false,MUTED);copy.addView(selectedEngine);runtimeText=label("",12,true,GOLD);runtimeText.setPadding(0,dp(6),0,0);copy.addView(runtimeText);feature.addView(copy,new LinearLayout.LayoutParams(0,-2,1));hero.addView(feature);
        playButton=action("▶  JOGAR",v->launchLastGame());styleAction(playButton,true);hero.addView(playButton);
        LinearLayout actions=new LinearLayout(this);gamesButton=action("Controles",v->openControls());profileButton=action("Informações",v->{String path=library.lastGamePath();if(path!=null)loadProfile(path,false,true);});Button files=action("Arquivos",v->showFiles());
        for(Button btn:new Button[]{gamesButton,profileButton,files}){btn.setTextSize(12);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(48),1);lp.rightMargin=dp(5);actions.addView(btn,lp);}hero.addView(actions);
        home.addView(label("JOGOS RECENTES",11,true,MUTED));recentShelf=KerberusUi.column(this);home.addView(recentShelf);
        countText=label("TODOS OS JOGOS",11,true,MUTED);countText.setPadding(0,dp(12),0,dp(8));home.addView(countText);shelves=KerberusUi.column(this);home.addView(shelves);
        LinearLayout importing=pageColumn("Importar");LinearLayout importCard=card(importing);importCard.addView(label("Adicione uma nova aventura",23,true,Color.WHITE));importCard.addView(label("Importe o jogo completo. Cada importação cria uma nova instalação e preserva os saves existentes.",14,false,MUTED));
        importButton=action("Escolher ZIP",v->chooseArchive());styleAction(importButton,true);importCard.addView(importButton);importCard.addView(action("Escolher pasta",v->chooseFolder()));importCard.addView(action("Escolher pacote compatível · MXP",v->chooseArchive()));
        importSummary=label("Pronto para importar",14,false,MUTED);importCard.addView(importSummary);importProgress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);importProgress.setIndeterminateTintList(ColorStateList.valueOf(GOLD));importProgress.setProgressTintList(ColorStateList.valueOf(GOLD));importCard.addView(importProgress,new LinearLayout.LayoutParams(-1,dp(8)));importCard.addView(action("▶  Jogar agora",v->launchLastGame()));
        LinearLayout compatibility=pageColumn("Compatibilidade");compatibility.addView(label("Perfil por jogo",23,true,Color.WHITE));compatibility.addView(label("A análise verifica a estrutura. Jogabilidade completa depende dos testes de campanha.",14,false,MUTED));
        kerberusXButton=action("Abrir diagnóstico e Kerberus Morph",v->openCompatibility());compatibility.addView(kerberusXButton);compatibility.addView(action("Executar diagnóstico",v->{String path=library.lastGamePath();if(path!=null)loadProfile(path,true,true);}));
        LinearLayout controls=pageColumn("Controles");controls.addView(label("Control Studio",25,true,Color.WHITE));controls.addView(label("A Confirmar    B Voltar\nX Correr          Y Menu\n\nArraste, redimensione, ajuste a transparência ou crie seus próprios botões. Cada jogo tem um layout independente.",15,false,MUTED));controls.addView(action("Editar controles deste jogo",v->openControls()));controls.addView(label("Os layouts das versões anteriores são preservados. Aplique um novo preset quando quiser.",13,false,GOLD));
        LinearLayout translation=pageColumn("Tradução");translation.addView(label("Português Brasileiro",24,true,Color.WHITE));translation.addView(label("Idioma original: identificar nos textos\nIdioma alvo: Português Brasileiro\n\nTraduções ficam em pacotes separados. O jogo original não é sobrescrito.",15,false,MUTED));translation.addView(action("Analisar textos e pacotes",v->openToolkit()));translation.addView(action("Traduzir jogo · configurar serviço",v->openToolkit()));translation.addView(action("Backup original e saves",v->openToolkit()));translation.addView(label("A tradução automática requer um serviço configurado nas ferramentas. Não há IA embutida nesta versão.",13,false,GOLD));
        LinearLayout settings=pageColumn("Configurações");settings.addView(label("Feito para jogar deitado",23,true,Color.WHITE));settings.addView(label("Landscape em toda a experiência.\nInterface nativa, sem blur e com animações curtas.\nAndroid 6+ · ARM64",15,false,MUTED));settings.addView(action("Tela e escala por jogo",v->{if(library.lastGamePath()!=null)DisplayPreferences.show(this,library.lastGamePath());}));settings.addView(action("Atualizar biblioteca",v->loadShelves()));settings.addView(action("Ferramentas e backups",v->openToolkit()));
        LinearLayout logs=pageColumn("Logs");diagnosticButton=action("Mostrar diagnóstico",v->setDiagnosticOpen(!diagnosticOpen));logs.addView(diagnosticButton);diagnosticBody=KerberusUi.column(this);logs.addView(diagnosticBody);diagnosticBody.addView(action("Copiar diagnóstico completo",v->{android.content.ClipboardManager c=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);c.setPrimaryClip(android.content.ClipData.newPlainText("Kerberus XP",currentReport()));Toast.makeText(this,"Diagnóstico copiado",Toast.LENGTH_SHORT).show();}));status=label("",13,false,Color.WHITE);status.setTextIsSelectable(true);diagnosticBody.addView(status);setDiagnosticOpen(diagnosticOpen);
        navigate("Biblioteca");updateInfo();loadShelves();return shell;
    }
    private LinearLayout pageColumn(String name){ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);LinearLayout col=KerberusUi.column(this);col.setPadding(dp(18),dp(18),dp(18),dp(16));TextView title=label(name,27,true,Color.WHITE);title.setPadding(0,0,0,dp(16));col.addView(title);scroll.addView(col);pages.addView(scroll,new FrameLayout.LayoutParams(-1,-1));pageViews.put(name,scroll);return col;}
    private void navigate(String name){page=name;navigation.removeAllViews();for(java.util.Map.Entry<String,View> e:pageViews.entrySet()){e.getValue().setVisibility(e.getKey().equals(name)?View.VISIBLE:View.GONE);String key=e.getKey();Button b=action(key,v->navigate(key));b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);b.setTextSize(13);b.setMinHeight(dp(48));b.setMinimumHeight(dp(48));if(key.equals(name)){b.setTextColor(GOLD);b.setBackground(shape(0xff302619,0xff684923,10));}LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(48));lp.bottomMargin=dp(4);navigation.addView(b,lp);}if(name.equals("Logs"))setDiagnosticOpen(true);KerberusUi.entrance(pageViews.get(name));}
    private void updateInfo(){if(information==null)return;information.removeAllViews();information.addView(label("PAINEL DO JOGO",10,true,GOLD));if(selectedEntry==null){information.addView(label("Pronto para\nsua aventura.",22,true,Color.WHITE));return;}GameCatalog.Entry e=selectedEntry;TextView title=label(e.title(),19,true,Color.WHITE);title.setPadding(0,dp(16),0,dp(10));information.addView(title);information.addView(label("●  EXPERIMENTAL",11,true,GOLD));info("Engine",e.engine());info("RGSS",e.get("rgss","—"));info("Essentials",e.get("essentials_version","Não identificado"));info("Runtime",runtimeText.getText().toString());info("Resolução","Definida pelo jogo");info("Save","Salvamento pelo jogo");info("Última sessão",e.lastLaunchRequest()==0?"Ainda não aberto":android.text.format.DateFormat.format("dd/MM · HH:mm",e.lastLaunchRequest()).toString());information.addView(action("Detalhes técnicos",v->showProfile(e)));}
    private void info(String key,String value){TextView h=label(key.toUpperCase(java.util.Locale.ROOT),10,true,MUTED);h.setPadding(0,dp(12),0,dp(3));information.addView(h);information.addView(label(value,13,false,Color.WHITE));}
    private void loadShelves(){if(shelfLoading||catalogWorker.isShutdown())return;shelfLoading=true;catalogWorker.execute(()->{try{List<GameCatalog.Entry> list=catalog.list();runOnUiThread(()->{shelfLoading=false;if(isDestroyed())return;shelves.removeAllViews();recentShelf.removeAllViews();countText.setText("TODOS OS JOGOS / "+list.size());int recents=0;for(GameCatalog.Entry e:list){Button b=action(e.title()+"\n"+e.engine(),v->{library.selectGame(e.game.getAbsolutePath());refreshLibraryState();navigate("Biblioteca");});b.setGravity(Gravity.LEFT|Gravity.CENTER_VERTICAL);shelves.addView(b);if(e.lastLaunchRequest()>0&&recents++<3)recentShelf.addView(action(e.title(),v->{library.selectGame(e.game.getAbsolutePath());refreshLibraryState();}));}if(list.isEmpty())shelves.addView(action("＋  Importar meu primeiro jogo",v->navigate("Importar")));if(library.lastGamePath()==null&&!list.isEmpty()){library.selectGame(list.get(0).game.getAbsolutePath());refreshLibraryState();}});}catch(IOException e){runOnUiThread(()->{shelfLoading=false;Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();});}});}
    private void continueRecent(){catalogWorker.execute(()->{try{List<GameCatalog.Entry> list=catalog.list();runOnUiThread(()->{if(isDestroyed())return;if(!list.isEmpty())library.selectGame(list.get(0).game.getAbsolutePath());launchLastGame();});}catch(IOException e){runOnUiThread(()->Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show());}});}
    private void openControls(){String path=library.lastGamePath();if(path!=null)startActivity(new Intent(this,ControlEditorActivity.class).putExtra(EXTRA_GAME_PATH,path));else Toast.makeText(this,"Selecione um jogo.",Toast.LENGTH_SHORT).show();}
    private void openCompatibility(){String path=library.lastGamePath();if(path!=null)startActivity(new Intent(this,com.kerberus.x.ui.KerberusXActivity.class).putExtra(EXTRA_GAME_PATH,path));}
    private void openToolkit(){openToolkit(null);}
    private void openToolkit(String action){String path=library.lastGamePath();if(path!=null)startActivity(new Intent(this,com.kerberus.toolkit.ToolkitActivity.class).putExtra(EXTRA_GAME_PATH,path).putExtra(com.kerberus.toolkit.ToolkitActivity.EXTRA_ACTION,action));}
    // 6.4.3: saves out of and back into the protected game folder in one tap.
    private void showFiles(){String path=library.lastGamePath();if(path!=null)new AlertDialog.Builder(this).setTitle("Arquivos do jogo").setItems(new String[]{"Exportar backup dos saves","Restaurar saves de um backup","Histórico automático de saves","Ferramentas e relatórios"},(d,which)->openToolkit(which==0?"backup":which==1?"restore":which==2?"history":null)).setNegativeButton("Fechar",null).show();}
    private void chooseFolder(){if(importer.isBusy())return;startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION),4102);}

    private void refreshLibraryState() {
        String path = library.lastGamePath();
        boolean valid = path != null && !path.isEmpty() && new File(path).isDirectory();
        boolean busy = importer.isBusy();
        playButton.setEnabled(valid && !busy);
        importButton.setEnabled(!busy);
        gamesButton.setEnabled(!busy && !loadingGames);
        profileButton.setEnabled(valid && !busy);
        kerberusXButton.setEnabled(valid && !busy);
        if (!valid) {
            profilePath = null; selectedEntry = null;
            compatibilityReport = "Nenhum jogo selecionado.";
            selectedSummary.setText("Seu próximo mundo começa aqui");
            selectedEngine.setText("Importe um jogo para começar.");
            playButton.setText("Jogar");
        } else if (!busy && !path.equals(profilePath)) {
            profilePath = path; selectedEntry = null;
            compatibilityReport = "Analisando os scripts do jogo selecionado...";
            selectedSummary.setText("Lendo informações do jogo...");
            selectedEngine.setText("Preparando sua biblioteca");
            loadProfile(path, false, false);
        }
        importButton.setText(busy ? "Importando jogo..." : "Escolher ZIP");
        importProgress.setVisibility(busy ? View.VISIBLE : View.GONE);
        java.util.regex.Matcher percent=java.util.regex.Pattern.compile("(\\d+)%").matcher(library.lastReport());boolean known=percent.find();importProgress.setIndeterminate(!known);if(known)importProgress.setProgress(Integer.parseInt(percent.group(1)));
        String last = library.lastReport();
        String[] lines = last.split("\n", 5);
        StringBuilder brief = new StringBuilder();
        for (int i=0; i<Math.min(lines.length, busy ? 5 : 4); i++) {
            if (i > 0) brief.append('\n');
            brief.append(lines[i]);
        }
        if (!brief.toString().contentEquals(importSummary.getText())) importSummary.setText(brief.toString());
        boolean failed = last.startsWith("FALHA") || last.startsWith("IMPORTAÇÃO INTERROMPIDA");
        importSummary.setTextColor(failed ? Color.rgb(255, 176, 155) : MUTED);
        String failure = (failed ? last : "") + library.launchError();
        if (!failure.equals(displayedFailure)) {
            displayedFailure = failure;
            if (!failure.isEmpty()) setDiagnosticOpen(true);
        }
        // Read the runtime log only while the diagnostic is visible or copied.
        if (diagnosticOpen) {
            String report = currentReport();
            if (!report.contentEquals(status.getText())) status.setText(report);
        }
    }

    private void chooseArchive() {
        if (importer.isBusy()) return;
        library.selectionReport("SELEÇÃO DO ARQUIVO\nEscolha o ZIP completo no seletor do Android. A importação começa após a seleção.");
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        try {
            startActivityForResult(intent, PICK_PROJECT);
        } catch (RuntimeException e) {
            library.selectionReport("FALHA AO ABRIR O SELETOR\n" + e.getMessage());
        }
        refreshLibraryState();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((requestCode != PICK_PROJECT && requestCode != 4102) || importer.isBusy()) return;
        if (resultCode != RESULT_OK) {
            library.selectionReport("SELEÇÃO CANCELADA\nNenhum arquivo foi recebido. Toque em Importar jogo e selecione o ZIP.");
        } else if (data == null || data.getData() == null) {
            library.selectionReport("ARQUIVO NÃO RECEBIDO\nO seletor não entregou um arquivo ao Kerberus. Tente selecionar o ZIP pela pasta Downloads.");
        } else {
            Uri uri = data.getData();
            try {
                if ((data.getFlags() & Intent.FLAG_GRANT_READ_URI_PERMISSION) != 0) {
                    getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                }
            } catch (SecurityException ignored) {
                // Some providers grant only temporary access, which is sufficient here.
            }
            if(requestCode==4102)importer.startFolder(uri);else importer.start(uri);
            navigate("Importar");
        }
        handler.removeCallbacks(refreshProgress);
        refreshProgress.run();
    }

    private void launchLastGame() {
        if (importer.isBusy()) return;
        String path = library.lastGamePath();
        if (path == null || !new File(path).isDirectory()) {
            library.saveLaunchError("Importe um jogo antes de iniciar.");
            refreshLibraryState();
            return;
        }
        library.saveLaunchError("");
        final RuntimeSelector.Selection runtime;
        try {
            runtime = RuntimeSelector.select(new File(path));
        } catch (IOException error) {
            library.saveLaunchError("Não foi possível escolher o runtime: " + error.getMessage());
            refreshLibraryState();
            return;
        }
        Intent intent = new Intent();
        intent.setClassName(this, RUNTIME_CLASS);
        intent.putExtra(EXTRA_GAME_PATH, path);
        intent.putExtra(EXTRA_RUBY_RUNTIME, runtime.runtime.id);
        intent.putExtra(EXTRA_RUBY_REASON, runtime.reason);
        try {
            startActivity(intent);
            // This records a request, not a successful boot or measured play time.
            catalogWorker.execute(() -> {
                try { catalog.recordLaunchRequest(new File(path), System.currentTimeMillis()); }
                catch (IOException ignored) { /* Metadata cannot prevent an existing game from starting. */ }
            });
        } catch (RuntimeException e) {
            library.saveLaunchError("Não foi possível iniciar o jogo: " + e.getMessage());
            refreshLibraryState();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        RuntimeExit.record(this, library.lastGamePath());
        handler.removeCallbacks(refreshProgress);
        refreshProgress.run();
        KerberusUi.immersive(this);if(shelves!=null)loadShelves();
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(refreshProgress);
        super.onPause();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        out.putBoolean("diagnostic_open", diagnosticOpen);
        super.onSaveInstanceState(out);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        pendingRestartPath = null;
        catalogWorker.shutdownNow();
        super.onDestroy();
    }

    private void showGames() {
        if (importer.isBusy() || loadingGames) return;
        loadingGames = true; gamesButton.setEnabled(false);
        catalogWorker.execute(() -> {
            try {
                List<GameCatalog.Entry> entries = catalog.list();
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    loadingGames = false; refreshLibraryState();
                    if (entries.isEmpty()) {
                        Toast.makeText(this, "Importe um jogo para começar.", Toast.LENGTH_LONG).show();
                        return;
                    }
                    String[] titles = new String[entries.size()];
                    for (int i=0; i<titles.length; i++) titles[i] = (i+1) + ". " + entries.get(i).title() + "\n" + entries.get(i).engine();
                    new AlertDialog.Builder(this).setTitle("Meus jogos")
                            .setItems(titles, (dialog, index) -> {
                                library.selectGame(entries.get(index).game.getAbsolutePath());
                                refreshLibraryState();
                            }).setNegativeButton("Fechar", null).show();
                });
            } catch (IOException error) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    loadingGames = false; refreshLibraryState();
                    Toast.makeText(this, error.getMessage(), Toast.LENGTH_LONG).show();
                });
            }
        });
    }

    private void loadProfile(String path, boolean analyze, boolean show) {
        if (catalogWorker.isShutdown()) return;
        catalogWorker.execute(() -> {
            try {
                GameCatalog.Entry entry = analyze ? catalog.analyze(new File(path)) : catalog.load(new File(path));
                String analysis;
                try { analysis = CompatibilityService.analyze(this,new File(path)); }
                catch(IOException failure) { analysis = "Analise de scripts indisponivel: "+failure.getMessage(); }
                final String staticReport = analysis;
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed() || !path.equals(library.lastGamePath())) return;
                    selectedEntry = entry;
                    compatibilityReport = staticReport;
                    selectedSummary.setText(entry.title());
                    selectedEngine.setText(entry.engine());
                    try { RuntimeSelector.Selection runtime=RuntimeSelector.select(entry.game);runtimeText.setText(runtime.runtime.id.equals("legacy18")?"Legacy 18 · Ruby 1.8":"Modern 31 · Ruby 3.1"); }catch(IOException ex){runtimeText.setText("Runtime indisponível");}
                    updateInfo();loadShelves();
                    playButton.setText("Jogar");
                    playButton.setContentDescription("Jogar " + entry.title());
                    if (diagnosticOpen) status.setText(currentReport());
                    if (show) showProfile(entry);
                });
            } catch (IOException error) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed() || !path.equals(library.lastGamePath())) return;
                    selectedSummary.setText("Jogo selecionado • perfil indisponível");
                    selectedEngine.setText("Você pode tentar abrir o jogo ou analisar novamente.");
                    if (show) new AlertDialog.Builder(this).setTitle("Informações do jogo")
                            .setMessage(error.getMessage() + "\nO jogo e seus saves foram preservados.")
                            .setPositiveButton("Fechar", null).show();
                });
            }
        });
    }

    private void showProfile(GameCatalog.Entry entry) {
        TextView text = label(entry.report(), 14, false, Color.WHITE);
        text.setTextIsSelectable(true);
        text.setPadding(dp(20), dp(12), dp(20), dp(12));
        long last = entry.lastLaunchRequest();
        if (last > 0) text.append("\n\nÚltima abertura solicitada: "
                + android.text.format.DateFormat.getDateFormat(this).format(new Date(last)) + " "
                + android.text.format.DateFormat.getTimeFormat(this).format(new Date(last)));
        ScrollView scroll = new ScrollView(this); scroll.addView(text);
        new AlertDialog.Builder(this).setTitle("Informações do jogo").setView(scroll)
                .setPositiveButton("Jogar", (dialog, which) -> launchLastGame())
                .setNeutralButton("Analisar novamente", (dialog, which) -> loadProfile(entry.game.getAbsolutePath(), true, true))
                .setNegativeButton("Fechar", null).show();
    }

    private String currentReport() {
        String path = library.lastGamePath();
        RuntimeExit.record(this, path);
        String runtime = path == null ? "Aguardando a importação de um jogo." : RuntimeReport.read(new File(path));
        String error = library.launchError();
        return "KERBERUS XP 6.6.3 — Pokémon Compatibility Expansion\n\nÚLTIMA IMPORTAÇÃO\n" + library.lastReport()
                + (selectedEntry == null ? "" : "\n\nJOGO SELECIONADO\n" + selectedEntry.report())
                + (path == null ? "" : "\n\nESTADO DE COMPATIBILIDADE (TESTES)\n" + CompatibilityService.status(this, new File(path)))
                + "\n\nCOMPATIBILIDADE\n" + compatibilityReport
                + "\n\nINICIALIZAÇÃO" + (path == null ? "" : " DO JOGO SELECIONADO") + "\n"
                + (error.isEmpty() ? "" : error + "\n") + runtime;
    }

    // UI helpers
    private void setDiagnosticOpen(boolean open) {
        diagnosticOpen = open;
        diagnosticBody.setVisibility(open ? View.VISIBLE : View.GONE);
        diagnosticButton.setText(open ? "Ocultar diagnóstico" : "Mostrar diagnóstico");
        if (open) status.setText(currentReport());
    }

    private GradientDrawable shape(int color, int stroke, int radius) {
        GradientDrawable background = new GradientDrawable();
        background.setColor(color);
        background.setCornerRadius(dp(radius));
        background.setStroke(dp(1), stroke);
        return background;
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        card.setBackground(shape(SURFACE, BORDER, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(16)); parent.addView(card, lp);
        return card;
    }

    private void styleAction(Button button, boolean primary) {
        StateListDrawable background = new StateListDrawable();
        background.addState(new int[]{-android.R.attr.state_enabled}, shape(Color.rgb(32, 33, 38), BORDER, 12));
        background.addState(new int[]{android.R.attr.state_focused}, shape(primary ? GOLD : Color.rgb(55, 43, 26), GOLD, 12));
        background.addState(new int[]{}, shape(primary ? GOLD : SURFACE, primary ? GOLD : BORDER, 12));
        button.setBackground(new RippleDrawable(ColorStateList.valueOf(0x445c3e1b), background, shape(Color.WHITE, Color.WHITE, 12)));
        button.setBackgroundTintList(null);
        button.setTextColor(new ColorStateList(new int[][]{new int[]{-android.R.attr.state_enabled}, new int[]{}},
                new int[]{Color.rgb(128, 129, 139), primary ? BACKGROUND : Color.WHITE}));
        button.setAllCaps(false);
        button.setTextSize(15);
        button.setTypeface(null, android.graphics.Typeface.BOLD);
        button.setMinHeight(dp(48));
        button.setMinimumHeight(dp(48));
        button.setPadding(dp(12), dp(8), dp(12), dp(8));
        button.setStateListAnimator(null);
        button.setElevation(0);
    }

    private int dp(int px) {
        return (int) (px * getResources().getDisplayMetrics().density);
    }

    private TextView label(String text, int sp, boolean bold, int color) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(null, android.graphics.Typeface.BOLD);
        return tv;
    }

    private Button action(String text, View.OnClickListener listener) {
        Button b = new Button(this);
        b.setText(text);
        b.setOnClickListener(listener);
        styleAction(b, false);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.setMargins(0, 0, 0, dp(12));
        b.setLayoutParams(lp);
        return b;
    }
}
