package com.kerberus.launcher;
import android.app.Activity;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.os.Build;
import android.view.*;
import android.widget.*;
/** Lightweight shared styling and safe-area policy. All dimensions are density independent. */
public final class KerberusUi {
 public static final int BG=0xff08090b,PANEL=0xff14161a,RAISED=0xff1d2026,BORDER=0xff30343b,GOLD=0xffffae45,TEXT=0xfff4f3ef,MUTED=0xffa3a8b2,GREEN=0xff72ca9a,ERROR=0xffff7777;
 private KerberusUi(){}
 public static int dp(Context c,float x){return Math.round(x*c.getResources().getDisplayMetrics().density);}
 public static GradientDrawable shape(Context c,int color,int border,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(dp(c,radius));d.setStroke(dp(c,1),border);return d;}
 public static TextView text(Context c,String s,int size,int color,boolean bold){TextView t=new TextView(c);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(Typeface.create("sans-serif-medium",0));return t;}
 public static LinearLayout column(Context c){LinearLayout l=new LinearLayout(c);l.setOrientation(1);return l;}
 public static Button button(Context c,String s,boolean primary,Runnable r){Button b=new Button(c);b.setText(s);b.setAllCaps(false);b.setTextSize(14);b.setTextColor(new ColorStateList(new int[][]{new int[]{-android.R.attr.state_enabled},new int[]{}},new int[]{MUTED,primary?BG:TEXT}));b.setTypeface(Typeface.create("sans-serif-medium",0));b.setMinHeight(dp(c,48));b.setMinimumHeight(dp(c,48));b.setPadding(dp(c,12),0,dp(c,12),0);b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x33ffae45),shape(c,primary?GOLD:RAISED,primary?GOLD:BORDER,12),null));b.setStateListAnimator(null);b.setElevation(0);b.setOnClickListener(v->r.run());return b;}
 public static void add(LinearLayout p,View v,int h){LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,h<0?h:dp(p.getContext(),h));lp.bottomMargin=dp(p.getContext(),8);p.addView(v,lp);}
 public static void immersive(Activity a){a.getWindow().setStatusBarColor(BG);a.getWindow().setNavigationBarColor(BG);a.getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY|View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);if(Build.VERSION.SDK_INT>=28){WindowManager.LayoutParams p=a.getWindow().getAttributes();p.layoutInDisplayCutoutMode=WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;a.getWindow().setAttributes(p);}}
 public static void safeArea(View view){view.setOnApplyWindowInsetsListener((v,i)->{int l=i.getSystemWindowInsetLeft(),r=i.getSystemWindowInsetRight(),t=i.getSystemWindowInsetTop(),b=i.getSystemWindowInsetBottom();if(Build.VERSION.SDK_INT>=28&&i.getDisplayCutout()!=null){android.view.DisplayCutout c=i.getDisplayCutout();l=Math.max(l,c.getSafeInsetLeft());r=Math.max(r,c.getSafeInsetRight());t=Math.max(t,c.getSafeInsetTop());b=Math.max(b,c.getSafeInsetBottom());}if(Build.VERSION.SDK_INT>=29){android.graphics.Insets g=i.getMandatorySystemGestureInsets();l=Math.max(l,g.left);r=Math.max(r,g.right);b=Math.max(b,g.bottom);}v.setPadding(l,t,r,b);return i;});view.requestApplyInsets();}
 public static void entrance(View v){v.setAlpha(0);v.setTranslationX(dp(v.getContext(),8));v.animate().alpha(1).translationX(0).setDuration(140).start();}
}
