package com.kerberus.launcher;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.LinkedHashMap;
import java.util.HashMap;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** ZIP inspection and transactional extraction, shared with the host tests. */
public final class ProjectArchiveCore {
    public static final long MAX_ARCHIVE_BYTES = 4L * 1024 * 1024 * 1024;
    private static final long MAX_EXPANDED_BYTES = 8L * 1024 * 1024 * 1024;
    private static final long MAX_ENTRY_BYTES = 512L * 1024 * 1024;
    private static final int MAX_ENTRIES = 200000;

    public enum ProjectKind { FULL_RMXP, FULL_RMVX, FULL_RMVX_ACE, DATA_ONLY, UNKNOWN }
    public enum Stage { INSPECT, EXTRACT }

    public interface ProgressListener {
        void update(Stage stage, long completed, long total);
    }

    private static final ProgressListener NO_PROGRESS = (stage, completed, total) -> {};

    public static final class Inspection {
        public ProjectKind kind;
        public String archiveRoot;
        public long expandedBytes;
        public String details = "";
    }

    public static final class ImportResult {
        public ProjectKind kind;
        public File gameDirectory;
        public String archiveRoot;
        public int extractedFiles;
    }

    private ProjectArchiveCore() {}

    private static void checkCancelled() throws IOException {
        if (Thread.currentThread().isInterrupted()) throw new IOException("Importação cancelada.");
    }

    private static String safeName(String raw) throws IOException {
        String name = raw.replace('\\', '/');
        if (name.isEmpty() || name.startsWith("/") || name.indexOf(':') >= 0) {
            throw new IOException("Caminho inválido no ZIP (path traversal).");
        }
        for (int i = 0; i < name.length(); i++) {
            if (Character.isISOControl(name.charAt(i))) throw new IOException("Caminho inválido no ZIP.");
        }
        String trimmed = name.endsWith("/") ? name.substring(0, name.length() - 1) : name;
        for (String part : trimmed.split("/", -1)) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) {
                throw new IOException("Caminho inválido no ZIP (path traversal).");
            }
        }
        return name;
    }

    public static Inspection inspect(File archive) throws IOException {
        if (!archive.isFile() || archive.length() > MAX_ARCHIVE_BYTES) {
            throw new IOException("Arquivo ausente ou ZIP maior que 4 GiB.");
        }
        try (ZipFile zip = new ZipFile(archive)) {
            return inspect(zip, NO_PROGRESS);
        }
    }

    private static Inspection inspect(ZipFile zip, ProgressListener progress) throws IOException {
        Set<String> names = new HashSet<>();
        Map<String, ZipEntry> files = new HashMap<>();
        Set<String> ambiguous = new HashSet<>();
        List<String> configurations = new ArrayList<>();
        List<String> indicators = new ArrayList<>();
        boolean data = false;
        long total = 0;
        int count = 0;
        progress.update(Stage.INSPECT, 0, zip.size());
        Enumeration<? extends ZipEntry> entries = zip.entries();
        while (entries.hasMoreElements()) {
            checkCancelled();
            ZipEntry entry = entries.nextElement();
            String name = safeName(entry.getName());
            if (++count > MAX_ENTRIES) throw new IOException("O ZIP contém mais de 200.000 entradas; este é o limite desta versão.");
            if (count % 256 == 0) progress.update(Stage.INSPECT, count, zip.size());
            if (!names.add(name)) throw new IOException("Caminho duplicado no ZIP: " + name);
            if (entry.isDirectory()) continue;
            long size = entry.getSize();
            if (size > entryLimit(name)) throw new IOException("Arquivo excede o limite de extração: " + name);
            if (size > 0) total += size;
            if (total > MAX_EXPANDED_BYTES) throw new IOException("O jogo descompactado excede 8 GiB.");
            String lower = name.toLowerCase(Locale.ROOT);
            if (files.put(lower, entry) != null) ambiguous.add(lower);
            if (lower.endsWith(".ini")) configurations.add(name);
            if (indicators.size() < 8 && (lower.endsWith(".ini") || lower.endsWith(".rgssad") || lower.endsWith(".exe")))
                indicators.add(name.substring(0, Math.min(180, name.length())));
            if (lower.startsWith("data/") || lower.contains("/data/")) data = true;
        }
        if (configurations.size() > 256) throw new IOException("Mais de 256 arquivos de configuração no ZIP; análise interrompida.");
        Map<String, Candidate> projects = new LinkedHashMap<>();
        for (String path : configurations) {
            checkCancelled();
            String root = path.substring(0, path.lastIndexOf('/')+1);
            String leaf = path.substring(root.length());
            boolean standard = leaf.equalsIgnoreCase("Game.ini");
            // Match runtime selection: an existing Game.ini takes precedence.
            if (!standard && lookup(files, ambiguous, root+"Game.ini") != null) continue;
            ZipEntry config = lookup(files, ambiguous, path);
            // A large unrelated plugin INI must not prevent a normal game import.
            if (!standard && config.getSize() > 65536) continue;
            GameIni ini;
            try (InputStream in = zip.getInputStream(config)) { ini = GameIni.read(leaf, in); }
            if (!standard && ini.engine == 0) continue;
            if (!ini.scripts.isEmpty() && !GameIni.safeRelative(ini.scripts))
                throw new IOException("Caminho de scripts inválido na configuração: " + path);
            Candidate candidate = new Candidate(root, standard);
            String scripts = ini.scripts.isEmpty() ? "Data/Scripts.rxdata" : ini.scripts;
            if (lookup(files, ambiguous, root+scripts) != null) {
                int scriptEngine = GameIntelligence.fromScriptName(scripts).rgss;
                candidate.kind = kind(scriptEngine == 0 ? ini.engine : scriptEngine);
            }
            if (ini.scripts.isEmpty() && candidate.kind == ProjectKind.UNKNOWN) {
                if (lookup(files, ambiguous, root+"Data/Scripts.rvdata2") != null) candidate.kind = ProjectKind.FULL_RMVX_ACE;
                else if (lookup(files, ambiguous, root+"Data/Scripts.rvdata") != null) candidate.kind = ProjectKind.FULL_RMVX;
            }
            ZipEntry packed = lookup(files, ambiguous, root+ini.baseName+".rgssad");
            if (packed != null) {
                try (InputStream in = zip.getInputStream(packed)) {
                    if (!GameIni.rgss1Header(in)) throw new IOException("Pacote RGSSAD inválido ou versão não suportada: " + packed.getName());
                }
                if (ini.engine > 1) throw new IOException("A configuração e o pacote RGSSAD indicam engines diferentes.");
                candidate.kind = ProjectKind.FULL_RMXP;
            } else if (lookup(files, ambiguous, root+ini.baseName+".rgss3a") != null) candidate.kind = ProjectKind.FULL_RMVX_ACE;
            else if (lookup(files, ambiguous, root+ini.baseName+".rgss2a") != null) candidate.kind = ProjectKind.FULL_RMVX;
            if (candidate.kind == ProjectKind.UNKNOWN) continue;
            Candidate previous = projects.get(root);
            if (previous == null || standard) projects.put(root, candidate);
            else if (!previous.standard) throw new IOException("Mais de uma configuração de jogo na mesma pasta.");
        }
        if (projects.size() > 1) throw new IOException("O ZIP contém mais de um jogo. Importe um por vez.");
        Inspection result = new Inspection();
        Candidate project = projects.isEmpty() ? null : projects.values().iterator().next();
        result.archiveRoot = project == null ? "" : project.root;
        // Recognizing the package does not establish script compatibility.
        result.kind = project != null ? project.kind : data ? ProjectKind.DATA_ONLY : ProjectKind.UNKNOWN;
        result.details = "Configurações encontradas: " + configurations.size() + ". Indícios no ZIP: " + indicators;
        entries = zip.entries();
        while (entries.hasMoreElements()) {
            checkCancelled();
            ZipEntry entry = entries.nextElement();
            if (!entry.isDirectory() && entry.getName().replace('\\', '/').startsWith(result.archiveRoot)) {
                result.expandedBytes += Math.max(0, entry.getSize());
            }
        }
        progress.update(Stage.INSPECT, count, zip.size());
        return result;
    }

    private static final class Candidate {
        final String root; final boolean standard;
        ProjectKind kind = ProjectKind.UNKNOWN;
        Candidate(String root, boolean standard) { this.root=root; this.standard=standard; }
    }

    private static ProjectKind kind(int engine) {
        return engine == 1 ? ProjectKind.FULL_RMXP : engine == 2 ? ProjectKind.FULL_RMVX
                : engine == 3 ? ProjectKind.FULL_RMVX_ACE : ProjectKind.UNKNOWN;
    }

    private static ZipEntry lookup(Map<String,ZipEntry> files, Set<String> ambiguous, String name) throws IOException {
        String lower = name.toLowerCase(Locale.ROOT);
        if (ambiguous.contains(lower)) throw new IOException("Arquivos de configuração ou dados com nomes ambíguos: " + name);
        return files.get(lower);
    }

    private static long entryLimit(String name) {
        // RGSSAD contains many assets; stream it without allocating the whole archive.
        return name.toLowerCase(Locale.ROOT).endsWith(".rgssad") ? MAX_ARCHIVE_BYTES : MAX_ENTRY_BYTES;
    }

    public static ImportResult importArchive(File archive, File gamesDir) throws IOException {
        return importArchive(archive, gamesDir, NO_PROGRESS);
    }

    public static ImportResult importArchive(File archive, File gamesDir, ProgressListener progress) throws IOException {
        if (!archive.isFile() || archive.length() > MAX_ARCHIVE_BYTES) {
            throw new IOException("Arquivo ausente ou ZIP maior que 4 GiB.");
        }
        File staging = null;
        try (ZipFile zip = new ZipFile(archive)) {
            Inspection inspection = inspect(zip, progress);
            if (inspection.kind == ProjectKind.DATA_ONLY) {
                throw new IOException("Dados encontrados sem uma configuração de jogo reconhecida. Importe o jogo completo.\n" + inspection.details);
            }
            if (inspection.kind == ProjectKind.FULL_RMVX || inspection.kind == ProjectKind.FULL_RMVX_ACE) {
                String engine = inspection.kind == ProjectKind.FULL_RMVX ? "RPG Maker VX / RGSS2" : "RPG Maker VX Ace / RGSS3";
                throw new IOException(engine + " detectado. A importação para executar essa engine ainda não foi habilitada. Esta versão prioriza RPG Maker XP / RGSS1.");
            }
            if (inspection.kind != ProjectKind.FULL_RMXP) {
                throw new IOException("Projeto RPG Maker XP não reconhecido. É necessário um .ini de jogo e scripts soltos (como Data/Scripts.rxdata) ou pacote RGSSAD v1 correspondente.\n" + inspection.details);
            }
            if (!gamesDir.isDirectory() && !gamesDir.mkdirs()) throw new IOException("Não foi possível criar a biblioteca.");
            long free = gamesDir.getUsableSpace();
            if (free > 0 && inspection.expandedBytes > free) {
                throw new IOException("Espaço interno insuficiente para descompactar o jogo. Necessários: "
                        + (inspection.expandedBytes / 1048576) + " MiB; livres: " + (free / 1048576) + " MiB.");
            }
            String id = UUID.randomUUID().toString();
            staging = new File(gamesDir, ".import-" + id);
            if (!staging.mkdir()) throw new IOException("Não foi possível preparar a importação.");
            String boundary = staging.getCanonicalPath() + File.separator;
            int count = 0;
            long total = 0;
            progress.update(Stage.EXTRACT, 0, inspection.expandedBytes);
            byte[] buffer = new byte[32768];
            Enumeration<? extends ZipEntry> entries = zip.entries();
            while (entries.hasMoreElements()) {
                checkCancelled();
                ZipEntry entry = entries.nextElement();
                String name = safeName(entry.getName());
                if (!name.startsWith(inspection.archiveRoot)) continue;
                String relative = name.substring(inspection.archiveRoot.length());
                if (relative.isEmpty()) continue;
                File output = new File(staging, relative);
                if (!output.getCanonicalPath().startsWith(boundary)) throw new IOException("Path traversal bloqueado.");
                if (entry.isDirectory() || name.endsWith("/")) {
                    if (!output.isDirectory() && !output.mkdirs()) throw new IOException("Pasta inválida no ZIP.");
                    continue;
                }
                File parent = output.getParentFile();
                if (!parent.isDirectory() && !parent.mkdirs()) throw new IOException("Falha ao criar a pasta do arquivo.");
                CRC32 crc = new CRC32();
                long written = 0;
                try (InputStream in = zip.getInputStream(entry); FileOutputStream out = new FileOutputStream(output)) {
                    int n;
                    while ((n = in.read(buffer)) != -1) {
                        checkCancelled();
                        written += n;
                        total += n;
                        if (written > entryLimit(name) || total > MAX_EXPANDED_BYTES) throw new IOException("Limite de extração excedido.");
                        crc.update(buffer, 0, n);
                        out.write(buffer, 0, n);
                        progress.update(Stage.EXTRACT, total, inspection.expandedBytes);
                    }
                }
                if ((entry.getSize() >= 0 && written != entry.getSize())
                        || (entry.getCrc() >= 0 && crc.getValue() != entry.getCrc())) {
                    throw new IOException("Arquivo corrompido no ZIP: " + name);
                }
                count++;
            }
            checkCancelled();
            progress.update(Stage.EXTRACT, total, inspection.expandedBytes);
            File destination = new File(gamesDir, "game-" + id);
            if (!staging.renameTo(destination)) throw new IOException("Não foi possível concluir a importação.");
            staging = null;
            ImportResult result = new ImportResult();
            result.kind = inspection.kind;
            result.archiveRoot = inspection.archiveRoot;
            result.gameDirectory = destination;
            result.extractedFiles = count;
            return result;
        } finally {
            if (staging != null) removeTree(staging);
        }
    }

    private static void removeTree(File file) {
        File[] children = file.listFiles();
        if (children != null) for (File child : children) removeTree(child);
        file.delete();
    }
}
