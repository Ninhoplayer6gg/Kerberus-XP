package com.kerberus.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;
import java.io.IOException;

/** Import diagnostics are saved even when no game has been imported yet. */
public final class ProjectLibrary implements ImportTask.Store {
    private final SharedPreferences prefs;
    private final GameCatalog catalog;

    public ProjectLibrary(Context context) {
        prefs = context.getSharedPreferences("kerberus_library", Context.MODE_PRIVATE);
        catalog = new GameCatalog(context.getFilesDir());
    }

    @Override
    public void saveLastGame(String path, String report) {
        // Called on ImportManager's worker, after extraction has committed successfully.
        try {
            GameCatalog.Entry entry = catalog.load(new File(path));
            report += "\n\n" + entry.title() + "\n" + entry.engine()
                    + "\nPokémon Essentials: " + entry.get("essentials", "Não confirmado");
        } catch (IOException error) {
            report += "\n\nO jogo foi importado, mas seu perfil não pôde ser salvo: " + error.getMessage();
        }
        prefs.edit().putString("last_path", path).putString("last_report", report)
                .putBoolean("import_active", false).remove("launch_error").commit();
    }

    @Override
    public void saveReport(String report, boolean active) {
        // Written by the worker so errors outlive the Activity.
        prefs.edit().putString("last_report", report).putBoolean("import_active", active).commit();
    }

    public void selectionReport(String report) {
        prefs.edit().putString("last_report", report).putBoolean("import_active", false).apply();
    }

    public void beginImport() {
        prefs.edit().putString("last_report", "IMPORTAÇÃO EM ANDAMENTO\nAbrindo o arquivo selecionado...")
                .putBoolean("import_active", true).apply();
    }

    @Override
    public boolean importWasActive() {
        return prefs.getBoolean("import_active", false);
    }

    public String lastGamePath() {
        return prefs.getString("last_path", null);
    }

    public void selectGame(String path) {
        prefs.edit().putString("last_path", path).remove("launch_error").apply();
    }

    @Override
    public String lastReport() {
        return prefs.getString("last_report", "Nenhum jogo importado. Toque em Importar jogo e selecione o ZIP completo.");
    }

    public void saveLaunchError(String message) {
        prefs.edit().putString("launch_error", message).apply();
    }

    public String launchError() {
        return prefs.getString("launch_error", "");
    }
}
