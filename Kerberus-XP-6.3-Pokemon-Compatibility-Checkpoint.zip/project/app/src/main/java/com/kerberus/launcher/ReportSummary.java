package com.kerberus.launcher;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 6.6.4: what matters in a runtime report, first. A pasted diagnostic was cut
 * before its [CRASH] block (the end of a long report), so the launcher puts a
 * summary of the last problems at the top, groups the per-section [Script]
 * lines and names the libmkxp-z18.so frames of a [CRASH] block with the symbol
 * map of the same build (assets/kerberus-symbols, made by the CI).
 */
public final class ReportSummary {
    private static final Pattern TAG = Pattern.compile("^\\[([A-Za-z0-9_]+)\\]");
    private static final Pattern SCRIPT = Pattern.compile("^\\[Script\\] (.*)$");
    private static final Pattern BUILD_ID = Pattern.compile(" build-id ([0-9a-f]{8,64})");
    // "#05 0x... libmkxp-z18.so +0x4abd70" or "pc 0x... libmkxp-z18.so +0x..." without a name yet.
    private static final Pattern FRAME = Pattern.compile("^(#\\d+|pc|lr) (0x[0-9a-f]+) (libmkxp-z18\\.so) \\+0x([0-9a-f]+)$");

    private ReportSummary() {}

    /** Blocks of a report: a "[TAG]" line and the lines after it up to the next tag. */
    static List<String[]> blocks(String log) {
        List<String[]> result = new ArrayList<>();
        String tag = null;
        StringBuilder body = new StringBuilder();
        for (String line : log.split("\n", -1)) {
            Matcher m = TAG.matcher(line);
            if (m.find()) {
                if (tag != null) result.add(new String[] {tag, body.toString()});
                tag = m.group(1);
                body.setLength(0);
                body.append(line);
            } else if (tag != null) {
                body.append('\n').append(line);
            }
        }
        if (tag != null) result.add(new String[] {tag, body.toString()});
        return result;
    }

    private static String last(List<String[]> blocks, String tag) {
        for (int i = blocks.size() - 1; i >= 0; i--)
            if (blocks.get(i)[0].equals(tag)) return blocks.get(i)[1].replaceAll("\\s+$", "");
        return null;
    }

    private static int count(List<String[]> blocks, String tag) {
        int n = 0;
        for (String[] b : blocks) if (b[0].equals(tag)) n++;
        return n;
    }

    private static String limitLines(String text, int lines) {
        String[] parts = text.split("\n", -1);
        if (parts.length <= lines) return text;
        return String.join("\n", Arrays.copyOf(parts, lines)) + "\n  … (" + (parts.length - lines) + " linhas a mais no relatório)";
    }

    /** Summary of the last problems of a runtime report, newest information first. */
    public static String summarize(String log, SymbolMap symbols) {
        if (log == null || log.isEmpty()) return "Nenhum relatório de execução ainda.";
        List<String[]> blocks = blocks(log);
        StringBuilder out = new StringBuilder();
        String first = log.split("\n", 2)[0];
        if (first.startsWith("Kerberus XP")) out.append("Relatório de: ").append(first).append('\n');
        String ready = last(blocks, "LEGACY18_READY");
        if (ready != null) out.append(ready.split("\n", 2)[0]).append('\n');
        String zlib = last(blocks, "ZLIB");
        if (zlib != null) out.append(zlib.split("\n", 2)[0]).append('\n');
        int scripts = count(blocks, "Script");
        if (scripts > 0) {
            String lastScript = last(blocks, "Script");
            out.append("Seções carregadas: ").append(scripts).append(" (última: ")
               .append(lastScript.substring("[Script] ".length())).append(")\n");
        }
        String crash = last(blocks, "CRASH");
        String exit = last(blocks, "SAIDA");
        String exception = last(blocks, "RUBY_EXCEPTION");
        String message = last(blocks, "Mensagem");
        int unavailable = count(blocks, "WINBRIDGE_UNAVAILABLE");
        int zlibRecovered = count(blocks, "ZLIB_INFLATE");
        if (crash == null && exit == null && exception == null && message == null && unavailable == 0)
            out.append("Nenhum crash, erro Ruby ou saída anormal registrados.\n");
        if (crash != null) out.append('\n').append(annotate(limitLines(crash, 40), symbols)).append('\n');
        if (exit != null) out.append('\n').append(exit).append('\n');
        if (exception != null) out.append('\n').append(limitLines(exception, 30)).append('\n');
        else if (message != null) out.append('\n').append(limitLines(message, 12)).append('\n');
        if (unavailable > 0)
            out.append('\n').append(unavailable).append("x WINBRIDGE_UNAVAILABLE; último:\n")
               .append(limitLines(last(blocks, "WINBRIDGE_UNAVAILABLE"), 12)).append('\n');
        if (zlibRecovered > 0) out.append('\n').append(limitLines(last(blocks, "ZLIB_INFLATE"), 12)).append('\n');
        return out.toString().replaceAll("\\s+$", "");
    }

    /** Runs of "[Script] ..." lines become one line; the rest is kept. */
    public static String groupScripts(String log) {
        StringBuilder out = new StringBuilder();
        String firstName = null;
        String lastName = null;
        int run = 0;
        String[] lines = log.split("\n", -1);
        for (int i = 0; i <= lines.length; i++) {
            Matcher m = i < lines.length ? SCRIPT.matcher(lines[i]) : null;
            if (m != null && m.matches()) {
                if (run == 0) firstName = m.group(1);
                lastName = m.group(1);
                run++;
                continue;
            }
            if (run > 3) out.append("[Script] ").append(firstName).append(" … ").append(lastName)
                            .append(" (").append(run).append(" seções)\n");
            else if (run > 0) {
                for (int k = i - run; k < i; k++) out.append(lines[k]).append('\n');
            }
            run = 0;
            if (i < lines.length) out.append(lines[i]).append(i + 1 < lines.length ? "\n" : "");
        }
        return out.toString();
    }

    /** The last lines of a report, with [Script] runs grouped. */
    public static String tail(String log, int lines) {
        String[] parts = groupScripts(log).split("\n", -1);
        int from = Math.max(0, parts.length - lines);
        return (from > 0 ? "[… " + from + " linhas anteriores]\n" : "")
                + String.join("\n", Arrays.copyOfRange(parts, from, parts.length));
    }

    /**
     * Adds the function name to libmkxp-z18.so frames of [CRASH] blocks when
     * the block's build-id is the symbol map's (another build has other offsets).
     */
    public static String annotate(String text, SymbolMap symbols) {
        if (symbols == null || text == null) return text;
        StringBuilder out = new StringBuilder();
        boolean sameBuild = false;
        String[] lines = text.split("\n", -1);
        for (int i = 0; i < lines.length; i++) {
            String line = lines[i];
            if (line.startsWith("[CRASH]")) {
                Matcher id = BUILD_ID.matcher(line);
                sameBuild = id.find() && id.group(1).equals(symbols.buildId);
            } else if (line.startsWith("[")) {
                sameBuild = false;
            }
            Matcher frame = sameBuild ? FRAME.matcher(line) : null;
            if (frame != null && frame.matches()) {
                long offset = Long.parseLong(frame.group(4), 16);
                // A return address is looked up one byte back (the [CRASH] report does the same).
                String name = symbols.name(frame.group(1).equals("pc") ? offset : offset - 1);
                if (name != null) line = line + " [" + name + "]";
            }
            out.append(line);
            if (i + 1 < lines.length) out.append('\n');
        }
        return out.toString();
    }

    /** "build-id <hex>" then "<hex address> <name>" lines sorted by address (CI, llvm-nm -n -C). */
    public static final class SymbolMap {
        final String buildId;
        private final long[] addresses;
        private final String[] names;

        SymbolMap(String buildId, long[] addresses, String[] names) {
            this.buildId = buildId;
            this.addresses = addresses;
            this.names = names;
        }

        public static SymbolMap read(InputStream in) throws IOException {
            BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
            String header = reader.readLine();
            if (header == null || !header.startsWith("build-id ")) throw new IOException("mapa de símbolos sem build-id");
            List<Long> addresses = new ArrayList<>();
            List<String> names = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                int space = line.indexOf(' ');
                if (space <= 0) continue;
                addresses.add(Long.parseLong(line.substring(0, space), 16));
                names.add(line.substring(space + 1));
            }
            long[] a = new long[addresses.size()];
            for (int i = 0; i < a.length; i++) a[i] = addresses.get(i);
            return new SymbolMap(header.substring("build-id ".length()).trim(), a, names.toArray(new String[0]));
        }

        /** "name+0xdelta" of the symbol at or before the address, or null. */
        String name(long address) {
            int lo = 0, hi = addresses.length - 1, found = -1;
            while (lo <= hi) {
                int mid = (lo + hi) >>> 1;
                if (addresses[mid] <= address) { found = mid; lo = mid + 1; } else hi = mid - 1;
            }
            if (found < 0) return null;
            String name = names[found];
            if (name.length() > 120) name = name.substring(0, 120) + "…";
            return name + "+0x" + Long.toHexString(address - addresses[found]);
        }
    }
}
