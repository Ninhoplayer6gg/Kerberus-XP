package com.kerberus.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Debug;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.HapticFeedbackConstants;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Lightweight touch overlay: redraw on input/layout changes, never on a frame timer. */
public final class RuntimeControls {
    private static final int ORANGE = Color.rgb(255, 151, 48);
    private static final int[] KEYS = {KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_ESCAPE,
            KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_Z, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_C,
            KeyEvent.KEYCODE_A, KeyEvent.KEYCODE_S, KeyEvent.KEYCODE_D, KeyEvent.KEYCODE_Q,
            KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_CTRL_LEFT,
            KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_DEL,
            KeyEvent.KEYCODE_F1, KeyEvent.KEYCODE_F5, KeyEvent.KEYCODE_F12,
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            RuntimeControls.TURBO_KEY};
    private static final String[] KEY_NAMES = {"ENTER", "ESC", "ESPAÇO", "Z", "X", "C",
            "A", "S", "D", "Q", "W", "SHIFT", "CTRL", "ALT", "TAB", "APAGAR",
            "F1", "F5", "F12", "CIMA", "BAIXO", "ESQUERDA", "DIREITA", "TURBO (segurar)"};
    // 6.5: a control or controller button mapped to TURBO_KEY runs the game at
    // 3x while held (or, with "travar", until touched again); PAD_NONE = unused.
    static final int TURBO_KEY = -2, PAD_NONE = -1;
    // 6.5: physical controller (Bluetooth/USB). SDL gives these buttons no
    // keyboard key, so before 6.5 only the D-pad reached the game.
    private static final int[] PAD_BUTTONS = {KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
            KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_L1, KeyEvent.KEYCODE_BUTTON_R1,
            KeyEvent.KEYCODE_BUTTON_L2, KeyEvent.KEYCODE_BUTTON_R2, KeyEvent.KEYCODE_BUTTON_START,
            KeyEvent.KEYCODE_BUTTON_SELECT, KeyEvent.KEYCODE_BUTTON_THUMBL, KeyEvent.KEYCODE_BUTTON_THUMBR};
    private static final String[] PAD_NAMES = {"A", "B", "X", "Y", "L1", "R1", "L2", "R2", "START", "SELECT", "L3", "R3"};
    private static final int[] PAD_DEFAULTS = {KeyEvent.KEYCODE_C, KeyEvent.KEYCODE_X, KeyEvent.KEYCODE_SHIFT_LEFT,
            KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_Q, KeyEvent.KEYCODE_W, KeyEvent.KEYCODE_A, TURBO_KEY,
            KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_F5, PAD_NONE, PAD_NONE};
    private static final String[] FILTER_NAMES = DisplayPreferences.FILTER_NAMES;

    private final Activity activity;
    private final SharedPreferences prefs;
    private final ControlInput input;
    private final Runnable keyboard;
    private final FrameLayout root;
    private final List<TouchControl> controls = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextView menuButton, toolbarEnter, fpsButton, turboButton, statistics;
    private boolean editing, resumed, focused = true, closed;
    private boolean statsEnabled, hudHidden, preview;
    private int turbo = 1;
    // 6.5: sources holding turbo (touch control ids, "pad_<keycode>")
    private final java.util.Set<String> turboHolders = new java.util.HashSet<>();
    private boolean debugOn;
    private long repliesUntil;
    private String gamePath;
    private LinearLayout toolbar;
    private View quickPanel;
    private final Runnable fadeHud=this::fadeIdle;
    private void fadeIdle() {
        if (!editing && resumed && focused && !closed && prefs.getBoolean("autohide",true)) {
            toolbar.animate().alpha(0.08f).setDuration(180).start();
            for (TouchControl c:controls) if (!c.pressed) c.animate().alpha(0.12f).setDuration(180).start();
        }
    }
    private void wakeHud(){if(closed)return;handler.removeCallbacks(fadeHud);toolbar.animate().cancel();toolbar.setAlpha(1);for(TouchControl c:controls){c.animate().cancel();c.setAlpha(opacity(c));}if(!editing&&resumed&&focused&&prefs.getBoolean("autohide",true))handler.postDelayed(fadeHud,prefs.getInt("hide_delay",4000));}
    private float opacity(TouchControl c){return Math.max(10,Math.min(100,prefs.getInt(c.id+".opacity",prefs.getInt("opacity",65))))/100f;}

    private int statsTicks;
    private long memoryKiB;

    private final Runnable updateStatistics = new Runnable() {
        @Override public void run() {
            if (!resumed || !focused || !statsEnabled || closed) return;
            try {
                float fps = RuntimeMetrics.framesPerSecond();
                if (statsTicks++ % 2 == 0) memoryKiB = Debug.getPss();
                String text = fps < 0 ? "— FPS" : String.format(Locale.forLanguageTag("pt-BR"),
                        "%.1f FPS", fps);

                text += " • " + (memoryKiB / 1024) + " MB";
                if (prefs.getBoolean("perf_detail", false)) text += detailText(RuntimeMetrics.details());
                statistics.setText(text);
            } catch (UnsatisfiedLinkError error) {
                statistics.setText("FPS indisponível neste núcleo");
                return;
            }
            handler.postDelayed(this, 1000);
        }
    };

    public RuntimeControls(Activity activity, ViewGroup parent, ControlInput.Sink sink, Runnable keyboard) {
        this(activity, parent, sink, keyboard, activity.getIntent().getStringExtra("kerberus_game_path"));
    }

    public RuntimeControls(Activity activity, ViewGroup parent, ControlInput.Sink sink, Runnable keyboard, String gamePath) {
        this.activity = activity;this.gamePath=gamePath;
        this.keyboard = keyboard;
        prefs = GameControlPreferences.open(activity, gamePath);
        input = new ControlInput(sink);
        statsEnabled = prefs.getBoolean("fps", false);

        root = new FrameLayout(activity);
        root.setMotionEventSplittingEnabled(true);KerberusUi.safeArea(root);
        root.setClipChildren(true);
        root.setOnTouchListener((view, event) -> editing);
        parent.addView(root, new ViewGroup.LayoutParams(-1, -1));

        add("pad", "Direcional", 0, 0.02f, 0.92f, 132, true);
        add("enter", "Enter", KeyEvent.KEYCODE_ENTER, 0.68f, 0.95f, 52, false);
        add("cancel", "B", KeyEvent.KEYCODE_X, 0.98f, 0.71f, 60, true);
        add("run", "X", KeyEvent.KEYCODE_SHIFT_LEFT, 0.80f, 0.71f, 60, true);
        add("action", "A", KeyEvent.KEYCODE_C, 0.89f, 0.40f, 60, true);
        add("menu", "Y", KeyEvent.KEYCODE_ESCAPE, 0.89f, 0.98f, 60, true);
        add("space", "ESPAÇO", KeyEvent.KEYCODE_SPACE, 0.64f, 0.98f, 58, false);
        add("z", "Z", KeyEvent.KEYCODE_Z, 0.71f, 0.64f, 54, false);
        add("a", "A", KeyEvent.KEYCODE_A, 0.71f, 0.30f, 54, false);
        add("s", "S", KeyEvent.KEYCODE_S, 0.57f, 0.64f, 54, false);
        add("d", "D", KeyEvent.KEYCODE_D, 0.57f, 0.30f, 54, false);
        add("q", "Q", KeyEvent.KEYCODE_Q, 0.02f, 0.05f, 52, false);
        add("w", "W", KeyEvent.KEYCODE_W, 0.97f, 0.05f, 52, false);
        add("ctrl", "CTRL", KeyEvent.KEYCODE_CTRL_LEFT, 0.34f, 0.98f, 54, false);
        add("alt", "ALT", KeyEvent.KEYCODE_ALT_LEFT, 0.44f, 0.98f, 54, false);
        add("delete", "APAGAR", KeyEvent.KEYCODE_DEL, 0.48f, 0.55f, 58, false);
        add("esc", "ESC", KeyEvent.KEYCODE_ESCAPE, 0.15f, 0.05f, 54, false);
        add("f1", "F1", KeyEvent.KEYCODE_F1, 0.28f, 0.05f, 52, false);
        add("f5", "F5", KeyEvent.KEYCODE_F5, 0.41f, 0.05f, 52, false);
        add("f12", "F12", KeyEvent.KEYCODE_F12, 0.54f, 0.05f, 52, false);
        add("turbo", "▶▶", TURBO_KEY, 0.02f, 0.40f, 50, true);

        for(String id:prefs.getStringSet("custom_ids",new java.util.HashSet<String>()))add(id,prefs.getString(id+".label","+"),prefs.getInt(id+".key",KeyEvent.KEYCODE_C),0.5f,0.6f,56,true);
        toolbar = new LinearLayout(activity){@Override public boolean onInterceptTouchEvent(MotionEvent e){if(e.getActionMasked()==MotionEvent.ACTION_DOWN&&getAlpha()<0.5f){wakeHud();return true;}return super.onInterceptTouchEvent(e);}};
        toolbar.setGravity(Gravity.CENTER);
        toolbar.setPadding(dp(3), 0, dp(3), 0);
        toolbar.setBackground(background(Color.argb(205, 22, 19, 18), ORANGE));
        FrameLayout.LayoutParams toolbarParams = new FrameLayout.LayoutParams(-2, dp(44), Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        toolbarParams.topMargin = dp(6);
        root.addView(toolbar, toolbarParams);
        tool(toolbar,"KERBERUS",this::showQuickMenu);
        menuButton = tool(toolbar, "Controles", () -> {
            if (editing) { editing = false; menuButtonText(); applyLayout(); }
            else {wakeHud();showSettings();}
        });
        tool(toolbar, "Teclado", () -> { releaseAll(); this.keyboard.run(); });
        toolbarEnter = tool(toolbar, "Enter ↵", null);
        toolbarEnter.setOnTouchListener((v, event) -> {
            if (editing) return true;
            int action = event.getActionMasked();
            if (action == MotionEvent.ACTION_DOWN) {
                input.set("toolbar_enter", KeyEvent.KEYCODE_ENTER, 0);
                v.setAlpha(0.55f);
            } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                input.release("toolbar_enter"); v.setAlpha(1);
            }
            return true;
        });
        fpsButton = tool(toolbar, "FPS", () -> {
            statsEnabled = !statsEnabled;
            prefs.edit().putBoolean("fps", statsEnabled).apply();
            refreshStatistics();
        });

        turboButton = tool(toolbar, "Turbo", () -> setTurbo(turbo % 3 + 1));

        tool(toolbar,"•••",this::showQuickMenu);
        statistics = new TextView(activity);
        statistics.setOnClickListener(v->showPerformance());
        statistics.setTextColor(Color.WHITE);
        statistics.setTextSize(12);
        statistics.setPadding(dp(7), dp(3), dp(7), dp(3));
        statistics.setBackground(background(Color.argb(190, 12, 12, 12), Color.TRANSPARENT));
        FrameLayout.LayoutParams metricsParams = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        metricsParams.leftMargin = dp(8); metricsParams.topMargin = dp(8);
        root.addView(statistics, metricsParams);
        root.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (r-l != or-ol || b-t != ob-ot) { releaseAll(); applyLayout(); }
        });
        applyLayout();
        refreshStatistics();wakeHud();
    }

    private void add(String id, String label, int key, float x, float y, int size, boolean visible) {
        TouchControl control = new TouchControl(id, label, key, x, y, size, visible);
        controls.add(control);
        root.addView(control, new FrameLayout.LayoutParams(dp(size), dp(size)));
    }

    private TextView tool(LinearLayout toolbar, String text, Runnable action) {
        TextView view = new TextView(activity);
        view.setText(text); view.setTextSize(12); view.setTextColor(Color.WHITE);
        view.setGravity(Gravity.CENTER); view.setPadding(dp(10), 0, dp(10), 0);
        view.setFocusable(false); view.setContentDescription(text);
        if (action != null) view.setOnClickListener(v -> action.run());
        toolbar.addView(view, new LinearLayout.LayoutParams(-2, -1));
        return view;
    }

    public void resume() { resumed = true;applyLayout();refreshStatistics();wakeHud();if(effectiveTurbo()>1){handler.removeCallbacks(updateTurboLabel);updateTurboLabel.run();}if(repliesUntil>0)handler.post(pollReplies); }
    public void pause() { resumed = false;handler.removeCallbacks(fadeHud);releaseAll();refreshStatistics(); }
    public void focusChanged(boolean value) { focused = value; if (!value) releaseAll(); refreshStatistics(); }
    public void close() { closed = true; pause(); handler.removeCallbacksAndMessages(null); }

    private void refreshStatistics() {
        handler.removeCallbacks(updateStatistics);
        if (statistics == null || fpsButton == null) return;
        statistics.setVisibility(statsEnabled && !hudHidden ? View.VISIBLE : View.GONE);
        fpsButton.setTextColor(statsEnabled ? ORANGE : Color.WHITE);
        boolean enabled = statsEnabled && resumed && focused && !closed && !hudHidden && !preview;
        if(preview)return;
        try { RuntimeMetrics.setEnabled(enabled); }
        catch (UnsatisfiedLinkError ignored) { statistics.setText("FPS indisponível neste núcleo"); return; }
        if (enabled) { statsTicks = 0; handler.post(updateStatistics); }
    }

    // 6.4.3: 2x/3x speed for the session only; each game starts at 1x.
    private void setTurbo(int factor) {
        if (preview) return;
        turbo = factor;
        applyTurbo();
    }

    // 6.5: 3x while a turbo control or controller button is held.
    private void holdTurbo(String source, boolean held) {
        if (preview) return;
        if (held ? !turboHolders.add(source) : !turboHolders.remove(source)) return;
        applyTurbo();
    }

    private int effectiveTurbo() { return turboHolders.isEmpty() ? turbo : 3; }

    private void applyTurbo() {
        int factor = effectiveTurbo();
        try { RuntimeSpeed.setTurbo(factor); }
        catch (UnsatisfiedLinkError error) { Toast.makeText(activity, "Turbo indisponível neste núcleo", Toast.LENGTH_SHORT).show(); turbo = 1; turboHolders.clear(); return; }
        turboButton.setTextColor(factor == 1 ? Color.WHITE : ORANGE);
        turboButton.setContentDescription(factor == 1 ? "Turbo desligado" : "Turbo " + factor + "x");
        handler.removeCallbacks(updateTurboLabel);
        updateTurboLabel.run();
    }

    // 6.5: the speed the device really reaches (adaptive turbo), once a second.
    private final Runnable updateTurboLabel = new Runnable() {
        @Override public void run() {
            int factor = effectiveTurbo();
            if (factor == 1) { turboButton.setText("Turbo"); return; }
            float real = -1;
            try { real = RuntimeSpeed.effectiveSpeed(); } catch (UnsatisfiedLinkError ignored) {}
            turboButton.setText("▶▶ " + factor + "x" + (real > 0 ? String.format(PT, " · %.1fx", real) : ""));
            if (resumed && !closed) handler.postDelayed(this, 1000);
        }
    };
    private static final Locale PT = Locale.forLanguageTag("pt-BR");

    private static String detailText(float[] d) {
        if (d == null || d.length < 9) return "\nDetalhes: aguardando amostra";
        return String.format(PT, "\nJogo %.1f ms (pior %.0f) • Desenho %.1f ms\nGC %d · %.0f ms • Pior quadro %.0f ms • %.2fx",
                d[RuntimeMetrics.LOGIC], d[RuntimeMetrics.LOGIC_MAX], d[RuntimeMetrics.RENDER],
                Math.round(d[RuntimeMetrics.GC_RUNS]), d[RuntimeMetrics.GC_MS], d[RuntimeMetrics.WORST], d[RuntimeMetrics.SPEED]);
    }

    private void releaseAll() {
        input.releaseAll();
        if (!turboHolders.isEmpty()) { turboHolders.clear(); applyTurbo(); }
        toolbarEnter.setAlpha(1);
        for (TouchControl control : controls) { control.pointer = -1; control.direction = 0; control.pressed = false; control.invalidate(); }
    }

    private void menuButtonText() {
        menuButton.setText(editing ? "Concluir" : "Controles");
    }

    private void applyLayout() {
        if (root.getWidth() == 0 || root.getHeight() == 0) return;
        for (TouchControl control : controls) {
            int scale = prefs.getInt(control.id + ".scale", prefs.getInt("scale", 100));
            int size = Math.max(dp(44), Math.min(dp(control.baseSize * Math.max(60, Math.min(160, scale)) / 100),
                    Math.min(root.getWidth() - dp(16), root.getHeight() - dp(72))));
            FrameLayout.LayoutParams params = (FrameLayout.LayoutParams) control.getLayoutParams();
            if (params.width != size || params.height != size) {
                params.width = size; params.height = size; control.setLayoutParams(params);
            }
            control.setX(ControlGeometry.position(prefs.getFloat(control.id + ".x", control.defaultX), root.getPaddingLeft()+dp(8), root.getWidth()-root.getPaddingRight()-size-dp(8)));
            control.setY(ControlGeometry.position(prefs.getFloat(control.id + ".y", control.defaultY), root.getPaddingTop()+dp(50), root.getHeight()-root.getPaddingBottom()-size-dp(8)));
            boolean visible = prefs.getBoolean(control.id + ".visible", control.defaultVisible);
            control.setVisibility(visible && ((!prefs.getBoolean("hidden", false) && !hudHidden) || editing) && root.getHeight() > dp(100) ? View.VISIBLE : View.GONE);
            control.setAlpha(opacity(control));
            control.invalidate();
        }
    }

    private void showSettings() {
        releaseAll();
        LinearLayout body = column();
        option(body, "Presets", this::choosePreset);
        option(body, "Adicionar botão", this::addCustomControl);
        check(body,"Mostrar legendas",prefs.getBoolean("labels",true),value->{prefs.edit().putBoolean("labels",value).apply();applyLayout();});
        check(body,"AUTO HIDE",prefs.getBoolean("autohide",true),value->{prefs.edit().putBoolean("autohide",value).apply();wakeHud();});
        slider(body,"Espera AUTO HIDE (segundos)",2,12,prefs.getInt("hide_delay",4000)/1000,value->{prefs.edit().putInt("hide_delay",value*1000).apply();wakeHud();});
        if (!preview) {
            option(body, "Encerrar jogo e voltar à biblioteca", () -> new AlertDialog.Builder(activity)
                    .setTitle("Encerrar a sessão?").setMessage("Salve pelo menu do jogo antes de sair.")
                    .setNegativeButton("Continuar",null).setPositiveButton("Encerrar",(d,w)->activity.finish()).show());
        } else {
            option(body, "Voltar à biblioteca", activity::finish);
        }
        text(body, "Os ajustes ficam salvos apenas para este jogo.");
        slider(body, "Tamanho geral", 60, 160, prefs.getInt("scale", 100), value -> {
            SharedPreferences.Editor editor = prefs.edit().putInt("scale", value);
            for (TouchControl control : controls) editor.remove(control.id + ".scale");
            editor.apply(); applyLayout();
        });
        slider(body, "Visibilidade dos botões", 10, 100, prefs.getInt("opacity", 65), value -> {
            prefs.edit().putInt("opacity", value).apply(); applyLayout();
        });
        check(body, "Permitir diagonais", prefs.getBoolean("diagonal", true), value -> prefs.edit().putBoolean("diagonal", value).apply());
        check(body, "Vibrar ao tocar nos botões", prefs.getBoolean("haptics", true), value -> prefs.edit().putBoolean("haptics", value).apply());
        option(body, "Controle físico (Bluetooth/USB)", this::showGamepad);
        check(body, "Ocultar botões de jogo", prefs.getBoolean("hidden", false), value -> {
            releaseAll(); prefs.edit().putBoolean("hidden", value).apply(); applyLayout();
        });
        text(body, "O botão Enter do topo confirma nomes. Teclado abre ou fecha o teclado do Android. FPS mostra quadros apresentados e RAM do processo do jogo.");
        AlertDialog dialog = dialog("Kerberus Control Studio", body).setPositiveButton("Pronto", null).create();
        option(body, "Mover botões na tela", () -> {
            dialog.dismiss(); releaseAll(); editing = true;
            menuButtonText(); applyLayout();
            Toast.makeText(activity, "Arraste os botões e toque em Concluir. As posições ficam salvas.", Toast.LENGTH_LONG).show();
        });
        option(body, "Personalizar cada botão", () -> { dialog.dismiss(); chooseControl(); });
        option(body, "Restaurar controles padrão", () -> {
            dialog.dismiss();
            new AlertDialog.Builder(activity).setTitle("Restaurar controles?")
                    .setMessage("Isso restaura apenas posições, teclas e aparência dos controles.")
                    .setNegativeButton("Cancelar", null).setPositiveButton("Restaurar", (d, w) -> {
                        releaseAll();
                        prefs.edit().clear().putBoolean("fps", statsEnabled)
                                .putBoolean(GameControlPreferences.INITIALIZED, true).apply();
                        editing = false; menuButtonText(); applyLayout();
                    }).show();
        });
        dialog.show();
    }

    private void choosePreset() {
        releaseAll();new AlertDialog.Builder(activity).setTitle("Aplicar preset neste jogo")
          .setItems(new String[]{"Pokémon Essentials","RPG Maker XP","Teclado completo","Minimalista","Personalizado · manter atual"},(d,index)->{
            if(index==4){beginEditing();return;}
            new AlertDialog.Builder(activity).setTitle("Substituir este layout?").setMessage("Somente os controles deste jogo serão alterados.").setNegativeButton("Cancelar",null).setPositiveButton("Aplicar",(confirm,w)->{
                android.content.SharedPreferences.Editor e=prefs.edit();for(TouchControl c:controls){e.remove(c.id+".x").remove(c.id+".y").remove(c.id+".scale").remove(c.id+".key").remove(c.id+".toggle").remove(c.id+".opacity").remove(c.id+".shape");e.putBoolean(c.id+".visible",index==2||c.defaultVisible);}
                e.putInt("scale",100).putInt("opacity",65).putBoolean("hidden",false).putBoolean("labels",true).putBoolean("diagonal",true).putBoolean("autohide",true).putString("preset",Integer.toString(index));
                if(index==1)e.putInt("action.key",KeyEvent.KEYCODE_ENTER);
                if(index==3)e.putBoolean("run.visible",false).putBoolean("menu.visible",false);
                if(index==2){int j=0;for(TouchControl c:controls){if(c.defaultKey!=0){e.putFloat(c.id+".x",(j%8)/7f).putFloat(c.id+".y",0.48f+(j/8)*0.24f);j++;}}e.putBoolean("pad.visible",false);}
                e.putBoolean(GameControlPreferences.INITIALIZED,true).apply();editing=false;menuButtonText();applyLayout();wakeHud();
            }).show();
          }).setNegativeButton("Cancelar",null).show();
    }
    public void beginEditing(){releaseAll();editing=true;hudHidden=false;toolbar.setVisibility(View.VISIBLE);menuButtonText();applyLayout();wakeHud();Toast.makeText(activity,"Arraste os botões. Toque e segure para editar. Concluir salva o layout.",Toast.LENGTH_LONG).show();}
    public void setPreview(){preview=true;statsEnabled=false;refreshStatistics();beginEditing();}
    private void addCustomControl(){
        String id="custom_"+System.currentTimeMillis();android.widget.EditText name=new android.widget.EditText(activity);name.setHint("Rótulo curto (ex.: Z)");
        new AlertDialog.Builder(activity).setTitle("Adicionar botão").setView(name).setNegativeButton("Cancelar",null).setPositiveButton("Adicionar",(d,w)->{
            String label=name.getText().toString().trim();if(label.isEmpty())label="+";if(label.length()>8)label=label.substring(0,8);
            java.util.Set<String> ids=new java.util.HashSet<>(prefs.getStringSet("custom_ids",new java.util.HashSet<String>()));if(ids.size()>=20){Toast.makeText(activity,"Limite de 20 botões adicionais.",Toast.LENGTH_LONG).show();return;}ids.add(id);prefs.edit().putStringSet("custom_ids",ids).putString(id+".label",label).putInt(id+".key",KeyEvent.KEYCODE_C).apply();add(id,label,KeyEvent.KEYCODE_C,0.5f,0.6f,56,true);toolbar.bringToFront();applyLayout();editControl(controls.get(controls.size()-1));
        }).show();
    }

    private void chooseControl() {
        String[] labels = new String[controls.size()];
        for (int i=0; i<labels.length; i++) labels[i] = controls.get(i).label;
        new AlertDialog.Builder(activity).setTitle("Escolha um controle").setItems(labels,
                (dialog, index) -> editControl(controls.get(index))).setNegativeButton("Voltar", (d,w) -> showSettings()).show();
    }

    private void editControl(TouchControl control) {
        releaseAll();
        LinearLayout body = column();
        check(body, "Mostrar este controle", prefs.getBoolean(control.id + ".visible", control.defaultVisible), value -> {
            prefs.edit().putBoolean(control.id + ".visible", value).apply(); applyLayout();
        });
        slider(body, "Tamanho", 60, 160, prefs.getInt(control.id + ".scale", prefs.getInt("scale", 100)), value -> {
            prefs.edit().putInt(control.id + ".scale", value).apply(); applyLayout();
        });
        slider(body,"Transparência individual",10,100,prefs.getInt(control.id+".opacity",prefs.getInt("opacity",65)),value->{prefs.edit().putInt(control.id+".opacity",value).apply();applyLayout();});
        option(body,"Formato",()->new AlertDialog.Builder(activity).setTitle("Formato").setItems(new String[]{"Circular","Quadrado arredondado"},(d,n)->{prefs.edit().putInt(control.id+".shape",n).apply();control.invalidate();}).show());
        option(body,"Redefinir posição",()->{prefs.edit().remove(control.id+".x").remove(control.id+".y").apply();applyLayout();});
        option(body,"Remover da tela",()->{releaseAll();prefs.edit().putBoolean(control.id+".visible",false).apply();applyLayout();});
        if(control.id.startsWith("custom_"))option(body,"Excluir botão personalizado",()->{releaseAll();java.util.Set<String> ids=new java.util.HashSet<>(prefs.getStringSet("custom_ids",new java.util.HashSet<String>()));ids.remove(control.id);prefs.edit().putStringSet("custom_ids",ids).apply();controls.remove(control);root.removeView(control);});
        if (control.defaultKey != 0) {
            check(body, "Travar tecla ao tocar (ex.: correr)", prefs.getBoolean(control.id+".toggle",false), value -> {
                releaseAll();prefs.edit().putBoolean(control.id+".toggle",value).apply();
            });
            if (control.defaultKey != TURBO_KEY) {
            TextView mapping = text(body, "Tecla: " + keyName(control.key()));
            option(body, "Trocar tecla", () -> new AlertDialog.Builder(activity).setTitle("Tecla enviada ao jogo")
                    .setItems(KEY_NAMES, (d, index) -> {
                        releaseAll(); prefs.edit().putInt(control.id + ".key", KEYS[index]).apply();
                        mapping.setText("Tecla: " + KEY_NAMES[index]); control.invalidate();
                    }).show());
            } else text(body, "Segure para jogar em 3x; solte para voltar à velocidade escolhida no Turbo.");
        }
        dialog(control.label, body).setPositiveButton("Pronto", null).show();
    }

    private interface IntChange { void changed(int value); }
    private interface BoolChange { void changed(boolean value); }

    private void slider(LinearLayout body, String name, int min, int max, int value, IntChange change) {
        TextView label = text(body, name + ": " + value + (name.contains("segundos")?" s":"%"));
        SeekBar seek = new SeekBar(activity); seek.setMax(max-min); seek.setProgress(Math.max(0, Math.min(max-min, value-min)));
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s, int progress, boolean user) {
                label.setText(name + ": " + (min+progress) + (name.contains("segundos")?" s":"%"));
                if (user) change.changed(min+progress);
            }
            public void onStartTrackingTouch(SeekBar s) { releaseAll(); }
            public void onStopTrackingTouch(SeekBar s) {}
        });
        body.addView(seek, new LinearLayout.LayoutParams(-1, dp(48)));
    }

    private void check(LinearLayout body, String label, boolean value, BoolChange change) {
        CheckBox check = new CheckBox(activity); check.setText(label); check.setChecked(value);
        check.setOnCheckedChangeListener((v, enabled) -> { releaseAll(); change.changed(enabled); });
        body.addView(check);
    }

    private LinearLayout column() {
        LinearLayout body = new LinearLayout(activity); body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(20), dp(8), dp(20), dp(8)); return body;
    }

    private TextView text(LinearLayout body, String value) {
        TextView text = new TextView(activity); text.setText(value); text.setTextSize(14);
        text.setPadding(0, dp(8), 0, dp(8)); body.addView(text); return text;
    }

    private void option(LinearLayout body, String label, Runnable action) {
        android.widget.Button button = KerberusUi.button(activity,label,false,action);KerberusUi.add(body,button,48);
    }

    private AlertDialog.Builder dialog(String title, LinearLayout body) {
        ScrollView scroll = new ScrollView(activity); scroll.addView(body);
        return new AlertDialog.Builder(activity).setTitle(title).setView(scroll);
    }

    public void showQuickMenu(){
        releaseAll();wakeHud();if(quickPanel!=null){closeMenu();return;}hudHidden=false;toolbar.setVisibility(View.VISIBLE);applyLayout();
        ScrollView scroll=new ScrollView(activity);LinearLayout body=column();body.setBackground(KerberusUi.shape(activity,0xf514161a,0xff39342a,16));scroll.addView(body);quickPanel=scroll;
        text(body,"KERBERUS / SESSÃO");option(body,"Continuar",this::closeMenu);
        if(!preview&&"legacy18".equals(activity.getIntent().getStringExtra("kerberus_ruby_runtime"))){
            option(body,"Salvar agora",()->{closeMenu();request(RuntimeSession.SAVE,0,null);});
            text(body,"Usa o salvamento do próprio jogo (Pokémon Essentials), parado no mapa. Snapshots completos do runtime não são suportados.");
        } else text(body,"Salve pelo menu do jogo. Snapshots completos do runtime ainda não são suportados.");
        if(!preview){
            option(body,"Captura de tela → galeria",()->{closeMenu();request(RuntimeSession.SHOT,0,new java.io.File(activity.getCacheDir(),"kerberus-shot-"+System.currentTimeMillis()+".png").getAbsolutePath());});
            option(body,"Histórico de saves",this::showHistory);
        }
        option(body,"Controles",()->{closeMenu();showSettings();});option(body,"Teclado RGSS",this::showRgssKeyboard);option(body,"Teclado Android",()->{closeMenu();keyboard.run();});
        option(body,turbo==1?"Turbo · 1x (normal)":"Turbo · "+turbo+"x",()->{setTurbo(turbo%3+1);closeMenu();showQuickMenu();});
        option(body,"Performance",this::showPerformance);option(body,"Tela / escala",()->DisplayPreferences.show(activity,gamePath));
        option(body,"Filtro de imagem · "+FILTER_NAMES[DisplayPreferences.filterMode(DisplayPreferences.open(activity,gamePath))],this::chooseFilter);
        if(!preview)option(body,"Modo debug (Essentials) · "+(debugOn?"ligado":"desligado"),this::toggleDebug);
        option(body,"Áudio",()->{LinearLayout box=column();android.media.AudioManager audio=(android.media.AudioManager)activity.getSystemService(Activity.AUDIO_SERVICE);text(box,"Volume de mídia do Android");slider(box,"Volume",0,audio.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC),audio.getStreamVolume(android.media.AudioManager.STREAM_MUSIC),v->audio.setStreamVolume(android.media.AudioManager.STREAM_MUSIC,v,0));dialog("Áudio",box).setPositiveButton("Fechar",null).show();});
        option(body,"Compatibilidade",()->{LinearLayout box=column();text(box,"Runtime: "+activity.getIntent().getStringExtra("kerberus_ruby_runtime")+"\nPerfil experimental. Configurações Morph ficam na biblioteca.");dialog("Compatibilidade",box).setPositiveButton("Fechar",null).show();});
        option(body,"Logs",()->{LinearLayout box=column();TextView log=text(box,RuntimeReport.read(new java.io.File(gamePath)));log.setTextIsSelectable(true);dialog("Última sessão",box).setPositiveButton("Fechar",null).show();});
        option(body,"Ocultar HUD · controle físico",()->{closeMenu();releaseAll();hudHidden=true;toolbar.setVisibility(View.GONE);applyLayout();refreshStatistics();Toast.makeText(activity,"Use Voltar do Android para reabrir o menu.",Toast.LENGTH_LONG).show();});
        if(!preview){option(body,"Reiniciar jogo",()->confirmEnd(true));option(body,"Sair para biblioteca",()->confirmEnd(false));}
        else option(body,"Voltar à biblioteca",activity::finish);
        FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(Math.min(dp(330),root.getWidth()-dp(28)),-1,Gravity.RIGHT);root.addView(scroll,lp);KerberusUi.entrance(scroll);
    }
    private void confirmEnd(boolean restart){new AlertDialog.Builder(activity).setTitle(restart?"Reiniciar jogo?":"Encerrar sessão?").setMessage("Salve pelo menu do jogo antes de continuar.").setNegativeButton("Cancelar",null).setPositiveButton("Continuar",(d,w)->{releaseAll();if(restart){android.content.Intent i=new android.content.Intent(activity,KerberusLauncherActivity.class).addFlags(android.content.Intent.FLAG_ACTIVITY_CLEAR_TOP|android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP|android.content.Intent.FLAG_ACTIVITY_NEW_TASK).putExtra(KerberusLauncherActivity.EXTRA_RESTART_PATH,gamePath);activity.startActivity(i);}activity.finish();}).show();}
    private void closeMenu(){if(quickPanel!=null){root.removeView(quickPanel);quickPanel=null;}releaseAll();wakeHud();}
    private void showPerformance(){LinearLayout box=column();float fps=-1;if(!preview)try{fps=RuntimeMetrics.framesPerSecond();}catch(UnsatisfiedLinkError ignored){}text(box,(fps<0?"FPS: aguardando amostra":String.format(Locale.ROOT,"FPS: %.1f\nTempo médio por quadro: %.2f ms",fps,1000f/Math.max(1,fps)))+"\nRAM: "+Debug.getPss()/1024+" MB\nRuntime: "+(preview?"Prévia":activity.getIntent().getStringExtra("kerberus_ruby_runtime"))+"\nRenderizador: OpenGL ES / SDL\nResolução interna: definida pelo jogo");float[] detail=null;if(!preview&&statsEnabled)try{detail=RuntimeMetrics.details();}catch(UnsatisfiedLinkError ignored){}if(detail!=null)text(box,detailText(detail).trim());check(box,"Mostrar FPS / RAM",statsEnabled,v->{statsEnabled=v;prefs.edit().putBoolean("fps",v).apply();refreshStatistics();});check(box,"Painel detalhado (tempo do jogo, desenho, GC)",prefs.getBoolean("perf_detail",false),v->{prefs.edit().putBoolean("perf_detail",v).apply();if(v&&!statsEnabled){statsEnabled=true;prefs.edit().putBoolean("fps",true).apply();}refreshStatistics();});text(box,"Jogo: tempo dos scripts por atualização. Desenho: tempo para compor a tela. GC: coletas de memória do Ruby no último segundo. Pior quadro: maior intervalo entre duas imagens (travadinha visível). Velocidade: 1,00x é o ritmo normal do jogo.");dialog("Performance",box).setPositiveButton("Fechar",null).show();}
    private void showRgssKeyboard(){
        closeMenu();releaseAll();LinearLayout box=column();text(box,"TECLADO RGSS");int[] keys={KeyEvent.KEYCODE_ENTER,KeyEvent.KEYCODE_ESCAPE,KeyEvent.KEYCODE_SHIFT_LEFT,KeyEvent.KEYCODE_CTRL_LEFT,KeyEvent.KEYCODE_Z,KeyEvent.KEYCODE_X,KeyEvent.KEYCODE_C,KeyEvent.KEYCODE_A,KeyEvent.KEYCODE_S,KeyEvent.KEYCODE_Q,KeyEvent.KEYCODE_W,KeyEvent.KEYCODE_F5,KeyEvent.KEYCODE_F12,KeyEvent.KEYCODE_DPAD_UP,KeyEvent.KEYCODE_DPAD_DOWN,KeyEvent.KEYCODE_DPAD_LEFT,KeyEvent.KEYCODE_DPAD_RIGHT};
        LinearLayout row=null;for(int n=0;n<keys.length;n++){if(n%5==0){row=new LinearLayout(activity);box.addView(row);}final int key=keys[n];TextView b=KerberusUi.text(activity,keyName(key),13,Color.WHITE,true);b.setGravity(Gravity.CENTER);b.setBackground(background(0xff242424,0xff746046));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(dp(64),dp(48));lp.setMargins(dp(2),dp(2),dp(2),dp(2));row.addView(b,lp);b.setOnTouchListener((v,e)->{String source="keyboard_"+key;if(e.getActionMasked()==MotionEvent.ACTION_DOWN){input.set(source,key,0);v.setAlpha(0.55f);}else if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){input.release(source);v.setAlpha(1);}return true;});}
        option(box,"Teclado Android",()->{closeMenu();keyboard.run();});option(box,"Fechar teclado",this::closeMenu);ScrollView scroll=new ScrollView(activity);box.setBackground(background(0xf014161a,0xff584322));scroll.addView(box);quickPanel=scroll;root.addView(scroll,new FrameLayout.LayoutParams(-2,-2,Gravity.CENTER));
    }

    // 6.5: requests to the game (RuntimeSession); replies are polled while any is pending.
    private void request(int code, int arg, String path) {
        boolean queued;
        try { queued = RuntimeSession.request(code, arg, path); }
        catch (UnsatisfiedLinkError error) { toast("Indisponível neste núcleo."); return; }
        if (!queued) { toast("Pedido anterior ainda aguardando o jogo."); return; }
        repliesUntil = System.currentTimeMillis() + 15000;
        handler.removeCallbacks(pollReplies);
        handler.postDelayed(pollReplies, 150);
    }

    private final Runnable pollReplies = new Runnable() {
        @Override public void run() {
            if (closed) return;
            String reply;
            try { while ((reply = RuntimeSession.takeReply()) != null) handleReply(reply); }
            catch (UnsatisfiedLinkError error) { repliesUntil = 0; return; }
            if (System.currentTimeMillis() < repliesUntil) { if (resumed) handler.postDelayed(this, 200); }
            else repliesUntil = 0;
        }
    };

    private void handleReply(String reply) {
        String[] part = reply.split(":", 3);
        String what = part[0], status = part.length > 1 ? part[1] : "", detail = part.length > 2 ? part[2] : "";
        if (what.equals("save")) toast(saveMessage(status, detail));
        else if (what.equals("debug")) {
            debugOn = status.equals("on");
            toast(debugOn ? "Modo debug ligado nesta sessão." : "Modo debug desligado.");
        } else if (what.equals("shot")) {
            if (status.equals("ok")) publishShot(new java.io.File(detail));
            else toast("A captura falhou: " + detail);
        } else toast("O jogo não reconheceu o pedido.");
    }

    private static String saveMessage(String status, String detail) {
        switch (status) {
            case "ok": return "Jogo salvo pelo salvamento do próprio jogo.";
            case "fail": return "O jogo informou falha ao salvar. Tente pelo menu do jogo.";
            case "error": return "Erro ao salvar: " + detail;
            case "unsupported":
                if (detail.equals("no_pbsave")) return "Este jogo não usa o salvamento do Pokémon Essentials. Salve pelo menu do jogo.";
                if (detail.equals("not_loaded")) return "Carregue ou comece um jogo primeiro.";
                return "Salvar agora não está disponível neste núcleo.";
            case "busy":
                switch (detail) {
                    case "scene": return "Volte ao mapa para salvar.";
                    case "battle": return "Termine a batalha para salvar.";
                    case "message": return "Feche a mensagem para salvar.";
                    case "transfer": return "Aguarde a troca de mapa e tente de novo.";
                    case "moving": return "Pare de andar e tente de novo.";
                    case "event": return "Aguarde o evento terminar e tente de novo.";
                    case "newgame": return "Jogo novo nesta sessão: salve a primeira vez pelo menu do jogo (ele confirma a troca do save antigo).";
                    default: return "Feche o menu ou a tela aberta e tente de novo, parado no mapa.";
                }
            default: return "Resposta inesperada do jogo: " + status;
        }
    }

    private void publishShot(java.io.File png) {
        final String title = gamePath == null ? "jogo" : new java.io.File(gamePath).getName();
        new Thread(() -> {
            String message;
            try { message = ScreenshotStore.save(activity, png, title); }
            catch (java.io.IOException | RuntimeException error) { message = "Não foi possível salvar a captura: " + error.getMessage(); }
            finally { png.delete(); }
            final String text = message;
            activity.runOnUiThread(() -> toast(text));
        }, "KerberusScreenshot").start();
    }

    private void toast(String text) { if (!closed) Toast.makeText(activity, text, Toast.LENGTH_LONG).show(); }

    private void showHistory() {
        java.util.List<com.kerberus.toolkit.SaveHistory.Entry> list = gamePath == null ? new ArrayList<>()
                : com.kerberus.toolkit.SaveHistory.list(new java.io.File(gamePath));
        LinearLayout box = column();
        java.text.DateFormat format = java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.MEDIUM);
        if (list.isEmpty()) text(box, "Nenhuma cópia ainda. O Kerberus copia os saves sempre que o jogo salva e guarda as últimas " + com.kerberus.toolkit.SaveHistory.KEEP + ".");
        for (com.kerberus.toolkit.SaveHistory.Entry e : list)
            text(box, format.format(new java.util.Date(e.time)) + " · " + e.count + " arquivo(s)" + (e.reason.isEmpty() ? "" : " · " + e.reason));
        text(box, "Para restaurar uma cópia, saia do jogo e use Arquivos → Histórico automático de saves na biblioteca.");
        dialog("Histórico de saves", box).setPositiveButton("Fechar", null).show();
    }

    private void chooseFilter() {
        SharedPreferences display = DisplayPreferences.open(activity, gamePath);
        new AlertDialog.Builder(activity).setTitle("Filtro de imagem").setSingleChoiceItems(FILTER_NAMES,
                DisplayPreferences.filterMode(display), (d, which) -> {
                    DisplayPreferences.setFilterMode(display, which);
                    if (!preview) try { RuntimeSession.setFilter(which); } catch (UnsatisfiedLinkError error) { toast("Aplicado na próxima abertura do jogo."); }
                    d.dismiss();
                    if (quickPanel != null) { closeMenu(); showQuickMenu(); }
                }).setNegativeButton("Cancelar", null).show();
    }

    private void toggleDebug() {
        if (debugOn) { request(RuntimeSession.DEBUG, 0, null); closeMenu(); return; }
        new AlertDialog.Builder(activity).setTitle("Ligar modo debug?")
                .setMessage("Liga o $DEBUG como no teste do RPG Maker, só nesta sessão. Jogos Pokémon Essentials mostram a opção Debug no menu e permitem atravessar paredes segurando CTRL. O que você mudar pelo Debug fica no save se você salvar.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Ligar", (d, w) -> { closeMenu(); request(RuntimeSession.DEBUG, 1, null); }).show();
    }

    // 6.5: physical controller buttons -> keys, per game (prefs "pad.<keycode>").
    private int padTarget(int code) {
        for (int i = 0; i < PAD_BUTTONS.length; i++)
            if (PAD_BUTTONS[i] == code) return prefs.getInt("pad." + code, PAD_DEFAULTS[i]);
        return prefs.getInt("pad." + code, PAD_NONE);
    }

    private static String padTargetName(int target) { return target == PAD_NONE ? "nenhuma" : keyName(target); }

    /** Called by the game activity first; true when the key was a controller button. */
    public boolean gamepadKey(KeyEvent event) {
        int code = event.getKeyCode();
        if (closed || preview || !KeyEvent.isGamepadButton(code)) return false;
        int action = event.getAction();
        if (action == KeyEvent.ACTION_DOWN && event.getRepeatCount() > 0) return true;
        boolean down = action == KeyEvent.ACTION_DOWN;
        if (action != KeyEvent.ACTION_DOWN && action != KeyEvent.ACTION_UP) return true;
        String source = "pad_" + code;
        int target = padTarget(code);
        if (target == TURBO_KEY) holdTurbo(source, down);
        else if (target != PAD_NONE) { if (down) input.set(source, target, 0); else input.release(source); }
        return true;
    }

    /** Analog stick and hat of a controller as the four directions. */
    public boolean gamepadMotion(MotionEvent event) {
        if (closed || preview || (event.getSource() & InputDevice.SOURCE_JOYSTICK) != InputDevice.SOURCE_JOYSTICK
                || event.getActionMasked() != MotionEvent.ACTION_MOVE) return false;
        float x = event.getAxisValue(MotionEvent.AXIS_HAT_X), y = event.getAxisValue(MotionEvent.AXIS_HAT_Y);
        if (Math.abs(x) < 0.5f && Math.abs(y) < 0.5f) { x = event.getAxisValue(MotionEvent.AXIS_X); y = event.getAxisValue(MotionEvent.AXIS_Y); }
        int horizontal = x <= -0.5f ? KeyEvent.KEYCODE_DPAD_LEFT : x >= 0.5f ? KeyEvent.KEYCODE_DPAD_RIGHT : 0;
        int vertical = y <= -0.5f ? KeyEvent.KEYCODE_DPAD_UP : y >= 0.5f ? KeyEvent.KEYCODE_DPAD_DOWN : 0;
        if (horizontal != 0 && vertical != 0 && !prefs.getBoolean("diagonal", true)) {
            if (Math.abs(x) >= Math.abs(y)) vertical = 0; else horizontal = 0;
        }
        input.set("pad_stick", horizontal, vertical);
        return true;
    }

    private void showGamepad() {
        releaseAll();
        LinearLayout body = column();
        String connected = null;
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice device = InputDevice.getDevice(id);
            if (device != null && (device.getSources() & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD) { connected = device.getName(); break; }
        }
        text(body, connected == null ? "Nenhum controle conectado agora. O mapeamento vale quando um controle for conectado."
                : "Controle conectado: " + connected);
        text(body, "Direcional e analógico movem o personagem. Toque em um botão para trocar a tecla enviada ao jogo. Vale só para este jogo.");
        AlertDialog dialog = dialog("Controle físico", body).setPositiveButton("Pronto", null).create();
        for (int i = 0; i < PAD_BUTTONS.length; i++) {
            final int code = PAD_BUTTONS[i]; final String name = PAD_NAMES[i];
            option(body, name + " → " + padTargetName(padTarget(code)), () -> {
                String[] names = new String[KEY_NAMES.length + 1];
                System.arraycopy(KEY_NAMES, 0, names, 0, KEY_NAMES.length); names[KEY_NAMES.length] = "Nenhuma";
                new AlertDialog.Builder(activity).setTitle("Botão " + name).setItems(names, (d, index) -> {
                    releaseAll();
                    prefs.edit().putInt("pad." + code, index < KEYS.length ? KEYS[index] : PAD_NONE).apply();
                    dialog.dismiss(); showGamepad();
                }).show();
            });
        }
        option(body, "Restaurar padrão do controle", () -> {
            SharedPreferences.Editor editor = prefs.edit();
            for (int code : PAD_BUTTONS) editor.remove("pad." + code);
            editor.apply(); releaseAll(); dialog.dismiss(); showGamepad();
        });
        dialog.show();
    }

    private final class TouchControl extends View {
        final String id, label;
        final int defaultKey, baseSize;
        final float defaultX, defaultY;
        final boolean defaultVisible;
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        int pointer = -1, direction;
        boolean pressed;
        float startRawX, startRawY, startX, startY;

        TouchControl(String id, String label, int key, float x, float y, int size, boolean visible) {
            super(activity); this.id=id; this.label=label; defaultKey=key; defaultX=x; defaultY=y;
            baseSize=size; defaultVisible=visible;
            setContentDescription(label); setFocusable(false);setOnLongClickListener(v->{if(editing){editControl(this);return true;}return false;});
        }

        int key() { return prefs.getInt(id + ".key", defaultKey); }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            float w=getWidth(), h=getHeight();
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(pressed ? 0xff835221 : 0xff15171c);
            canvas.drawRoundRect(2, 2, w-2, h-2, defaultKey!=0&&prefs.getInt(id+".shape",0)==0?w/2:w*0.20f, defaultKey!=0&&prefs.getInt(id+".shape",0)==0?h/2:h*0.20f, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(1)); paint.setColor(pressed?ORANGE:0xff8a785f);
            canvas.drawRoundRect(2, 2, w-2, h-2, defaultKey!=0&&prefs.getInt(id+".shape",0)==0?w/2:w*0.20f, defaultKey!=0&&prefs.getInt(id+".shape",0)==0?h/2:h*0.20f, paint);
            paint.setStyle(Paint.Style.FILL); paint.setTextAlign(Paint.Align.CENTER); paint.setTypeface(Typeface.DEFAULT_BOLD);
            if (defaultKey == 0) {
                paint.setTextSize(w*0.22f);
                arrow(canvas, "▲", w/2, h*0.29f, ControlGeometry.UP);
                arrow(canvas, "▼", w/2, h*0.91f, ControlGeometry.DOWN);
                arrow(canvas, "◀", w*0.19f, h*0.60f, ControlGeometry.LEFT);
                arrow(canvas, "▶", w*0.81f, h*0.60f, ControlGeometry.RIGHT);
            } else {
                paint.setColor(Color.WHITE); paint.setTextSize(w*(label.length()>3 ? 0.19f : 0.38f));
                canvas.drawText(label, w/2, h*0.45f-(paint.ascent()+paint.descent())/2, paint);
                if(prefs.getBoolean("labels",true)){paint.setTextSize(Math.min(dp(10),w*0.17f));paint.setColor(0xffc4b8a5);String caption=id.equals("turbo")?"Turbo":id.equals("action")?"Confirmar":id.equals("cancel")?"Voltar":id.equals("run")?"Correr":id.equals("menu")?"Menu":keyName(key());canvas.drawText(caption,w/2,h*0.77f,paint);}
            }
        }

        private void arrow(Canvas canvas, String symbol, float x, float y, int mask) {
            paint.setColor((direction & mask)!=0 ? ORANGE : Color.WHITE); canvas.drawText(symbol, x, y, paint);
        }

        @Override public boolean onTouchEvent(MotionEvent event) {
            int action=event.getActionMasked();
            if (action==MotionEvent.ACTION_DOWN) {
                wakeHud();
                if(editing){handler.postDelayed(()->{if(pointer>=0&&Math.abs(getX()-startX)<dp(5)&&Math.abs(getY()-startY)<dp(5))performLongClick();},600);}
                pointer=event.getPointerId(0);
                if (editing) { startRawX=event.getRawX(); startRawY=event.getRawY(); startX=getX(); startY=getY(); }
                else if (defaultKey != 0 && prefs.getBoolean(id+".toggle",false)) {
                    pressed=!pressed;send(pressed);if(pressed)haptic();invalidate();
                } else updatePress(event.getX(), event.getY());
                return true;
            }
            // Multi-touch: a second finger on the same control must not steal the
            // tracked pointer; the active finger keeps ownership until it lifts.
            if (action==MotionEvent.ACTION_POINTER_DOWN) return true;
            if (pointer<0) return true;
            if (action==MotionEvent.ACTION_MOVE) {
                int index=event.findPointerIndex(pointer);
                if (index<0) { release(); return true; }
                if (editing) {
                    float x=ControlGeometry.normalized(startX+event.getRawX(index)-startRawX, root.getPaddingLeft()+dp(8), root.getWidth()-root.getPaddingRight()-getWidth()-dp(8));
                    float y=ControlGeometry.normalized(startY+event.getRawY(index)-startRawY, root.getPaddingTop()+dp(50), root.getHeight()-root.getPaddingBottom()-getHeight()-dp(8));
                    setX(ControlGeometry.position(x, root.getPaddingLeft()+dp(8), root.getWidth()-root.getPaddingRight()-getWidth()-dp(8)));
                    setY(ControlGeometry.position(y, root.getPaddingTop()+dp(50), root.getHeight()-root.getPaddingBottom()-getHeight()-dp(8)));
                } else if (!(defaultKey != 0 && prefs.getBoolean(id+".toggle",false))) updatePress(event.getX(index), event.getY(index));
            } else if (action==MotionEvent.ACTION_UP || action==MotionEvent.ACTION_CANCEL ||
                    (action==MotionEvent.ACTION_POINTER_UP && event.getPointerId(event.getActionIndex())==pointer)) {
                if (editing && action!=MotionEvent.ACTION_CANCEL) {
                    prefs.edit().putFloat(id+".x", ControlGeometry.normalized(getX(), root.getPaddingLeft()+dp(8), root.getWidth()-root.getPaddingRight()-getWidth()-dp(8)))
                            .putFloat(id+".y", ControlGeometry.normalized(getY(), root.getPaddingTop()+dp(50), root.getHeight()-root.getPaddingBottom()-getHeight()-dp(8))).apply();
                }
                if(!editing && defaultKey!=0 && prefs.getBoolean(id+".toggle",false) && action!=MotionEvent.ACTION_CANCEL) pointer=-1;
                else release();
            }
            return true;
        }

        private void updatePress(float x, float y) {
            if (defaultKey==0) {
                int next=ControlGeometry.direction((x-getWidth()/2f)/(getWidth()/2f), (y-getHeight()/2f)/(getHeight()/2f), prefs.getBoolean("diagonal", true));
                int horizontal=(next & ControlGeometry.LEFT)!=0 ? KeyEvent.KEYCODE_DPAD_LEFT :
                        (next & ControlGeometry.RIGHT)!=0 ? KeyEvent.KEYCODE_DPAD_RIGHT : 0;
                int vertical=(next & ControlGeometry.UP)!=0 ? KeyEvent.KEYCODE_DPAD_UP :
                        (next & ControlGeometry.DOWN)!=0 ? KeyEvent.KEYCODE_DPAD_DOWN : 0;
                input.set(id, horizontal, vertical);
                if (next!=direction) { if (direction==0) haptic(); direction=next; pressed=next!=0; invalidate(); }
            } else {
                boolean next=x>=0 && x<getWidth() && y>=0 && y<getHeight();
                send(next);
                if (next!=pressed) { if (next) haptic(); pressed=next; invalidate(); }
            }
        }

        // 6.5: TURBO_KEY holds turbo instead of sending a key.
        private void send(boolean down) {
            int k = key();
            if (k == TURBO_KEY) { input.release(id); holdTurbo(id, down); }
            else { holdTurbo(id, false); input.set(id, down ? k : 0, 0); }
        }

        private void haptic() { if (prefs.getBoolean("haptics", true)) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY); }

        private void release() { holdTurbo(id, false); input.release(id); pointer=-1; direction=0; pressed=false; invalidate(); }
    }

    private static String keyName(int key) {
        for (int i=0; i<KEYS.length; i++) if (KEYS[i]==key) return KEY_NAMES[i];
        return KeyEvent.keyCodeToString(key).replace("KEYCODE_", "");
    }

    private GradientDrawable background(int color, int stroke) {
        GradientDrawable background = new GradientDrawable(); background.setColor(color);
        background.setCornerRadius(dp(9)); background.setStroke(dp(1), stroke); return background;
    }

    private int dp(float value) { return Math.round(value * activity.getResources().getDisplayMetrics().density); }
}
