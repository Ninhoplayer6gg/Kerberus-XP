package com.kerberus.launcher;

import android.app.ActivityManager;
import android.app.ApplicationExitInfo;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;

import java.io.File;
import java.util.List;

/**
 * 6.6.2: why the game process (":runtime") ended, as Android 11+ records it
 * (ApplicationExitInfo), written once as a [SAIDA] line to the report of the
 * game it was running. A kill for lack of memory leaves no other trace.
 */
final class RuntimeExit {
    private static final String PREFS = "kerberus_runtime_exit";

    private RuntimeExit() {}

    static void record(Context context, String gamePath) {
        if (gamePath == null || Build.VERSION.SDK_INT < 30) return;
        File game = new File(gamePath);
        File report = new File(game, RuntimeReport.FILE_NAME);
        if (!report.isFile()) return;
        ActivityManager manager = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        if (manager == null) return;
        List<ApplicationExitInfo> exits;
        try {
            exits = manager.getHistoricalProcessExitReasons(context.getPackageName(), 0, 8);
        } catch (SecurityException | IllegalArgumentException e) {
            RuntimeReport.append(game, "[SAIDA] motivo da saída indisponível: " + e.getMessage());
            return;
        }
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        for (ApplicationExitInfo exit : exits) {
            String process = exit.getProcessName();
            if (process == null || !process.endsWith(":runtime")) continue;
            long time = exit.getTimestamp();
            // Newest first: an exit already handled ends the search.
            if (time <= prefs.getLong("handled", 0L)) return;
            prefs.edit().putLong("handled", time).apply();
            if (RuntimeReport.exitBelongsToReport(report.lastModified(), time))
                RuntimeReport.append(game, RuntimeReport.describeExit(exit.getReason(), exit.getStatus(),
                        exit.getDescription(), exit.getPss(), exit.getRss()));
            return;
        }
    }
}
