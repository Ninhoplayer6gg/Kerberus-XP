package com.kerberus.launcher;

/** Implemented in the loaded mkxp-z library, without accessing Ruby from Java. */
public final class RuntimeMetrics {
    private RuntimeMetrics() {}
    public static native void setEnabled(boolean enabled);
    public static native float framesPerSecond();
    /**
     * 6.5: last second while enabled, or null without a recent sample:
     * updates/s, presented frames/s, speed, logic ms (mean, worst), render ms,
     * worst gap between presented frames ms, Ruby collections, their ms.
     */
    public static native float[] details();
    public static final int UPDATES = 0, PRESENTS = 1, SPEED = 2, LOGIC = 3, LOGIC_MAX = 4,
            RENDER = 5, WORST = 6, GC_RUNS = 7, GC_MS = 8;
}
