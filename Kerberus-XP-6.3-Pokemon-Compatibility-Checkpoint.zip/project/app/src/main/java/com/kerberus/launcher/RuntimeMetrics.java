package com.kerberus.launcher;

/** Implemented in the loaded mkxp-z library, without accessing Ruby from Java. */
public final class RuntimeMetrics {
    private RuntimeMetrics() {}
    public static native void setEnabled(boolean enabled);
    public static native float framesPerSecond();
}
