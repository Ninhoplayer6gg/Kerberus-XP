package com.kerberus.launcher;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Optional per-game runtime options read from ".kerberus-options" in the game
 * folder (same place as ".kerberus-runtime"). Only whitelisted keys/values
 * become environment variables for the engine; anything else is rejected.
 *
 *   wintrace=off|summary|detail   -> KERBERUS_WINTRACE
 *   filesystem=windows|native     -> KERBERUS_FS_COMPAT (native = off)
 *   dump_scripts=on|off           -> KERBERUS_DUMP_SCRIPTS
 *   ports_disable=id1,id2         -> KERBERUS_PORTS_DISABLE
 *   frameskip=on|off              -> KERBERUS_FRAMESKIP (RGSS1 frame skipping, legacy18)
 *   gc_malloc_limit=4..512        -> KERBERUS_GC_MALLOC_LIMIT (MB, Ruby 1.8 GC, legacy18)
 */
public final class RuntimeOptions {
    public static final String FILE_NAME = ".kerberus-options";
    private static final Pattern PORT_LIST = Pattern.compile("[a-z0-9_]{1,40}(,[a-z0-9_]{1,40}){0,15}");

    private RuntimeOptions() {}

    public static Map<String, String> environment(File game) throws IOException {
        Map<String, String> env = new LinkedHashMap<>();
        env.put("KERBERUS_WINTRACE", "summary");
        env.put("KERBERUS_FS_COMPAT", "on");
        env.put("KERBERUS_DUMP_SCRIPTS", "0");
        env.put("KERBERUS_PORTS_DISABLE", "");
        env.put("KERBERUS_FRAMESKIP", "on");
        File file = new File(game, FILE_NAME);
        if (!file.isFile()) return env;
        if (file.length() > 4096) throw new IOException(FILE_NAME + " excede 4 KiB.");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[1024]; int count;
            while ((count = in.read(buffer)) != -1) bytes.write(buffer, 0, count);
        }
        for (String raw : new String(bytes.toByteArray(), StandardCharsets.UTF_8).split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#") || line.startsWith(";")) continue;
            int eq = line.indexOf('=');
            if (eq <= 0) throw new IOException(FILE_NAME + ": linha inválida: " + line);
            String key = line.substring(0, eq).trim().toLowerCase(Locale.ROOT);
            String value = line.substring(eq + 1).trim().toLowerCase(Locale.ROOT);
            switch (key) {
                case "wintrace":
                    if (!value.equals("off") && !value.equals("summary") && !value.equals("detail"))
                        throw new IOException(FILE_NAME + ": wintrace deve ser off, summary ou detail.");
                    env.put("KERBERUS_WINTRACE", value);
                    break;
                case "filesystem":
                    if (!value.equals("windows") && !value.equals("native"))
                        throw new IOException(FILE_NAME + ": filesystem deve ser windows ou native.");
                    env.put("KERBERUS_FS_COMPAT", value.equals("native") ? "off" : "on");
                    break;
                case "dump_scripts":
                    if (!value.equals("on") && !value.equals("off"))
                        throw new IOException(FILE_NAME + ": dump_scripts deve ser on ou off.");
                    env.put("KERBERUS_DUMP_SCRIPTS", value.equals("on") ? "1" : "0");
                    break;
                case "ports_disable":
                    if (!value.isEmpty() && !PORT_LIST.matcher(value).matches())
                        throw new IOException(FILE_NAME + ": ports_disable deve listar ids de ports separados por virgula.");
                    env.put("KERBERUS_PORTS_DISABLE", value);
                    break;
                case "frameskip":
                    if (!value.equals("on") && !value.equals("off"))
                        throw new IOException(FILE_NAME + ": frameskip deve ser on ou off.");
                    env.put("KERBERUS_FRAMESKIP", value);
                    break;
                case "gc_malloc_limit": {
                    int megabytes;
                    try { megabytes = Integer.parseInt(value); } catch (NumberFormatException bad) { megabytes = -1; }
                    if (megabytes < 4 || megabytes > 512)
                        throw new IOException(FILE_NAME + ": gc_malloc_limit deve ser um número de MB entre 4 e 512.");
                    env.put("KERBERUS_GC_MALLOC_LIMIT", Long.toString(megabytes * 1000000L));
                    break;
                }
                default:
                    throw new IOException(FILE_NAME + ": opção desconhecida: " + key);
            }
        }
        return env;
    }
}
