package com.kerberus.launcher;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

/** Local, bounded diagnostic; no game files or logs are sent over the network. */
public final class RuntimeReport {
    public static final String FILE_NAME = "kerberus-runtime.log";
    private static final int DISPLAY_BYTES = 32768;

    private RuntimeReport() {}

    public static void begin(File game) throws IOException {
        try (FileOutputStream out = new FileOutputStream(new File(game, FILE_NAME))) {
            out.write("Kerberus XP 6.4.2 — Pokémon Compatibility Expansion\nInicialização solicitada. Aguardando o núcleo do jogo.\n".getBytes(StandardCharsets.UTF_8));
        }
    }

    public static void boot(File game, String message) {
        String safe = message.replace('\n', ' ').replace('\r', ' ');
        if (safe.length() > 1024) safe = safe.substring(0, 1024);
        try (FileOutputStream out = new FileOutputStream(new File(game, FILE_NAME), true)) {
            out.write(("[BOOT] " + safe + "\n").getBytes(StandardCharsets.UTF_8));
        } catch (IOException ignored) { /* A diagnostic must not prevent startup. */ }
    }

    public static String read(File game) {
        if (game == null || !new File(game, FILE_NAME).isFile()) return "O jogo ainda não foi iniciado. Toque em Jogar após concluir a importação.";
        try (RandomAccessFile input = new RandomAccessFile(new File(game, FILE_NAME), "r")) {
            long length = input.length();
            int size = (int) Math.min(length, DISPLAY_BYTES);
            input.seek(length - size);
            byte[] data = new byte[size];
            input.readFully(data);
            String report = new String(data, StandardCharsets.UTF_8);
            if (length > size) {
                int newline = report.indexOf('\n');
                report = "[Trecho final do relatório]\n" + (newline >= 0 ? report.substring(newline + 1) : report);
            }
            return report;
        } catch (IOException e) {
            return "Não foi possível ler o relatório: " + e.getMessage();
        }
    }
}
