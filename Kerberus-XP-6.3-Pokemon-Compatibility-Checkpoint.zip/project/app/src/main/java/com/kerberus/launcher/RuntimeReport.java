package com.kerberus.launcher;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;

/** Local, bounded diagnostic; no game files or logs are sent over the network. */
public final class RuntimeReport {
    public static final String FILE_NAME = "kerberus-runtime.log";
    private static final int DISPLAY_BYTES = 32768;

    private RuntimeReport() {}

    public static void begin(File game) throws IOException {
        try (FileOutputStream out = new FileOutputStream(new File(game, FILE_NAME))) {
            out.write("Kerberus XP 6.6.2 — Pokémon Compatibility Expansion\nInicialização solicitada. Aguardando o núcleo do jogo.\n".getBytes(StandardCharsets.UTF_8));
        }
    }

    public static void boot(File game, String message) {
        String safe = message.replace('\n', ' ').replace('\r', ' ');
        if (safe.length() > 1024) safe = safe.substring(0, 1024);
        append(game, "[BOOT] " + safe);
    }

    static void append(File game, String line) {
        try (FileOutputStream out = new FileOutputStream(new File(game, FILE_NAME), true)) {
            out.write((line + "\n").getBytes(StandardCharsets.UTF_8));
        } catch (IOException ignored) { /* A diagnostic must not prevent startup. */ }
    }

    /**
     * 6.6.2: an exit reported by Android (ApplicationExitInfo, API 30+) belongs
     * to this report when the game wrote to it shortly before the process ended.
     */
    static boolean exitBelongsToReport(long reportWritten, long exitTime) {
        return reportWritten <= exitTime + 5000L && reportWritten >= exitTime - 10L * 60L * 1000L;
    }

    /** One [SAIDA] line for an ApplicationExitInfo of the game process (sizes in kB). */
    static String describeExit(int reason, int status, String description, long pssKb, long rssKb) {
        String name;
        String meaning;
        switch (reason) {
            case 1: name = "EXIT_SELF"; meaning = status == 0 ? "o jogo encerrou normalmente" : "o próprio jogo encerrou com o código " + status; break;
            case 2: name = "SIGNALED"; meaning = "processo encerrado pelo sinal " + status; break;
            case 3: name = "LOW_MEMORY"; meaning = "o Android encerrou o jogo por falta de memória"; break;
            case 4: name = "CRASH"; meaning = "erro Java no processo do jogo"; break;
            case 5: name = "CRASH_NATIVE"; meaning = "crash nativo (sinal " + status + "); o bloco [CRASH] acima, quando existe, mostra onde"; break;
            case 6: name = "ANR"; meaning = "o jogo parou de responder e o Android o encerrou"; break;
            case 7: name = "INITIALIZATION_FAILURE"; meaning = "falha ao iniciar o processo"; break;
            case 8: name = "PERMISSION_CHANGE"; meaning = "uma permissão do app mudou"; break;
            case 9: name = "EXCESSIVE_RESOURCE_USAGE"; meaning = "o Android encerrou o jogo por uso excessivo de recursos"; break;
            case 10: name = "USER_REQUESTED"; meaning = "encerrado a pedido do usuário"; break;
            case 11: name = "USER_STOPPED"; meaning = "o usuário parou o app"; break;
            case 12: name = "DEPENDENCY_DIED"; meaning = "um processo do qual o jogo dependia terminou"; break;
            case 13: name = "OTHER"; meaning = "encerrado pelo sistema"; break;
            case 14: name = "FREEZER"; meaning = "encerrado pelo congelamento de apps em segundo plano"; break;
            case 15: name = "PACKAGE_STATE_CHANGE"; meaning = "o estado do app mudou"; break;
            case 16: name = "PACKAGE_UPDATED"; meaning = "o app foi atualizado"; break;
            default: name = "UNKNOWN"; meaning = "motivo não informado pelo Android"; break;
        }
        StringBuilder line = new StringBuilder("[SAIDA] processo do jogo: ").append(name).append(" (").append(reason)
                .append(") — ").append(meaning).append("; status=").append(status)
                .append("; memoria pss=").append(pssKb / 1024).append(" MB rss=").append(rssKb / 1024).append(" MB");
        if (description != null && !description.isEmpty()) {
            String safe = description.replace('\n', ' ').replace('\r', ' ');
            line.append("; descricao=").append(safe.length() > 300 ? safe.substring(0, 300) : safe);
        }
        return line.toString();
    }

    public static String read(File game) {
        if (game == null || !new File(game, FILE_NAME).isFile()) return "O jogo ainda não foi iniciado. Toque em Jogar após concluir a importação.";
        try (RandomAccessFile input = new RandomAccessFile(new File(game, FILE_NAME), "r")) {
            long length = input.length();
            int size = (int) Math.min(length, DISPLAY_BYTES);
            input.seek(length - size);
            byte[] data = new byte[size];
            input.readFully(data);
            String report = new String(data, StandardCharsets.UTF_8);
            if (length > size) {
                int newline = report.indexOf('\n');
                report = "[Trecho final do relatório]\n" + (newline >= 0 ? report.substring(newline + 1) : report);
            }
            return report;
        } catch (IOException e) {
            return "Não foi possível ler o relatório: " + e.getMessage();
        }
    }
}
