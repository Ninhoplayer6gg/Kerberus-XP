package com.kerberus.launcher;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.regex.Pattern;

/**
 * Selects the Ruby/engine runtime before SDL loads any native library.
 *
 * Order (first match wins):
 *  1. local override file .kerberus-runtime (legacy18 / modern31);
 *  2. RGSS2/RGSS3 games use the modern runtime;
 *  3. Infinite Fusion is pinned to the modern runtime it was validated on;
 *  4. evidence that the game was built for mkxp-z / Ruby >= 2 (mkxp.json,
 *     a Ruby 2/3 runtime DLL, Essentials v19+ external scripts) -> modern31;
 *  5. every other RPG Maker XP (RGSS1) game -> legacy18 (real Ruby 1.8).
 * Game names only label the reason; they never force legacy18.
 */
public final class RuntimeSelector {
    public static final String OVERRIDE_FILE = ".kerberus-runtime";
    private static final Pattern RUBY_MODERN_DLL = Pattern.compile("(?:x64-)?msvcrt-ruby[23][0-9]{1,2}\\.dll");
    private static final Pattern ESSENTIALS_VERSION = Pattern.compile("^([0-9]+)");

    public enum Runtime {
        LEGACY18("legacy18", "mkxp-z18", "Ruby 1.8 / RGSS1 Legacy"),
        MODERN31("modern31", "mkxp-z31", "Ruby 3.1 / mkxp-z Modern");

        public final String id;
        public final String engineLibrary;
        public final String label;
        Runtime(String id, String engineLibrary, String label) {
            this.id = id;
            this.engineLibrary = engineLibrary;
            this.label = label;
        }

        public static Runtime fromId(String id) {
            if (id == null) return null;
            for (Runtime value : values()) if (value.id.equalsIgnoreCase(id.trim())) return value;
            return null;
        }
    }

    public static final class Selection {
        public final Runtime runtime;
        public final String reason;
        public final boolean overridden;
        Selection(Runtime runtime, String reason, boolean overridden) {
            this.runtime = runtime;
            this.reason = reason;
            this.overridden = overridden;
        }
    }

    private RuntimeSelector() {}

    public static Selection select(File game) throws IOException {
        if (game == null || !game.isDirectory()) throw new IOException("A pasta do jogo não foi encontrada.");

        Runtime forced = readOverride(game);
        if (forced != null)
            return new Selection(forced, "override local " + OVERRIDE_FILE, true);

        GameIni ini = GameIni.find(game);
        if (ini.engine != 1)
            return new Selection(Runtime.MODERN31, "RGSS" + ini.engine + " não usa o runtime legado de XP", false);

        String identity = normalizedIdentity(game);
        // Infinite Fusion is intentionally kept on the already proven modern path.
        if (identity.contains("infinite fusion") || identity.contains("infinitefusion"))
            return new Selection(Runtime.MODERN31, "perfil preservado: Infinite Fusion já validado no runtime moderno", false);

        String modern = modernEvidence(game);
        if (modern != null)
            return new Selection(Runtime.MODERN31, "evidência mkxp-z/Ruby moderno: " + modern, false);

        if (identity.contains("uranium"))
            return new Selection(Runtime.LEGACY18, "RGSS1 legado; perfil prioritário Pokémon Uranium", false);
        if (identity.contains("insurgence"))
            return new Selection(Runtime.LEGACY18, "RGSS1 legado; perfil prioritário Pokémon Insurgence", false);
        if (identity.contains("xenoverse") || identity.contains("xeno verse"))
            return new Selection(Runtime.LEGACY18, "RGSS1 legado; perfil prioritário Pokémon Xenoverse", false);

        return new Selection(Runtime.LEGACY18, "RPG Maker XP/RGSS1: parser e semântica Ruby 1.8 preferidos", false);
    }

    /** Files that only exist in games built for mkxp-z / Ruby >= 2. */
    static String modernEvidence(File game) {
        File config = resolveQuietly(game, "mkxp.json");
        if (config != null && config.isFile()) return "mkxp.json";
        File[] files = game.listFiles();
        if (files != null && files.length <= 4096) {
            for (File file : files) {
                String name = file.getName().toLowerCase(Locale.ROOT);
                if (file.isFile() && RUBY_MODERN_DLL.matcher(name).matches()) return file.getName();
            }
        }
        File scripts = resolveQuietly(game, "Data/Scripts");
        if (scripts != null && scripts.isDirectory()) {
            String[] entries = scripts.list();
            if (entries != null && entries.length > 0 && entries.length <= 4096) {
                for (String entry : entries) {
                    File child = new File(scripts, entry);
                    if (entry.toLowerCase(Locale.ROOT).endsWith(".rb") || (child.isDirectory() && containsRuby(child)))
                        return "scripts externos Data/Scripts (Essentials v19+)";
                }
            }
        }
        try {
            GameIntelligence.Result info = GameIntelligence.inspect(game);
            java.util.regex.Matcher match = ESSENTIALS_VERSION.matcher(info.essentialsVersion);
            if (match.find() && Integer.parseInt(match.group(1)) >= 19)
                return "Pokémon Essentials v" + info.essentialsVersion;
        } catch (IOException | NumberFormatException ignored) {
            // Detection is evidence-based: unreadable metadata is simply no evidence.
        }
        return null;
    }

    private static File resolveQuietly(File game, String relative) {
        try {
            return GameIntelligence.resolve(game, relative);
        } catch (IOException unreadable) {
            return null; // unreadable metadata is no evidence either way
        }
    }

    private static boolean containsRuby(File directory) {
        String[] entries = directory.list();
        if (entries == null || entries.length > 4096) return false;
        for (String entry : entries) if (entry.toLowerCase(Locale.ROOT).endsWith(".rb")) return true;
        return false;
    }

    private static Runtime readOverride(File game) throws IOException {
        File file = new File(game, OVERRIDE_FILE);
        if (!file.isFile()) return null;
        if (file.length() > 64) throw new IOException(OVERRIDE_FILE + " excede o limite de 64 bytes.");
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        try (FileInputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[64]; int count;
            while ((count = in.read(buffer)) != -1) bytes.write(buffer, 0, count);
        }
        Runtime runtime = Runtime.fromId(new String(bytes.toByteArray(), StandardCharsets.UTF_8).trim());
        if (runtime == null)
            throw new IOException(OVERRIDE_FILE + " deve conter legacy18 ou modern31.");
        return runtime;
    }

    private static String normalizedIdentity(File game) {
        StringBuilder text = new StringBuilder(game.getName());
        try {
            GameIntelligence.Result info = GameIntelligence.inspect(game);
            text.append(' ').append(info.title);
        } catch (IOException ignored) { /* GameIni already validated the launch above. */ }
        return text.toString().toLowerCase(Locale.ROOT)
                .replace('é', 'e').replace('ê', 'e').replace('ó', 'o').replace('ô', 'o')
                .replace('á', 'a').replace('ã', 'a').replace('í', 'i').replace('ú', 'u');
    }
}
