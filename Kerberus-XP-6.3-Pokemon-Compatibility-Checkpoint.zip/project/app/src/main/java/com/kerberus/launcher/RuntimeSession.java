package com.kerberus.launcher;

/**
 * 6.5: requests to the running game from the Kerberus menu, served on the
 * game thread at its next frame (kerberus-session.h). Each request gets one
 * text reply from takeReply(): "save:ok", "save:busy:<reason>",
 * "debug:on", "shot:ok:<path>", "shot:error:<message>", ...
 */
public final class RuntimeSession {
    private RuntimeSession() {}
    public static final int SAVE = 1, DEBUG = 2, SHOT = 3;
    /** false when the same request is still waiting for the game. */
    public static native boolean request(int code, int arg, String path);
    public static native String takeReply();
    /** 0 sharp pixels, 1 smooth, 2 sharp + smooth; applied at the next frame. */
    public static native void setFilter(int mode);
}
