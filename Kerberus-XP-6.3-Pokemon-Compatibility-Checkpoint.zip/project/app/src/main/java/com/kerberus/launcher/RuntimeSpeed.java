package com.kerberus.launcher;

/** Turbo of the running game (1, 2 or 3), implemented in the loaded mkxp-z library. */
public final class RuntimeSpeed {
    private RuntimeSpeed() {}
    public static native void setTurbo(int factor);
    /** 6.5: measured speed (1.0 = the game's own rate), or -1 without a recent sample. */
    public static native float effectiveSpeed();
}
