package com.kerberus.launcher;

/** Turbo of the running game (1, 2 or 3), implemented in the loaded mkxp-z library. */
public final class RuntimeSpeed {
    private RuntimeSpeed() {}
    public static native void setTurbo(int factor);
}
