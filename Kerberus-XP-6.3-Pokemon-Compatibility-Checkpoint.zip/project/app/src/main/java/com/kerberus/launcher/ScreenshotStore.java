package com.kerberus.launcher;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * 6.5: a screenshot PNG written by the engine (kerberus-session.h) goes to
 * the gallery, Pictures/Kerberus, through MediaStore (Android 10+, no
 * permission). On Android 6-9 that needs a storage permission the app does
 * not ask for, so the image stays in the app's own Pictures folder and the
 * message says where.
 */
public final class ScreenshotStore {
    private ScreenshotStore() {}

    public static String save(Context context, File png, String gameName) throws IOException {
        if (!png.isFile() || png.length() == 0) throw new IOException("imagem não gerada");
        String safe = gameName.replaceAll("[^A-Za-z0-9_-]+", "_");
        if (safe.length() > 40) safe = safe.substring(0, 40);
        String name = "Kerberus-" + safe + "-" + new SimpleDateFormat("yyyyMMdd-HHmmss", Locale.ROOT).format(new Date()) + ".png";
        if (Build.VERSION.SDK_INT >= 29) {
            ContentResolver resolver = context.getContentResolver();
            ContentValues values = new ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/Kerberus");
            values.put(MediaStore.Images.Media.IS_PENDING, 1);
            Uri uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            if (uri == null) throw new IOException("a galeria recusou a imagem");
            try (OutputStream out = resolver.openOutputStream(uri)) {
                if (out == null) throw new IOException("a galeria não abriu a imagem");
                copy(png, out);
            } catch (IOException | RuntimeException error) {
                resolver.delete(uri, null, null);
                throw error;
            }
            values.clear();
            values.put(MediaStore.Images.Media.IS_PENDING, 0);
            resolver.update(uri, values, null, null);
            return "Captura salva na galeria (Imagens/Kerberus).";
        }
        File dir = new File(context.getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Kerberus");
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("sem acesso à pasta de imagens");
        File target = new File(dir, name);
        try (OutputStream out = new FileOutputStream(target)) { copy(png, out); }
        return "Captura salva em " + target.getAbsolutePath() + " (no Android 9 ou anterior ela não aparece na galeria).";
    }

    private static void copy(File from, OutputStream out) throws IOException {
        try (InputStream in = new FileInputStream(from)) {
            byte[] buffer = new byte[16384]; int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
        }
    }
}
