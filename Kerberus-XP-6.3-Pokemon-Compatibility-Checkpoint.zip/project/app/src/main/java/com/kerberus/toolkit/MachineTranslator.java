package com.kerberus.toolkit;
import org.json.*;
import java.io.*;
import java.net.*;
import javax.net.ssl.HttpsURLConnection;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;
import java.util.concurrent.atomic.AtomicBoolean;

/** Explicit user-started LibreTranslate job. No service/key is bundled. */
public final class MachineTranslator {
    public interface Progress{void update(int done,int total);}
    public static String translate(File dir,String address,String key,AtomicBoolean cancel,Progress progress)throws Exception{
        URL url=new URL(address.trim());
        if(!"https".equals(url.getProtocol())||url.getUserInfo()!=null||url.getQuery()!=null)throw new IOException("Use a URL HTTPS do servidor terminada em /translate, sem chave na URL.");
        JSONObject pack=TranslationPack.withCaptured(dir);JSONArray rows=pack.getJSONArray("entries"),terms=pack.optJSONArray("protected_terms");
        int total=0,done=0,rejected=0;for(int i=0;i<rows.length();i++)if(rows.getJSONObject(i).getString("target").isEmpty())total++;
        total=Math.min(total,50);TranslationPack.save(dir,pack);
        for(int i=0;i<rows.length()&&done+rejected<total&&!cancel.get();i++){
            JSONObject row=rows.getJSONObject(i);if(!row.getString("target").isEmpty())continue;
            String source=row.getString("source");Map<String,String> masks=new LinkedHashMap<>();
            String salt="KRB"+UUID.randomUUID().toString().replace("-","")+"X";
            StringBuffer text=new StringBuffer();Matcher m=TranslationPack.TOKEN.matcher(source);
            while(m.find()){String id=salt+masks.size()+"Z";masks.put(id,m.group());m.appendReplacement(text,id);}m.appendTail(text);
            String query=text.toString();if(terms!=null)for(int t=0;t<terms.length();t++){
                String term=terms.getString(t);if(query.contains(term)){String id=salt+masks.size()+"Z";masks.put(id,term);query=query.replace(term,id);}
            }
            JSONObject body=new JSONObject().put("q",query).put("source","auto").put("target","pt").put("format","text");if(!key.isEmpty())body.put("api_key",key);
            HttpsURLConnection c=(HttpsURLConnection)url.openConnection();
            try{
                c.setInstanceFollowRedirects(false);c.setConnectTimeout(10000);c.setReadTimeout(20000);c.setRequestMethod("POST");c.setDoOutput(true);c.setRequestProperty("Content-Type","application/json; charset=utf-8");
                byte[] bytes=body.toString().getBytes(StandardCharsets.UTF_8);c.setFixedLengthStreamingMode(bytes.length);try(OutputStream out=c.getOutputStream()){out.write(bytes);}
                int status=c.getResponseCode();if(status!=200)throw new IOException("Servidor respondeu HTTP "+status+". Traduções concluídas foram mantidas; confira endereço, limite e chave.");
                String translated;try(InputStream in=c.getInputStream()){translated=new JSONObject(new String(TranslationPack.read(in,131072),StandardCharsets.UTF_8)).getString("translatedText");}
                boolean valid=true;for(Map.Entry<String,String> mask:masks.entrySet()){
                    if(occurrences(translated,mask.getKey())!=occurrences(query,mask.getKey()))valid=false;
                    translated=translated.replace(mask.getKey(),mask.getValue());
                }
                if(valid&&!translated.isEmpty()&&TranslationPack.tokens(source).equals(TranslationPack.tokens(translated))){
                    row.put("target",translated).put("review","machine");
                    try{TranslationPack.validate(pack);done++;}catch(IOException invalid){row.put("target","");rejected++;}
                }else rejected++;
                TranslationPack.save(dir,pack);progress.update(done+rejected,total);
            }finally{c.disconnect();}
        }
        return done+" frases traduzidas; "+rejected+" rejeitadas por alterar os códigos/termos. "+(cancel.get()?"Operação cancelada. ":"")+"Revise o português antes de compartilhar. Execute novamente para continuar.";
    }
    private static int occurrences(String s,String p){int n=0,i=0;while((i=s.indexOf(p,i))>=0){n++;i+=p.length();}return n;}
}
