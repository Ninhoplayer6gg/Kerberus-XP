package com.kerberus.toolkit;
import java.io.*;
import java.util.*;
public final class ResourceAudit {
    private int count,large,audio,video,collisions;private long estimated;
    private final StringBuilder details=new StringBuilder();
    public String scan(File game)throws IOException{walk(game,game,"",0);return "RECURSOS DO JOGO\n"+count+" arquivos analisados\n"+large+" PNGs com dimensão acima de 4096\n"+audio+" arquivos WMA\n"+video+" vídeos AVI/WMV\n"+collisions+" conflitos de maiúsculas/minúsculas\n\n"+details+"\n4096 é um alerta conservador, não uma medição da GPU. Nenhum mapa foi alterado. Arquivos dentro de RGSSAD não são examinados nesta análise.\n";}
    private void walk(File root,File dir,String prefix,int depth)throws IOException{
        if(depth>12)throw new IOException("Pastas profundas demais.");File[] fs=dir.listFiles();if(fs==null)return;Set<String> names=new HashSet<>();
        for(File f:fs){if(++count>100000)throw new IOException("Limite de 100 mil arquivos.");String n=prefix+f.getName();SaveArchive.safe(root,n);
            if(!names.add(f.getName().toLowerCase(Locale.ROOT))){collisions++;add("Conflito: "+n);}
            if(f.isDirectory()){if(!f.getName().startsWith("."))walk(root,f,n+"/",depth+1);continue;}
            String lower=n.toLowerCase(Locale.ROOT);
            if(lower.endsWith(".wma")){audio++;add("Áudio WMA: "+n);}
            if(lower.endsWith(".avi")||lower.endsWith(".wmv")){video++;add("Vídeo Windows: "+n);}
            if(lower.endsWith(".png"))try(DataInputStream in=new DataInputStream(new FileInputStream(f))){
                if(in.readLong()!=0x89504e470d0a1a0aL)continue;
                if(in.readInt()!=13 || in.readInt()!=0x49484452)continue;
                int w=in.readInt(),h=in.readInt();if(w>4096||h>4096){large++;add(w+" × "+h+": "+n);}
            }catch(EOFException e){add("PNG truncado: "+n);}
        }
    }
    private void add(String s){if(details.length()<12000)details.append(s).append('\n');}
}
