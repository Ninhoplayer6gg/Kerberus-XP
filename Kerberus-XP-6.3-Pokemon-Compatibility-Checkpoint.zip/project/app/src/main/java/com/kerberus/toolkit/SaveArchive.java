package com.kerberus.toolkit;
import java.io.*;
import java.util.*;
import java.util.zip.*;

/** Backup of discovered save files only. Restore is staged and rollback protected. */
public final class SaveArchive {
    public static final long MAX=128L*1024*1024;
    private static final int MAX_FILES=512;
    // 6.4.3: saves with the game's own name (Uranium.rxdata, GlobalSettings.rxdata),
    // save folders (Backups/Uranium.rxdata) and the folders the legacy runtime
    // gives as APPDATA/USERPROFILE (.kerberus/appdata, .kerberus/profile).
    private static final List<String> SAVE_DIRS=Arrays.asList("saves","save","backups","backup","savedata","saved games");
    private static final String SAVE_EXT=".+\\.(?:rxdata|rvdata2?|sav|save|dat)(?:\\.bak)?";
    public static boolean saveName(String rel){
        String n=rel.replace('\\','/').toLowerCase(Locale.ROOT);
        if(n.equals("data/lastsave.dat"))return true;
        if(n.startsWith("data/")||n.startsWith("graphics/")||n.startsWith("audio/")||n.startsWith("fonts/"))return false;
        String base=n.substring(n.lastIndexOf('/')+1);
        if(n.startsWith(".kerberus/"))return (n.startsWith(".kerberus/appdata/")||n.startsWith(".kerberus/profile/"))&&base.matches(SAVE_EXT);
        if(n.startsWith(".")||n.contains("/."))return false;
        if(base.matches("(?:game(?:_.*)?|save.*)\\.(?:rxdata|rvdata2?)(?:\\.bak)?") || base.matches(".+\\.(?:sav|save)(?:\\.bak)?"))return true;
        int slash=n.indexOf('/');
        if(slash<0)return base.matches(".+\\.(?:rxdata|rvdata2?)(?:\\.bak)?");
        return SAVE_DIRS.contains(n.substring(0,slash))&&base.matches(SAVE_EXT);
    }
    private static boolean walkInto(String rel){
        String n=rel.toLowerCase(Locale.ROOT),name=n.substring(n.lastIndexOf('/')+1);
        if(n.equals(".kerberus"))return true;
        if(n.startsWith(".kerberus/")&&!n.equals(".kerberus/appdata")&&!n.equals(".kerberus/profile")
           &&!n.startsWith(".kerberus/appdata/")&&!n.startsWith(".kerberus/profile/"))return false;
        return !name.startsWith(".")&&!Arrays.asList("graphics","audio","fonts").contains(name);
    }
    public static File safe(File root,String rel)throws IOException{
        if(rel.isEmpty()||rel.startsWith("/")||rel.contains("\\")||rel.contains(":"))throw new IOException("Caminho de save inválido.");
        for(String p:rel.split("/",-1))if(p.equals("..")||p.equals(".")||p.isEmpty())throw new IOException("Caminho de save inválido.");
        File f=new File(root,rel);
        if(!f.getCanonicalPath().startsWith(root.getCanonicalPath()+File.separator))throw new IOException("Save fora da pasta do jogo.");
        return f;
    }
    public static List<String> discover(File game)throws IOException{
        List<String> result=new ArrayList<>();walk(game,game,"",result,0,new int[]{0});Collections.sort(result);return result;
    }
    private static void walk(File root,File dir,String prefix,List<String> out,int depth,int[] count)throws IOException{
        if(depth>8)return;File[] files=dir.listFiles();if(files==null)return;
        for(File f:files){if(++count[0]>100000)throw new IOException("Muitos arquivos para buscar saves.");String rel=prefix+f.getName();safe(root,rel);
            if(f.isDirectory()){
                if(!walkInto(rel))continue;
                if(rel.equalsIgnoreCase("Data")){File last=new File(f,"LastSave.dat");if(last.isFile())out.add(rel+"/LastSave.dat");continue;}
                walk(root,f,rel+"/",out,depth+1,count);
            }else if(saveName(rel)){out.add(rel);if(out.size()>MAX_FILES)throw new IOException("Muitos saves.");}
        }
    }
    public static int backup(File game,String fingerprint,OutputStream output)throws IOException{
        List<String> names=discover(game);if(names.isEmpty())throw new IOException("Nenhum save reconhecido na pasta do jogo. Salve dentro do jogo primeiro.");
        long total=0;for(String n:names){total+=safe(game,n).length();if(total>MAX)throw new IOException("Saves excedem 128 MiB.");}
        try(ZipOutputStream zip=new ZipOutputStream(output)){
            Properties p=new Properties();p.setProperty("schema","1");p.setProperty("scripts_sha256",fingerprint);
            zip.putNextEntry(new ZipEntry("kerberus-save.properties"));p.store(zip,"Kerberus save archive");zip.closeEntry();
            byte[] buffer=new byte[8192];
            for(String n:names){zip.putNextEntry(new ZipEntry("saves/"+n));try(InputStream in=new FileInputStream(safe(game,n))){int c;while((c=in.read(buffer))!=-1)zip.write(buffer,0,c);}zip.closeEntry();}
        }return names.size();
    }
    public static int restore(File game,String fingerprint,InputStream input,File privateDir)throws IOException{
        File stage=new File(privateDir,"restore-"+UUID.randomUUID());if(!stage.mkdirs())throw new IOException("Sem espaço para preparar restauração.");
        List<String> names=new ArrayList<>(),committed=new ArrayList<>();Set<String> seen=new HashSet<>();Properties metadata=null;long total=0;
        File payload=new File(stage,"new"),old=new File(stage,"old");payload.mkdirs();old.mkdirs();
        try{
            try(ZipInputStream zip=new ZipInputStream(input)){ZipEntry e;byte[] buf=new byte[8192];int count=0;
                while((e=zip.getNextEntry())!=null){if(++count>MAX_FILES+1)throw new IOException("Backup contém entradas demais.");String n=e.getName();if(!seen.add(n.toLowerCase(Locale.ROOT)))throw new IOException("Entrada duplicada.");
                    if(n.equals("kerberus-save.properties")){metadata=new Properties();metadata.load(new ByteArrayInputStream(readLimited(zip,16384)));continue;}
                    if(e.isDirectory()||!n.startsWith("saves/"))throw new IOException("Arquivo não reconhecido no backup.");
                    n=n.substring(6);if(!saveName(n))throw new IOException("Backup contém arquivo que não é save.");
                    File f=safe(payload,n);safe(game,n);f.getParentFile().mkdirs();
                    try(FileOutputStream out=new FileOutputStream(f)){int c;while((c=zip.read(buf))!=-1){total+=c;if(total>MAX)throw new IOException("Backup excede 128 MiB.");out.write(buf,0,c);}out.getFD().sync();}names.add(n);
                }
            }
            if(metadata==null||!"1".equals(metadata.getProperty("schema"))||!fingerprint.equals(metadata.getProperty("scripts_sha256")))throw new IOException("Backup pertence a outro jogo ou versão de scripts. Nada foi substituído.");
            if(names.isEmpty())throw new IOException("Backup vazio.");
            for(String n:names){File target=safe(game,n),previous=safe(old,n);previous.getParentFile().mkdirs();target.getParentFile().mkdirs();
                if(target.exists()&&(!target.isFile()||!target.renameTo(previous)))throw new IOException("Não foi possível preservar o save anterior.");
                committed.add(n);
                if(!safe(payload,n).renameTo(target))throw new IOException("Não foi possível restaurar save.");
            }
            return names.size();
        }catch(IOException error){
            Collections.reverse(committed);boolean failed=false;
            for(String n:committed){File dst=safe(game,n),prev=safe(old,n);if(dst.exists()&&!dst.delete())failed=true;if(prev.isFile()&&!prev.renameTo(dst))failed=true;}
            if(failed){throw new IOException("Restauração interrompida. Cópias anteriores preservadas em "+old.getAbsolutePath(),error);}
            throw error;
        }finally{
            // Keep old bytes after success and failures; recovery is explicit.
            deleteTree(payload);
        }
    }
    private static byte[] readLimited(InputStream in,int max)throws IOException{
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){if(out.size()+n>max)throw new IOException("Arquivo excede o limite de tamanho.");out.write(buf,0,n);}return out.toByteArray();
    }
    private static void deleteTree(File f){File[] c=f.listFiles();if(c!=null)for(File x:c)deleteTree(x);f.delete();}
    private SaveArchive(){}
}
