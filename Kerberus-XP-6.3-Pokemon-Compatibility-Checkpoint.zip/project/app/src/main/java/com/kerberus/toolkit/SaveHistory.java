package com.kerberus.toolkit;
import java.io.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.zip.*;

/**
 * 6.5: automatic copies of the game's saves (the files SaveArchive
 * recognizes), kept in the game folder under .kerberus/save-history, newest
 * KEEP. A copy is made while a session runs, after the game writes its saves
 * and they stop changing, at the start and at the end of the session, and
 * before a copy is restored. A copy with the same contents as the newest one
 * is not made again. Restoring uses SaveArchive.restore (staged, the replaced
 * files preserved) and needs the game closed (SessionLock in the toolkit).
 */
public final class SaveHistory {
    public static final int KEEP = 10;
    public static final String DIR = ".kerberus/save-history";
    private static final String PREFIX = "saves-", SUFFIX = ".zip";

    public static final class Entry {
        public final File file; public final long time; public final int count;
        public final String fingerprint, digest, reason;
        Entry(File file, long time, int count, String fingerprint, String digest, String reason) {
            this.file = file; this.time = time; this.count = count;
            this.fingerprint = fingerprint; this.digest = digest; this.reason = reason;
        }
    }

    public static File directory(File game) { return new File(game, DIR); }

    /** Cheap change detector: names, sizes and modification times of the saves. */
    public static String signature(File game) throws IOException {
        StringBuilder out = new StringBuilder();
        for (String name : SaveArchive.discover(game)) {
            File file = SaveArchive.safe(game, name);
            out.append(name).append('|').append(file.length()).append('|').append(file.lastModified()).append('\n');
        }
        return out.toString();
    }

    /** SHA-256 over every save's name and bytes. */
    public static String digest(File game) throws IOException {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] buffer = new byte[8192];
            for (String name : SaveArchive.discover(game)) {
                md.update(name.getBytes("UTF-8")); md.update((byte) 0);
                try (InputStream in = new FileInputStream(SaveArchive.safe(game, name))) {
                    int n; while ((n = in.read(buffer)) != -1) md.update(buffer, 0, n);
                }
                md.update((byte) 0);
            }
            StringBuilder hex = new StringBuilder();
            for (byte b : md.digest()) hex.append(String.format(Locale.ROOT, "%02x", b & 255));
            return hex.toString();
        } catch (NoSuchAlgorithmException error) { throw new IOException(error); }
    }

    /** Copies the current saves; null when there are none or the newest copy has the same contents. */
    public static synchronized Entry capture(File game, String fingerprint, String reason) throws IOException {
        if (SaveArchive.discover(game).isEmpty()) return null;
        String digest = digest(game);
        List<Entry> entries = list(game);
        if (!entries.isEmpty() && digest.equals(entries.get(0).digest)) return null;
        File dir = directory(game);
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Não foi possível criar " + DIR);
        long now = System.currentTimeMillis();
        if (!entries.isEmpty() && now <= entries.get(0).time) now = entries.get(0).time + 1;
        String stamp = new SimpleDateFormat("yyyyMMdd-HHmmss-SSS", Locale.ROOT).format(new Date(now));
        File target = new File(dir, PREFIX + stamp + SUFFIX), temp = new File(dir, PREFIX + stamp + ".tmp");
        Map<String, String> extra = new HashMap<>();
        extra.put("content_sha256", digest);
        extra.put("created", Long.toString(now));
        extra.put("reason", reason == null ? "" : reason);
        int count;
        try (FileOutputStream out = new FileOutputStream(temp)) {
            // the zip writer closes its stream; the file stays open for the sync
            count = SaveArchive.backup(game, fingerprint, new FilterOutputStream(out) {
                @Override public void write(byte[] b, int off, int len) throws IOException { out.write(b, off, len); }
                @Override public void close() throws IOException { flush(); }
            }, extra);
            out.getFD().sync();
        } catch (IOException error) {
            temp.delete();
            throw error;
        }
        if (!temp.renameTo(target)) { temp.delete(); throw new IOException("Não foi possível gravar a cópia do save."); }
        prune(game);
        return new Entry(target, now, count, fingerprint, digest, extra.get("reason"));
    }

    /** Newest first; unreadable files are left out (and kept on disk). */
    public static List<Entry> list(File game) {
        List<Entry> entries = new ArrayList<>();
        File[] files = directory(game).listFiles();
        if (files == null) return entries;
        for (File file : files) {
            String name = file.getName();
            if (!file.isFile() || !name.startsWith(PREFIX) || !name.endsWith(SUFFIX)) continue;
            try (ZipFile zip = new ZipFile(file)) {
                ZipEntry meta = zip.getEntry("kerberus-save.properties");
                if (meta == null) continue;
                Properties p = new Properties();
                try (InputStream in = zip.getInputStream(meta)) { p.load(in); }
                int count = 0;
                for (Enumeration<? extends ZipEntry> e = zip.entries(); e.hasMoreElements();)
                    if (e.nextElement().getName().startsWith("saves/")) count++;
                long time;
                try { time = Long.parseLong(p.getProperty("created", "")); } catch (NumberFormatException bad) { time = file.lastModified(); }
                entries.add(new Entry(file, time, count, p.getProperty("scripts_sha256", ""),
                        p.getProperty("content_sha256", ""), p.getProperty("reason", "")));
            } catch (IOException unreadable) {
                // a partly written or damaged copy is not offered for restore
            }
        }
        Collections.sort(entries, (a, b) -> Long.compare(b.time, a.time));
        return entries;
    }

    private static void prune(File game) {
        List<Entry> entries = list(game);
        for (int i = KEEP; i < entries.size(); i++) entries.get(i).file.delete();
        File[] files = directory(game).listFiles();
        if (files != null) for (File f : files) if (f.getName().endsWith(".tmp")) f.delete();
    }

    /** Restores a copy; the current saves are copied first, so the restore can be undone. */
    public static int restore(File game, Entry entry, String currentFingerprint, File privateDir) throws IOException {
        File held = new File(privateDir, "history-restore-" + UUID.randomUUID() + SUFFIX);
        copy(entry.file, held);
        try {
            capture(game, currentFingerprint, "antes de restaurar");
            try (InputStream in = new FileInputStream(held)) {
                return SaveArchive.restore(game, entry.fingerprint, in, privateDir);
            }
        } finally {
            held.delete();
        }
    }

    private static void copy(File from, File to) throws IOException {
        try (InputStream in = new FileInputStream(from); OutputStream out = new FileOutputStream(to)) {
            byte[] buffer = new byte[8192]; int n; long total = 0;
            while ((n = in.read(buffer)) != -1) {
                total += n; if (total > SaveArchive.MAX) throw new IOException("Cópia excede 128 MiB.");
                out.write(buffer, 0, n);
            }
        }
    }

    private SaveHistory() {}
}
