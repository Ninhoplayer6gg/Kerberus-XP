package com.kerberus.toolkit;
import java.io.File;
import java.io.IOException;

/**
 * 6.5 save history during a game session (SaveHistory): runs on its own
 * low-priority thread; every PERIOD_S seconds the saves' signature is
 * compared and a change that holds for one more check (the game finished
 * writing) is copied. Also at the start, when the session pauses and ends.
 */
public final class SaveHistoryWatcher {
    public interface Log { void line(String text); }
    private static final int FIRST_S = 20, PERIOD_S = 10;
    private final File game; private final Log log;
    private final java.util.concurrent.ScheduledExecutorService executor;
    private String seen, saved, fingerprint;
    private boolean failed;

    public SaveHistoryWatcher(File game, Log log) {
        this.game = game; this.log = log;
        executor = java.util.concurrent.Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(() -> { android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND); r.run(); }, "KerberusSaveHistory");
            t.setDaemon(true); return t;
        });
    }

    public void start() {
        executor.scheduleWithFixedDelay(this::tick, FIRST_S, PERIOD_S, java.util.concurrent.TimeUnit.SECONDS);
    }

    /** The session is going to the background: copy a change at once. */
    public void flushSoon() { if (!executor.isShutdown()) executor.execute(() -> check(true, "sessão pausada")); }

    /** End of the session: copy a change, waiting up to two seconds. */
    public void stop() {
        if (executor.isShutdown()) return;
        executor.execute(() -> check(true, "fim da sessão"));
        executor.shutdown();
        try { executor.awaitTermination(2, java.util.concurrent.TimeUnit.SECONDS); }
        catch (InterruptedException interrupted) { Thread.currentThread().interrupt(); }
    }

    private void tick() { check(false, saved == null ? "início da sessão" : "o jogo salvou"); }

    private void check(boolean now, String reason) {
        if (failed) return;
        try {
            String signature = SaveHistory.signature(game);
            if (!now && !signature.equals(seen)) { seen = signature; return; }
            seen = signature;
            if (signature.equals(saved) || signature.isEmpty()) { saved = signature; return; }
            if (fingerprint == null) fingerprint = fingerprintOf(game);
            SaveHistory.Entry entry = SaveHistory.capture(game, fingerprint, reason);
            saved = signature;
            if (entry != null) log.line("Histórico de saves: cópia de " + entry.count + " arquivo(s) (" + reason + ")");
        } catch (IOException | RuntimeException error) {
            failed = true;
            log.line("Histórico de saves desativado nesta sessão: " + error.getMessage());
        }
    }

    /** Scripts fingerprint when the game's scripts can be read (RGSS1), else "pasta". */
    public static String fingerprintOf(File game) {
        try { return com.kerberus.x.compat.ScriptPackReader.fingerprint(game); }
        catch (IOException | RuntimeException unavailable) { return "pasta"; }
    }
}
