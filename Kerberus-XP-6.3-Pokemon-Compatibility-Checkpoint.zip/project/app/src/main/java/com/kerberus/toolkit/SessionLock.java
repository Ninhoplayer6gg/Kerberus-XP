package com.kerberus.toolkit;
import java.io.*;
import java.nio.channels.*;
/** OS releases the lock even if Android kills the runtime. */
public final class SessionLock implements Closeable {
    private static final String LOCK_NAME="kerberus-session.lock";
    private final RandomAccessFile file;private final FileLock lock;
    private SessionLock(RandomAccessFile f,FileLock l){file=f;lock=l;}
    public static SessionLock acquire(File game)throws IOException{
        RandomAccessFile f=new RandomAccessFile(new File(game,LOCK_NAME),"rw");
        try{FileLock l=f.getChannel().tryLock();if(l==null)throw new IOException("O jogo está aberto. Encerre a sessão para usar as ferramentas.");return new SessionLock(f,l);}
        catch(IOException|OverlappingFileLockException e){f.close();throw new IOException("O jogo está aberto ou a pasta está indisponível.",e);}
    }
    /** True while another runtime/toolkit process owns the per-game lock. */
    public static boolean isLocked(File game)throws IOException{
        if(game==null||!game.isDirectory())return false;
        File marker=new File(game,LOCK_NAME);
        if(!marker.exists())return false;
        try(RandomAccessFile f=new RandomAccessFile(marker,"rw")){
            try{
                FileLock probe=f.getChannel().tryLock();
                if(probe==null)return true;
                probe.release();
                return false;
            }catch(OverlappingFileLockException busy){return true;}
        }
    }
    public void close()throws IOException{try{if(lock.isValid())lock.release();}finally{file.close();}}
}
