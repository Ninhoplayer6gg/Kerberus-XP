package com.kerberus.toolkit;
import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import com.kerberus.launcher.*;
import com.kerberus.x.compat.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.*;

public final class ToolkitActivity extends Activity {
    private final java.util.List<View> interactions=new java.util.ArrayList<>();
    private File game,dir;private LinearLayout root;private TextView result;private ProgressBar progress;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();private volatile boolean busy;
    private final AtomicBoolean cancel=new AtomicBoolean();private SessionLock gate;
    private static final int IMPORT=6201,EXPORT=6202,BACKUP=6203,RESTORE=6204,REPORT=6205;
    public static final String EXTRA_ACTION="kerberus_toolkit_action";
    private final String[] stages={"Novo jogo e personagem","Primeira batalha e captura","Salvar e carregar após reiniciar","PC, equipe, itens e evolução","Mapas, cavernas e efeitos","Sessão de 60 minutos sem falha","Última batalha e créditos","Pós-jogo"};
    @Override public void onCreate(Bundle state){super.onCreate(state);
        try{String path=getIntent().getStringExtra("kerberus_game_path");if(path==null)throw new IOException("Nenhum jogo selecionado.");game=new File(path);dir=ToolkitStore.directory(this,game);gate=SessionLock.acquire(game);}
        catch(IOException e){new AlertDialog.Builder(this).setMessage(e.getMessage()).setPositiveButton("Voltar",(d,w)->finish()).setOnCancelListener(d->finish()).show();return;}
        draw();
        // 6.4.3: the library's Files dialog opens a save action directly.
        String action=state==null?getIntent().getStringExtra(EXTRA_ACTION):null;
        if("backup".equals(action))exportSaves();else if("restore".equals(action))confirmRestore();else if("history".equals(action))showHistory();
    }
    private void exportSaves(){create(BACKUP,"application/zip","Kerberus-Saves.zip");}
    private void confirmRestore(){new AlertDialog.Builder(this).setTitle("Restaurar progresso?").setMessage("Os saves reconhecidos serão substituídos pelos do backup. Uma cópia local dos anteriores será preservada.").setNegativeButton("Cancelar",null).setPositiveButton("Escolher backup",(d,w)->pick(RESTORE,"application/zip")).show();}
    private void draw(){
        ScrollView scroll=new ScrollView(this);scroll.setBackgroundColor(Color.rgb(9,13,20));root=new LinearLayout(this);root.setOrientation(1);root.setPadding(dp(20),dp(24),dp(20),dp(24));scroll.addView(root);setContentView(scroll);
        label("KERBERUS  /  FERRAMENTAS",12,0xffffb44a);label("Prepare sua aventura",27,Color.WHITE);label(game.getName(),14,0xffadb8ca);
        progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setIndeterminate(true);progress.setVisibility(View.GONE);root.addView(progress);
        result=label("Configurações e pacotes são independentes para cada jogo.",14,0xffc3cbd7);result.setTextIsSelectable(true);
        section("01   Compatibilidade");
        button("Selecionar perfil de execução",()->new AlertDialog.Builder(this).setTitle("Perfil deste jogo").setItems(new String[]{"Automático — recomendado","Moderno / preservar scripts","RGSS1 clássico","Pokémon Uranium","Pokémon Insurgence","Pokémon Xenoverse"},(d,n)->job(()->{ToolkitStore.set(dir,"profile",ToolkitStore.PROFILES[n]);return "Perfil: "+ToolkitStore.PROFILES[n]+". Aplicado ao abrir o jogo.";})).show());
        button("Analisar scripts e APIs",()->job(()->CompatibilityService.analyze(this,game)));
        button("Analisar imagens, áudio e vídeos",()->job(()->new ResourceAudit().scan(game)));
        section("02   Tradução para português");
        label("Capture falas durante o jogo, traduza e aplique um pacote. Golpes, Pokémon e itens não são coletados pelo tradutor de nomes. Pacotes podem incluir termos protegidos.",14,0xffadb8ca);
        toggle("Ativar tradução por pacote","translation");toggle("Capturar falas ainda sem tradução","capture");
        button("Editar uma frase / tradução",this::editPhrase);
        button("Importar pacote PT-BR",()->pick(IMPORT,"application/json"));
        button("Exportar pacote + falas capturadas",()->create(EXPORT,"application/json","Kerberus-PTBR.json"));
        button("Tradução automática pelo meu servidor",this::machineDialog);
        section("03   Proteja seu progresso");
        label("Use o menu Salvar dentro do jogo. Backups incluem os saves reconhecidos na pasta importada. A restauração exige a mesma versão de scripts. Enquanto você joga, o Kerberus guarda as últimas "+SaveHistory.KEEP+" versões dos saves no histórico automático.",14,0xffadb8ca);
        button("Ver saves encontrados",()->job(()->String.join("\n",SaveArchive.discover(game))));
        button("Exportar backup de saves",this::exportSaves);
        button("Restaurar backup",this::confirmRestore);
        button("Histórico automático de saves",this::showHistory);
        section("04   Teste da campanha");
        label("Marque apenas o que você jogou e verificou. Abertura da tela inicial não confirma a campanha completa.",14,0xffadb8ca);
        for(int i=0;i<stages.length;i++)toggle(stages[i],"stage."+i);
        button("Exportar relatório de teste",()->create(REPORT,"text/plain","Kerberus-Teste.txt"));
        button("Voltar à biblioteca",this::finish);
    }
    private void machineDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(20),0,dp(20),0);
        EditText url=new EditText(this);url.setHint("https://seu-servidor/translate");url.setInputType(17);box.addView(url);
        EditText key=new EditText(this);key.setHint("Chave da API, se exigida");key.setInputType(129);box.addView(key);
        TextView help=new TextView(this);help.setText("Envia até 50 falas pendentes ao servidor LibreTranslate que você informar. O serviço pode exigir conta ou cobrança. A chave não será salva. Os códigos das falas serão conferidos antes de aplicar.");box.addView(help);
        new AlertDialog.Builder(this).setTitle("Tradução automática").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Traduzir 50 falas",(d,w)->{
            String address=url.getText().toString(),secret=key.getText().toString();cancel.set(false);
            job(()->MachineTranslator.translate(dir,address,secret,cancel,(n,t)->runOnUiThread(()->result.setText("Traduzindo "+n+" / "+t+". Voltar cancela após a solicitação atual."))));
        }).show();
    }
    private void editPhrase(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(1);box.setPadding(dp(20),0,dp(20),0);
        EditText original=new EditText(this),translated=new EditText(this);original.setHint("Frase original completa");translated.setHint("Tradução PT-BR (mantenha os códigos)");box.addView(original);box.addView(translated);
        new AlertDialog.Builder(this).setTitle("Adicionar ou corrigir frase").setView(box).setNegativeButton("Cancelar",null).setPositiveButton("Salvar",(d,w)->{
            String a=original.getText().toString(),b=translated.getText().toString();
            job(()->{JSONObject p=TranslationPack.withCaptured(dir);JSONArray rows=p.getJSONArray("entries");boolean found=false;
                for(int i=0;i<rows.length();i++)if(rows.getJSONObject(i).getString("source").equals(a)){rows.getJSONObject(i).put("target",b).put("review","human");found=true;break;}
                if(!found)rows.put(new JSONObject().put("source",a).put("target",b).put("kind","dialogue").put("review","human"));
                TranslationPack.save(dir,p);return "Frase salva. Reabra o jogo para aplicar.";});
        }).show();
    }
    private interface Work {String run()throws Exception;}
    private void job(Work task){if(busy)return;busy=true;for(View v:interactions)v.setEnabled(false);progress.setVisibility(View.VISIBLE);result.setText("Trabalhando…");worker.execute(()->{
        String text;try{text=task.run();if(text.isEmpty())text="Nenhum resultado encontrado.";}catch(Exception e){text="Não foi possível concluir: "+e.getMessage();}
        final String msg=text;runOnUiThread(()->{busy=false;if(isFinishing()||isDestroyed())return;progress.setVisibility(View.GONE);for(View v:interactions)v.setEnabled(true);result.setText(msg);});
    });}
    private void toggle(String title,String key){CheckBox c=new CheckBox(this);c.setText(title);c.setTextColor(Color.WHITE);try{c.setChecked(ToolkitStore.on(dir,key).equals("1"));}catch(IOException ignored){}
        c.setOnCheckedChangeListener((v,on)->{if(busy)return;job(()->{ToolkitStore.set(dir,key,Boolean.toString(on));return "Preferência salva.";});});root.addView(c);interactions.add(c);}
    private void pick(int code,String mime){if(busy)return;startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime),code);}
    private void create(int code,String mime,String name){if(busy)return;startActivityForResult(new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(mime).putExtra(Intent.EXTRA_TITLE,name),code);}
    @Override protected void onActivityResult(int code,int status,Intent data){super.onActivityResult(code,status,data);if(status!=RESULT_OK||data==null||data.getData()==null)return;Uri uri=data.getData();
        job(()->{
            if(code==IMPORT){try(InputStream in=getContentResolver().openInputStream(uri)){TranslationPack.save(dir,TranslationPack.parse(TranslationPack.read(in,TranslationPack.LIMIT)));}return "Pacote validado e importado. Ative a tradução e reabra o jogo.";}
            if(code==RESTORE){try(InputStream in=getContentResolver().openInputStream(uri)){return SaveArchive.restore(game,fingerprint(),in,dir)+" saves restaurados. Cópias anteriores preservadas.";}}
            if(code==BACKUP){String digest=fingerprint();if(SaveArchive.discover(game).isEmpty())throw new IOException("Nenhum save reconhecido.");try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){return SaveArchive.backup(game,digest,out)+" saves exportados.";}}
            byte[] bytes;if(code==EXPORT)bytes=TranslationPack.withCaptured(dir).toString(2).getBytes(StandardCharsets.UTF_8);
            else bytes=report().getBytes(StandardCharsets.UTF_8);
            try(OutputStream out=getContentResolver().openOutputStream(uri,"wt")){out.write(bytes);}return "Arquivo exportado.";
        });
    }
    private String fingerprint()throws IOException{return ScriptPackReader.fingerprint(game);}
    // 6.5: copies made while playing (SaveHistory); restoring copies the current saves first.
    private void showHistory(){job(()->{List<SaveHistory.Entry> list=SaveHistory.list(game);
        if(list.isEmpty())return "Nenhuma cópia automática ainda. Enquanto você joga, o Kerberus copia os saves sempre que o jogo salva e guarda as últimas "+SaveHistory.KEEP+".";
        runOnUiThread(()->{if(!isFinishing())pickHistory(list);});return list.size()+" cópia(s) automática(s) no histórico.";});}
    private void pickHistory(List<SaveHistory.Entry> list){
        java.text.DateFormat format=java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT,java.text.DateFormat.MEDIUM);String[] items=new String[list.size()];
        for(int i=0;i<items.length;i++){SaveHistory.Entry e=list.get(i);items[i]=format.format(new Date(e.time))+" · "+e.count+" arquivo(s)"+(e.reason.isEmpty()?"":" · "+e.reason);}
        new AlertDialog.Builder(this).setTitle("Histórico de saves").setItems(items,(d,i)->confirmHistory(list.get(i))).setNegativeButton("Fechar",null).show();}
    private void confirmHistory(SaveHistory.Entry entry){new AlertDialog.Builder(this).setTitle("Restaurar esta cópia?").setMessage("Os saves atuais entram no histórico antes, então dá para desfazer escolhendo a cópia \"antes de restaurar\".").setNegativeButton("Cancelar",null)
        .setPositiveButton("Restaurar",(d,w)->job(()->SaveHistory.restore(game,entry,SaveHistoryWatcher.fingerprintOf(game),dir)+" saves restaurados. Os anteriores ficaram no histórico.")).show();}
    private String report()throws IOException{
        Properties p=ToolkitStore.read(dir);StringBuilder out=new StringBuilder("KERBERUS XP 6.0 DEV1\nJogo: "+game.getName()+"\nScripts SHA-256: "+fingerprint()+"\nPerfil: "+ToolkitStore.profile(dir)+"\n\nETAPAS INFORMADAS PELO JOGADOR\n");
        for(int i=0;i<stages.length;i++)out.append(p.getProperty("stage."+i,"false").equals("true")?"[feito] ":"[pendente] ").append(stages[i]).append('\n');
        out.append("\n").append(CompatibilityService.cached(this,game)).append("\nEVENTOS\n").append(CompatibilityService.events(this,game));
        out.append("\nÚLTIMA SESSÃO\n").append(com.kerberus.launcher.RuntimeReport.read(game));return out.toString();
    }
    private void section(String s){TextView v=label(s,18,0xffffb44a);v.setPadding(0,dp(28),0,dp(8));}
    private TextView label(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,dp(5),0,dp(9));if(size>=18)t.setTypeface(null,Typeface.BOLD);root.addView(t);return t;}
    private void button(String s,Runnable action){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setMinHeight(dp(52));GradientDrawable bg=new GradientDrawable();bg.setColor(0xff182231);bg.setCornerRadius(dp(14));bg.setStroke(dp(1),0xff304055);b.setBackground(bg);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));root.addView(b,lp);interactions.add(b);b.setOnClickListener(v->{if(!busy)action.run();});}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    @Override public void onBackPressed(){if(busy){cancel.set(true);Toast.makeText(this,"Cancelando após a tarefa atual…",Toast.LENGTH_SHORT).show();return;}super.onBackPressed();}
    @Override protected void onDestroy(){cancel.set(true);worker.shutdown();if(gate!=null){final SessionLock old=gate;new Thread(()->{try{while(!worker.awaitTermination(30,TimeUnit.SECONDS)){}old.close();}catch(Exception ignored){}},"KerberusToolsClose").start();}super.onDestroy();}
}
