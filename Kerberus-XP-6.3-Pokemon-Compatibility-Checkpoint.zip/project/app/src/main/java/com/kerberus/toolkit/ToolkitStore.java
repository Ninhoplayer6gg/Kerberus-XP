package com.kerberus.toolkit;
import android.content.Context;
import com.kerberus.launcher.GameIdentity;
import com.kerberus.x.shared.AtomicProperties;
import java.io.*;
import java.util.*;

public final class ToolkitStore {
    public static final String[] PROFILES={"auto","modern","classic","uranium","insurgence","xenoverse"};
    public static File directory(Context c, File game) throws IOException {
        String root=new File(c.getFilesDir(),"games").getCanonicalPath()+File.separator;
        if(!game.isDirectory() || !game.getCanonicalPath().startsWith(root)) throw new IOException("Selecione um jogo importado.");
        File dir=new File(c.getFilesDir(),"toolkit/"+GameIdentity.of(game));
        if(!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Não foi possível preparar as ferramentas.");
        return dir;
    }
    public static Properties read(File dir) throws IOException {return AtomicProperties.read(new File(dir,"settings.properties"));}
    public static void set(File dir,String key,String value) throws IOException {
        Properties p=read(dir);p.setProperty(key,value);AtomicProperties.write(new File(dir,"settings.properties"),p);
    }
    public static String profile(File dir) throws IOException {
        String p=read(dir).getProperty("profile","auto");
        return Arrays.asList(PROFILES).contains(p)?p:"auto";
    }
    public static String on(File dir,String key) throws IOException {return read(dir).getProperty(key,"false").equals("true")?"1":"0";}
    private ToolkitStore(){}
}
