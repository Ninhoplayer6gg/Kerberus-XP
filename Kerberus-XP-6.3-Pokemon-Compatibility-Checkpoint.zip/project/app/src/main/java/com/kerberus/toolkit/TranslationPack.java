package com.kerberus.toolkit;
import org.json.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.regex.*;

/** Versioned data-only packs. A failed import never replaces the current pack. */
public final class TranslationPack {
    public static final int LIMIT=8*1024*1024;
    public static final Pattern TOKEN=Pattern.compile("\\\\(?:[A-Za-z]+(?:\\[[^\\]\\r\\n]*\\])?|[.!|^><$\\\\])|\\{\\d+\\}|%(?:\\d+\\$)?[-+0-9.]*[sdif]|<\\/?[A-Za-z][^>]*>|\\r?\\n");
    public static List<String> tokens(String text){List<String> v=new ArrayList<>();Matcher m=TOKEN.matcher(text);while(m.find())v.add(m.group());return v;}
    public static byte[] read(InputStream in,int max)throws IOException{
        ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] buf=new byte[8192];int n;
        while((n=in.read(buf))!=-1){if(out.size()+n>max)throw new IOException("Arquivo excede o limite de tamanho.");out.write(buf,0,n);}return out.toByteArray();
    }
    public static JSONObject empty()throws JSONException{
        return new JSONObject().put("schema",1).put("language","pt-BR").put("protected_terms",new JSONArray()).put("entries",new JSONArray());
    }
    public static JSONObject parse(byte[] raw)throws IOException{
        if(raw.length>LIMIT)throw new IOException("Pacote maior que 8 MiB.");
        try{
            String text=StandardCharsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(raw)).toString();
            JSONObject p=new JSONObject(text);validate(p);return p;
        }catch(JSONException|java.nio.charset.CharacterCodingException e){throw new IOException("Pacote JSON UTF-8 inválido: "+e.getMessage(),e);}
    }
    public static void validate(JSONObject p)throws IOException,JSONException{
        if(p.getInt("schema")!=1 || !p.getString("language").equals("pt-BR"))throw new IOException("Formato: schema 1 e language pt-BR.");
        JSONArray entries=p.getJSONArray("entries"),terms=p.optJSONArray("protected_terms");
        if(entries.length()>20000)throw new IOException("Limite de 20.000 frases.");
        if(terms!=null && terms.length()>5000)throw new IOException("Glossário grande demais.");
        Set<String> seen=new HashSet<>();
        for(int i=0;i<entries.length();i++){
            JSONObject row=entries.getJSONObject(i);
            if(!(row.get("source") instanceof String)||!(row.get("target") instanceof String))throw new IOException("Frases devem ser textos.");
            String a=row.getString("source"),b=row.getString("target"),kind=row.getString("kind");
            if(!kind.equals("dialogue")&&!kind.equals("ui"))throw new IOException("Use dialogue ou ui. Golpes e nomes de gameplay ficam em inglês.");
            if(a.isEmpty()||a.getBytes(StandardCharsets.UTF_8).length>16384||b.getBytes(StandardCharsets.UTF_8).length>16384||!seen.add(a))throw new IOException("Frase vazia, duplicada ou grande demais.");
            if(!b.isEmpty()&&!tokens(a).equals(tokens(b)))throw new IOException("Os códigos e quebras de linha da frase "+(i+1)+" foram alterados.");
            if(terms!=null)for(int j=0;j<terms.length();j++){
                String t=terms.getString(j);if(t.isEmpty()||t.length()>120)throw new IOException("Termo protegido inválido.");
                if(!b.isEmpty()&&occurrences(a,t)!=occurrences(b,t))throw new IOException("Termo protegido alterado: "+t);
            }
        }
    }
    private static int occurrences(String s,String p){int n=0,i=0;while((i=s.indexOf(p,i))>=0){n++;i+=p.length();}return n;}
    public static JSONObject load(File dir)throws IOException{
        File f=new File(dir,"pt-BR.json");
        try{if(!f.isFile())return empty();try(InputStream in=new FileInputStream(f)){return parse(read(in,LIMIT));}}
        catch(JSONException e){throw new IOException(e);}
    }
    public static void save(File dir,JSONObject pack)throws IOException{
        try{validate(pack);byte[] data=pack.toString(2).getBytes(StandardCharsets.UTF_8);if(data.length>LIMIT)throw new IOException("Pacote maior que 8 MiB.");
            File f=new File(dir,"pt-BR.json"),tmp=File.createTempFile("translation-",".tmp",dir);
            try{try(FileOutputStream out=new FileOutputStream(tmp)){out.write(data);out.getFD().sync();}
                if(!tmp.renameTo(f))throw new IOException("Não foi possível gravar. Pacote anterior preservado.");
            }finally{tmp.delete();}
        }catch(JSONException e){throw new IOException(e);}
    }
    public static JSONObject withCaptured(File dir)throws IOException{
        JSONObject pack=load(dir);File f=new File(dir,"captured.jsonl");
        try{
            JSONArray entries=pack.getJSONArray("entries");Set<String> seen=new HashSet<>();
            for(int i=0;i<entries.length();i++)seen.add(entries.getJSONObject(i).getString("source"));
            if(f.isFile())try(InputStream in=new FileInputStream(f)){
                String text=new String(read(in,LIMIT),StandardCharsets.UTF_8);
                for(String line:text.split("\n")){if(line.trim().isEmpty())continue;
                    JSONObject row;try{row=new JSONObject(line);}catch(JSONException truncated){continue;}
                    String src=row.getString("source");if(seen.add(src)&&entries.length()<20000)entries.put(row);
                }
            }validate(pack);return pack;
        }catch(JSONException e){throw new IOException("Catálogo de falas inválido.",e);}
    }
    private TranslationPack(){}
}
