package com.kerberus.x.compat;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.util.*;
import java.util.regex.*;

/** Audits every decoded section. Exact content hashes use the complete offline
 * Ripper audit, including indirect factories. Unknown contents are labelled
 * preliminary, never advertised as a complete or confirmed compatibility score. */
public final class CompatibilityAnalyzer {
    public static final class Api {
        public final String name,kind,detail;
        Api(String name,String kind,String detail) { this.name=name; this.kind=kind; this.detail=detail; }
    }
    public static final class Result {
        public final Map<String,Api> apis=new TreeMap<>();
        public int scripts,audited,preliminary,unresolved;
        public boolean uraniumLinker,uraniumAudio,insurgenceRenderer,insurgenceMarker,xenoverseMarker;
        public String profile() { return uraniumLinker && uraniumAudio ? "Pokémon Uranium" : insurgenceRenderer && insurgenceMarker ? "Pokémon Insurgence" : xenoverseMarker ? "Pokémon Xenoverse" : "Não identificado"; }
        public String report() {
            int supported=0,profile=0,fallback=0,missing=0,unknown=0;
            for(Api api:apis.values()) {
                if(api.kind.equals("equivalent")) supported++;
                else if(api.kind.equals("profile")) profile++;
                else if(api.kind.equals("fallback")) fallback++;
                else if(api.kind.equals("unavailable")) missing++;
                else unknown++;
            }
            StringBuilder out=new StringBuilder("ANÁLISE ESTÁTICA (DETECTED_STATIC) • Kerberus 6.3\nAPIs encontradas no código; só as chamadas em jogo (CALLED_RUNTIME, relatório WINTRACE) indicam uso real.\nPerfil detectado: "+profile());
            out.append("\nScripts examinados: ").append(scripts).append("\nConteúdo conferido com auditoria completa: ").append(audited).append('/').append(scripts);
            out.append("\n\nWin32API distintas detectadas: ").append(apis.size());
            out.append("\nImplementações equivalentes: ").append(supported);
            out.append("\nAdaptadas pelo perfil: ").append(profile);
            out.append("\nFallbacks com limitações: ").append(fallback);
            out.append("\nAinda indisponíveis: ").append(missing);
            out.append("\nNão classificadas: ").append(unknown);
            if(preliminary>0 || unresolved>0) out.append("\n\nANÁLISE PARCIAL: ").append(preliminary).append(" scripts sem auditoria de conteúdo e ").append(unresolved).append(" referências não resolvidas. São candidatos encontrados no texto; comentários também podem ser contados e chamadas dinâmicas podem faltar.");
            out.append("\n\nA detecção não confirma execução. Sintaxe é validada no boot antes dos scripts. APK, Android, mapas, batalhas, áudio e saves exigem testes próprios.\n");
            for(Api api:apis.values()) {
                String label=api.kind.equals("equivalent")?"EQUIVALENTE":api.kind.equals("profile")?"PERFIL":api.kind.equals("fallback")?"LIMITADO":api.kind.equals("unavailable")?"INDISPONÍVEL":"NÃO CLASSIFICADA";
                out.append('\n').append(label).append(" • ").append(api.name);
                if(!api.kind.equals("equivalent")) out.append("\n").append(api.detail);
            }
            return out.toString();
        }
    }
    private final Map<String,Api> catalog=new HashMap<>();
    private final Map<String,String[]> audit=new HashMap<>();
    public CompatibilityAnalyzer(InputStream catalogInput,InputStream auditInput) throws IOException {
        try(BufferedReader in=new BufferedReader(new InputStreamReader(catalogInput,StandardCharsets.UTF_8))) {
            String line; int rows=0;
            while((line=in.readLine())!=null) {
                if(++rows>4096 || line.length()>4096) throw new IOException("Catálogo inválido.");
                if(line.startsWith("#") || line.isEmpty()) continue;
                String[] parts=line.split("\t",5);
                if(parts.length!=5) throw new IOException("Catálogo de APIs inválido.");
                String key=parts[0]+"!"+parts[1]; catalog.put(key,new Api(key,parts[3],parts[4]));
            }
        }
        try(BufferedReader in=new BufferedReader(new InputStreamReader(auditInput,StandardCharsets.UTF_8))) {
            String line; int rows=0;
            while((line=in.readLine())!=null) {
                if(++rows>4096 || line.length()>16384) throw new IOException("Auditoria inválida.");
                if(line.startsWith("#") || line.isEmpty()) continue;
                String[] parts=line.split("\t",2);
                if(parts.length!=2 || !parts[0].matches("[a-f0-9]{64}")) throw new IOException("Hash de auditoria inválido.");
                audit.put(parts[0],parts[1].isEmpty()?new String[0]:parts[1].split("\\|"));
            }
        }
    }
    public static String digest(byte[] bytes) {
        try {
            byte[] hash=MessageDigest.getInstance("SHA-256").digest(bytes); StringBuilder result=new StringBuilder(64);
            for(byte value:hash) { result.append(Character.forDigit((value>>4)&15,16)); result.append(Character.forDigit(value&15,16)); }
            return result.toString();
        } catch(NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }
    /** DLL aliases of the legacy18 WinBridge (40_winbridge.rb DLL_ALIASES; kept equal by a host test). */
    static final Map<String,String> DLL_ALIASES=new LinkedHashMap<>();
    static {
        String[] pairs={"xinput1_1","xinput","xinput1_2","xinput","xinput1_3","xinput","xinput1_4","xinput","xinput9_1_0","xinput",
            "wsock32","ws2_32","kernelbase","kernel32","msvcr70","msvcrt","msvcr71","msvcrt","msvcr80","msvcrt","msvcr90","msvcrt",
            "msvcr100","msvcrt","msvcr110","msvcrt","msvcr120","msvcrt","ucrtbase","msvcrt","rgss fmodex","rgss_fmodex","rgss linker","rgss_linker"};
        for(int i=0;i<pairs.length;i+=2) DLL_ALIASES.put(pairs[i],pairs[i+1]);
    }
    /** Same resolution as Win32API.new in the legacy18 WinBridge: DLL alias, then the name, then the name with A. */
    Api classify(String key) {
        int bang=key.indexOf('!');
        if(bang<0) return catalog.get(key);
        String library=key.substring(0,bang).replace('\\','/').toLowerCase(Locale.ROOT).trim();
        library=library.substring(library.lastIndexOf('/')+1).replaceFirst("\\.dll$","");
        if(library.matches("rgss1\\d\\d[a-z]?")) library="rgss1";
        String alias=DLL_ALIASES.get(library);
        if(alias!=null) library=alias;
        String function=key.substring(bang+1);
        Api api=catalog.get(library+"!"+function);
        return api!=null?api:catalog.get(library+"!"+function+"A");
    }
    private void add(Result result,String key) throws IOException {
        if(result.apis.size()>=512 && !result.apis.containsKey(key)) throw new IOException("Mais de 512 APIs distintas; análise interrompida.");
        Api api=classify(key);
        result.apis.put(key,api==null?new Api(key,"unknown","Sem assinatura/provider classificado; será reportada como API_MISSING."):new Api(key,api.kind,api.detail));
    }
    private static final Pattern DIRECT=Pattern.compile("Win32API\\s*\\.\\s*new\\s*\\(\\s*(['\"])([^'\"\\r\\n]+)\\1\\s*,\\s*(['\"])([^'\"\\r\\n]+)\\3");
    public Result analyze(byte[] pack) throws IOException {
        return analyze(null,pack);
    }
    public Result analyze(File game,byte[] pack) throws IOException {
        Result result=new Result();
        ScriptPackReader.Consumer consumer=(index,name,source)->{
            String text=new String(source,StandardCharsets.UTF_8);
            result.uraniumLinker|=text.contains("RGSSLinker_Initialize") && text.contains("Uranium.ini");
            result.uraniumAudio|=text.contains("Init_FmodEx") && text.contains("LOOP_TABLE") && text.contains("bgmvolume");
            result.insurgenceRenderer|=text.contains("MGC_Hmode7") && text.contains("renderHM7") && text.contains("drawMapTileset");
            result.insurgenceMarker|=text.contains("Insurgence") || text.contains("INSURGENCE");
            result.xenoverseMarker|=text.contains("Xenoverse - Per Aspera Ad Astra");
            String[] known=audit.get(digest(source));
            if(known!=null) {
                result.audited++;
                for(String key:known) add(result,key);
            } else {
                result.preliminary++;
                // An intentionally conservative fallback. It is marked partial
                // even if every literal happens to be in the API catalogue.
                Matcher match=DIRECT.matcher(text); int literals=0;
                while(match.find()) {
                    String library=match.group(2).replace('\\','/').toLowerCase(Locale.ROOT);
                    library=library.substring(library.lastIndexOf('/')+1).replaceFirst("\\.dll$","");
                    add(result,library+"!"+match.group(4)); literals++;
                }
                int declarations=0,offset=0;
                while((offset=text.indexOf("Win32API",offset))>=0) { declarations++; offset+=8; }
                result.unresolved+=Math.max(0,declarations-literals);
            }
        };
        result.scripts=game==null?ScriptPackReader.read(pack,consumer):ScriptPackReader.readGame(game,pack,consumer);
        return result;
    }
}
