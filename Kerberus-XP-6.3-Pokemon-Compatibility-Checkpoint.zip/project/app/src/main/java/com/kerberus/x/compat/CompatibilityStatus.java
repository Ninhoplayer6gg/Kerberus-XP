package com.kerberus.x.compat;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.EnumMap;
import java.util.Locale;
import java.util.Map;

/**
 * Per-game compatibility state built ONLY from evidence recorded by the
 * runtimes (milestones.log next to events.log). Detecting the engine never
 * counts as a test. Pure Java so it is covered by host tests.
 */
public final class CompatibilityStatus {
    public enum Level {
        NOT_TESTED("Não testado"),
        BOOT("Boot confirmado"),
        TITLE("Title confirmado"),
        MAP("Mapa confirmado"),
        BATTLE("Batalha confirmada"),
        SAVE("Save confirmado"),
        LONG_PLAY("Jogabilidade prolongada confirmada");

        public final String label;
        Level(String label) { this.label = label; }
    }

    public static final class Evidence {
        public final long epochSeconds;
        public final String runtime;
        public final String detail;
        Evidence(long epochSeconds, String runtime, String detail) {
            this.epochSeconds = epochSeconds;
            this.runtime = runtime;
            this.detail = detail;
        }
    }

    public static final int LIMIT = 256 * 1024;
    public final Map<Level, Evidence> reached = new EnumMap<>(Level.class);

    public Level level() {
        Level best = Level.NOT_TESTED;
        for (Level level : reached.keySet()) if (level.ordinal() > best.ordinal()) best = level;
        return best;
    }

    public static CompatibilityStatus read(File directory) throws IOException {
        CompatibilityStatus status = new CompatibilityStatus();
        File file = new File(directory, "milestones.log");
        for (int generation = 0; generation < 2; generation++) {
            File source = generation == 0 ? new File(file.getPath() + ".previous") : file;
            if (!source.isFile()) continue;
            if (source.length() > LIMIT) throw new IOException("Registro de marcos excede o limite.");
            byte[] data;
            try (InputStream in = new FileInputStream(source)) { data = ScriptPackReader.bounded(in, LIMIT); }
            status.parse(new String(data, StandardCharsets.UTF_8));
        }
        return status;
    }

    void parse(String text) {
        for (String line : text.split("\n")) {
            String[] parts = line.split("\t", 5);
            if (parts.length < 4 || !parts[0].equals("MILESTONE")) continue;
            Level level;
            try { level = Level.valueOf(parts[1].trim()); } catch (IllegalArgumentException unknown) { continue; }
            if (level == Level.NOT_TESTED) continue;
            long epoch;
            try { epoch = Long.parseLong(parts[3].trim()); } catch (NumberFormatException invalid) { continue; }
            if (!reached.containsKey(level))
                reached.put(level, new Evidence(epoch, parts[2].trim(), parts.length > 4 ? parts[4].trim() : ""));
        }
    }

    public String report() {
        StringBuilder out = new StringBuilder("Estado: ").append(level().label);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT);
        for (Level level : Level.values()) {
            if (level == Level.NOT_TESTED) continue;
            Evidence evidence = reached.get(level);
            out.append('\n').append(evidence == null ? "  [ ] " : "  [x] ").append(level.label);
            if (evidence != null) {
                out.append(" — ").append(format.format(new Date(evidence.epochSeconds * 1000L)))
                   .append(" (").append(evidence.runtime).append(')');
                if (!evidence.detail.isEmpty()) out.append(": ").append(evidence.detail);
            }
        }
        out.append("\nOs marcos são registrados pelo próprio runtime durante o jogo; detectar a engine não conta como teste.");
        return out.toString();
    }
}
