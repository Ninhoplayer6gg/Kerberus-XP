package com.kerberus.x.compat;

import com.kerberus.launcher.GameIni;
import com.kerberus.launcher.GameIntelligence;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.zip.*;

/** RGSS1 preflight reader. Primitive Marshal values only: no object instantiation,
 * Ruby execution, native pointers, or writes to the imported game. */
public final class ScriptPackReader {
    public static final int MAX_PACK=16*1024*1024, MAX_SCRIPT=4*1024*1024, MAX_TOTAL=64*1024*1024;
    public interface Consumer { void script(int index, String name, byte[] source) throws IOException; }
    public static boolean externalLoader(byte[] pack) throws IOException {
        final boolean[] match={false};
        int count=read(pack,(i,n,b)->{
            String s=new String(b,StandardCharsets.UTF_8);
            match[0]=s.contains("def load_scripts_from_folder(path)") && s.contains("def traceback_report") && s.contains("folders.sort!") &&
                java.util.regex.Pattern.compile("(?m)^\\s*load_scripts_from_folder\\(\"Data/Scripts\"\\)\\s*$").matcher(s).find();
        });
        return count==1 && match[0];
    }
    public static int readGame(File game,byte[] pack,Consumer consumer) throws IOException {
        if(!externalLoader(pack))return read(pack,consumer);
        File root=new File(game,"Data/Scripts").getCanonicalFile();
        if(!root.getPath().startsWith(game.getCanonicalPath()+File.separator))throw new IOException("Scripts externos fora do jogo.");
        int[] counts={0,0};
        external(root,root,0,new HashSet<>(),counts,consumer);
        if(counts[0]==0)throw new IOException("Pasta de scripts externos vazia.");
        return counts[0];
    }
    private static void external(File root,File dir,int depth,Set<String> seen,int[] counts,Consumer consumer)throws IOException{
        File real=dir.getCanonicalFile();String boundary=root.getPath()+File.separator;
        if(depth>8||!(real.equals(root)||real.getPath().startsWith(boundary))||!seen.add(real.getPath()))throw new IOException("Link externo, ciclo ou profundidade excessiva nos scripts.");
        File[] files=dir.listFiles();if(files==null)throw new IOException("Pasta de scripts inacessível.");
        Arrays.sort(files,Comparator.comparing(File::getName));
        for(File f:files)if(!f.isDirectory()){
            if(!f.getName().endsWith(".rb")||!f.getCanonicalPath().startsWith(boundary)||++counts[0]>4096)throw new IOException("Arquivo de script externo inválido.");
            byte[] data;try(InputStream in=new FileInputStream(f)){data=bounded(in,MAX_SCRIPT);}
            counts[1]+=data.length;if(counts[1]>MAX_TOTAL)throw new IOException("Scripts externos excedem 64 MiB.");
            try{StandardCharsets.UTF_8.newDecoder().decode(java.nio.ByteBuffer.wrap(data));}catch(java.nio.charset.CharacterCodingException e){throw new IOException("Script externo sem UTF-8: "+f.getName(),e);}
            consumer.script(counts[0]-1,f.getCanonicalPath().substring(boundary.length()),data);
        }
        for(File f:files)if(f.isDirectory())external(root,f,depth+1,seen,counts,consumer);
    }
    public static String fingerprint(File game)throws IOException{
        byte[] pack=locate(game);
        if(!externalLoader(pack))return CompatibilityAnalyzer.digest(pack);
        try{
            java.security.MessageDigest md=java.security.MessageDigest.getInstance("SHA-256");md.update(pack);
            readGame(game,pack,(i,n,b)->{byte[] path=n.getBytes(StandardCharsets.UTF_8);md.update(java.nio.ByteBuffer.allocate(8).putInt(path.length).putInt(b.length).array());md.update(path);md.update(b);});
            StringBuilder hex=new StringBuilder();for(byte b:md.digest())hex.append(String.format(Locale.ROOT,"%02x",b&255));return hex.toString();
        }catch(java.security.NoSuchAlgorithmException e){throw new IOException(e);}
    }
    public static byte[] locate(File game) throws IOException {
        GameIni ini=GameIni.find(game);
        if (ini.engine!=1 || !GameIni.safeRelative(ini.scripts)) throw new IOException("Análise disponível para scripts RGSS1.");
        File plain=GameIntelligence.resolve(game,ini.scripts);
        if (plain!=null && plain.isFile()) {
            try(InputStream in=new FileInputStream(plain)) { return bounded(in,MAX_PACK); }
        }
        String name=ini.archiveName(game);
        if (name.isEmpty()) throw new IOException("Scripts não encontrados na configuração ou pacote.");
        File archive=GameIntelligence.resolve(game,name);
        if (archive==null) throw new IOException("Pacote não encontrado.");
        return archive(archive,ini.scripts);
    }
    static byte[] bounded(InputStream in,int max) throws IOException {
        ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buffer=new byte[8192]; int count;
        while((count=in.read(buffer))!=-1) {
            if(out.size()>max-count) throw new IOException("Dados excedem limite de memória da análise.");
            out.write(buffer,0,count);
        }
        return out.toByteArray();
    }
    private static long u32(RandomAccessFile in) throws IOException {
        return (in.readUnsignedByte() | ((long)in.readUnsignedByte()<<8) | ((long)in.readUnsignedByte()<<16) | ((long)in.readUnsignedByte()<<24)) & 0xffffffffL;
    }
    private static long next(long key) { return (key*7+3)&0xffffffffL; }
    public static byte[] archive(File file,String requested) throws IOException {
        try(RandomAccessFile in=new RandomAccessFile(file,"r")) {
            byte[] header=new byte[8]; in.readFully(header);
            if(!Arrays.equals(header,new byte[]{'R','G','S','S','A','D',0,1})) throw new IOException("Cabeçalho RGSSAD v1 inválido.");
            long key=0xdeadcafeL; String target=requested.replace('\\','/'); byte[] result=null;
            int entries=0;
            while(in.getFilePointer()<in.length()) {
                if(++entries>100000) throw new IOException("Pacote contém entradas demais.");
                long length=u32(in)^key; key=next(key);
                if(length<1 || length>4096 || length>in.length()-in.getFilePointer()-4) throw new IOException("Nome RGSSAD inválido.");
                byte[] bytes=new byte[(int)length];
                for(int i=0;i<bytes.length;i++) { bytes[i]=(byte)(in.readUnsignedByte()^(key&255)); key=next(key); }
                String name=new String(bytes,StandardCharsets.UTF_8).replace('\\','/');
                long size=u32(in)^key; key=next(key);
                if(size>in.length()-in.getFilePointer()) throw new IOException("Entrada RGSSAD truncada.");
                if(name.equalsIgnoreCase(target)) {
                    if(result!=null) throw new IOException("Mais de uma entrada corresponde aos scripts.");
                    if(size>MAX_PACK) throw new IOException("Scripts compactados excedem 16 MiB.");
                    result=new byte[(int)size]; in.readFully(result); long dataKey=key;
                    for(int i=0;i<result.length;i++) {
                        result[i]^=(byte)(dataKey>>((i&3)*8));
                        if((i&3)==3) dataKey=next(dataKey);
                    }
                } else in.seek(in.getFilePointer()+size);
            }
            if(result==null) throw new IOException("Scripts configurados não encontrados no RGSSAD.");
            return result;
        }
    }
    public static int read(byte[] pack,Consumer consumer) throws IOException {
        if(pack.length>MAX_PACK) throw new IOException("Pacote de scripts excede 16 MiB.");
        Marshal reader=new Marshal(pack); Object root=reader.read(0);
        if(reader.position!=pack.length || !(root instanceof List)) throw new IOException("Tabela Marshal inválida.");
        List<?> rows=(List<?>)root;
        if(rows.size()>4096) throw new IOException("Mais de 4096 scripts.");
        int total=0;
        for(int i=0;i<rows.size();i++) {
            if(!(rows.get(i) instanceof List)) throw new IOException("Entrada de script inválida.");
            List<?> row=(List<?>)rows.get(i);
            if(row.size()<3 || !(row.get(1) instanceof byte[]) || !(row.get(2) instanceof byte[])) throw new IOException("Entrada de script inválida.");
            byte[] zipped=(byte[])row.get(2); Inflater inflater=new Inflater();
            ByteArrayOutputStream out=new ByteArrayOutputStream(); byte[] buffer=new byte[8192];
            try {
                inflater.setInput(zipped);
                while(!inflater.finished()) {
                    int count=inflater.inflate(buffer);
                    if(count==0 && !inflater.finished()) throw new IOException("Bloco zlib incompleto/dicionário não suportado.");
                    if(out.size()>MAX_SCRIPT-count || total>MAX_TOTAL-count) throw new IOException("Scripts descompactados excedem limite de memória.");
                    out.write(buffer,0,count); total+=count;
                }
                if(inflater.getRemaining()!=0) throw new IOException("Bytes extras após bloco zlib.");
            } catch(DataFormatException error) { throw new IOException("Bloco zlib inválido.",error); }
            finally { inflater.end(); }
            consumer.script(i,new String((byte[])row.get(1),StandardCharsets.UTF_8),out.toByteArray());
        }
        return rows.size();
    }
    private static final class Marshal {
        final byte[] data; int position=2, nodes;
        final List<Object> objects=new ArrayList<>(); final List<String> symbols=new ArrayList<>();
        Marshal(byte[] data) throws IOException {
            this.data=data;
            if(data.length<2 || data[0]!=4 || data[1]!=8) throw new IOException("Cabeçalho Marshal 4.8 inválido.");
        }
        int byteValue() throws IOException { if(position>=data.length) throw new EOFException("Marshal truncado."); return data[position++]&255; }
        int integer() throws IOException {
            int count=(byte)byteValue();
            if(count==0) return 0;
            if(count>4) return count-5;
            if(count< -4) return count+5;
            int value=count>0?0:-1;
            for(int i=0;i<Math.abs(count);i++) { value&=~(255<<(i*8)); value|=byteValue()<<(i*8); }
            return value;
        }
        int length(int max) throws IOException { int n=integer(); if(n<0 || n>max || n>data.length-position) throw new IOException("Comprimento Marshal inválido."); return n; }
        byte[] bytes() throws IOException { int n=length(MAX_PACK); byte[] b=Arrays.copyOfRange(data,position,position+n); position+=n; return b; }
        Object read(int depth) throws IOException {
            if(depth>32 || ++nodes>100000) throw new IOException("Estrutura Marshal excessiva.");
            int tag=byteValue();
            switch(tag) {
                case '0': return null;
                case 'T': return Boolean.TRUE;
                case 'F': return Boolean.FALSE;
                case 'i': return integer();
                case '"': { byte[] value=bytes(); objects.add(value); return value; }
                case ':': { String name=new String(bytes(),StandardCharsets.UTF_8); symbols.add(name); return name; }
                case ';': { int index=integer(); if(index<0 || index>=symbols.size()) throw new IOException("Link de símbolo inválido."); return symbols.get(index); }
                case '@': { int index=integer(); if(index<0 || index>=objects.size()) throw new IOException("Link de objeto inválido."); return objects.get(index); }
                case '[': {
                    int count=length(16384); List<Object> values=new ArrayList<>(count); objects.add(values);
                    for(int i=0;i<count;i++) values.add(read(depth+1));
                    return values;
                }
                case 'I': {
                    Object value=read(depth+1); int count=length(16);
                    for(int i=0;i<count;i++) { Object key=read(depth+1), item=read(depth+1);
                        if(!(key instanceof String) || (!key.equals("E") && !key.equals("encoding"))) throw new IOException("Metadado Marshal não permitido.");
                        if(!(item instanceof Boolean) && !(item instanceof byte[])) throw new IOException("Encoding Marshal inválido.");
                    }
                    return value;
                }
                case 'l': {
                    int sign=byteValue(); int words=length(8);
                    if((sign!='+' && sign!='-') || words*2>data.length-position) throw new IOException("Bignum inválido.");
                    byte[] value=Arrays.copyOfRange(data,position,position+words*2); position+=words*2;
                    objects.add(value); return value; // script IDs are metadata, never executed
                }
                default: throw new IOException("Tipo Marshal não permitido na tabela de scripts: "+(char)tag);
            }
        }
    }
}
