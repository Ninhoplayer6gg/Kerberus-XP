package com.kerberus.x.morph;
import android.content.res.AssetManager;
import java.io.*;
import java.util.*;
/** Read-only packages shipped by Kerberus. No game script or network content. */
public final class BundledPatchProvider implements PatchProvider {
    private final AssetManager assets;
    public BundledPatchProvider(AssetManager assets) { this.assets=assets; }
    public List<KfixPatch> patches() throws IOException {
        String[] files=assets.list("morph");
        List<KfixPatch> patches=new ArrayList<>(); Set<String> ids=new HashSet<>();
        if (files==null) return patches;
        if (files.length>32) throw new IOException("Catálogo Morph excede o limite desta versão.");
        Arrays.sort(files);
        for (String file:files) {
            if (!file.endsWith(".kfix")) continue;
            try (InputStream in=assets.open("morph/"+file)) {
                KfixPatch patch=KfixPatch.read(in);
                if (!ids.add(patch.id)) throw new IOException("ID de correção repetido no catálogo.");
                patches.add(patch);
            }
        }
        return Collections.unmodifiableList(patches);
    }
}
