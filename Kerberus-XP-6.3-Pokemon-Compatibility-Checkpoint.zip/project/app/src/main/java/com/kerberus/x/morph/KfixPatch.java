package com.kerberus.x.morph;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.*;
import java.security.*;
import java.util.*;

/** Declarative .kfix v1. A package cannot execute Ruby, shell commands or write game files. */
public final class KfixPatch {
    public static final int RUNTIME_VERSION = 4080, MAX_BYTES = 16384;
    public final String id, name, description, engine, game, condition, provider, category, fingerprint;
    public final int version, minRuntime, minAndroid;
    public final boolean experimental;
    private static final Set<String> KEYS = new HashSet<>(Arrays.asList(
            "format", "id", "name", "version", "description", "engine", "game", "condition", "provider",
            "provider_version", "min_runtime", "min_android", "experimental", "default_enabled", "can_disable", "logging", "category"));
    private KfixPatch(Map<String,String> values, byte[] raw) throws IOException {
        if (!"1".equals(values.get("format"))) throw invalid("Versão de formato .kfix não suportada.");
        id=values.get("id");
        if (!id.matches("KERBERUS-FIX-[0-9]{4,8}")) throw invalid("ID de correção inválido.");
        name=values.get("name"); description=values.get("description");
        if (name.length()>100 || description.length()>600) throw invalid("Metadados de correção grandes demais.");
        version=number(values,"version"); minRuntime=number(values,"min_runtime"); minAndroid=number(values,"min_android");
        engine=values.get("engine"); game=values.get("game"); condition=values.get("condition");
        if (!game.equals("*") && !game.matches("[a-f0-9]{64}")) throw invalid("Alvo de jogo inválido; use * ou a identidade da importação.");
        provider=values.get("provider"); category=values.get("category");
        if (category.length()>100 || engine.length()>32) throw invalid("Categoria ou engine grande demais.");
        if (!"1".equals(values.get("provider_version"))) throw invalid("Versão do provedor não suportada.");
        if (!provider.equals("windows.uptime") && !provider.equals("windows.performance_counter")
                && !provider.equals("windows.thread_identity"))
            throw invalid("Esta versão não implementa o provedor: " + provider);
        if (!condition.equals("native_api_missing")) throw invalid("Condição não suportada.");
        if (!values.get("default_enabled").equals("false") || !values.get("can_disable").equals("true")
                || !values.get("logging").equals("bounded")) throw invalid("O pacote deve permitir desativação e começar desligado, com logs limitados.");
        if (!values.get("experimental").equals("true") && !values.get("experimental").equals("false"))
            throw invalid("Sinalizador experimental inválido.");
        experimental=Boolean.parseBoolean(values.get("experimental"));
        try {
            byte[] digest=MessageDigest.getInstance("SHA-256").digest(raw);
            StringBuilder hex=new StringBuilder();
            for (byte b:digest) hex.append(String.format(Locale.ROOT,"%02x", b & 255));
            fingerprint=hex.toString();
        } catch (NoSuchAlgorithmException error) { throw new IOException(error); }
    }
    public static KfixPatch read(InputStream input) throws IOException {
        ByteArrayOutputStream bytes=new ByteArrayOutputStream(); byte[] buffer=new byte[2048]; int n;
        while ((n=input.read(buffer))!=-1) {
            if (bytes.size()+n>MAX_BYTES) throw invalid("Pacote .kfix excede 16 KiB.");
            bytes.write(buffer,0,n);
        }
        byte[] raw=bytes.toByteArray(); String text;
        try { text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(raw)).toString(); }
        catch (CharacterCodingException error) { throw invalid("O pacote deve usar UTF-8 válido."); }
        if (text.startsWith("\ufeff")) text=text.substring(1);
        Map<String,String> values=new LinkedHashMap<>();
        for (String line:text.split("\n",-1)) {
            line=line.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            for (int i=0;i<line.length();i++) if (Character.isISOControl(line.charAt(i))) throw invalid("Caractere de controle no pacote.");
            int separator=line.indexOf('=');
            if (separator<1) throw invalid("Use uma propriedade chave=valor por linha.");
            String key=line.substring(0,separator).trim(), value=line.substring(separator+1).trim();
            if (!KEYS.contains(key) || value.isEmpty() || values.put(key,value)!=null) throw invalid("Propriedade desconhecida, vazia ou repetida: "+key);
        }
        if (!values.keySet().equals(KEYS)) throw invalid("Metadados obrigatórios ausentes no .kfix.");
        return new KfixPatch(values,raw);
    }
    private static int number(Map<String,String> values,String key) throws IOException {
        try {
            if (!values.get(key).matches("[0-9]{1,9}")) throw new NumberFormatException();
            int n=Integer.parseInt(values.get(key)); if (n<1) throw new NumberFormatException(); return n;
        } catch (NumberFormatException error) { throw invalid("Número inválido: "+key); }
    }
    private static IOException invalid(String text) { return new IOException(text); }
    public String incompatibility(String gameId,int rgss,int android) {
        if (!engine.equals("RGSS1") || rgss!=1) return "Requer RPG Maker XP / RGSS1.";
        if (!game.equals("*") && !game.equals(gameId)) return "Este pacote destina-se a outro jogo.";
        if (minRuntime>RUNTIME_VERSION) return "Requer uma versão mais nova do Kerberus.";
        if (minAndroid>android) return "Requer Android API "+minAndroid+" ou superior.";
        return "";
    }
    public String approval() { return version+":"+fingerprint; }
}
