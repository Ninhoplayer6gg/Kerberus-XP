package com.kerberus.x.morph;
import com.kerberus.x.shared.CompatibilityEvent;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Read on request, never polled each frame. Reads at most 128 KiB of generated logs. */
public final class MorphEventLog {
    private MorphEventLog() {}
    public static List<CompatibilityEvent> latest(File file) throws IOException {
        List<CompatibilityEvent> events=new ArrayList<>();
        read(new File(file.getPath()+".previous"),events); read(file,events);
        if (events.isEmpty()) return events;
        String session=events.get(events.size()-1).session;
        List<CompatibilityEvent> result=new ArrayList<>();
        for (CompatibilityEvent event:events) if (event.session.equals(session)) result.add(event);
        return result;
    }
    private static void read(File file,List<CompatibilityEvent> events) throws IOException {
        if (!file.exists()) return;
        try (RandomAccessFile in=new RandomAccessFile(file,"r")) {
            long start=Math.max(0,in.length()-65536); in.seek(start);
            byte[] bytes=new byte[(int)Math.min(65536,in.length()-start)]; in.readFully(bytes);
            String text=new String(bytes,StandardCharsets.UTF_8);
            // Ignore an incomplete first/last line during rotation or a concurrent append.
            int from=start==0 ? 0 : text.indexOf('\n')+1, to=text.lastIndexOf('\n');
            if (to<from) return;
            for (String line:text.substring(from,to).split("\n")) {
                CompatibilityEvent event=CompatibilityEvent.parse(line);
                if (event!=null) {
                    if (events.size()==80) events.remove(0);
                    events.add(event);
                }
            }
        } catch (FileNotFoundException rotated) { /* A rotating log is optional, never a boot failure. */ }
    }
    public static String report(File file) throws IOException {
        List<CompatibilityEvent> events=latest(file);
        if (events.isEmpty()) return "Nenhuma chamada registrada pelo Morph. Abra o jogo para iniciar o diagnóstico.";
        StringBuilder text=new StringBuilder("REGISTROS DA ÚLTIMA SESSÃO\nHabilitada: disponível para uso. APPLIED: utilizada na chamada indicada.\n");
        for (CompatibilityEvent event:events) text.append('\n').append(event.readable()).append('\n');
        return text.toString();
    }
}
