package com.kerberus.x.morph;
import android.content.Context;
import android.os.Build;
import java.io.File;
import java.io.IOException;
import java.util.UUID;

/** Immutable session configuration. A settings failure must not prevent normal game execution. */
public final class MorphRuntime {
    public final String plan, log, session, warning;
    private MorphRuntime(String plan,String log,String warning) {
        this.plan=plan; this.log=log; this.warning=warning; session=UUID.randomUUID().toString();
    }
    public static MorphRuntime prepare(Context context,File game,int rgss) {
        String path="";
        try {
            MorphStore store=new MorphStore(context.getFilesDir(),game);
            path=store.eventsFile().getAbsolutePath();
            return new MorphRuntime(store.plan(new BundledPatchProvider(context.getAssets()).patches(),rgss,Build.VERSION.SDK_INT),path,"");
        } catch (IOException error) {
            return new MorphRuntime("KMX1\n",path,"Morph indisponível nesta sessão: "+error.getMessage());
        }
    }
}
