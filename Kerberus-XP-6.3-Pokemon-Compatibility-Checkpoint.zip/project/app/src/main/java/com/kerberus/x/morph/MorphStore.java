package com.kerberus.x.morph;
import com.kerberus.launcher.GameIdentity;
import com.kerberus.x.shared.AtomicProperties;
import java.io.*;
import java.util.*;

/** Per-game opt-in, with one persistent undo. No path inside a game is written. */
public final class MorphStore {
    private static final Object LOCK=new Object();
    public final String gameId;
    private final File directory,settings;
    public MorphStore(File files,File game) throws IOException {
        File managed=game.getCanonicalFile();
        if (!managed.isDirectory() || managed.getName().startsWith(".")
                || !new File(files,"games").getCanonicalFile().equals(managed.getParentFile()))
            throw new IOException("Jogo fora da biblioteca gerenciada.");
        gameId=GameIdentity.of(managed);
        File base=new File(files,"kerberus-x/morph");
        directory=new File(base,gameId); settings=new File(directory,"settings.properties");
        if (!directory.getCanonicalFile().getParentFile().equals(base.getCanonicalFile()))
            throw new IOException("Pasta Morph inválida.");
    }
    private Properties read() throws IOException {
        Properties values=AtomicProperties.read(settings);
        if (settings.exists() && !"1".equals(values.getProperty("schema")))
            throw new IOException("Versão das configurações Morph não suportada; conteúdo preservado.");
        return values;
    }
    public boolean enabled(KfixPatch patch) throws IOException {
        synchronized(LOCK) { return patch.approval().equals(read().getProperty("enabled."+patch.id)); }
    }
    public void setEnabled(KfixPatch patch,boolean enabled,List<KfixPatch> catalog,int rgss,int android) throws IOException {
        synchronized(LOCK) {
            String reason=patch.incompatibility(gameId,rgss,android);
            if (enabled && !reason.isEmpty()) throw new IOException(reason);
            Properties values=read(); String key="enabled."+patch.id;
            if (enabled==patch.approval().equals(values.getProperty(key))) return;
            if (enabled) for (KfixPatch other:catalog)
                if (!other.id.equals(patch.id) && other.provider.equals(patch.provider)
                        && other.approval().equals(values.getProperty("enabled."+other.id)))
                    throw new IOException("Outra correção desse provedor já está habilitada.");
            preserveUndo(values);
            if (enabled) values.setProperty(key,patch.approval()); else values.remove(key);
            save(values);
        }
    }
    public void disableAll() throws IOException {
        synchronized(LOCK) {
            Properties values=read();
            boolean any=false;
            for (String key:values.stringPropertyNames()) if (key.startsWith("enabled.")) { any=true; break; }
            if (!any) return;
            preserveUndo(values);
            for (String key:new HashSet<>(values.stringPropertyNames())) if (key.startsWith("enabled.")) values.remove(key);
            save(values);
        }
    }
    public boolean canUndo() throws IOException { synchronized(LOCK) { return "true".equals(read().getProperty("undo.available")); } }
    public void undo() throws IOException {
        synchronized(LOCK) {
            Properties values=read();
            if (!"true".equals(values.getProperty("undo.available"))) return;
            for (String key:new HashSet<>(values.stringPropertyNames())) if (key.startsWith("enabled.")) values.remove(key);
            for (String key:new HashSet<>(values.stringPropertyNames())) {
                if (key.startsWith("undo.enabled.")) values.setProperty(key.substring(5),values.getProperty(key));
                if (key.startsWith("undo.")) values.remove(key);
            }
            save(values);
        }
    }
    private static void preserveUndo(Properties values) {
        for (String key:new HashSet<>(values.stringPropertyNames())) if (key.startsWith("undo.")) values.remove(key);
        for (String key:new HashSet<>(values.stringPropertyNames())) if (key.startsWith("enabled.")) values.setProperty("undo."+key,values.getProperty(key));
        values.setProperty("undo.available","true");
    }
    private void save(Properties values) throws IOException { values.setProperty("schema","1"); AtomicProperties.write(settings,values); }
    public String plan(List<KfixPatch> patches,int rgss,int android) throws IOException {
        synchronized(LOCK) {
            Properties values=read(); StringBuilder result=new StringBuilder("KMX1\n"); Set<String> providers=new HashSet<>();
            for (KfixPatch patch:patches) {
                if (!patch.incompatibility(gameId,rgss,android).isEmpty()
                        || !patch.approval().equals(values.getProperty("enabled."+patch.id))) continue;
                if (!providers.add(patch.provider)) throw new IOException("Provedores Morph em conflito; sessão sem correções.");
                result.append(patch.id).append('\t').append(patch.version).append('\t').append(patch.provider).append('\n');
            }
            if (result.length()>4096) throw new IOException("Plano Morph excede o limite de tamanho.");
            return result.toString();
        }
    }
    public File eventsFile() throws IOException {
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("Não foi possível preparar os registros Morph.");
        return new File(directory,"events.tsv");
    }
}
