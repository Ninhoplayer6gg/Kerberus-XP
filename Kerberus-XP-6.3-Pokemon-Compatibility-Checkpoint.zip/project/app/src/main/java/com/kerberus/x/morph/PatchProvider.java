package com.kerberus.x.morph;
import java.io.IOException;
import java.util.List;
/** Catalog boundary. Forge can later supply separately validated packages. */
public interface PatchProvider { List<KfixPatch> patches() throws IOException; }
