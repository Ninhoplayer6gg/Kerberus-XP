package com.kerberus.x.shared;
import java.io.*;
import java.util.Properties;

/** Bounded private metadata. Rename commits the complete file on Android/Linux. */
public final class AtomicProperties {
    public static final int LIMIT=32768;
    private AtomicProperties() {}
    public static Properties read(File file) throws IOException {
        Properties values=new Properties();
        if (!file.exists()) return values;
        if (!file.isFile() || file.length()>LIMIT) throw new IOException("Configuração privada inválida ou grande demais.");
        try (InputStream in=new FileInputStream(file)) {
            ByteArrayOutputStream bytes=new ByteArrayOutputStream(); byte[] buffer=new byte[2048]; int count;
            while ((count=in.read(buffer))!=-1) {
                if (bytes.size()+count>LIMIT) throw new IOException("Configuração privada excedeu o limite de leitura.");
                bytes.write(buffer,0,count);
            }
            values.load(new ByteArrayInputStream(bytes.toByteArray()));
        }
        catch (IllegalArgumentException error) { throw new IOException("Configuração privada danificada.",error); }
        return values;
    }
    public static void write(File target,Properties values) throws IOException { write(target,values,LIMIT); }
    public static void write(File target,Properties values,int limit) throws IOException {
        if(limit<1 || limit>131072) throw new IOException("Limite de configuracao invalido.");
        File parent=target.getParentFile();
        if (!parent.isDirectory() && !parent.mkdirs()) throw new IOException("Não foi possível preparar as configurações.");
        File temp=File.createTempFile(".write-", ".tmp",parent);
        try {
            try (FileOutputStream out=new FileOutputStream(temp)) { values.store(out,"Kerberus X private settings"); out.getFD().sync(); }
            if (temp.length()>limit) throw new IOException("Configuração excedeu o limite de tamanho.");
            if (!temp.renameTo(target)) throw new IOException("Não foi possível concluir a gravação; configuração anterior preservada.");
        } finally { temp.delete(); }
    }
}
