package com.kerberus.x.shared;

/** Shared, bounded event contract for Morph and the future Forge/Doctor. */
public final class CompatibilityEvent {
    public final long time;
    public final String session, type, patchId, version, provider, library, function, script, parameters, outcome;
    private CompatibilityEvent(String[] fields, long time) {
        this.time=time; session=fields[2]; type=fields[3]; patchId=fields[4]; version=fields[5];
        provider=fields[6]; library=fields[7]; function=fields[8]; script=fields[9]; parameters=fields[10]; outcome=fields[11];
    }
    public static CompatibilityEvent parse(String line) {
        if (line.length()>2048) return null;
        String[] fields=line.split("\t",-1);
        if (fields.length!=12 || !fields[0].equals("1") || !fields[3].matches("[A-Z_]{1,32}")) return null;
        try { long time=Long.parseLong(fields[1]); return time<0 ? null : new CompatibilityEvent(fields,time); }
        catch (NumberFormatException error) { return null; }
    }
    public String readable() {
        if (type.equals("SESSION")) return "[Sessão] "+outcome+" ("+parameters+")";
        return "["+type+"] "+(patchId.equals("-")?"":patchId+" v"+version+" • ")
                +library+(function.isEmpty()?"":"!"+function)+"\nScript: "+script
                +"\n"+parameters+"\n"+outcome;
    }
}
