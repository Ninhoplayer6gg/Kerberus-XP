package com.kerberus.x.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import com.kerberus.launcher.GameCatalog;
import com.kerberus.launcher.GameIni;
import com.kerberus.x.morph.*;
import com.kerberus.x.compat.CompatibilityService;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/** Lightweight native UI. Future modules are labelled as planned, never simulated. */
public final class KerberusXActivity extends Activity {
    public static final String EXTRA_GAME_PATH="kerberus_game_path";
    private static final int GOLD=0xffffb441, MUTED=0xffb3b4bf;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private volatile boolean closed;
    private boolean busy, morphPage;
    private File game;
    private State state;
    private String error="";
    private LinearLayout root;
    private final List<Button> actions=new ArrayList<>();
    private static final class State {
        MorphStore store; List<KfixPatch> patches; Set<String> enabled=new HashSet<>();
        String title,report,analysis,compatEvents; int rgss; boolean undo,compatEnabled;
    }
    private interface Change { void run(State state) throws IOException; }
    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        String path=getIntent().getStringExtra(EXTRA_GAME_PATH);
        if (path==null || path.isEmpty()) { finish(); return; }
        game=new File(path); morphPage=saved!=null && saved.getBoolean("morph");
        render(); load(null);
    }
    private void load(Change change) {
        if (busy || closed) return;
        busy=true; for (Button action:actions) action.setEnabled(false);
        final State previous=state;
        worker.execute(()->{
            State result=null; String failure="";
            try {
                if (change!=null) change.run(previous);
                State next=new State();
                next.store=new MorphStore(getFilesDir(),game);
                next.title=new GameCatalog(getFilesDir()).load(game).title();
                next.rgss=GameIni.find(game).engine;
                next.patches=new BundledPatchProvider(getAssets()).patches();
                for (KfixPatch patch:next.patches) if (next.store.enabled(patch)) next.enabled.add(patch.id);
                next.undo=next.store.canUndo();
                next.report=MorphEventLog.report(next.store.eventsFile());
                next.compatEnabled=CompatibilityService.enabled(this,game);
                try { next.analysis=CompatibilityService.analyze(this,game); }
                catch(IOException issue) { next.analysis="Analise incompleta: "+issue.getMessage(); }
                next.compatEvents=CompatibilityService.events(this,game);
                result=next;
            } catch (IOException exception) { failure=exception.getMessage(); }
            final State loaded=result; final String problem=failure;
            runOnUiThread(()->{
                if (closed || isFinishing()) return;
                busy=false; state=loaded; error=problem; render();
            });
        });
    }
    private void render() {
        actions.clear();
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setBackgroundColor(0xff090a0c);
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(20),dp(20),dp(28));
        scroll.addView(root); setContentView(scroll);
        text(root,"KERBERUS X",25,GOLD,true);
        text(root,state==null?"Compatibilidade por jogo":state.title,17,Color.WHITE,true);
        button(root,morphPage?"‹  Voltar ao Kerberus X":"‹  Voltar à biblioteca",()->{
            if (morphPage) { morphPage=false; render(); } else finish();
        });
        if (!error.isEmpty()) {
            text(root,"Não foi possível ler as configurações.\n"+error,15,0xffffb09b,false);
            button(root,"Tentar novamente",()->load(null));
        } else if (state==null) text(root,"Lendo configurações…",15,MUTED,false);
        if (morphPage) renderMorph(); else renderHome();
    }
    private void renderHome() {
        LinearLayout compatibility=card();
        text(compatibility,"Pokémon Compatibility",22,Color.WHITE,true);
        text(compatibility,"Alpha 5.2.0 • Experimental\nPerfil automático por conteúdo. Adapta scripts em memória e usa recursos nativos do Android/mkxp. HMode7, rede e algumas extensões ainda têm limitações.",14,MUTED,false);
        if(state!=null) {
            text(compatibility,state.compatEnabled?"Perfil automático habilitado":"Perfil desativado para este jogo",15,GOLD,true);
            button(compatibility,state.compatEnabled?"Desativar perfil":"Reativar perfil automático",()->load(s->CompatibilityService.enabled(this,game,!s.compatEnabled)));
            button(compatibility,"Ver análise dos scripts",()->new AlertDialog.Builder(this).setTitle("Compatibilidade estática").setMessage(state.analysis)
                    .setPositiveButton("Fechar",null).setNeutralButton("Copiar",(dialog,which)->copyCompatibility(state.analysis)).show());
            button(compatibility,"Ver chamadas e limitações",()->new AlertDialog.Builder(this).setTitle("Chamadas de compatibilidade").setMessage(state.compatEvents)
                    .setPositiveButton("Fechar",null).setNeutralButton("Copiar",(dialog,which)->copyCompatibility(state.compatEvents)).show());
            text(compatibility,"Ativar/desativar vale na próxima execução. Reativar desfaz a desativação. Saves e arquivos originais são preservados.",13,MUTED,false);
        }

        LinearLayout card=card(); text(card,"Morph",22,Color.WHITE,true);
        text(card,"Correções de compatibilidade, ativação por jogo e registros de chamadas.",15,MUTED,false);
        button(card,"Abrir Morph",()->{ morphPage=true; render(); });
        text(root,"EM DESENVOLVIMENTO",12,GOLD,true);
        text(root,"Forge • Fase 2\nAnálise de registros e instalação de .kfix.\n\nNitro • Fase 3\nProfiling de scripts.\n\nBabel • Fase 4\nTradução com dicionários locais.\n\nTime Machine • Fase 5\nExperimental Lab: snapshots seguros.",15,MUTED,false);
        text(root,"Esses quatro módulos ainda não estão disponíveis nesta versão.",14,MUTED,false);
    }
    private void renderMorph() {
        text(root,"Kerberus Morph",23,Color.WHITE,true);
        text(root,"As alterações valem na próxima inicialização do jogo. Se ele estiver aberto, encerre pelo menu do runtime antes de abrir novamente.\n\nOs arquivos originais e saves permanecem intactos. Uma correção habilitada só é aplicada quando a API correspondente é chamada.",14,MUTED,false);
        if (state==null) return;
        for (KfixPatch patch:state.patches) {
            LinearLayout card=card(); boolean enabled=state.enabled.contains(patch.id);
            String reason=patch.incompatibility(state.store.gameId,state.rgss,Build.VERSION.SDK_INT);
            text(card,patch.name,19,Color.WHITE,true);
            text(card,patch.id+" • v"+patch.version+(patch.experimental?" • Experimental":""),12,GOLD,true);
            text(card,patch.description,14,MUTED,false);
            text(card,!reason.isEmpty()?"Indisponível: "+reason:enabled?"Habilitada para a próxima sessão":"Desligada",14,enabled?GOLD:MUTED,true);
            Button toggle=button(card,enabled?"Desativar":"Ativar para este jogo",()->{
                if (enabled) changePatch(patch,false);
                else if (patch.experimental) new AlertDialog.Builder(this).setTitle("Ativar correção experimental?")
                    .setMessage(patch.name+"\n\nAinda precisa de validação em jogos e aparelhos. Você pode desativar ou desfazer a alteração nesta tela.")
                    .setPositiveButton("Ativar",(dialog,which)->changePatch(patch,true)).setNegativeButton("Cancelar",null).show();
                else changePatch(patch,true);
            });
            toggle.setEnabled(!busy && (enabled || reason.isEmpty()));
        }
        button(root,"Desativar todas",()->load(s->s.store.disableAll())).setEnabled(!busy && !state.enabled.isEmpty());
        button(root,"Desfazer última alteração",()->load(s->s.store.undo())).setEnabled(!busy && state.undo);
        text(root,"CORREÇÕES UTILIZADAS E DIAGNÓSTICO",12,GOLD,true);
        text(root,"APPLIED indica uma chamada atendida, não uma confirmação de compatibilidade completa do jogo. Os registros são limitados e renovados automaticamente.",14,MUTED,false);
        button(root,"Atualizar registros",()->load(null));
        button(root,"Copiar registros",()->{
            ClipboardManager clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
            clipboard.setPrimaryClip(ClipData.newPlainText("Kerberus Morph", "KERBERUS XP • Alpha 5.2.0 — Pokémon Compatibility\n"+state.title+"\n\n"+state.report));
            Toast.makeText(this,"Registros copiados",Toast.LENGTH_SHORT).show();
        });
        TextView log=text(root,state.report,13,MUTED,false); log.setTextIsSelectable(true);
    }
    private void copyCompatibility(String report) {
        ClipboardManager clipboard=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(ClipData.newPlainText("Kerberus Compatibility",report));
        Toast.makeText(this,"Relatório copiado",Toast.LENGTH_SHORT).show();
    }
    private void changePatch(KfixPatch patch,boolean enabled) {
        load(s->s.store.setEnabled(patch,enabled,s.patches,s.rgss,Build.VERSION.SDK_INT));
    }
    private LinearLayout card() {
        LinearLayout view=new LinearLayout(this); view.setOrientation(LinearLayout.VERTICAL); view.setPadding(dp(16),dp(12),dp(16),dp(12));
        GradientDrawable background=new GradientDrawable(); background.setColor(0xff16171b); background.setCornerRadius(dp(16)); background.setStroke(dp(1),0xff313136);
        view.setBackground(background);
        LinearLayout.LayoutParams params=new LinearLayout.LayoutParams(-1,-2); params.setMargins(0,dp(12),0,dp(12));
        root.addView(view,params); return view;
    }
    private TextView text(LinearLayout parent,String value,int size,int color,boolean bold) {
        TextView view=new TextView(this); view.setText(value); view.setTextSize(size); view.setTextColor(color);
        if (bold) view.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        view.setPadding(0,dp(6),0,dp(8)); parent.addView(view); return view;
    }
    private Button button(LinearLayout parent,String title,Runnable action) {
        Button button=new Button(this); button.setText(title); button.setAllCaps(false); button.setMinHeight(dp(52));
        button.setTextColor(GOLD); button.setOnClickListener(v->{if(!busy)action.run();}); button.setEnabled(!busy);
        parent.addView(button,new LinearLayout.LayoutParams(-1,-2)); actions.add(button); return button;
    }
    private int dp(int value) { return (int)(value*getResources().getDisplayMetrics().density+.5f); }
    @Override public void onBackPressed() {
        if (morphPage) { morphPage=false; render(); } else super.onBackPressed();
    }
    @Override protected void onSaveInstanceState(Bundle state) { state.putBoolean("morph",morphPage); super.onSaveInstanceState(state); }
    @Override protected void onDestroy() { closed=true; worker.shutdown(); super.onDestroy(); }
}
