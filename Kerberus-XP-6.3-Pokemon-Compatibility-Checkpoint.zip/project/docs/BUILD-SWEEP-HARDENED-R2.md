# Build Sweep — Kerberus XP 6.1.2 Hardened R2

## Falhas reproduzidas/identificadas nos logs

1. Setup antigo do Android SDK tentava instalar o pacote obsoleto `tools`.
2. Pixman 0.42.2 tentava compilar assembly AArch64 antigo incompatível com o assembler do Clang/NDK r23.
3. OpenAL não habilitava o backend OpenSL no cross-build.
4. OpenSSL não encontrava o compilador Android quando o toolchain do NDK não estava no PATH.
5. Ruby 3.1 tentava instalar gems no host (`/var/lib/gems`).
6. Ruby 1.8 precisava de um host Ruby separado para gerar artefatos de cross-build.
7. O helper `*-fake.rb` precisa ser gerado pelo target `make fake`.
8. `missing/memcmp.c` perdeu o include da raiz do Ruby quando CPPFLAGS foi sobrescrito.
9. Ruby 1.8 `mkconfig.rb`/`rbconfig.rb` faz uma checagem de versão que é correta no runtime, mas precisa ser ignorada enquanto ferramentas do host executam a configuração alvo durante cross-build.
10. `lib/fileutils.rb` do Ruby 1.8 não pode ser executado pelo Ruby 3 do host; as bibliotecas de host são pré-carregadas antes do helper alvo.

## Problemas encontrados antes de virarem a próxima falha

- AGP 7.3.1 estava combinado com Gradle 8.1; R2 usa Gradle 7.4.2 e JDK 11 no estágio Gradle.
- `APP_ABI` não basta com Gradle `externalNativeBuild`; R2 também usa `ndk.abiFilters 'arm64-v8a'`.
- Bibliotecas compartilhadas não tinham uma política global de alinhamento ELF de 16 KB.
- OpenSSL 1.1.1t foi substituído por 1.1.1w, a última manutenção pública da linha 1.1.1. A linha 1.1.1 continua EOL e deve ser migrada separadamente depois.
- O core Ruby 1.8 estático agora é compilado com `-fPIC`, necessário para ser incorporado em `libmkxp-z18.so` no AArch64.
- A etapa legado agora valida `ruby_init`, `Init_zlib`, `Init_stringio` e `Init_strscan`.
- O binding Ruby 1.8 continha placeholders `Finish me!` para aridade e formatação; foram substituídos por implementações reais.
- `showExc` no caminho Ruby legado usava o ponteiro do objeto de exceção onde deveria usar a string `message`; corrigido.
- Um workflow antigo e incompatível foi desabilitado no source.

## Auditoria final de APK

O script `scripts/audit-apk.sh` confere:
- somente `arm64-v8a`;
- presença de `libmkxp-z18.so`, `libmkxp-z31.so`, `libruby.so`, `libopenal.so` e `libc++_shared.so`;
- engine Ruby 1.8 não pode depender dinamicamente de `libruby.so`;
- engine Ruby 3.1 deve depender de `libruby.so`;
- nenhuma DT_NEEDED pode conter caminho do Termux/runner;
- relatório do alinhamento dos segmentos ELF.

## Limite conhecido

O NDK r23 é mantido por compatibilidade. Mesmo com as bibliotecas do projeto alinhadas para 16 KB, o `libc++_shared.so` fornecido por NDKs antigos pode continuar sendo um limitador em dispositivos 16 KB. Migrar de NDK deve ser feito depois da APK dual-runtime estar estável para não misturar duas mudanças grandes ao mesmo tempo.
