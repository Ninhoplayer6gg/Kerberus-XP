# Kerberus XP 6.3 — Documentação técnica

Pokémon Compatibility Expansion. Este documento descreve o que existe no código da 6.3,
onde está e como é testado. A lista completa de APIs está em
`docs/KERBERUS-6.3-WINBRIDGE-APIS.md` (gerada do código).

## 1. Arquitetura multi-runtime (preservada)

| Motor | Ruby | Camada de compatibilidade | Quem usa |
|---|---|---|---|
| `libmkxp-z18.so` | Ruby 1.8.7 real (estático) | Bootstrap Legacy18: WinBridge, Kerberus Ports, Paths, Recorder | RPG Maker XP/RGSS1 comum, Uranium, Insurgence, Xenoverse |
| `libmkxp-z31.so` | Ruby 3.1 (`libruby.so`) | `kerberus-uranium-compat.h`, **inalterado** desde a 6.1.2 | Infinite Fusion, jogos feitos para mkxp-z, RGSS2/3 |

Na 6.3 cada motor embute **somente** a própria camada (`binding-mri.cpp`, `#if RAPI_MAJOR < 2`).
Antes, os dois textos Ruby eram compilados nos dois `.so`. A auditoria da APK no workflow v20
falha se `libmkxp-z18.so` contiver o bootstrap moderno ou se `libmkxp-z31.so` contiver `KerberusLegacy18`.

### Ruby 1.8 compilado no CI

O Ruby 1.8 do `libmkxp-z18.so` vem do fork `joiplay/ruby`, branch `ruby_1_8`, no commit
`50783b870e31259ed5c91badbd5c8e41f8e56273`. `scripts/build-ruby18-android.sh` compila esse commit com o
NDK r23 (API 23), com os mesmos patches, flags e saída do passo 3/8 do builder do Termux: núcleo
estático mais as extensões `zlib`, `stringio` e `strscan`, em `build-arm64-v8a/ruby18/`.

No workflow v20, a cópia pré-compilada do checkpoint vira referência. O build falha se `config.h`, os
headers ou a lista de objetos dos dois arquivos `.a` diferirem dela; se tudo bater, a cópia nova
substitui a antiga antes do Gradle. O preflight falha se o commit do CI e o do Termux divergirem.

Uma diferença de receita: o Ruby de apoio carrega o `rbconfig.rb` do próprio host por caminho
absoluto. Com `-I` apontando para a pasta do Ruby 1.8, `-rrbconfig` pegava o `rbconfig.rb` 1.8
gerado e falhava na checagem de versão fora do Termux.

Mudanças no interpretador entram como patch aplicado sobre o commit fixado, como a regra de
superclasse do RGSS1 (`scripts/patch-ruby18-rgss1.py`, 6.3.3). Elas mudam o código de `eval.o`, mas
não `config.h`, headers ou a lista de objetos, então a comparação com a referência continua valendo.
O Oniguruma (6.4.1) é a exceção, conferida exatamente: o `regex.h` do build tem de ser o da
referência mais o campo `kerberus_onig` (o próprio `patch-ruby18-oniguruma.py --regex-h` aplica o
campo numa cópia da referência para comparar), e o núcleo tem de ter os objetos da referência mais
os 19 do Oniguruma (`kerberus_onig.o`, `konig_*.o`).

### Seleção de runtime (`RuntimeSelector.java`)

1. `.kerberus-runtime` na pasta do jogo (`legacy18` ou `modern31`) sempre vence.
2. RGSS2/RGSS3 → modern31.
3. Infinite Fusion (nome da pasta ou título) → modern31.
4. Evidência de jogo feito para mkxp-z/Ruby ≥ 2 → modern31: `mkxp.json`, DLL `x64-msvcrt-ruby3xx.dll`/`msvcrt-ruby2xx.dll`,
   scripts externos em `Data/Scripts/*.rb` (Essentials v19+) ou cabeçalho Essentials ≥ 19.
5. Qualquer outro RGSS1 → legacy18.

Nomes de jogo só rotulam o motivo; nunca forçam o legacy18.

## 2. Bootstrap Legacy18 (Ruby 1.8)

Fontes: `app/jni/mkxp-z/binding/kerberus/legacy18/*.rb`, concatenados por
`tools/gen-legacy18-header.py` em `kerberus-legacy18-compat.rb` (cópia legível) e
`kerberus-legacy18-compat.h` (raw string C++). `--check` falha se o gerado estiver desatualizado
ou se o código usar recursos de Ruby ≥ 1.9. A prova definitiva é a suíte rodando num Ruby 1.8.7 real.

| Arquivo | Conteúdo |
|---|---|
| `00_core.rb` | configuração por ambiente, logs limitados, localização script/section/linha via `caller`, métodos nativos capturados antes dos scripts |
| `10_signature.rb` | parser de assinaturas Win32API |
| `20_memory.rb` | buffers Ruby, heap virtual (ponteiros sem endereço real), UTF-8 ↔ UTF-16LE ↔ Windows-1252 sem `Encoding` |
| `30_recorder.rb` | WINTRACE e marcos de compatibilidade |
| `40_winbridge.rb` | interceptação de `Win32API`, resolução, Deferred Binding, conversão de retorno RGSS1 |
| `45_ini.rb`, `46_registry.rb` | INI nativo (leitura e escrita), registro virtual por jogo |
| `47_input.rb`, `48_audio.rb`, `49_system.rb` | ponte única de input/XInput, ponte única de áudio/MCI/PlaySound, janela lógica, locale, handles, console |
| `50_kernel32.rb` … `53_media_misc.rb` | providers por DLL |
| `54_extended.rb` | 6.4: funções Win32 comuns em scripts de RMXP que a 6.3 não atendia |
| `80_filesystem.rb` | caminhos estilo Windows para `File`/`FileTest`/`IO`/`Dir`/`load`/`save_data` |
| `85_ruby181.rb` | regra de superclasse do Ruby 1.8.1 do RGSS1: registro dos casos (6.3.3) e fallback por texto (6.3.2) |
| `90_ports.rb` | Kerberus Ports |
| `95_frame.rb`, `97_profiles.rb`, `99_activate.rb` | gancho por frame, perfis por evidência, ativação |

A ativação roda uma única vez, depois que `$RGSS_SCRIPTS` foi decodificado e antes da Section000.
Nenhum arquivo do jogo é alterado.

### Regra de superclasse do Ruby 1.8.1 (6.3.2 no bootstrap, 6.3.3 no interpretador)

O RPG Maker XP roda os scripts no Ruby 1.8.1. Quando um script reabre uma classe com outra
superclasse, o 1.8.1 define uma classe nova com esse nome (`eval.c`, `NODE_CLASS`,
`goto override_class`). A partir do 1.8.2 o interpretador lança `superclass mismatch for class X`.
O Pokémon Uranium depende da regra antiga (`Window_PokemonBag`, section 199).

Desde a 6.3.3 a regra está no próprio interpretador. `scripts/patch-ruby18-rgss1.py` altera o
`NODE_CLASS` do `eval.c`: na superclasse diferente, em vez de `rb_raise`, o código salta para a
definição de classe nova, como o `goto override_class` do 1.8.1. Duas diferenças invisíveis para o
jogo: a constante antiga é removida antes (o 1.8.1 a sobrescrevia e avisava "already initialized
constant"), e cada caso é passado ao gancho opcional `$__kerberus_rgss1_class_override`, cujos erros
são ignorados. O patch vale para qualquer superclasse, inclusive `Struct.new(...)` e classes criadas
por `eval` durante o jogo. Ele é aplicado no build Android do CI, no builder do Termux e no Ruby 1.8.7
dos testes de host; `run-legacy18-tests.sh` recusa um Ruby 1.8 sem ele, e a auditoria da APK falha se
o `libmkxp-z18.so` não o contiver.

O bootstrap testa o interpretador com uma classe de prova em um módulo anônimo. Com o patch, ele só
instala o gancho, que grava `[RUBY181_CLASS_OVERRIDE]` com section, linha e as duas superclasses, e
os scripts ficam intactos. Sem o patch (build antigo ou Ruby 1.8.7 comum), vale o fallback da 6.3.2:
depois dos ports, cada `class Nome < CaminhoDeConstante` recebe na mesma linha uma chamada a
`KerberusLegacy18::Ruby181.reopen`, que remove a constante quando a superclasse difere. A numeração
das linhas não muda e blocos `=begin/=end` não são tocados. `KERBERUS_RUBY181=transform` força o
fallback para diagnóstico.

### Regex do RGSS1: Oniguruma para o que o GNU recusa (6.4.1)

O RPG Maker XP compila as expressões regulares com o Oniguruma: o mesmo `Scripts.rxdata` do Uranium
carrega no RPG Maker XP do Windows, e na época só o Oniguruma dava look-behind ao Ruby 1.8. Scripts
de jogo usam, por isso,
look-behind `(?<=...)`/`(?<!...)`, grupos nomeados `(?<nome>...)`, `\h` e quantificadores possessivos. O
motor GNU (`regex.c`) do Ruby 1.8.7 recusa essa sintaxe enquanto lê o script, e a section inteira
vira `SyntaxError`: o Uranium parava na section 253 (GENERATE WIKI PAGES) com
`undefined (?...) sequence: /(?<!\\)"/`. Um literal assim quebra a section mesmo que nunca seja usado.

`scripts/patch-ruby18-oniguruma.py` resolve no interpretador, sem tocar nos scripts:

- `re_compile_pattern` tenta o GNU primeiro. Toda regex que ele aceita continua nele, com o mesmo
  resultado de antes. Só quando ele recusa, o padrão vai para o Oniguruma 6.9.10 com sintaxe Ruby,
  no encoding do `$KCODE` em uso (ASCII, EUC-JP, Shift_JIS ou UTF-8) e com as opções `i`, `x`, `m`.
  Se o Oniguruma também recusar, volta o erro original do GNU; nada vira sucesso falso.
- `struct re_pattern_buffer` ganha o campo `kerberus_onig`. `re_search`, `re_match`,
  `re_adjust_startpos`, `re_compile_fastmap` e `re_free_pattern` desviam para o Oniguruma quando ele
  está preenchido, com os mesmos valores de retorno e registradores do GNU (posição ou tamanho, -1
  sem correspondência, -2 falha). Assim `=~`, `match`, `scan`, `gsub`, `split`, `index`/`rindex`,
  `$~`, `StringScanner`, `Regexp.union`, `Marshal` e a recompilação ao trocar `$KCODE` funcionam
  sem mudança em `re.c`.
- Texto que não é válido no encoding (bytes soltos) é casado byte a byte por uma segunda
  compilação do padrão em ASCII, como o GNU faz, em vez de ser lido fora do limite.
- `Regexp.kerberus_oniguruma` devolve `[versão, regex compiladas pelo Oniguruma]`. O bootstrap
  testa com o padrão do Uranium e grava `[RUBY181_REGEX] RGSS1 ... Oniguruma 6.9.10`, ou um aviso se o
  interpretador não tiver o patch. Não há fallback por texto: reescrever um look-behind mudaria o que
  ele casa.

O Oniguruma vem do commit fixado `4ef89209a239c1aea328cf13c05a2807e5c146d1` (tag `v6.9.10`), baixado
pelos builds e conferido por sha256; o código dele entra sem alteração. `kerberus_onig.c` usa só a API
pública e fica num arquivo próprio, porque `oniguruma.h` e o `regex.h` do Ruby definem
`struct re_registers` de formas diferentes. Os objetos entram no `libruby18-static.a`; só o
`libmkxp-z18.so` os contém. Licença BSD 2-Clause em `THIRD-PARTY-NOTICES.md` e, no APK, em
`assets/licenses/oniguruma-COPYING.txt`.

Relatório de erro: o Ruby 1.8 lança o `SyntaxError` na última linha da section (369 no Uranium); a
linha do erro está na mensagem (`Section253:270: ...`). Desde a 6.4.1 o relatório mostra a linha da
mensagem (`kerberus/exception-line.h`).

## 3. WinBridge

### Resolução de `Win32API.new(dll, função, imports, exports)`

```
provider nativo Kerberus (kernel32, user32, ...)
  -> provider de Port (DLL de fangame substituída)
  -> backend opcional (WinBridge.backend; nil no build normal)
  -> biblioteca real ".so" via MiniFFI
  -> Deferred Binding
```

O objeto devolvido é sempre uma instância real de `Win32API` (MiniFFI). Só `#initialize` e `#call`
são envolvidos. Scripts que reabrem `Win32API`, fazem `alias` de `call` ou testam `is_a?(Win32API)`
continuam funcionando (coberto por teste).

- **DLL**: nome base, sem diferenciar maiúsculas, com ou sem `.dll`, com caminho Windows ou relativo.
  Aliases: `xinput1_1/1_2/1_3/1_4/9_1_0 → xinput`, `wsock32 → ws2_32`, `kernelbase → kernel32`,
  `msvcr*/ucrtbase → msvcrt`, `RGSS1xxE → rgss1`.
- **Função**: diferencia maiúsculas como o `GetProcAddress`. Tenta o nome exato e depois o nome com `A`,
  como o Win32API do RGSS1.
- **Assinatura**: `nil`, `""`, `[]`, `%w()` real, texto literal `"%w(...)"`/`"%W[...]"`, `P`, `S`(=P),
  `I`/`L`/`N`(inteiro 32 bits), `B` (BOOL do MiniFFI), `V`/`"0"`/`0` (void), forma combinada `PPI:I`,
  minúsculas equivalentes, separadores ignorados. Caracteres desconhecidos são ignorados como no
  Win32API e geram aviso `SIGNATURE_ADAPTED`. Tipos impossíveis (número, Hash) geram `TypeError` com
  `WINBRIDGE_SIGNATURE`, dll, função, script e linha.
- **Retorno**: como no RGSS1 de 32 bits. Void devolve `0`. Inteiros viram `long` de 32 bits com sinal
  (`GetAsyncKeyState` pressionada = `-32768`, recém-pressionada = `-32767`). `B` devolve `true/false`. `P` devolve String.
- **Aridade**: número de argumentos diferente do declarado gera o mesmo `wrong number of parameters`
  do Win32API, acrescido de dll/função/assinatura.

### Deferred Binding

Declarar uma API sem provider nunca derruba o jogo. A chamada gera `KerberusLegacy18::WinBridge::Unavailable`
(`RuntimeError`, portanto `rescue` comum funciona):

```
WINBRIDGE_UNAVAILABLE
dll=user32
function=Foo
imports=PPI
exports=I
signature="PPI" / "I"
provider=missing
reason=nenhum provider, port ou backend para esta API
script=Mouse Input
section=Section123
line=48
declared=Section010:12 (Input)
runtime=legacy18
call_count=1
```

O mesmo bloco vai para `kerberus-runtime.log` como `[WINBRIDGE]` na primeira chamada.

### Heap virtual

APIs que devolvem ponteiros (`FormatMessage` com ALLOCATE_BUFFER, `CoTaskMemAlloc`, `GlobalAlloc`...)
recebem handles de um heap virtual. `RtlMoveMemory`, `lstrlenA/W`, `MultiByteToWideChar`,
`WideCharToMultiByte`, `CoTaskMemFree` entendem esses handles. Endereços reais (por exemplo `object_id`
de Bitmap) geram `InvalidPointer` com a explicação, nunca leitura de memória arbitrária.

### Providers

307 registros em 19 nomes de DLL: 182 equivalentes, 74 limitados, 2 de port e 49 indisponíveis
conhecidos. Destaques:

| Área | Implementação |
|---|---|
| Teclado/mouse/toque | `GetAsyncKeyState`, `GetKeyState`, `GetKeyboardState`, `GetCursorPos`, `MapVirtualKey`, `ToUnicode`/`ToAscii` (layout US) sobre o estado SDL **ao vivo** da thread de eventos (6.3.1, ver abaixo) |
| Gamepad | `XInputGetState/SetState/GetCapabilities/GetBatteryInformation` sobre o controle SDL ao vivo; vibração via `SDL_GameControllerRumble`. O controle também aciona as teclas do gamepad de tela (A→C, B→X, X→Z, Y→A, L3→S, R3→D, LB→Q, RB→W, D-pad e analógico esquerdo→setas, zona morta 0x4000 do mkxp-z) |
| Janela | janela lógica `RGSS Player` (HWND 1) cujo retângulo é a resolução RGSS; métricas do desktop virtual |
| INI | `GetPrivateProfileString/Int/Section/SectionNames`, `WritePrivateProfileString`, `Get/WriteProfileString` (win.ini virtual) |
| Registro | `RegOpenKeyEx/RegCreateKeyEx/RegQueryValueEx/RegSetValueEx/RegDelete*/RegCloseKey`, persistido por jogo |
| Tempo | `GetTickCount(64)`, `timeGetTime`, `QueryPerformanceCounter/Frequency` (CLOCK_BOOTTIME), `Sleep`, `timeBeginPeriod` |
| Sistema | idioma e região do Android → LANGID/LCID/GEOID/code page; bateria real; memória; CPUs; versão Windows 8 virtual |
| Arquivos | `CreateFile/ReadFile/WriteFile/GetFileSize/SetFilePointer`, `FindFirstFile/NextFile`, `Get/SetFileAttributes`, `Create/RemoveDirectory`, `Copy/Move/DeleteFile` |
| Console | `AllocConsole`, `WriteConsole`, `GetStdHandle`, `_write` → log do Kerberus |
| Áudio | `PlaySound`, `mciSendString` (open/play/stop/pause/resume/close/setaudio/status) → ponte única de áudio |
| Rede | Winsock sem rede: `WSAStartup` → WSASYSNOTREADY, `socket` → INVALID_SOCKET, demais → SOCKET_ERROR; conversões puras (`htons`, `inet_addr`...) equivalentes |
| Pastas especiais | `SHGetKnownFolderPath/SHGetFolderPath/SHGetSpecialFolderLocation` falham como num sistema sem a pasta, para o jogo usar o próprio fallback e os saves existentes não mudarem de lugar |

### APIs Win32 ampliadas (6.4)

Uma lista de 256 funções Win32 comuns em scripts de RPG Maker XP foi conferida contra o registro real
do WinBridge. 99 não tinham provider, e qualquer chamada parava o jogo com `WINBRIDGE_UNAVAILABLE`.
Entre elas estava `kernel32!SetPriorityClass`, que aparece na análise estática do Pokémon Uranium.
`54_extended.rb` cobre as 99, e a mesma conferência agora dá zero faltando. Cada uma faz a coisa de
verdade ou devolve a falha documentada do Windows:

| Área | Comportamento |
|---|---|
| Processo | `Set/GetPriorityClass`, `Set/GetThreadPriority`: o Android controla a prioridade; `Set*` falha com `ERROR_ACCESS_DENIED`, `Get*` informa o normal. `ExitProcess`/`TerminateProcess` (só o próprio processo) encerram o jogo. `GetCommandLine` devolve o executável do jogo |
| Instância única | `CreateMutex/OpenMutex/ReleaseMutex` com nomes por processo; a segunda criação devolve `ERROR_ALREADY_EXISTS` |
| Texto e memória | `lstrcpy/lstrcpyn/lstrcat/lstrcmp/lstrcmpi`, `memcpy/memmove/memset/strlen`, `sprintf`/`wsprintf` (formato C), `rand/srand` com o gerador exato do MSVCRT, `CharUpper/CharLower`, `VirtualAlloc/VirtualFree` no heap virtual, `RtlZeroMemory` do ntdll |
| Data e hora | `GetLocalTime`, `GetSystemTime`, `GetTimeZoneInformation`, `GetDateFormat`/`GetTimeFormat` com os formatos do Windows no idioma do aparelho (pt, es, en) |
| Arquivos e discos | `GetDiskFreeSpaceEx` (statvfs real), `GetShortPathName`, `GetFullPathName`, `GetTempFileName`; unidade virtual `C:` para `GetLogicalDrives`, `GetDriveType`, `GetVolumeInformation` |
| Janela e tela | `EnumDisplaySettings` e `ChangeDisplaySettings` com um único modo, a resolução do jogo; `GetWindowPlacement`, `GetSysColor`, `WindowFromPoint`, menus inexistentes, cursores como handles virtuais, `GetKeyNameText`, `GetPixel` da tela do jogo (uma captura por quadro) |
| Área de transferência | `Open/Close/Empty/GetClipboardData/SetClipboardData/IsClipboardFormatAvailable` sobre a área de transferência do Android (CF_TEXT em Windows-1252, CF_UNICODETEXT) |
| Joystick | `joyGetPosEx`, `joyGetPos`, `joyGetDevCaps`, `joyGetNumDevs` do winmm sobre o controle SDL, para scripts antigos de joypad |
| Rede | `wininet` e `URLDownloadToFile` seguem a política do Winsock: sem conexão, com os códigos de erro do Windows |
| Outros | `GetProcessMemoryInfo` real (`/proc/self/status`), `RegEnumKeyEx` no registro virtual, `SetEnvironmentVariable` no ambiente virtual |

Sem efeito possível no Android e com falha documentada: `Beep`, `MessageBeep`, `SetTimer`,
`SetKeyboardState`, `SHFileOperation`, `SHBrowseForFolder`, `ShellExecuteEx`, `system`, `SetPixel`.

A análise estática do launcher usa os mesmos aliases de DLL e o mesmo sufixo `A` do WinBridge
(`xinput1_3`, `xinput9_1_0`, `RGSS Linker`...). Um teste de host compara as duas listas de aliases.

### Pulo de quadros do RGSS1 e desempenho do Ruby 1.8 (6.4)

O RGSS1 pula o desenho de quadros quando o jogo atrasa, e o jogo mantém a velocidade. O mkxp-z vem com
isso desligado, então num aparelho lento o jogo roda em câmera lenta. O legacy18 liga
`Graphics.frameskip` na ativação (`frameskip=off` em `.kerberus-options` desliga).

`scripts/patch-ruby18-performance.py` muda números do Ruby 1.8, não algoritmos, e acrescenta
`GC.kerberus_stats`. Medido no host (x86-64, Ruby 1.8.7 com os patches), com uma carga no formato de
um jogo Essentials carregado (cerca de 750 mil objetos vivos):

| Configuração | Carga leve (4000 quadros): coletas, tempo total de GC, pior pausa | Carga pesada (2000 quadros): coletas, tempo, pior pausa |
|---|---|---|
| Ruby 1.8.7 original (8 MB) | 47, 488 ms, 13,5 ms | 173, 2119 ms, 16,4 ms |
| **Kerberus 6.4 (16 MB)** | **27, 306 ms, 17,2 ms** | **90, 1404 ms, 20,3 ms** |
| 32 MB | 23, 290 ms, 19,6 ms | 74, 1235 ms, 24,0 ms |
| 8 MB com heap inicial de 100 mil objetos | – | 168, 2448 ms, 22,7 ms |

Um limite maior troca muitas pausas curtas por poucas pausas um pouco mais longas. Com o pulo de
quadros ligado, menos coletas significam menos engasgos; o heap inicial maior piorou tudo e ficou de
fora. `gc_malloc_limit=4..512` (MB) em `.kerberus-options` ajusta por jogo. O cache global de métodos
passou de 2048 para 16384 entradas: 3% a 13% mais rápido em chamadas variadas, ao custo de cerca de 768 KiB de memória (48 bytes por entrada no ARM64).

### Relatório `[PERF]` (6.4)

A cada 1200 quadros (cerca de 30 segundos) o legacy18 grava no log do jogo uma linha como:

```
[PERF] quadros=1200 fps=39.8 quadro_medio=25.1ms p95<=25ms pior=61ms lentos(>50ms)=2 gc=9 (180ms no total, pior 24ms, heap 752773 objetos) frameskip=on
```

O tempo é medido entre chamadas de `Graphics.update`, incluindo a espera de ritmo do próprio mkxp-z.
É esse número que diz se o gargalo é o Ruby, o desenho ou a coleta de lixo num aparelho real.

### Input ao vivo (6.3.1)

`Input.pressex?`, `Input.mouse_x/mouse_y` e `Input::Controller` do mkxp-z leem uma cópia do estado
que só o `Input.update` nativo atualiza. O Essentials v15–v17 (Uranium, Insurgence, Xenoverse)
substitui `Input.update` pela própria leitura via `GetAsyncKeyState` e nunca chama o nativo: a cópia
ficava vazia e nenhum controle respondia. No legacy18, `KerberusNative` expõe as tabelas vivas da
thread de eventos SDL (`key_down?` com a tabela VK→scancode do próprio mkxp-z, `mouse_position` com
a mesma transformação de `mouse_x`, `pad_buttons`, `pad_axis`), como o Windows responde a partir do
teclado real. Sem esses métodos (build antigo), a cópia do mkxp-z continua como fallback. O bit 0 do
`GetAsyncKeyState` sai na primeira consulta depois que a tecla desce. O modern31 não muda: a saída
do pré-processador do `binding-mri.cpp` do modern31 é idêntica byte a byte.

### Desempenho (host x86-64, Ruby 1.8.7)

| Caminho | Antes da otimização | 6.3 |
|---|---|---|
| `GetAsyncKeyState` por chamada | 9,4 µs | 4,3 µs (6.3.1, leitura ao vivo) |
| `GetKeyboardState` (256 teclas) | 0,91 ms | 0,097 ms |
| `File.exist?` acerto | – | 1,3 µs |
| `File.exist?` falha resolvida por cache | – | 2,4 µs |

Os métodos nativos ficam em cache como `Method`, sem alocar chave por chamada; o controle só é
consultado para as teclas que ele aciona. O gravador faz um incremento inteiro por chamada e
escreve arquivo só na primeira chamada de cada API, em bloqueios, a cada 600 frames se houver
mudança e no encerramento.

## 4. Kerberus Ports

Registro declarativo inspirado no mecanismo de patches do Kawariki (ideia, não código): cada port
tem marcadores (todos precisam existir na section), condição opcional e transformação em memória.
Ports que substituem uma section declaram os nomes que fornecem; nomes do original sem equivalente
geram `PORT_COVERAGE` (ou `PORT_SKIPPED` em ports estritos). Falha de transformação gera `PORT_FAILED`
e mantém a section original.

| Id | Detecta | Substitui por |
|---|---|---|
| `rgss_linker` | `RGSSLinker_Initialize` + `def load_module` | `load_module` nativo; `RGSS FmodEx!Init_FmodEx` → áudio nativo; outras extensões → erro preciso |
| `fmodex_audio` | `Init_FmodEx` + `LOOP_TABLE` + `bgmvolume` | API de áudio Essentials sobre a ponte única, com volume do menu de opções e fade-in real |
| `audio_dll` | `class AudioContext` + `AudioContextInitialize` + `module AudioState` | mesma API de áudio; `AudioState` mínimo com erro preciso para métodos desconhecidos |
| `gif_dll` | `module GifLibrary` + `class GifBitmap` + `GifToPngFilesInMemory` | `GifBitmap` sobre Bitmap animado nativo (libnsgif), com hue e quadros |
| `klein_bitmap` | `KLEIN_BFUNCS_DLL` + `def klein_dll` + `compare_klein_bitmaps` | scroll, `to_negative`, `modify_color`, `to_retro` (4 tons documentados), `add_outline` (documentado), pattern, comparação; paletas proprietárias → erro preciso |
| `bitmap_memory` | `def pbSetResizeFactor2` + `RtlMoveMemory_pi` + `def saveToPng` | `getData/setData/asOpaque/saveToPng` via `raw_data`; escala de janela fixa (superfície Android) |
| `font_installer` | `FontInstaller` + `AddFontResource` + `WriteProfileString` | instalação no sistema ignorada; `Fonts/` já é indexado pelo mkxp-z |
| `text_entry` | `class Window_TextEntry_Keyboard` + `@toUnicode` + `GetKeyboardState` | texto do teclado Android/IME via `Input.gets`; teclado abre com a janela |
| `unicode_pointer` | `def getUnicodeStringFromAnsi(addr)` + `def getUnicodeString(addr)` | leitura de buffers Ruby/heap virtual |
| `zeus_video` | `:Zeus_Video_Player` + `MciSendString` + `ZVP_OldAviMode` | `Graphics.play_movie` nativo com OGV equivalente; sem OGV → vídeo pulado com diagnóstico |

`KERBERUS_COMPAT_MODE=off` (opção existente do launcher) desliga os Ports; o WinBridge continua ativo.

## 5. Filesystem estilo Windows

`80_filesystem.rb` envolve `File`/`FileTest` (predicados, `size`, `mtime`, `stat`, `open`, `delete`,
`rename`), `IO.read/readlines/foreach`, `Dir.entries/foreach/glob/[]/chdir/mkdir/rmdir`, `Kernel#load`
e `save_data`. O caminho exato é tentado primeiro; só em falha `\` vira `/` e cada componente é
comparado sem diferenciar maiúsculas contra um índice de diretório validado por `mtime`. Escrita num
nome que já existe com outra caixa reutiliza o arquivo (NTFS), sem criar duplicata. O Ruby 1.8 não
aceita reexecutar `File#initialize` depois de falhar, por isso a resolução acontece antes da abertura.

## 6. Ciclo de vida RGSS (C++)

No mkxp-z, `dispose` e `disposed?` chamavam `getPrivateData`, que lança
`No instance data for variable (missing call to super?)` antes da checagem `if (!d)`, que nunca era
alcançada. Subclasses do Essentials como `LargePlane < Plane` nunca chamam o `initialize` da base e
chamam `super` no `dispose`. No legacy18, `dispose` sem objeto nativo agora não faz nada e `disposed?`
devolve `true`. Acesso a propriedades continua sendo erro, agora com o nome da classe. O modern31 não mudou.

## 7. Diagnósticos

| Arquivo | Onde | Conteúdo |
|---|---|---|
| `kerberus-runtime.log` | pasta do jogo (já existia) | `[BOOT]`, `[Script]`, `[MILESTONE]`, `[WINBRIDGE]`, `[PORT_*]`, `[RUBY181_*]`, `[RUBY_EXCEPTION]` com script, section, linha, classe, mensagem e backtrace anotado (6.3.2: quadros `SectionNNN:linha` do Ruby 1.8 lidos sem corromper o backtrace) |
| `events.log` | armazenamento privado do app | eventos de compatibilidade (1 por tipo+API) |
| `winbridge/wintrace.txt` | armazenamento privado do app | resumo WINTRACE |
| `milestones.log` | armazenamento privado do app | marcos com data e runtime |
| `winbridge/registry.dat`, `winbridge/Windows/` | armazenamento privado do app | registro e pasta Windows virtuais |

O launcher mostra em **Logs → Mostrar diagnóstico** o estado de testes (Não testado → Boot → Title
→ Mapa → Batalha → Save → Jogabilidade prolongada), o resumo WINTRACE e a análise estática. A análise
estática usa o catálogo do runtime que vai rodar o jogo e deixa claro que são APIs `DETECTED_STATIC`.

Marcos: BOOT é gravado pelo C++ nos dois runtimes (última section começou). TITLE, MAP (mapa e
movimento), BATTLE, SAVE e LONG_PLAY (60 min em mapa) são gravados pelo legacy18.

### Opções por jogo (`.kerberus-options` na pasta do jogo)

```
wintrace=off|summary|detail
filesystem=windows|native
dump_scripts=on|off          # grava as sections transformadas para depuração
ports_disable=klein_bitmap,gif_dll
frameskip=on|off             # 6.4: pulo de quadros do RGSS1 (padrão on)
gc_malloc_limit=16           # 6.4: MB de alocação entre coletas do Ruby 1.8 (4 a 512)
```

Chaves e valores fora dessa lista são recusados.

## 8. Testes

| Suíte | Onde roda | O que prova |
|---|---|---|
| `tests/legacy18/` (17 arquivos, 642 verificações) | Ruby 1.8.7 real com os patches RGSS1, de desempenho e Oniguruma | assinaturas, aliases, deferred binding, INI, registro, input ao vivo com o `Input.update` do Essentials, regra de superclasse do Ruby 1.8.1 no interpretador e no fallback, regex do RGSS1 (look-behind do Uranium, grupos nomeados, encodings, GNU inalterado), XInput, memória/texto, filesystem, semântica Ruby 1.8 sem monkey patch nas classes centrais, áudio/MCI, ports, WINTRACE, marcos, ativação, opções por jogo |
| `tests/native/` (7 + 8 verificações) | extensão Ruby 1.8 compilada contra os headers reais do mkxp-z; C++ do host | ciclo de vida LargePlane (falha com o header antigo e passa com o novo); linha do `SyntaxError` no relatório de erro |
| `tests/modern31/` | Ruby 3.1 | bootstrap moderno idêntico ao validado (sha256), executa com scripts estilo Infinite Fusion, nenhum código legacy18 |
| `tests/*HostTest.java` | JDK | seleção de runtime (14 casos, 3 proteções do Infinite Fusion), estado de compatibilidade, opções |
| `tools/host-compile-check.sh` | clang do host | arquivos C++ alterados compilam nos dois runtimes |

`scripts/run-all-host-tests.sh` roda tudo. O workflow v20 compila um Ruby 1.8.7 real a partir da tag
`v1_8_7_374` do repositório oficial, roda as suítes e só então compila a APK.

## 9. Backend opcional de DLL (futuro)

`KerberusLegacy18::WinBridge.backend` é consultado depois dos providers e ports e antes do Deferred
Binding. Deve responder `resolve(dll, função, assinatura)` com um `Provider` ou `nil`. Nenhum backend
(Box64, Hangover, FEX, Winlator) está integrado: seria o último recurso para uma DLL impossível de portar,
fora do caminho normal.

## 10. Projetos estudados

| Projeto | O que foi aproveitado |
|---|---|
| mkxp-z (upstream e este fork) | semântica de MiniFFI, `pressex?` com VK, `Input::Controller`, Bitmap animado, `raw_data`, `to_file` |
| Ruby 1.8 `ext/Win32API` | regras de assinatura (caractere a caractere, desconhecidos ignorados), `INT2NUM(long)` no retorno, void = 0, tentativa `nameA` |
| Kawariki (GPLv3) | ideia do registro de patches com condições e ações e de ports por script; **nenhum código copiado**. Os stubs Win32API do Kawariki devolvem sucesso genérico, o oposto do que o Kerberus quer |
| Documentação Win32 (comportamento público) | regras de INI, registro, `GetAsyncKeyState`/`GetKeyState`, XInput, Winsock, MCI |
| Klein Bitmap Functions (descrição pública) | semântica de `to_retro(c1..c4)` e `add_outline(cor, tamanho)` |
| Oniguruma 6.9.10 (BSD 2-Clause) | motor de regex para a sintaxe do RGSS1 que o GNU recusa; código usado **sem alteração**, baixado pelo build no commit fixado (`THIRD-PARTY-NOTICES.md`) |
| Ruby 1.9 `re.c` (comportamento) | mesmo mapeamento de `range` do `re_search` para `onig_search` |
