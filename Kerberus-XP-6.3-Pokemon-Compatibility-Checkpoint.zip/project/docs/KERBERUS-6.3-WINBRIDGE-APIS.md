# Kerberus XP 6.3 — APIs do WinBridge (legacy18)

Gerado por `tools/gen-winbridge-api-list.py` a partir de `api-catalog-legacy18.tsv`,
que por sua vez é gerado do registro real de providers do bootstrap Ruby 1.8.

| Entradas no catálogo | Novas em relação à 6.1.2 (v19) |
|---|---|
| 531 | 452 |

Legenda: **equivalente** = mesmo comportamento observável; **limitada** = falha documentada
do Windows ou efeito parcial descrito; **port/perfil** = substituída por Kerberus Ports;
**indisponível** = chamada gera `WINBRIDGE_UNAVAILABLE` com dll/função/script/linha.

## advapi32

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `GetUserNameA` | 2 | equivalente | não | nome virtual Player; nenhum dado pessoal do aparelho |
| `GetUserName` | 2 | equivalente | não | nome virtual Player; nenhum dado pessoal do aparelho |
| `RegCloseKey` | 1 | equivalente | não | registro virtual persistente por jogo |
| `RegCreateKeyA` | 3 | equivalente | sim | registro virtual persistente por jogo |
| `RegCreateKey` | 3 | equivalente | sim | registro virtual persistente por jogo |
| `RegCreateKeyExA` | 9 | equivalente | sim | registro virtual persistente por jogo |
| `RegCreateKeyEx` | 9 | equivalente | sim | registro virtual persistente por jogo |
| `RegDeleteKeyA` | 2 | equivalente | sim | registro virtual persistente por jogo |
| `RegDeleteKey` | 2 | equivalente | sim | registro virtual persistente por jogo |
| `RegDeleteValueA` | 2 | equivalente | sim | registro virtual persistente por jogo |
| `RegDeleteValue` | 2 | equivalente | sim | registro virtual persistente por jogo |
| `RegEnumKeyExA` | 8 | equivalente | sim | subchaves do registro virtual |
| `RegEnumKeyEx` | 8 | equivalente | sim | subchaves do registro virtual |
| `RegFlushKey` | 1 | equivalente | sim | registro virtual persistido a cada escrita |
| `RegOpenKeyA` | 3 | equivalente | sim | registro virtual persistente por jogo |
| `RegOpenKey` | 3 | equivalente | sim | registro virtual persistente por jogo |
| `RegOpenKeyExA` | 5 | equivalente | não | registro virtual persistente por jogo |
| `RegOpenKeyEx` | 5 | equivalente | sim | registro virtual persistente por jogo |
| `RegQueryValueExA` | 6 | equivalente | não | registro virtual persistente por jogo |
| `RegQueryValueEx` | 6 | equivalente | sim | registro virtual persistente por jogo |
| `RegSetValueExA` | 6 | equivalente | sim | registro virtual persistente por jogo |
| `RegSetValueEx` | 6 | equivalente | sim | registro virtual persistente por jogo |

## audio

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `AudioContextFadeIn` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `AudioContextFadeOut` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `AudioContextFree` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `AudioContextGetPosition` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `AudioContextInitialize` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `AudioContextIsActive` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `AudioContextPlay` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `AudioContextSEPlay` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `AudioContextSetVolume` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `AudioContextStop` | * | port/perfil | sim | substituida pelo port audio_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |

## gdi32

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `AddFontResourceA` | 1 | equivalente | não | fontes em Fonts/ ja sao carregadas pelo mkxp-z; outras pastas nao |
| `AddFontResource` | 1 | equivalente | não | fontes em Fonts/ ja sao carregadas pelo mkxp-z; outras pastas nao |
| `AddFontResourceExA` | 3 | equivalente | sim | fontes em Fonts/ ja sao carregadas pelo mkxp-z |
| `AddFontResourceEx` | 3 | equivalente | sim | fontes em Fonts/ ja sao carregadas pelo mkxp-z |
| `BitBlt` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `CreateCompatibleBitmap` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `CreateCompatibleDC` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `CreateFontA` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `CreateFont` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `CreateFontIndirectA` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `CreateFontIndirect` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `DeleteDC` | 1 | equivalente | sim | DCs virtuais |
| `DeleteObject` | 1 | equivalente | sim | objetos GDI virtuais |
| `GetDIBits` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `GetDeviceCaps` | 2 | equivalente | sim | DC virtual: 96 DPI, 32 bpp, resolucao do jogo |
| `GetPixel` | 3 | equivalente | sim | pixel da tela do jogo (Graphics.snap_to_bitmap, uma captura por quadro) |
| `GetStockObject` | 1 | equivalente | sim | objetos de estoque como handles virtuais |
| `GetTextExtentPoint32A` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `GetTextExtentPoint32` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `RemoveFontResourceA` | 1 | equivalente | sim | fonte continua indexada pelo mkxp-z |
| `RemoveFontResource` | 1 | equivalente | sim | fonte continua indexada pelo mkxp-z |
| `SelectObject` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `SetDIBitsToDevice` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `SetPixel` | 4 | limitada | sim | a tela do jogo nao aceita desenho GDI; CLR_INVALID |
| `StretchBlt` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `TextOutA` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |
| `TextOut` | * | indisponível (erro preciso) | sim | desenho GDI sem superficie: use Bitmap do RGSS |

## gif

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `CopyDataString` | * | port/perfil | sim | substituida pelo port gif_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `FreeDataString` | * | port/perfil | sim | substituida pelo port gif_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `GifToPngFiles` | * | port/perfil | sim | substituida pelo port gif_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `GifToPngFilesInMemory` | * | port/perfil | sim | substituida pelo port gif_dll quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |

## kernel32

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `AllocConsole` | 0 | equivalente | sim | console virtual escrito no log do Kerberus |
| `AttachConsole` | 1 | limitada | sim | sem console de processo pai no Android |
| `Beep` | 2 | limitada | sim | sem alto-falante de sistema; falha documentada |
| `CloseHandle` | 1 | equivalente | sim | handles virtuais |
| `CopyFileA` | 3 | equivalente | sim | copia binaria |
| `CopyFile` | 3 | equivalente | sim | copia binaria |
| `CreateConsoleScreenBuffer` | 5 | equivalente | sim | buffer de console virtual |
| `CreateDirectoryA` | 2 | equivalente | sim | Dir.mkdir com resolucao estilo Windows |
| `CreateDirectory` | 2 | equivalente | sim | Dir.mkdir com resolucao estilo Windows |
| `CreateFileA` | 7 | equivalente | sim | arquivos do jogo via File; console via log |
| `CreateFile` | 7 | equivalente | sim | arquivos do jogo via File; console via log |
| `CreateMutexA` | 3 | equivalente | sim | objetos nomeados deste processo; ERROR_ALREADY_EXISTS na segunda criacao |
| `CreateMutex` | 3 | equivalente | sim | objetos nomeados deste processo; ERROR_ALREADY_EXISTS na segunda criacao |
| `DeleteFileA` | 1 | equivalente | sim | File.delete |
| `DeleteFile` | 1 | equivalente | sim | File.delete |
| `ExitProcess` | 1 | equivalente | sim | encerra o jogo |
| `FindClose` | 1 | equivalente | sim | handle de busca virtual |
| `FindFirstFileA` | 2 | equivalente | sim | Dir com curinga sem diferenciar maiusculas |
| `FindFirstFile` | 2 | equivalente | sim | Dir com curinga sem diferenciar maiusculas |
| `FindNextFileA` | 2 | equivalente | sim | Dir com curinga |
| `FindNextFile` | 2 | equivalente | sim | Dir com curinga |
| `FlushFileBuffers` | 1 | equivalente | sim | IO#flush |
| `FormatMessageA` | 5 | equivalente | não | tabela de mensagens de sistema comuns; demais codigos falham como no Windows |
| `FormatMessage` | 5 | equivalente | sim | tabela de mensagens de sistema comuns; demais codigos falham como no Windows |
| `FreeConsole` | 0 | equivalente | sim | console virtual |
| `FreeLibrary` | 1 | equivalente | não | modulos virtuais |
| `GetACP` | 0 | equivalente | sim | code page ANSI do idioma do Android |
| `GetCommandLineA` | 0 | equivalente | sim | linha de comando do executavel do jogo, sem argumentos |
| `GetCommandLine` | 0 | equivalente | sim | linha de comando do executavel do jogo, sem argumentos |
| `GetCommandLineW` | 0 | equivalente | sim | linha de comando do executavel do jogo, sem argumentos |
| `GetComputerNameA` | 2 | equivalente | sim | nome virtual KERBERUS (nenhum dado pessoal) |
| `GetComputerName` | 2 | equivalente | sim | nome virtual KERBERUS (nenhum dado pessoal) |
| `GetConsoleWindow` | 0 | equivalente | sim | console virtual sem janela |
| `GetCurrentDirectoryA` | 2 | equivalente | sim | Dir.pwd com separadores Windows |
| `GetCurrentDirectory` | 2 | equivalente | sim | Dir.pwd com separadores Windows |
| `GetCurrentProcess` | 0 | equivalente | não | pseudo-handle -1 documentado |
| `GetCurrentProcessId` | 0 | equivalente | sim | getpid do Android |
| `GetCurrentThread` | 0 | equivalente | sim | pseudo-handle -2 documentado |
| `GetCurrentThreadId` | 0 | equivalente | não | gettid do Android |
| `GetDateFormatA` | 6 | equivalente | sim | formatos de data do Windows no idioma do aparelho (pt/es/en) |
| `GetDateFormat` | 6 | equivalente | sim | formatos de data do Windows no idioma do aparelho (pt/es/en) |
| `GetDiskFreeSpaceExA` | 4 | equivalente | sim | statvfs da pasta pedida (ou da pasta do jogo) |
| `GetDiskFreeSpaceEx` | 4 | equivalente | sim | statvfs da pasta pedida (ou da pasta do jogo) |
| `GetDriveTypeA` | 1 | equivalente | sim | C: fixa; demais letras inexistentes |
| `GetDriveType` | 1 | equivalente | sim | C: fixa; demais letras inexistentes |
| `GetEnvironmentVariableA` | 3 | limitada | sim | ambiente virtual minimo; demais variaveis ausentes |
| `GetEnvironmentVariable` | 3 | limitada | sim | ambiente virtual minimo; demais variaveis ausentes |
| `GetExitCodeProcess` | 2 | equivalente | sim | proprio processo: STILL_ACTIVE |
| `GetFileAttributesA` | 1 | equivalente | sim | atributos a partir do sistema de arquivos Android |
| `GetFileAttributes` | 1 | equivalente | sim | atributos a partir do sistema de arquivos Android |
| `GetFileSize` | 2 | equivalente | sim | tamanho do arquivo |
| `GetFullPathNameA` | 4 | equivalente | sim | caminho absoluto a partir da pasta atual, separadores Windows |
| `GetFullPathName` | 4 | equivalente | sim | caminho absoluto a partir da pasta atual, separadores Windows |
| `GetLastError` | 0 | equivalente | não | ultimo erro definido pelos providers |
| `GetLocalTime` | 1 | equivalente | sim | hora local do aparelho |
| `GetLocaleInfoA` | 4 | limitada | sim | somente LOCALE_SISO639LANGNAME/SISO3166CTRYNAME/IDEFAULTANSICODEPAGE |
| `GetLocaleInfo` | 4 | limitada | sim | somente LOCALE_SISO639LANGNAME/SISO3166CTRYNAME/IDEFAULTANSICODEPAGE |
| `GetLogicalDrives` | 0 | equivalente | sim | unidade virtual C: |
| `GetModuleFileNameA` | 3 | equivalente | sim | caminho real do jogo com separadores Windows |
| `GetModuleFileName` | 3 | equivalente | sim | caminho real do jogo com separadores Windows |
| `GetModuleHandleA` | 1 | equivalente | sim | modulo do jogo e DLLs com provider Kerberus |
| `GetModuleHandle` | 1 | equivalente | sim | modulo do jogo e DLLs com provider Kerberus |
| `GetNativeSystemInfo` | 1 | limitada | sim | CPUs reais; arquitetura x86 como um RGSS 32 bits |
| `GetOEMCP` | 0 | equivalente | sim | code page OEM |
| `GetPriorityClass` | 1 | equivalente | sim | NORMAL_PRIORITY_CLASS |
| `GetPrivateProfileIntA` | 4 | equivalente | sim | parser INI nativo |
| `GetPrivateProfileInt` | 4 | equivalente | sim | parser INI nativo |
| `GetPrivateProfileSectionA` | 4 | equivalente | sim | parser INI nativo |
| `GetPrivateProfileSection` | 4 | equivalente | sim | parser INI nativo |
| `GetPrivateProfileSectionNamesA` | 3 | equivalente | sim | parser INI nativo |
| `GetPrivateProfileSectionNames` | 3 | equivalente | sim | parser INI nativo |
| `GetPrivateProfileStringA` | 6 | equivalente | não | parser INI nativo (regras do Windows) |
| `GetPrivateProfileString` | 6 | equivalente | não | parser INI nativo (regras do Windows) |
| `GetProcAddress` | 2 | equivalente | sim | endereco virtual somente para funcoes com provider |
| `GetProcessHeap` | 0 | equivalente | sim | heap virtual unico |
| `GetProfileIntA` | 3 | equivalente | sim | win.ini virtual do jogo |
| `GetProfileInt` | 3 | equivalente | sim | win.ini virtual do jogo |
| `GetProfileStringA` | 5 | equivalente | sim | win.ini virtual do jogo |
| `GetProfileString` | 5 | equivalente | sim | win.ini virtual do jogo |
| `GetShortPathNameA` | 3 | equivalente | sim | sem nomes 8.3: o caminho curto e o proprio caminho |
| `GetShortPathName` | 3 | equivalente | sim | sem nomes 8.3: o caminho curto e o proprio caminho |
| `GetStdHandle` | 1 | equivalente | sim | handles do console virtual |
| `GetSystemDefaultLCID` | 0 | equivalente | sim | idioma do Android convertido para LANGID |
| `GetSystemDefaultLangID` | 0 | equivalente | sim | idioma do Android convertido para LANGID |
| `GetSystemDefaultUILanguage` | 0 | equivalente | sim | idioma do Android convertido para LANGID |
| `GetSystemDirectoryA` | 2 | equivalente | sim | pasta System32 virtual por jogo |
| `GetSystemDirectory` | 2 | equivalente | sim | pasta System32 virtual por jogo |
| `GetSystemInfo` | 1 | limitada | sim | CPUs reais; arquitetura x86 como um RGSS 32 bits |
| `GetSystemPowerStatus` | 1 | equivalente | não | bateria via SDL_GetPowerInfo |
| `GetSystemTime` | 1 | equivalente | sim | hora UTC do aparelho |
| `GetTempFileNameA` | 4 | equivalente | sim | arquivo temporario unico na pasta pedida |
| `GetTempFileName` | 4 | equivalente | sim | arquivo temporario unico na pasta pedida |
| `GetTempPathA` | 2 | equivalente | sim | pasta temporaria virtual por jogo |
| `GetTempPath` | 2 | equivalente | sim | pasta temporaria virtual por jogo |
| `GetThreadLocale` | 0 | equivalente | sim | idioma do Android convertido para LANGID |
| `GetThreadPriority` | 1 | equivalente | sim | THREAD_PRIORITY_NORMAL |
| `GetTickCount` | 0 | equivalente | não | CLOCK_BOOTTIME em ms (32 bits, reinicia como no Windows) |
| `GetTickCount64` | 0 | equivalente | não | CLOCK_BOOTTIME em ms |
| `GetTimeFormatA` | 6 | equivalente | sim | formatos de hora do Windows no idioma do aparelho |
| `GetTimeFormat` | 6 | equivalente | sim | formatos de hora do Windows no idioma do aparelho |
| `GetTimeZoneInformation` | 1 | equivalente | sim | fuso do aparelho (Bias); horario de verao nao informado |
| `GetUserDefaultLCID` | 0 | equivalente | sim | idioma do Android convertido para LANGID |
| `GetUserDefaultLangID` | 0 | equivalente | não | idioma do Android convertido para LANGID |
| `GetUserDefaultUILanguage` | 0 | equivalente | sim | idioma do Android convertido para LANGID |
| `GetUserGeoID` | 1 | equivalente | não | regiao do Android convertida para GEOID |
| `GetVersion` | 0 | limitada | sim | Windows 8 (6.2.9200), como o Windows 10 reporta a um jogo sem manifesto |
| `GetVersionExA` | 1 | limitada | sim | Windows 8 (6.2.9200), como o Windows 10 reporta a um jogo sem manifesto |
| `GetVersionEx` | 1 | limitada | sim | Windows 8 (6.2.9200), como o Windows 10 reporta a um jogo sem manifesto |
| `GetVolumeInformationA` | 8 | equivalente | sim | volume virtual KERBERUS em C: |
| `GetVolumeInformation` | 8 | equivalente | sim | volume virtual KERBERUS em C: |
| `GetWindowsDirectoryA` | 2 | equivalente | sim | pasta Windows virtual por jogo (fora da pasta do jogo) |
| `GetWindowsDirectory` | 2 | equivalente | sim | pasta Windows virtual por jogo (fora da pasta do jogo) |
| `GlobalAlloc` | 2 | equivalente | sim | heap virtual (ate 64 KiB por bloco) |
| `GlobalFree` | 1 | equivalente | sim | heap virtual |
| `GlobalLock` | 1 | equivalente | sim | bloco fixo do heap virtual |
| `GlobalMemoryStatus` | 1 | equivalente | sim | memoria total do SDL e MemAvailable do Linux (limitada a 4 GiB) |
| `GlobalMemoryStatusEx` | 1 | equivalente | sim | memoria total do SDL e MemAvailable do Linux |
| `GlobalUnlock` | 1 | equivalente | sim | bloco fixo do heap virtual |
| `HeapAlloc` | 3 | equivalente | sim | heap virtual |
| `HeapFree` | 3 | equivalente | sim | heap virtual |
| `IsDebuggerPresent` | 0 | equivalente | sim | sem depurador |
| `LoadLibraryA` | 1 | equivalente | não | sucesso apenas para DLLs com provider/port; demais = ERROR_MOD_NOT_FOUND |
| `LoadLibrary` | 1 | equivalente | não | sucesso apenas para DLLs com provider/port; demais = ERROR_MOD_NOT_FOUND |
| `LoadLibraryExA` | 1 | equivalente | sim | sucesso apenas para DLLs com provider/port |
| `LoadLibraryEx` | 1 | equivalente | sim | sucesso apenas para DLLs com provider/port |
| `LocalAlloc` | 2 | equivalente | sim | heap virtual (ate 64 KiB por bloco) |
| `LocalFree` | 1 | equivalente | sim | heap virtual |
| `MoveFileA` | 2 | equivalente | sim | File.rename |
| `MoveFile` | 2 | equivalente | sim | File.rename |
| `MoveFileExA` | 3 | equivalente | sim | File.rename (MOVEFILE_REPLACE_EXISTING suportado) |
| `MoveFileEx` | 3 | equivalente | sim | File.rename (MOVEFILE_REPLACE_EXISTING suportado) |
| `MultiByteToWideChar` | 6 | equivalente | sim | UTF-8 (65001) e Windows-1252 (ACP) sem Encoding |
| `OpenMutexA` | 3 | equivalente | sim | objetos nomeados deste processo |
| `OpenMutex` | 3 | equivalente | sim | objetos nomeados deste processo |
| `OutputDebugStringA` | 1 | equivalente | sim | texto enviado ao log do Kerberus |
| `OutputDebugString` | 1 | equivalente | sim | texto enviado ao log do Kerberus |
| `QueryPerformanceCounter` | 1 | equivalente | não | CLOCK_BOOTTIME em ns |
| `QueryPerformanceFrequency` | 1 | equivalente | não | 1 GHz (contador em ns) |
| `ReadConsoleA` | 4 | limitada | sim | sem entrada de console no Android |
| `ReadConsole` | 4 | limitada | sim | sem entrada de console no Android |
| `ReadFile` | 5 | equivalente | sim | leitura binaria |
| `ReleaseMutex` | 1 | equivalente | sim | objetos nomeados deste processo |
| `RemoveDirectoryA` | 1 | equivalente | sim | Dir.rmdir |
| `RemoveDirectory` | 1 | equivalente | sim | Dir.rmdir |
| `RtlFillMemory` | 3 | equivalente | sim | preenche buffer Ruby/heap virtual |
| `RtlMoveMemory` | 3 | equivalente | não | copia entre buffers Ruby/heap virtual; enderecos reais rejeitados |
| `RtlZeroMemory` | 2 | equivalente | sim | zera buffer Ruby/heap virtual |
| `SetConsoleActiveScreenBuffer` | 1 | equivalente | sim | buffer de console virtual |
| `SetConsoleScreenBufferSize` | 2 | equivalente | sim | buffer de console virtual |
| `SetConsoleTextAttribute` | 2 | equivalente | sim | cores sem efeito em log de texto |
| `SetConsoleTitleA` | 1 | equivalente | sim | titulo registrado no log |
| `SetConsoleTitle` | 1 | equivalente | sim | titulo registrado no log |
| `SetCurrentDirectoryA` | 1 | equivalente | sim | Dir.chdir com resolucao estilo Windows |
| `SetCurrentDirectory` | 1 | equivalente | sim | Dir.chdir com resolucao estilo Windows |
| `SetEnvironmentVariableA` | 2 | equivalente | sim | ambiente virtual do jogo (lido por GetEnvironmentVariable) |
| `SetEnvironmentVariable` | 2 | equivalente | sim | ambiente virtual do jogo (lido por GetEnvironmentVariable) |
| `SetFileAttributesA` | 2 | limitada | sim | atributos Windows nao existem no Android; arquivo verificado |
| `SetFileAttributes` | 2 | limitada | sim | atributos Windows nao existem no Android; arquivo verificado |
| `SetFilePointer` | 4 | equivalente | sim | seek (FILE_BEGIN/CURRENT/END) |
| `SetLastError` | 1 | equivalente | sim | define o ultimo erro |
| `SetPriorityClass` | 2 | limitada | não | prioridade gerida pelo Android; pedido recusado com ERROR_ACCESS_DENIED |
| `SetThreadPriority` | 2 | limitada | sim | prioridade gerida pelo Android; pedido recusado com ERROR_ACCESS_DENIED |
| `Sleep` | 1 | equivalente | sim | suspende a thread Ruby como o Sleep do Windows |
| `TerminateProcess` | 2 | equivalente | sim | somente o proprio processo (pseudo-handle -1) |
| `VirtualAlloc` | 4 | equivalente | sim | heap virtual (ate 64 KiB); endereco fixo pedido e recusado |
| `VirtualFree` | 3 | equivalente | sim | heap virtual |
| `WideCharToMultiByte` | 6 | equivalente | sim | UTF-16LE para UTF-8 (65001) ou Windows-1252 |
| `WriteConsoleA` | 4 | equivalente | sim | texto do console vai para o log |
| `WriteConsole` | 4 | equivalente | sim | texto do console vai para o log |
| `WriteConsoleW` | 4 | equivalente | sim | texto do console vai para o log |
| `WriteFile` | 5 | equivalente | sim | escrita binaria; console vai para o log |
| `WritePrivateProfileStringA` | 4 | equivalente | sim | escrita INI preservando o arquivo |
| `WritePrivateProfileString` | 4 | equivalente | sim | escrita INI preservando o arquivo |
| `WriteProfileStringA` | 3 | equivalente | não | win.ini virtual do jogo |
| `WriteProfileString` | 3 | equivalente | não | win.ini virtual do jogo |
| `lstrcatA` | 2 | equivalente | sim | concatena em buffer Ruby/heap virtual |
| `lstrcat` | 2 | equivalente | sim | concatena em buffer Ruby/heap virtual |
| `lstrcmpA` | 2 | equivalente | sim | comparacao de bytes |
| `lstrcmp` | 2 | equivalente | sim | comparacao de bytes |
| `lstrcmpW` | 2 | equivalente | sim | comparacao de texto UTF-16 |
| `lstrcmpiA` | 2 | equivalente | sim | comparacao sem diferenciar maiusculas (ASCII) |
| `lstrcmpi` | 2 | equivalente | sim | comparacao sem diferenciar maiusculas (ASCII) |
| `lstrcmpiW` | 2 | equivalente | sim | comparacao sem diferenciar maiusculas (ASCII) |
| `lstrcpyA` | 2 | equivalente | sim | copia em buffer Ruby/heap virtual |
| `lstrcpy` | 2 | equivalente | sim | copia em buffer Ruby/heap virtual |
| `lstrcpynA` | 3 | equivalente | sim | copia limitada em buffer Ruby/heap virtual |
| `lstrcpyn` | 3 | equivalente | sim | copia limitada em buffer Ruby/heap virtual |
| `lstrlenA` | 1 | equivalente | sim | strlen em buffer Ruby/heap virtual |
| `lstrlen` | 1 | equivalente | sim | strlen em buffer Ruby/heap virtual |
| `lstrlenW` | 1 | equivalente | sim | wcslen em buffer Ruby/heap virtual |

## kleinbitmap

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `add_outline` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `compare_bitmap` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `modify_color` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `modify_pallete` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `save_pallete` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `scroll_down` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `scroll_left` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `scroll_right` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `scroll_up` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `set_pattern` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `to_negative` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `to_retro` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |
| `version` | * | port/perfil | sim | substituida pelo port klein_bitmap quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |

## mgc_hmode7

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `applyLighting` | * | indisponível (erro preciso) | sim | MGC HMode7: renderizador 3D x86 sem port; mapas HM7 precisam de backend proprio |
| `applyOpacity` | * | indisponível (erro preciso) | sim | MGC HMode7: renderizador 3D x86 sem port; mapas HM7 precisam de backend proprio |
| `computeM7` | * | indisponível (erro preciso) | sim | MGC HMode7: renderizador 3D x86 sem port; mapas HM7 precisam de backend proprio |
| `drawHeightmap` | * | indisponível (erro preciso) | sim | MGC HMode7: renderizador 3D x86 sem port; mapas HM7 precisam de backend proprio |
| `drawMapTileset` | * | indisponível (erro preciso) | sim | MGC HMode7: renderizador 3D x86 sem port; mapas HM7 precisam de backend proprio |
| `drawTextureset` | * | indisponível (erro preciso) | sim | MGC HMode7: renderizador 3D x86 sem port; mapas HM7 precisam de backend proprio |
| `refreshMapTileset` | * | indisponível (erro preciso) | sim | MGC HMode7: renderizador 3D x86 sem port; mapas HM7 precisam de backend proprio |
| `renderHM7` | * | indisponível (erro preciso) | sim | MGC HMode7: renderizador 3D x86 sem port; mapas HM7 precisam de backend proprio |

## msvcrt

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `_read` | 3 | limitada | sim | sem stdin no Android (EBADF) |
| `_write` | 3 | equivalente | sim | stdout/stderr para o log do Kerberus |
| `memcpy` | 3 | equivalente | sim | copia entre buffers Ruby/heap virtual |
| `memmove` | 3 | equivalente | sim | copia entre buffers Ruby/heap virtual |
| `memset` | 3 | equivalente | sim | preenche buffer Ruby/heap virtual |
| `rand` | 0 | equivalente | sim | gerador exato do MSVCRT |
| `sprintf` | 2 | equivalente | sim | formato C (d i u x X o c s f e g p) |
| `srand` | 1 | equivalente | sim | gerador exato do MSVCRT |
| `strlen` | 1 | equivalente | sim | strlen em buffer Ruby/heap virtual |
| `system` | 1 | limitada | sim | sem interpretador de comandos no Android |

## ntdll

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `RtlMoveMemory` | 3 | equivalente | não | copia entre buffers Ruby/heap virtual; enderecos reais rejeitados |
| `RtlZeroMemory` | 2 | equivalente | sim | zera buffer Ruby/heap virtual |

## ole32

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `CoCreateGuid` | 1 | equivalente | sim | GUID aleatorio versao 4 |
| `CoCreateInstance` | 5 | indisponível (erro preciso) | sim | objetos COM do Windows nao existem no Android |
| `CoInitialize` | 1 | equivalente | sim | apartamento COM logico (S_OK/S_FALSE) |
| `CoInitializeEx` | 2 | equivalente | sim | apartamento COM logico (S_OK/S_FALSE) |
| `CoTaskMemAlloc` | 1 | equivalente | sim | heap virtual |
| `CoTaskMemFree` | 1 | equivalente | não | libera bloco do heap virtual |
| `CoUninitialize` | 0 | equivalente | sim | apartamento COM logico |

## psapi

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `GetProcessMemoryInfo` | 3 | equivalente | sim | memoria real do processo (/proc/self/status) |

## rgss1

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `RGSSGetPathWithRTP` | 1 | equivalente | sim | sem RTP: caminho original |
| `RGSSGetRTPPath` | 1 | equivalente | sim | sem RTP instalado: caminho vazio |

## rgss_fmodex

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `Init_FmodEx` | * | port/perfil | sim | substituida pelo port fmodex_audio quando o script e reconhecido; chamada direta = WINBRIDGE_UNAVAILABLE |

## rpg.net

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `InputGetWheelDelta` | 0 | equivalente | não | roda do mouse via Input.scroll_v |

## rubyscreen

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `SwapRgb` | 2 | port/perfil | sim | troca R/B em buffer BGRA Ruby |
| `TakeScreenshot` | 1 | port/perfil | não | Graphics.snap_to_bitmap + Bitmap#to_file (PNG, JPG ou BMP pela extensao) |

## shell32

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `DragAcceptFiles` | 2 | equivalente | sim | arrastar arquivos nao existe no Android |
| `ExtractIconA` | 3 | limitada | sim | icones de executaveis nao sao extraidos |
| `ExtractIcon` | 3 | limitada | sim | icones de executaveis nao sao extraidos |
| `SHBrowseForFolderA` | 1 | limitada | sim | sem seletor de pastas: nenhuma pasta escolhida |
| `SHBrowseForFolder` | 1 | limitada | sim | sem seletor de pastas: nenhuma pasta escolhida |
| `SHFileOperationA` | 1 | limitada | sim | estrutura com ponteiros reais; operacao recusada (DE_INVALIDFILES) |
| `SHFileOperation` | 1 | limitada | sim | estrutura com ponteiros reais; operacao recusada (DE_INVALIDFILES) |
| `SHGetFolderPathA` | 5 | limitada | sim | pasta especial indisponivel; o jogo usa o proprio fallback e os saves existentes continuam no mesmo lugar |
| `SHGetFolderPath` | 5 | limitada | sim | pasta especial indisponivel; o jogo usa o proprio fallback e os saves existentes continuam no mesmo lugar |
| `SHGetKnownFolderPath` | 4 | limitada | não | pasta especial indisponivel; o jogo usa o proprio fallback e os saves existentes continuam no mesmo lugar |
| `SHGetPathFromIDListA` | 2 | equivalente | não | nenhum PIDL e emitido; PIDL nulo falha como no Windows |
| `SHGetPathFromIDList` | 2 | equivalente | não | nenhum PIDL e emitido; PIDL nulo falha como no Windows |
| `SHGetSpecialFolderLocation` | 3 | limitada | não | pasta especial indisponivel; o jogo usa o proprio fallback e os saves existentes continuam no mesmo lugar |
| `SHGetSpecialFolderPathA` | 4 | limitada | sim | pasta especial indisponivel; o jogo usa o proprio fallback e os saves existentes continuam no mesmo lugar |
| `SHGetSpecialFolderPath` | 4 | limitada | sim | pasta especial indisponivel; o jogo usa o proprio fallback e os saves existentes continuam no mesmo lugar |
| `ShellExecuteA` | 6 | limitada | sim | abrir programas/URLs externos indisponivel |
| `ShellExecute` | 6 | limitada | sim | abrir programas/URLs externos indisponivel |
| `ShellExecuteExA` | 1 | limitada | sim | abrir programas/URLs externos indisponivel |
| `ShellExecuteEx` | 1 | limitada | sim | abrir programas/URLs externos indisponivel |

## urlmon

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `URLDownloadToFileA` | 5 | limitada | sim | rede desativada no Kerberus (mesma politica do Winsock): sem conexao |
| `URLDownloadToFile` | 5 | limitada | sim | rede desativada no Kerberus (mesma politica do Winsock): sem conexao |

## user32

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `AdjustWindowRect` | 3 | equivalente | sim | janela sem bordas: retangulo inalterado |
| `AdjustWindowRectEx` | 4 | equivalente | sim | janela sem bordas: retangulo inalterado |
| `BringWindowToTop` | 1 | limitada | sim | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `CallWindowProcA` | 4 | limitada | sim | sem procedimento de janela Win32 |
| `CallWindowProc` | 4 | limitada | sim | sem procedimento de janela Win32 |
| `ChangeDisplaySettingsA` | 2 | limitada | sim | apenas o modo atual (resolucao do jogo) e aceito |
| `ChangeDisplaySettings` | 2 | limitada | sim | apenas o modo atual (resolucao do jogo) e aceito |
| `CharLowerA` | 1 | equivalente | sim | minusculas ASCII no buffer ou caractere |
| `CharLower` | 1 | equivalente | sim | minusculas ASCII no buffer ou caractere |
| `CharUpperA` | 1 | equivalente | sim | maiusculas ASCII no buffer ou caractere |
| `CharUpper` | 1 | equivalente | sim | maiusculas ASCII no buffer ou caractere |
| `ClientToScreen` | 2 | equivalente | sim | tela e cliente coincidem na janela logica |
| `ClipCursor` | 1 | limitada | sim | sem cursor de hardware no Android; confinamento vazio |
| `CloseClipboard` | 0 | equivalente | sim | area de transferencia do Android |
| `DefWindowProcA` | 4 | limitada | sim | sem procedimento de janela Win32 |
| `DefWindowProc` | 4 | limitada | sim | sem procedimento de janela Win32 |
| `DestroyIcon` | 1 | equivalente | sim | handles virtuais |
| `DispatchMessageA` | 1 | equivalente | sim | fila Win32 sempre vazia no Android |
| `DispatchMessage` | 1 | equivalente | sim | fila Win32 sempre vazia no Android |
| `DrawMenuBar` | 1 | equivalente | sim | a janela do jogo nao tem menu |
| `EmptyClipboard` | 0 | equivalente | sim | area de transferencia do Android |
| `EnableWindow` | 2 | equivalente | sim | estado habilitado da janela logica |
| `EnumDisplaySettingsA` | 3 | equivalente | sim | um modo: resolucao do jogo, 32 bpp, 60 Hz |
| `EnumDisplaySettings` | 3 | equivalente | sim | um modo: resolucao do jogo, 32 bpp, 60 Hz |
| `FindWindowA` | 2 | equivalente | sim | janela logica "RGSS Player" |
| `FindWindow` | 2 | equivalente | sim | janela logica "RGSS Player" |
| `FindWindowExA` | 4 | equivalente | não | janela logica "RGSS Player" |
| `FindWindowEx` | 4 | equivalente | não | janela logica "RGSS Player" |
| `FlashWindow` | 2 | limitada | sim | a janela do jogo ja esta ativa; sem piscar |
| `GetActiveWindow` | 0 | equivalente | sim | janela logica quando o app tem foco |
| `GetAsyncKeyState` | 1 | equivalente | não | estado SDL ao vivo (toque/teclado/controle/mouse); SHORT com sinal como no RGSS1 |
| `GetCapture` | 0 | equivalente | sim | captura logica da janela |
| `GetClassLongA` | 2 | equivalente | sim | dados de classe da janela logica |
| `GetClassLong` | 2 | equivalente | sim | dados de classe da janela logica |
| `GetClassNameA` | 3 | equivalente | sim | classe RGSS Player |
| `GetClassName` | 3 | equivalente | sim | classe RGSS Player |
| `GetClientRect` | 2 | equivalente | não | resolucao logica do RGSS |
| `GetClipboardData` | 1 | equivalente | sim | CF_TEXT/CF_UNICODETEXT em bloco do heap virtual |
| `GetCursorPos` | 1 | equivalente | não | mouse/toque SDL ao vivo em coordenadas do jogo |
| `GetDC` | 1 | equivalente | sim | DC virtual do jogo |
| `GetDesktopWindow` | 0 | equivalente | sim | desktop virtual |
| `GetDoubleClickTime` | 0 | equivalente | sim | 500 ms, padrao do Windows |
| `GetFocus` | 0 | equivalente | sim | janela logica quando o app tem foco |
| `GetForegroundWindow` | 0 | equivalente | não | janela logica quando o app tem foco |
| `GetKeyNameTextA` | 3 | equivalente | sim | nomes de teclas do layout US |
| `GetKeyNameText` | 3 | equivalente | sim | nomes de teclas do layout US |
| `GetKeyState` | 1 | equivalente | não | estado SDL ao vivo; bits de toggle nao expostos pelo SDL |
| `GetKeyboardLayout` | 1 | equivalente | sim | HKL US, coerente com ToUnicode |
| `GetKeyboardState` | 1 | equivalente | não | 256 estados SDL ao vivo; bits de toggle 0 |
| `GetMenu` | 1 | equivalente | sim | a janela do jogo nao tem menu |
| `GetMessageA` | 4 | indisponível (erro preciso) | sim | bloquearia o jogo: a fila Win32 nao recebe eventos no Android |
| `GetMessage` | 4 | indisponível (erro preciso) | sim | bloquearia o jogo: a fila Win32 nao recebe eventos no Android |
| `GetParent` | 1 | equivalente | sim | janela de nivel superior |
| `GetSysColor` | 1 | equivalente | sim | cores padrao do Windows 10 |
| `GetSystemMenu` | 2 | equivalente | sim | a janela do jogo nao tem menu de sistema |
| `GetSystemMetrics` | 1 | equivalente | não | desktop virtual = resolucao do jogo; bordas 0 |
| `GetWindowDC` | 1 | equivalente | sim | DC virtual do jogo |
| `GetWindowLongA` | 2 | equivalente | sim | estilos da janela logica |
| `GetWindowLong` | 2 | equivalente | sim | estilos da janela logica |
| `GetWindowPlacement` | 2 | equivalente | sim | janela logica normal na resolucao do jogo |
| `GetWindowRect` | 2 | equivalente | não | janela logica sem bordas |
| `GetWindowTextA` | 3 | equivalente | sim | titulo da janela SDL |
| `GetWindowText` | 3 | equivalente | sim | titulo da janela SDL |
| `GetWindowTextLengthA` | 1 | equivalente | sim | titulo da janela SDL |
| `GetWindowTextLength` | 1 | equivalente | sim | titulo da janela SDL |
| `GetWindowThreadProcessId` | 2 | equivalente | não | thread dona da janela e pid Android |
| `InvalidateRect` | 3 | limitada | sim | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `IsClipboardFormatAvailable` | 1 | equivalente | sim | texto da area de transferencia do Android |
| `IsIconic` | 1 | equivalente | sim | janela logica nunca minimizada |
| `IsWindow` | 1 | equivalente | sim | janela logica |
| `IsWindowEnabled` | 1 | equivalente | sim | estado habilitado da janela logica |
| `IsWindowVisible` | 1 | equivalente | sim | janela logica sempre visivel |
| `IsZoomed` | 1 | equivalente | sim | janela logica em tela cheia |
| `KillTimer` | 2 | limitada | sim | nenhum timer Win32 e criado |
| `LoadCursorA` | 2 | equivalente | sim | cursores do sistema como handles virtuais |
| `LoadCursor` | 2 | equivalente | sim | cursores do sistema como handles virtuais |
| `LoadCursorFromFileA` | 1 | equivalente | sim | arquivo de cursor existente vira handle virtual |
| `LoadCursorFromFile` | 1 | equivalente | sim | arquivo de cursor existente vira handle virtual |
| `LoadImageA` | 6 | equivalente | sim | arquivo existente ou recurso do sistema vira handle virtual |
| `LoadImage` | 6 | equivalente | sim | arquivo existente ou recurso do sistema vira handle virtual |
| `MapVirtualKeyA` | 2 | equivalente | não | tabela de scan codes US |
| `MapVirtualKey` | 2 | equivalente | não | tabela de scan codes US |
| `MapVirtualKeyExA` | 2 | equivalente | sim | tabela de scan codes US |
| `MapVirtualKeyEx` | 2 | equivalente | sim | tabela de scan codes US |
| `MessageBeep` | 1 | limitada | sim | sem sons de sistema; falha documentada |
| `MessageBoxA` | 4 | limitada | sim | mensagem RGSS nativa; botoes Sim/Nao retornam a opcao segura |
| `MessageBox` | 4 | limitada | sim | mensagem RGSS nativa; botoes Sim/Nao retornam a opcao segura |
| `MessageBoxW` | 4 | limitada | sim | mensagem RGSS nativa; botoes Sim/Nao retornam a opcao segura |
| `MoveWindow` | 6 | limitada | sim | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `OpenClipboard` | 1 | equivalente | sim | area de transferencia do Android |
| `PeekMessageA` | 5 | equivalente | não | fila Win32 vazia: eventos pertencem ao SDL |
| `PeekMessage` | 5 | equivalente | não | fila Win32 vazia: eventos pertencem ao SDL |
| `PostMessageA` | 4 | limitada | não | WM_CLOSE encerra o jogo; demais mensagens sem efeito |
| `PostMessage` | 4 | limitada | não | WM_CLOSE encerra o jogo; demais mensagens sem efeito |
| `RegisterHotKey` | 4 | limitada | não | atalhos globais indisponiveis no Android |
| `ReleaseCapture` | 0 | equivalente | não | captura logica da janela |
| `ReleaseDC` | 2 | equivalente | sim | DC virtual do jogo |
| `ScreenToClient` | 2 | equivalente | não | tela e cliente coincidem na janela logica |
| `SendInput` | 3 | limitada | sim | eventos sinteticos nao sao injetados |
| `SendMessageA` | 4 | limitada | não | WM_CLOSE encerra o jogo; demais mensagens sem efeito |
| `SendMessage` | 4 | limitada | não | WM_CLOSE encerra o jogo; demais mensagens sem efeito |
| `SetActiveWindow` | 1 | limitada | sim | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `SetCapture` | 1 | equivalente | não | captura logica da janela |
| `SetClassLongA` | 3 | equivalente | sim | dados de classe da janela logica |
| `SetClassLong` | 3 | equivalente | sim | dados de classe da janela logica |
| `SetClipboardData` | 2 | equivalente | sim | CF_TEXT/CF_UNICODETEXT de bloco do heap virtual |
| `SetCursor` | 1 | limitada | sim | sem cursor visivel no Android; handle anterior devolvido |
| `SetCursorPos` | 2 | limitada | sim | Android nao permite mover o ponteiro de toque |
| `SetFocus` | 1 | limitada | sim | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `SetForegroundWindow` | 1 | limitada | sim | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `SetKeyboardState` | 1 | limitada | sim | o estado das teclas vem do SDL e nao pode ser escrito |
| `SetMenu` | 2 | equivalente | sim | a janela do jogo nao tem menu |
| `SetTimer` | 4 | limitada | sim | timers Win32 dependem de fila de mensagens; recusado |
| `SetWindowLongA` | 3 | limitada | não | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `SetWindowLong` | 3 | limitada | não | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `SetWindowPlacement` | 2 | limitada | sim | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `SetWindowPos` | 7 | limitada | não | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `SetWindowTextA` | 2 | equivalente | não | titulo da janela SDL |
| `SetWindowText` | 2 | equivalente | sim | titulo da janela SDL |
| `ShowCursor` | 1 | equivalente | não | contador de exibicao do cursor |
| `ShowWindow` | 2 | limitada | não | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `SystemParametersInfoA` | 4 | limitada | sim | parametros de desktop nao expostos |
| `SystemParametersInfo` | 4 | limitada | sim | parametros de desktop nao expostos |
| `ToAscii` | 4 | equivalente | sim | layout US com Shift/Ctrl/CapsLock do estado informado |
| `ToAsciiEx` | 4 | equivalente | sim | layout US com Shift/Ctrl/CapsLock do estado informado |
| `ToUnicode` | 5 | equivalente | não | layout US com Shift/Ctrl/CapsLock do estado informado |
| `ToUnicodeEx` | 5 | equivalente | sim | layout US com Shift/Ctrl/CapsLock do estado informado |
| `TranslateMessage` | 1 | equivalente | sim | fila Win32 sempre vazia no Android |
| `UnregisterHotKey` | 2 | limitada | sim | atalhos globais indisponiveis no Android |
| `UpdateWindow` | 1 | limitada | sim | superficie Android gerenciada pelo Kerberus; geometria logica do jogo preservada |
| `WindowFromPoint` | 2 | equivalente | sim | janela logica dentro da resolucao do jogo |
| `keybd_event` | 4 | limitada | sim | teclas sinteticas nao sao injetadas; Alt+Enter/fullscreen ja e gerenciado pelo Android |
| `wsprintfA` | 2 | equivalente | sim | formato C (d i u x X c s p) |
| `wsprintf` | 2 | equivalente | sim | formato C (d i u x X c s p) |

## wininet

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `InternetCloseHandle` | 1 | limitada | sim | rede desativada no Kerberus (mesma politica do Winsock): sem conexao |
| `InternetGetConnectedState` | 2 | limitada | sim | rede desativada no Kerberus (mesma politica do Winsock): sem conexao |
| `InternetOpenA` | 5 | limitada | sim | rede desativada no Kerberus (mesma politica do Winsock): sem conexao |
| `InternetOpen` | 5 | limitada | sim | rede desativada no Kerberus (mesma politica do Winsock): sem conexao |
| `InternetOpenUrlA` | 6 | limitada | sim | rede desativada no Kerberus (mesma politica do Winsock): sem conexao |
| `InternetOpenUrl` | 6 | limitada | sim | rede desativada no Kerberus (mesma politica do Winsock): sem conexao |
| `InternetReadFile` | 4 | limitada | sim | rede desativada no Kerberus (mesma politica do Winsock): sem conexao |

## winmm

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `PlaySoundA` | 3 | equivalente | sim | arquivos via Audio nativo (SE ou BGS em loop) |
| `PlaySound` | 3 | equivalente | sim | arquivos via Audio nativo (SE ou BGS em loop) |
| `auxGetVolume` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `auxSetVolume` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `joyGetDevCapsA` | 3 | equivalente | sim | controle SDL como gamepad de 10 botoes e 6 eixos |
| `joyGetDevCaps` | 3 | equivalente | sim | controle SDL como gamepad de 10 botoes e 6 eixos |
| `joyGetNumDevs` | 0 | equivalente | sim | 16 posicoes de joystick, como o driver do Windows |
| `joyGetPos` | 2 | equivalente | sim | controle SDL do jogador 0 |
| `joyGetPosEx` | 2 | equivalente | sim | controle SDL do jogador 0 |
| `mciGetErrorStringA` | 3 | equivalente | não | tabela de mensagens MCI |
| `mciGetErrorString` | 3 | equivalente | não | tabela de mensagens MCI |
| `mciSendStringA` | 4 | limitada | não | open/play/stop/pause/resume/close/setaudio/status sobre canais nativos; video indisponivel |
| `mciSendString` | 4 | limitada | não | open/play/stop/pause/resume/close/setaudio/status sobre canais nativos; video indisponivel |
| `midiOutClose` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `midiOutGetNumDevs` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `midiOutOpen` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `midiOutShortMsg` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `sndPlaySoundA` | 2 | equivalente | sim | arquivos via Audio nativo |
| `sndPlaySound` | 2 | equivalente | sim | arquivos via Audio nativo |
| `timeBeginPeriod` | 1 | equivalente | sim | timers do Android ja tem resolucao de 1 ms (TIMERR_NOERROR) |
| `timeEndPeriod` | 1 | equivalente | sim | timers do Android ja tem resolucao de 1 ms (TIMERR_NOERROR) |
| `timeGetDevCaps` | 2 | equivalente | sim | periodo minimo 1 ms |
| `timeGetTime` | 0 | equivalente | não | CLOCK_BOOTTIME em ms (32 bits) |
| `waveOutClose` | * | limitada | não | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `waveOutGetNumDevs` | 0 | limitada | não | nenhum dispositivo waveOut: o jogo deve usar o Audio nativo |
| `waveOutGetVolume` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `waveOutOpen` | * | limitada | não | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `waveOutPause` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `waveOutPrepareHeader` | * | limitada | não | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `waveOutReset` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `waveOutRestart` | * | limitada | sim | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `waveOutSetVolume` | * | limitada | não | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `waveOutUnprepareHeader` | * | limitada | não | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |
| `waveOutWrite` | * | limitada | não | saida PCM/MIDI direta sem backend (MMSYSERR_NOTSUPPORTED) |

## ws2_32

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `WSACleanup` | 0 | limitada | sim | rede indisponivel |
| `WSAGetLastError` | 0 | equivalente | sim | ultimo erro Winsock |
| `WSAStartup` | 2 | limitada | sim | rede indisponivel: WSASYSNOTREADY |
| `accept` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `bind` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `closesocket` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `connect` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `gethostbyaddr` | 3 | limitada | sim | rede indisponivel: WSAHOST_NOT_FOUND |
| `gethostbyname` | 1 | limitada | sim | rede indisponivel: WSAHOST_NOT_FOUND |
| `gethostname` | 2 | equivalente | sim | nome virtual kerberus |
| `getservbyname` | 2 | limitada | sim | rede indisponivel: WSANO_DATA |
| `getsockopt` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `htonl` | 1 | equivalente | sim | conversao pura |
| `htons` | 1 | equivalente | sim | conversao pura |
| `inet_addr` | 1 | equivalente | sim | conversao pura |
| `inet_ntoa` | 1 | equivalente | sim | conversao pura |
| `ioctlsocket` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `listen` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `ntohl` | 1 | equivalente | sim | conversao pura |
| `ntohs` | 1 | equivalente | sim | conversao pura |
| `recv` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `recvfrom` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `select` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `send` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `sendto` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `setsockopt` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `shutdown` | * | limitada | sim | rede indisponivel: SOCKET_ERROR/WSAENOTSOCK |
| `socket` | 3 | limitada | sim | rede indisponivel: INVALID_SOCKET/WSAENETDOWN |

## xinput

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `XInputEnable` | 1 | equivalente | sim | sem efeito colateral |
| `XInputGetBatteryInformation` | 3 | equivalente | sim | nivel de energia SDL |
| `XInputGetCapabilities` | 3 | equivalente | sim | controle SDL como gamepad padrao |
| `XInputGetKeystroke` | 3 | limitada | sim | fila de teclas do XInput nao existe no SDL (ERROR_EMPTY) |
| `XInputGetState` | 2 | equivalente | não | controle SDL ao vivo (jogador 0) |
| `XInputSetState` | 2 | equivalente | não | vibracao via SDL_GameControllerRumble |

## rgss_linker

| API | Parâmetros | Classe | Nova | Comportamento |
|---|---|---|---|---|
| `RGSSLinker_Initialize` | 1 | port/perfil | sim | RGSS Linker substituido pelo port rgss_linker |
