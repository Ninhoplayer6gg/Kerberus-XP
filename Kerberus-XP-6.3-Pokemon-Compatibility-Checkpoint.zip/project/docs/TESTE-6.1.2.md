# Kerberus XP 6.1.2 — teste rápido

## Antes
- Mantenha uma cópia da 6.1 anterior.
- Compile em ARM64 pelo script `TERMUX-BUILD-KERBERUS-6.1.2.sh`.
- Não apague os jogos/saves já importados.

## Biblioteca / landscape
1. Abra o Kerberus deitado.
2. Troque entre Biblioteca, Importar, Compatibilidade, Controles, Tradução, Configurações e Logs.
3. Selecione um jogo e confirme título, engine e runtime no painel lateral.

## Controles
1. Abra Control Studio sem iniciar o jogo.
2. Mova A/B/X/Y e direcional.
3. Mude tamanho e transparência de um botão.
4. Adicione um botão personalizado.
5. Desative AUTO HIDE e confirme que toolbar/botões não desaparecem.
6. Inicie o jogo e confirme que só existe um HUD touch do Kerberus.

## Reinício
1. Abra um jogo.
2. Menu Kerberus -> Reiniciar jogo.
3. Confirme.
4. O runtime antigo deve encerrar, o launcher deve assumir e o mesmo jogo deve abrir novamente.
5. Se o encerramento demorar, o launcher deve parar de tentar automaticamente em vez de abrir duas instâncias.

## Multi-runtime
- Infinite Fusion: `modern31`.
- Uranium: `legacy18`.
- Insurgence: `legacy18`.
- Xenoverse: `legacy18`.
- RGSS1 clássico: `legacy18` por padrão.

## Regressões que não podem acontecer
- não perder save;
- não sobrescrever scripts do jogo ao abrir;
- não misturar Ruby 1.8 e Ruby 3.1 no mesmo engine;
- não mostrar dois gamepads touch;
- não travar a biblioteca ao voltar do runtime.

Depois de um erro, copie a tela **Logs** e o arquivo de build `~/kerberus-6.1.2-build.log` quando o problema for de compilação.
