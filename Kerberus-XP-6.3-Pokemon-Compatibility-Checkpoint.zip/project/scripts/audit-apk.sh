#!/usr/bin/env bash
set -euo pipefail
APK="${1:?uso: audit-apk.sh caminho.apk [llvm-readelf]}"
READELF="${2:-llvm-readelf}"
[[ -f "$APK" ]] || { echo "[AUDIT][ERRO] APK ausente: $APK" >&2; exit 1; }
command -v unzip >/dev/null || { echo '[AUDIT][ERRO] unzip ausente' >&2; exit 1; }
command -v "$READELF" >/dev/null 2>&1 || [[ -x "$READELF" ]] || { echo "[AUDIT][ERRO] readelf ausente: $READELF" >&2; exit 1; }

TMP="${TMPDIR:-/tmp}/kerberus-apk-audit-$$"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP"
unzip -qq "$APK" 'lib/*/*.so' -d "$TMP"

# ARM64 only is intentional in this checkpoint.
BAD_ABI="$(find "$TMP/lib" -mindepth 1 -maxdepth 1 -type d ! -name arm64-v8a -print 2>/dev/null || true)"
if [[ -n "$BAD_ABI" ]]; then
  echo "[AUDIT][ERRO] ABI inesperada empacotada:" >&2
  echo "$BAD_ABI" >&2
  exit 1
fi

LIBDIR="$TMP/lib/arm64-v8a"
for lib in libmkxp-z18.so libmkxp-z31.so libruby.so libopenal.so libc++_shared.so; do
  [[ -s "$LIBDIR/$lib" ]] || { echo "[AUDIT][ERRO] $lib ausente" >&2; exit 1; }
done

if "$READELF" -d "$LIBDIR/libmkxp-z18.so" | grep -q 'NEEDED.*libruby\.so'; then
  echo '[AUDIT][ERRO] mkxp-z18 ficou dependente do Ruby 3.1 dinâmico' >&2
  exit 1
fi
"$READELF" -d "$LIBDIR/libmkxp-z31.so" | grep -q 'NEEDED.*libruby\.so' || {
  echo '[AUDIT][ERRO] mkxp-z31 não referencia libruby.so' >&2
  exit 1
}

BAD=0
while IFS= read -r so; do
  if "$READELF" -d "$so" 2>/dev/null | grep -E 'NEEDED.*(/data/data/com\.termux|/data/user/[0-9]+/com\.termux|/home/runner/)' >/dev/null; then
    echo "[AUDIT][ERRO] dependência absoluta do host em: $so" >&2
    BAD=1
  fi
done < <(find "$LIBDIR" -type f -name '*.so' -print)
[[ "$BAD" -eq 0 ]] || exit 1

# Diagnostic only: old NDK prebuilts such as libc++_shared from r23 may still be 4K-aligned.
echo '[AUDIT] ELF LOAD alignment:'
while IFS= read -r so; do
  name="$(basename "$so")"
  align="$($READELF -lW "$so" 2>/dev/null | awk '$1=="LOAD" {print $NF}' | sort -u | tr '\n' ',' | sed 's/,$//')"
  echo "  $name: ${align:-unknown}"
done < <(find "$LIBDIR" -type f -name '*.so' -print | sort)

echo KERBERUS_APK_AUDIT_OK
