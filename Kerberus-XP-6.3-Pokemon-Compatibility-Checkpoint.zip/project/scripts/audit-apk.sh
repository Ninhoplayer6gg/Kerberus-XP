#!/usr/bin/env bash
set -euo pipefail
APK="${1:?uso: audit-apk.sh caminho.apk [llvm-readelf]}"
READELF="${2:-llvm-readelf}"
[[ -f "$APK" ]] || { echo "[AUDIT][ERRO] APK ausente: $APK" >&2; exit 1; }
command -v unzip >/dev/null || { echo '[AUDIT][ERRO] unzip ausente' >&2; exit 1; }
command -v "$READELF" >/dev/null 2>&1 || [[ -x "$READELF" ]] || { echo "[AUDIT][ERRO] readelf ausente: $READELF" >&2; exit 1; }

TMP="${TMPDIR:-/tmp}/kerberus-apk-audit-$$"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP"
unzip -qq "$APK" 'lib/*/*.so' -d "$TMP"

# ARM64 only is intentional in this checkpoint.
BAD_ABI="$(find "$TMP/lib" -mindepth 1 -maxdepth 1 -type d ! -name arm64-v8a -print 2>/dev/null || true)"
if [[ -n "$BAD_ABI" ]]; then
  echo "[AUDIT][ERRO] ABI inesperada empacotada:" >&2
  echo "$BAD_ABI" >&2
  exit 1
fi

LIBDIR="$TMP/lib/arm64-v8a"
for lib in libmkxp-z18.so libmkxp-z31.so libruby.so libopenal.so libc++_shared.so; do
  [[ -s "$LIBDIR/$lib" ]] || { echo "[AUDIT][ERRO] $lib ausente" >&2; exit 1; }
done

if "$READELF" -d "$LIBDIR/libmkxp-z18.so" | grep -q 'NEEDED.*libruby\.so'; then
  echo '[AUDIT][ERRO] mkxp-z18 ficou dependente do Ruby 3.1 dinâmico' >&2
  exit 1
fi
"$READELF" -d "$LIBDIR/libmkxp-z31.so" | grep -q 'NEEDED.*libruby\.so' || {
  echo '[AUDIT][ERRO] mkxp-z31 não referencia libruby.so' >&2
  exit 1
}

# 6.4.1: the Ruby 1.8 of libmkxp-z18 carries Oniguruma (Regexp.kerberus_oniguruma
# is a NUL-terminated C string of its re.c); libmkxp-z31 must not.
PY="$(command -v python3 || command -v python || true)"
[[ -n "$PY" ]] || { echo '[AUDIT][ERRO] python ausente' >&2; exit 1; }
has_onig() { "$PY" -c 'import sys; sys.exit(0 if b"kerberus_oniguruma\0" in open(sys.argv[1], "rb").read() else 1)' "$1"; }
has_onig "$LIBDIR/libmkxp-z18.so" || { echo '[AUDIT][ERRO] libmkxp-z18.so sem o Oniguruma do Ruby 1.8' >&2; exit 1; }
if has_onig "$LIBDIR/libmkxp-z31.so"; then echo '[AUDIT][ERRO] libmkxp-z31.so contém o Oniguruma do Ruby 1.8' >&2; exit 1; fi
# 6.4.3: IO#eof? of the Ruby 1.8 reads the file on bionic (IO.kerberus_eof_probe).
"$PY" -c 'import sys; sys.exit(0 if b"kerberus_eof_probe\0" in open(sys.argv[1], "rb").read() else 1)' "$LIBDIR/libmkxp-z18.so" ||
  { echo '[AUDIT][ERRO] libmkxp-z18.so sem o patch de IO#eof? do Ruby 1.8' >&2; exit 1; }
# 6.4.3: collections at scene transitions need GC.kerberus_pressure.
"$PY" -c 'import sys; sys.exit(0 if b"kerberus_pressure\0" in open(sys.argv[1], "rb").read() else 1)' "$LIBDIR/libmkxp-z18.so" ||
  { echo '[AUDIT][ERRO] libmkxp-z18.so sem GC.kerberus_pressure do Ruby 1.8' >&2; exit 1; }
unzip -l "$APK" > "$TMP/files.txt"
grep -q 'assets/licenses/oniguruma-COPYING.txt' "$TMP/files.txt" || { echo '[AUDIT][ERRO] APK sem a licença do Oniguruma' >&2; exit 1; }
# 6.4.3: CJK fallback font (shared by both runtimes) with its license, and
# the turbo entry point of the in-game toolbar in both engines.
grep -q 'assets/kerberus/fonts/wqymicrohei.ttf' "$TMP/files.txt" || { echo '[AUDIT][ERRO] APK sem a fonte CJK do Kerberus' >&2; exit 1; }
grep -q 'assets/licenses/wqy-microhei-LICENSE.txt' "$TMP/files.txt" || { echo '[AUDIT][ERRO] APK sem a licença da fonte CJK' >&2; exit 1; }
for lib in libmkxp-z18.so libmkxp-z31.so; do
  "$PY" -c 'import sys; sys.exit(0 if b"Java_com_kerberus_launcher_RuntimeSpeed_setTurbo\0" in open(sys.argv[1], "rb").read() else 1)' "$LIBDIR/$lib" ||
    { echo "[AUDIT][ERRO] $lib sem o turbo (RuntimeSpeed.setTurbo)" >&2; exit 1; }
  # 6.5: in-game menu requests, measured speed and the performance panel.
  for entry in RuntimeSession_request RuntimeSession_takeReply RuntimeSession_setFilter RuntimeSpeed_effectiveSpeed RuntimeMetrics_details; do
    "$PY" -c 'import sys; sys.exit(0 if ("Java_com_kerberus_launcher_" + sys.argv[2] + "\0").encode() in open(sys.argv[1], "rb").read() else 1)' "$LIBDIR/$lib" "$entry" ||
      { echo "[AUDIT][ERRO] $lib sem $entry" >&2; exit 1; }
  done
done
# 6.5: script code outside the collected heap (GC.kerberus_code_arena) only in Ruby 1.8.
"$PY" -c 'import sys; sys.exit(0 if b"kerberus_code_arena\0" in open(sys.argv[1], "rb").read() else 1)' "$LIBDIR/libmkxp-z18.so" ||
  { echo '[AUDIT][ERRO] libmkxp-z18.so sem a area de codigo do Ruby 1.8' >&2; exit 1; }

BAD=0
while IFS= read -r so; do
  if "$READELF" -d "$so" 2>/dev/null | grep -E 'NEEDED.*(/data/data/com\.termux|/data/user/[0-9]+/com\.termux|/home/runner/)' >/dev/null; then
    echo "[AUDIT][ERRO] dependência absoluta do host em: $so" >&2
    BAD=1
  fi
done < <(find "$LIBDIR" -type f -name '*.so' -print)
[[ "$BAD" -eq 0 ]] || exit 1

# Diagnostic only: old NDK prebuilts such as libc++_shared from r23 may still be 4K-aligned.
echo '[AUDIT] ELF LOAD alignment:'
while IFS= read -r so; do
  name="$(basename "$so")"
  align="$($READELF -lW "$so" 2>/dev/null | awk '$1=="LOAD" {print $NF}' | sort -u | tr '\n' ',' | sed 's/,$//')"
  echo "  $name: ${align:-unknown}"
done < <(find "$LIBDIR" -type f -name '*.so' -print | sort)

echo KERBERUS_APK_AUDIT_OK
