#!/usr/bin/env bash
# Kerberus XP - build the legacy Ruby 1.8 core used by libmkxp-z18.
#
# Same source, patches, flags and output as the Termux builder
# (TERMUX-BUILD-KERBERUS-6.3.sh, step 3/8), for a Linux host with the NDK:
#   joiplay/ruby, branch ruby_1_8, pinned commit -> static core + zlib,
#   stringio and strscan extensions, staged as build-arm64-v8a/ruby18.
#
# Required:
#   R18_TOOLCHAIN  NDK llvm toolchain dir (.../toolchains/llvm/prebuilt/<host>)
#                  or "host": use CC/AR/RANLIB/NM from the environment and
#                  R18_HOST_TRIPLE (script self-test with another cross gcc)
#   R18_SRC        work directory for the source checkout
#   R18_OUT        output directory (replaced): include/ and lib/
# Optional:
#   R18_PIN        commit (default below)      R18_REPO  git URL
#   HOST_RUBY      Ruby used for build-time scripts (default: ruby)
#   R18_REFERENCE  existing ruby18 dir: config.h, headers and archive members
#                  must match it exactly, otherwise the build fails
set -euo pipefail

R18_PIN="${R18_PIN:-50783b870e31259ed5c91badbd5c8e41f8e56273}"
R18_REPO="${R18_REPO:-https://github.com/joiplay/ruby}"
HOST_RUBY="${HOST_RUBY:-ruby}"
: "${R18_TOOLCHAIN:?defina R18_TOOLCHAIN (toolchain LLVM do NDK ou host)}"
: "${R18_SRC:?defina R18_SRC}"
: "${R18_OUT:?defina R18_OUT}"

log(){ printf '[RUBY18] %s\n' "$*"; }
die(){ printf '[RUBY18][ERRO] %s\n' "$*" >&2; exit 1; }

# 1. Pinned source, always from a clean tree.
if [[ ! -d "$R18_SRC/.git" ]]; then
  rm -rf "$R18_SRC"
  git clone -q -b ruby_1_8 "$R18_REPO" "$R18_SRC"
fi
git -C "$R18_SRC" fetch -q origin ruby_1_8 || true
git -C "$R18_SRC" checkout -q -f "$R18_PIN"
git -C "$R18_SRC" reset --hard -q "$R18_PIN"
git -C "$R18_SRC" clean -fdxq
[[ "$(git -C "$R18_SRC" rev-parse HEAD)" == "$R18_PIN" ]] || die "commit fixado nao encontrado: $R18_PIN"
log "fonte: $R18_REPO @ $R18_PIN"

# 2. Patches (identical to the Termux builder).
for name in config.guess config.sub; do
  for dir in /usr/share/libtool/build-aux /usr/share/misc "${PREFIX:-/nonexistent}/share/libtool/build-aux"; do
    if [[ -f "$dir/$name" ]]; then cp -f "$dir/$name" "$R18_SRC/$name"; break; fi
  done
  chmod +x "$R18_SRC/$name"
done
sed -i 's/=>TRUE/=>true/g' "$R18_SRC/mkconfig.rb"
python3 - "$R18_SRC/mkconfig.rb" <<'PY_MKCONFIG'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
old="""module RbConfig
  RUBY_VERSION == "#{version}" or
    raise "ruby lib version (#{version}) doesn't match executable version (\\#{RUBY_VERSION})"

"""
new="""module RbConfig
  unless defined?(CROSS_COMPILING)
    RUBY_VERSION == "#{version}" or
      raise "ruby lib version (#{version}) doesn't match executable version (\\#{RUBY_VERSION})"
  end

"""
if old in s:
    p.write_text(s.replace(old,new,1))
elif 'unless defined?(CROSS_COMPILING)' not in s:
    raise SystemExit('[RUBY18][ERRO] guarda de versao esperado nao encontrado em mkconfig.rb')
PY_MKCONFIG
python3 - "$R18_SRC/ruby.c" <<'PY_R18'
from pathlib import Path
import sys
p=Path(sys.argv[1]); s=p.read_text()
old='''#ifndef CharNext\t\t/* defined as CharNext[AW] on Windows. */\n#define CharNext(p) ((p) + mblen(p, RUBY_MBCHAR_MAXSIZE))\n#endif'''
new='''#if defined(__ANDROID__)\n#include <wchar.h>\nstatic int kerberus_android_mblen(const char *s, size_t n)\n{\n    mbstate_t state = {0};\n    size_t r = mbrlen(s, n, &state);\n    if (r == (size_t)-1 || r == (size_t)-2) return -1;\n    return (int)r;\n}\n#define KERBERUS_MBLEN(s,n) kerberus_android_mblen((s),(n))\n#else\n#define KERBERUS_MBLEN(s,n) mblen((s),(n))\n#endif\n\n#ifndef CharNext\t\t/* defined as CharNext[AW] on Windows. */\n#define CharNext(p) ((p) + KERBERUS_MBLEN(p, RUBY_MBCHAR_MAXSIZE))\n#endif'''
if old in s: p.write_text(s.replace(old,new,1))
elif 'KERBERUS_MBLEN' not in s: raise SystemExit('[RUBY18][ERRO] macro CharNext nao encontrada em ruby.c')
PY_R18
(cd "$R18_SRC" && autoconf > kerberus-autoconf.log 2>&1) || { tail -30 "$R18_SRC/kerberus-autoconf.log"; die "autoconf falhou"; }

# 3. Toolchain and flags (Android: NDK clang wrapper, API 23, as in Termux).
COMMON_CFLAGS="-std=gnu89 -O2 -fPIC -fno-stack-protector -fno-strict-aliasing -fwrapv -Wno-implicit-function-declaration -Wno-implicit-int -Wno-incompatible-pointer-types -Wno-int-conversion -Wno-incompatible-function-pointer-types"
if [[ "$R18_TOOLCHAIN" == host ]]; then
  CC="${CC:-cc}"; AR="${AR:-ar}"; RANLIB="${RANLIB:-ranlib}"; NM="${NM:-nm}"
  HOST_TRIPLE="${R18_HOST_TRIPLE:-$(cd "$R18_SRC" && ./config.guess)}"
  R18INC="-I$R18_SRC -I."
  R18CFLAGS="$COMMON_CFLAGS $R18INC"
  R18LDFLAGS=""
  CROSS_ARGS=()
else
  TC="$R18_TOOLCHAIN"
  CC="$TC/bin/aarch64-linux-android23-clang"; AR="$TC/bin/llvm-ar"; RANLIB="$TC/bin/llvm-ranlib"; NM="$TC/bin/llvm-nm"
  for tool in "$CC" "$AR" "$RANLIB" "$NM"; do [[ -x "$tool" ]] || die "ferramenta do NDK ausente: $tool"; done
  HOST_TRIPLE=aarch64-linux-android
  RES="$("$CC" -print-resource-dir)"
  R18INC="-I$R18_SRC -I. -nostdinc -isystem $RES/include -isystem $TC/sysroot/usr/include/aarch64-linux-android -isystem $TC/sysroot/usr/include"
  R18CFLAGS="$COMMON_CFLAGS --sysroot=$TC/sysroot $R18INC"
  R18LDFLAGS="--sysroot=$TC/sysroot -Wl,-z,max-page-size=16384 -Wl,-z,common-page-size=16384 -ldl -lm -lz"
  CROSS_ARGS=(ac_cv_func_fork=no ac_cv_func_memcmp=yes ac_cv_header_pwd_h=no ac_cv_header_langinfo_h=no)
fi
"$HOST_RUBY" --disable-gems -e 'exit 0' 2>/dev/null || die "HOST_RUBY nao executa: $HOST_RUBY"
log "alvo: $HOST_TRIPLE; compilador: $("$CC" --version | head -1)"

# 4. configure + static core.
(
  cd "$R18_SRC"
  export RUBYOPT="--disable-gems"
  BUILD_TRIPLE="$(./config.guess)"
  CC="$CC" AR="$AR" RANLIB="$RANLIB" NM="$NM" RUBY="$HOST_RUBY --disable-gems" BASERUBY="$HOST_RUBY --disable-gems" \
  CFLAGS="$R18CFLAGS" CPPFLAGS="$R18INC" LDFLAGS="$R18LDFLAGS" \
  ./configure --host="$HOST_TRIPLE" --build="$BUILD_TRIPLE" --disable-shared --with-static-linked-ext "${CROSS_ARGS[@]}" \
    > kerberus-configure.log 2>&1 || { tail -40 kerberus-configure.log; tail -60 config.log; die "configure falhou"; }
  printf '#!/usr/bin/env bash\nexec %s --disable-gems "$@"\n' "$HOST_RUBY" > kerberus-host-ruby
  chmod +x kerberus-host-ruby
  make -j1 fake > kerberus-fake.log 2>&1 || true
  FAKE_RB="$(find . -maxdepth 1 -type f -name '*-fake.rb' -print -quit || true)"
  if [[ -n "$FAKE_RB" ]]; then
    # Host rbconfig, fileutils and erb load before the fake platform file
    # changes RUBY_VERSION. rbconfig is required by absolute path: with
    # -I$R18_SRC, "-rrbconfig" would pick the generated 1.8 rbconfig.rb as
    # soon as it exists and fail its version check.
    HOST_RBCONFIG="$("$HOST_RUBY" --disable-gems -rrbconfig -e 'print $LOADED_FEATURES.grep(/\/rbconfig\.rb\z/).first')"
    [[ -f "$HOST_RBCONFIG" ]] || die "rbconfig.rb do HOST_RUBY nao encontrado"
    HOST_MINIRUBY="$R18_SRC/kerberus-host-ruby -r$HOST_RBCONFIG -rfileutils -rerb -I$R18_SRC -r$(basename "$FAKE_RB" .rb)"
  else
    HOST_MINIRUBY="$R18_SRC/kerberus-host-ruby"
  fi
  make -j1 CC="$CC" MINIRUBY="$HOST_MINIRUBY" RUBY="$R18_SRC/kerberus-host-ruby" BASERUBY="$R18_SRC/kerberus-host-ruby" \
    CPPFLAGS="$R18INC" CFLAGS="$R18CFLAGS" libruby-static.a > kerberus-make.log 2>&1 || { tail -60 kerberus-make.log; die "make libruby-static.a falhou"; }
)
[[ -s "$R18_SRC/libruby-static.a" ]] || die "libruby-static.a nao foi gerado"

# 5. Stage exactly like the Termux builder: include/ + lib/.
rm -rf "$R18_OUT"
mkdir -p "$R18_OUT/lib" "$R18_OUT/include"
OBJ="$R18_SRC/kerberus-ext-obj"; rm -rf "$OBJ"; mkdir -p "$OBJ"
cp -f "$R18_SRC/libruby-static.a" "$R18_OUT/lib/libruby18-static.a"
find "$R18_SRC" -maxdepth 1 -type f -name '*.h' -exec cp -f {} "$R18_OUT/include/" \;
for spec in 'zlib:zlib.c' 'stringio:stringio.c' 'strscan:strscan.c'; do
  dir="${spec%%:*}"; file="${spec#*:}"
  "$CC" $R18CFLAGS -I"$R18_SRC" -I"$R18_OUT/include" -DOS_CODE=OS_UNIX -c "$R18_SRC/ext/$dir/$file" -o "$OBJ/$dir.o"
done
"$AR" rcs "$R18_OUT/lib/libruby18-ext.a" "$OBJ/"*.o
"$RANLIB" "$R18_OUT/lib/libruby18-static.a" "$R18_OUT/lib/libruby18-ext.a"

# 6. Verification. nm output goes to files (no grep -q on a pipe under pipefail).
"$NM" "$R18_OUT/lib/libruby18-static.a" > "$OBJ/static.nm" 2>/dev/null
"$NM" "$R18_OUT/lib/libruby18-ext.a" > "$OBJ/ext.nm" 2>/dev/null
grep -q ' ruby_init$' "$OBJ/static.nm" || die "ruby_init ausente no core"
for sym in Init_zlib Init_stringio Init_strscan; do grep -q " $sym$" "$OBJ/ext.nm" || die "$sym ausente"; done
"$AR" t "$R18_OUT/lib/libruby18-static.a" > "$OBJ/static.members"
"$AR" t "$R18_OUT/lib/libruby18-ext.a" > "$OBJ/ext.members"
log "core: $(wc -l < "$OBJ/static.members") objetos; ext: $(tr '\n' ' ' < "$OBJ/ext.members")"

if [[ -n "${R18_REFERENCE:-}" ]]; then
  REF="$R18_REFERENCE"
  [[ -d "$REF/include" && -d "$REF/lib" ]] || die "referencia invalida: $REF"
  status=0
  for header in "$REF"/include/*.h; do
    name="$(basename "$header")"
    if ! cmp -s "$header" "$R18_OUT/include/$name"; then
      log "DIFERENTE da referencia: include/$name"
      diff -u "$header" "$R18_OUT/include/$name" | head -80 || true
      status=1
    fi
  done
  extra="$(comm -13 <(ls "$REF/include") <(ls "$R18_OUT/include") | tr '\n' ' ')"
  [[ -z "$extra" ]] || { log "headers novos sem referencia: $extra"; status=1; }
  for lib in libruby18-static.a libruby18-ext.a; do
    if ! diff <("$AR" t "$REF/lib/$lib") <("$AR" t "$R18_OUT/lib/$lib") > "$OBJ/$lib.members.diff"; then
      log "membros diferentes da referencia em $lib:"; cat "$OBJ/$lib.members.diff"; status=1
    fi
  done
  [[ "$status" -eq 0 ]] || die "o build nao reproduz o Ruby 1.8 de referencia"
  log "config.h, headers e membros dos arquivos identicos a referencia"
fi
for file in "$R18_OUT"/lib/*.a; do log "$(sha256sum "$file" | cut -c1-16)  $(basename "$file") $(stat -c %s "$file") bytes"; done
echo KERBERUS_RUBY18_BUILD_OK
