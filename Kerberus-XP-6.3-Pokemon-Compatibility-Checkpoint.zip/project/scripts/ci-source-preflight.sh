#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

need_file(){ [[ -f "$1" ]] || { echo "[PRECHECK][ERRO] arquivo ausente: $1" >&2; exit 1; }; }
need_text(){ grep -Fq -- "$2" "$1" || { echo "[PRECHECK][ERRO] $1 não contém: $2" >&2; exit 1; }; }

need_file app/build.gradle
need_file build.gradle
need_file gradle/wrapper/gradle-wrapper.properties
need_file app/jni/Application.mk
need_file app/jni/Makefile
need_file app/jni/get_deps.sh
need_file app/jni/mkxp-z18.mk
need_file app/jni/mkxp-z31.mk
need_file app/jni/ruby18.mk
need_file app/jni/ruby.mk

need_text build.gradle "version '7.3.1'"
need_text gradle/wrapper/gradle-wrapper.properties 'gradle-7.4.2-bin.zip'
need_text app/build.gradle "abiFilters 'arm64-v8a'"
need_text app/jni/Application.mk 'max-page-size=16384'
need_text app/jni/Application.mk 'common-page-size=16384'
need_text app/jni/Makefile 'ALSOFT_BACKEND_OPENSL=ON'
need_text app/jni/Makefile '--disable-arm-a64-neon'
need_text app/jni/Makefile 'install-nodoc INSTRUBY_OPTS='
need_text app/jni/get_deps.sh 'OpenSSL_1_1_1w'

if grep -Rqs 'Finish me! rb_' app/jni/mkxp-z/binding; then
  echo '[PRECHECK][ERRO] shim Ruby legado TODO ainda presente' >&2
  exit 1
fi

# Kerberus 6.3: Legacy18 WinBridge sources, generated bootstrap and tests.
need_file tools/gen-legacy18-header.py
need_file tools/gen-legacy18-catalog.rb
need_file tests/legacy18/run-legacy18-tests.sh
need_file tests/modern31/run-modern31-tests.sh
need_file tests/modern31/modern31-compat.sha256
need_file app/src/main/assets/kerberus/compat/api-catalog-legacy18.tsv
need_file app/jni/mkxp-z/binding/kerberus/milestones.h
need_text app/jni/mkxp-z/binding/binding-mri.cpp '#include "kerberus-legacy18-compat.h"'
need_text app/jni/mkxp-z/binding/binding-mri.cpp 'kerberusCompatSource = KERBERUS_LEGACY18_COMPAT_RUBY'
need_text app/jni/mkxp-z/binding/disposable-binding.h 'Kerberus legacy18: RGSS1 subclasses may never call the base'
need_text app/build.gradle 'versionName "6.3.1-pokemon-compatibility"'
python3 tools/gen-legacy18-header.py --check
python3 tools/gen-winbridge-api-list.py --check
need_file KERBERUS-6.3-COMPATIBILITY-REPORT.md
need_file docs/KERBERUS-6.3-TECHNICAL.md
EXPECTED="$(tr -d ' \n' < tests/modern31/modern31-compat.sha256)"
ACTUAL="$(sha256sum app/jni/mkxp-z/binding/kerberus-uranium-compat.h | cut -d' ' -f1)"
[[ "$EXPECTED" == "$ACTUAL" ]] || { echo '[PRECHECK][ERRO] bootstrap modern31 (Infinite Fusion) alterado sem revalidacao' >&2; exit 1; }

bash scripts/validate-host.sh

echo KERBERUS_63_SOURCE_PREFLIGHT_OK
