#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

need_file(){ [[ -f "$1" ]] || { echo "[PRECHECK][ERRO] arquivo ausente: $1" >&2; exit 1; }; }
need_text(){ grep -Fq -- "$2" "$1" || { echo "[PRECHECK][ERRO] $1 não contém: $2" >&2; exit 1; }; }

need_file app/build.gradle
need_file build.gradle
need_file gradle/wrapper/gradle-wrapper.properties
need_file app/jni/Application.mk
need_file app/jni/Makefile
need_file app/jni/get_deps.sh
need_file app/jni/mkxp-z18.mk
need_file app/jni/mkxp-z31.mk
need_file app/jni/ruby18.mk
need_file app/jni/ruby.mk

need_text build.gradle "version '7.3.1'"
need_text gradle/wrapper/gradle-wrapper.properties 'gradle-7.4.2-bin.zip'
need_text app/build.gradle "abiFilters 'arm64-v8a'"
need_text app/jni/Application.mk 'max-page-size=16384'
need_text app/jni/Application.mk 'common-page-size=16384'
need_text app/jni/Makefile 'ALSOFT_BACKEND_OPENSL=ON'
need_text app/jni/Makefile '--disable-arm-a64-neon'
need_text app/jni/Makefile 'install-nodoc INSTRUBY_OPTS='
need_text app/jni/get_deps.sh 'OpenSSL_1_1_1w'

if grep -Rqs 'Finish me! rb_' app/jni/mkxp-z/binding; then
  echo '[PRECHECK][ERRO] shim Ruby legado TODO ainda presente' >&2
  exit 1
fi

# Kerberus 6.3: Legacy18 WinBridge sources, generated bootstrap and tests.
need_file tools/gen-legacy18-header.py
need_file tools/gen-legacy18-catalog.rb
need_file tests/legacy18/run-legacy18-tests.sh
need_file tests/modern31/run-modern31-tests.sh
need_file tests/modern31/modern31-compat.sha256
need_file app/src/main/assets/kerberus/compat/api-catalog-legacy18.tsv
need_file app/jni/mkxp-z/binding/kerberus/milestones.h
need_text app/jni/mkxp-z/binding/binding-mri.cpp '#include "kerberus-legacy18-compat.h"'
need_text app/jni/mkxp-z/binding/binding-mri.cpp 'kerberusCompatSource = KERBERUS_LEGACY18_COMPAT_RUBY'
need_text app/jni/mkxp-z/binding/disposable-binding.h 'Kerberus legacy18: RGSS1 subclasses may never call the base'
need_text app/build.gradle 'versionName "6.4.3-pokemon-compatibility"'
python3 tools/gen-legacy18-header.py --check
python3 tools/gen-winbridge-api-list.py --check
need_file KERBERUS-6.3-COMPATIBILITY-REPORT.md
# Ruby 1.8 (legacy18): the CI build and the Termux builder use one pinned commit.
need_file scripts/build-ruby18-android.sh
need_file scripts/patch-ruby18-rgss1.py
need_text scripts/build-ruby18-android.sh 'patch-ruby18-rgss1.py'
need_text TERMUX-BUILD-KERBERUS-6.3.sh 'patch-ruby18-rgss1.py'
need_file scripts/patch-ruby18-performance.py
need_text scripts/build-ruby18-android.sh 'patch-ruby18-performance.py'
need_text TERMUX-BUILD-KERBERUS-6.3.sh 'patch-ruby18-performance.py'
PIN_CI="$(sed -n 's/^R18_PIN="\${R18_PIN:-\([0-9a-f]\{40\}\)}"$/\1/p' scripts/build-ruby18-android.sh)"
PIN_TERMUX="$(sed -n 's/^PIN_RUBY18="\([0-9a-f]\{40\}\)"$/\1/p' TERMUX-BUILD-KERBERUS-6.3.sh)"
[[ -n "$PIN_CI" && "$PIN_CI" == "$PIN_TERMUX" ]] || { echo "[PRECHECK][ERRO] commit do Ruby 1.8 diferente entre CI ($PIN_CI) e Termux ($PIN_TERMUX)" >&2; exit 1; }
# Oniguruma (regex RGSS1 que o GNU rejeita): um commit fixado em todos os builds.
need_file scripts/patch-ruby18-oniguruma.py
need_file scripts/ruby18-oniguruma/kerberus_onig.c
need_file scripts/ruby18-oniguruma/onig-config.h
need_file THIRD-PARTY-NOTICES.md
need_file app/src/main/assets/licenses/oniguruma-COPYING.txt
need_text scripts/build-ruby18-android.sh 'patch-ruby18-oniguruma.py'
need_text TERMUX-BUILD-KERBERUS-6.3.sh 'patch-ruby18-oniguruma.py'
ONIG_CI="$(sed -n 's/^ONIG_PIN="\${ONIG_PIN:-\([0-9a-f]\{40\}\)}"$/\1/p' scripts/build-ruby18-android.sh)"
ONIG_TERMUX="$(sed -n 's/^PIN_ONIG="\([0-9a-f]\{40\}\)"$/\1/p' TERMUX-BUILD-KERBERUS-6.3.sh)"
ONIG_PATCH="$(sed -n "s/^ONIG_COMMIT = '\([0-9a-f]\{40\}\)'$/\1/p" scripts/patch-ruby18-oniguruma.py)"
[[ -n "$ONIG_CI" && "$ONIG_CI" == "$ONIG_TERMUX" && "$ONIG_CI" == "$ONIG_PATCH" ]] || {
  echo "[PRECHECK][ERRO] commit do Oniguruma diferente entre CI ($ONIG_CI), Termux ($ONIG_TERMUX) e patch ($ONIG_PATCH)" >&2; exit 1; }
need_file docs/KERBERUS-6.3-TECHNICAL.md
# 6.4.2: found by running Pokemon Uranium in the real engine (desktop harness).
need_file app/jni/mkxp-z/binding/kerberus/legacy18/83_winenv.rb
need_file tests/legacy18/test_uranium_runtime.rb
need_text app/jni/mkxp-z/src/display/bitmap.cpp 'static void kerberusMegaSourceBlt('
need_text app/jni/mkxp-z/src/display/bitmap.cpp 'if (!txtSurf)'
need_text tools/host-compile-check.sh 'src/display/bitmap.cpp'
need_file tools/game-harness/build-desktop.sh
# 6.4.3: IO#eof? on bionic stdio, idle GC, turbo, CJK font, saves, fixed key.
need_file scripts/patch-ruby18-io.py
need_text scripts/build-ruby18-android.sh 'patch-ruby18-io.py'
need_text TERMUX-BUILD-KERBERUS-6.3.sh 'patch-ruby18-io.py'
need_text scripts/patch-ruby18-performance.py 'KERBERUS_RUBY18_GC_PRESSURE'
need_file app/jni/mkxp-z/binding/kerberus/legacy18/84_io_eof.rb
need_file app/jni/mkxp-z/binding/kerberus/legacy18/94_idle_gc.rb
need_file tests/legacy18/ruby18_io_eof.rb
need_file tests/legacy18/test_io_eof_fallback.rb
need_file app/jni/mkxp-z/src/display/kerberus-turbo.h
need_text app/jni/mkxp-z/src/display/graphics.cpp '#include "kerberus-turbo.h"'
need_file app/src/main/java/com/kerberus/launcher/RuntimeSpeed.java
need_text app/jni/mkxp-z/src/display/bitmap.cpp 'static TTF_Font *kerberusTextFont('
need_file app/jni/mkxp-z/assets/wqymicrohei.ttf
need_file app/src/main/assets/licenses/wqy-microhei-LICENSE.txt
need_text app/build.gradle 'task kerberusCjkFont(type: Copy)'
need_text app/build.gradle "System.getenv('KERBERUS_KEYSTORE')"
need_file tests/SaveArchiveHostTest.java
need_text scripts/validate-host.sh 'SaveArchiveHostTest'
EXPECTED="$(tr -d ' \n' < tests/modern31/modern31-compat.sha256)"
ACTUAL="$(sha256sum app/jni/mkxp-z/binding/kerberus-uranium-compat.h | cut -d' ' -f1)"
[[ "$EXPECTED" == "$ACTUAL" ]] || { echo '[PRECHECK][ERRO] bootstrap modern31 (Infinite Fusion) alterado sem revalidacao' >&2; exit 1; }

bash scripts/validate-host.sh

echo KERBERUS_63_SOURCE_PREFLIGHT_OK
