#!/usr/bin/env python3
"""Kerberus: IO#eof? that reads the file, not the stdio flag, on Android.

Ruby 1.8's io.c learns how much a stdio FILE has buffered from its private
fields (glibc _IO_read_ptr/_IO_read_end, or FILE_COUNT/FILE_READEND found by
configure). Bionic hides FILE, so the Android build falls back to
READ_DATA_PENDING(fp) = !feof(fp), and rb_io_eof trusted it: after a seek
(which clears the EOF flag) to the end of a file, IO#eof? answered false and
the next read returned nil. Pokemon Uranium measures the title music this
way and stopped with "undefined method `unpack' for nil" (AudioUtilities
v17:1010); on glibc (desktop) the check is exact and nothing happened.

With this patch rb_io_eof keeps the buffer shortcut only where io.c reads the
buffer exactly (READ_DATA_PENDING_COUNT defined); elsewhere it probes with
getc/ungetc, the code rb_io_eof already had after the shortcut. Behaviour on
glibc is unchanged. IO.kerberus_eof_probe tells which mode the interpreter
uses (true = probe, i.e. Android). A desktop build whose config.h loses
FILE_READEND/FILE_READPTR, as Android's has none, reproduces the fallback.

Usage: patch-ruby18-io.py path/to/ruby-source   (idempotent)
"""
import pathlib
import sys

MARK = 'KERBERUS_RUBY18_IO_EOF'


def fail(message):
    sys.exit('[RUBY18][ERRO] patch de IO: ' + message)


def replace_once(text, old, new, what):
    if text.count(old) != 1:
        fail(what + ' nao encontrado exatamente uma vez')
    return text.replace(old, new)


def patch_io(path):
    text = path.read_text(encoding='latin-1')
    if MARK in text:
        return False
    text = replace_once(text, '''#define READ_CHECK(fp) do {\\''', '''/* KERBERUS_RUBY18_IO_EOF: see scripts/patch-ruby18-io.py */
#ifdef READ_DATA_PENDING_COUNT
#  define KERBERUS_READ_DATA_EXACT 1
#else
#  define KERBERUS_READ_DATA_EXACT 0
#endif

#define READ_CHECK(fp) do {\\''', 'READ_CHECK')
    text = replace_once(text, '''    if (feof(fptr->f)) return Qtrue;
    if (READ_DATA_PENDING(fptr->f)) return Qfalse;
    READ_CHECK(fptr->f);''', '''    if (feof(fptr->f)) return Qtrue;
#if KERBERUS_READ_DATA_EXACT
    if (READ_DATA_PENDING(fptr->f)) return Qfalse;
#endif
    READ_CHECK(fptr->f);''', 'atalho de buffer do rb_io_eof')
    text = replace_once(text, '''VALUE
rb_io_eof(io)
    VALUE io;
{''', '''/* true when IO#eof? probes the file (stdio buffer not readable here) */
static VALUE
kerberus_io_eof_probe(klass)
    VALUE klass;
{
    return KERBERUS_READ_DATA_EXACT ? Qfalse : Qtrue;
}

VALUE
rb_io_eof(io)
    VALUE io;
{''', 'rb_io_eof')
    text = replace_once(text, '''    rb_define_method(rb_cIO, "eof", rb_io_eof, 0);''', '''    rb_define_method(rb_cIO, "eof", rb_io_eof, 0);
    rb_define_singleton_method(rb_cIO, "kerberus_eof_probe", kerberus_io_eof_probe, 0);''', 'registro de IO#eof')
    path.write_text(text, encoding='latin-1')
    return True


def main():
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    io = pathlib.Path(sys.argv[1]) / 'io.c'
    if not io.is_file():
        fail('io.c ausente em ' + sys.argv[1])
    changed = patch_io(io)
    print('[RUBY18] IO#eof? por leitura quando o buffer do stdio nao e legivel: ' + ('aplicado' if changed else 'ja aplicado'))


if __name__ == '__main__':
    main()
