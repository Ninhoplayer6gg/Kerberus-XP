#!/usr/bin/env python3
"""Kerberus: Oniguruma fallback for regex syntax that Ruby 1.8's GNU engine rejects.

RPG Maker XP (RGSS1) runs game scripts on a Ruby 1.8.1 whose regular
expressions accept look-behind (?<=...) (?<!...), named groups and other
Oniguruma syntax. Ruby 1.8.7's GNU regex.c rejects them while the script is
parsed, so the whole script section fails with a SyntaxError
("undefined (?...) sequence: /(?<!\\\\)"/", Pokemon Uranium Section253).

This patch keeps GNU as the engine for every pattern it accepts (their
behaviour does not change) and hands only the patterns GNU rejects to
Oniguruma 6.9.10, compiled with Ruby syntax in the current $KCODE:

  regex.h   - struct re_pattern_buffer gains `void *kerberus_onig`
  regex.c   - re_compile_pattern: GNU first, Oniguruma when GNU fails (the
              GNU error is still reported when both fail); re_search,
              re_match, re_adjust_startpos, re_compile_fastmap and
              re_free_pattern dispatch Oniguruma patterns
  re.c      - Regexp.kerberus_oniguruma -> [Oniguruma version, patterns it
              compiled], for the runtime log and the tests
  common.mk - kerberus_onig.o (scripts/ruby18-oniguruma/kerberus_onig.c)
              and the Oniguruma objects join the core (libruby-static.a)
  kerberus-onig/ - the Oniguruma sources, verified against ONIG_SHA256,
              its COPYING, and scripts/ruby18-oniguruma/onig-config.h as
              its config.h

Oniguruma is BSD 2-Clause (K.Kosako); see THIRD-PARTY-NOTICES.md.

Usage: patch-ruby18-oniguruma.py RUBY_SRC ONIG_CHECKOUT   (idempotent;
fails loudly when the Ruby 1.8 code or the Oniguruma sources differ from
what this patch expects)
       patch-ruby18-oniguruma.py --regex-h FILE   (only the regex.h field,
for the reference comparison of scripts/build-ruby18-android.sh)
"""
import hashlib
import pathlib
import shutil
import sys

MARK = 'KERBERUS_ONIG'
ONIG_VERSION = '6.9.10'
ONIG_COMMIT = '4ef89209a239c1aea328cf13c05a2807e5c146d1'
# sha256 over "<name>\0<bytes>\0" of COPYING and every src/*.c, src/*.h,
# in name order: the exact sources of kkos/oniguruma v6.9.10 (ONIG_COMMIT).
ONIG_SHA256 = '4509630b9526dba053a4e1d09feb9faf95968883c7c610039f1fb5e76e992b0b'
ONIG_UNITS = [
    'regparse', 'regcomp', 'regexec', 'regenc', 'regerror', 'regversion', 'st',
    'unicode', 'unicode_unfold_key', 'unicode_fold1_key', 'unicode_fold2_key',
    'unicode_fold3_key', 'ascii', 'utf8', 'euc_jp', 'euc_jp_prop', 'sjis',
    'sjis_prop',
]
HERE = pathlib.Path(__file__).resolve().parent / 'ruby18-oniguruma'


def fail(message):
    sys.exit('[RUBY18][ERRO] patch Oniguruma: ' + message)


def replace_once(text, old, new, what):
    if text.count(old) != 1:
        fail(what + ' nao encontrado exatamente uma vez')
    return text.replace(old, new)


def onig_files(onig):
    files = [onig / 'COPYING']
    files += sorted(p for p in (onig / 'src').iterdir() if p.suffix in ('.c', '.h'))
    return files


def onig_digest(onig):
    h = hashlib.sha256()
    for path in onig_files(onig):
        name = 'COPYING' if path.name == 'COPYING' else 'src/' + path.name
        h.update(name.encode() + b'\0' + path.read_bytes() + b'\0')
    return h.hexdigest()


def copy_onig(ruby, onig):
    if not (onig / 'src' / 'oniguruma.h').is_file():
        fail('fonte do Oniguruma nao encontrada em %s' % onig)
    digest = onig_digest(onig)
    if digest != ONIG_SHA256:
        fail('fonte do Oniguruma diferente da %s (%s): sha256 %s' % (ONIG_VERSION, ONIG_COMMIT, digest))
    dest = ruby / 'kerberus-onig'
    if dest.exists():
        shutil.rmtree(dest)
    (dest / 'src').mkdir(parents=True)
    for path in onig_files(onig):
        target = dest / 'COPYING' if path.name == 'COPYING' else dest / 'src' / path.name
        shutil.copyfile(path, target)
    shutil.copyfile(HERE / 'onig-config.h', dest / 'src' / 'config.h')
    shutil.copyfile(HERE / 'kerberus_onig.c', ruby / 'kerberus_onig.c')
    for unit in ONIG_UNITS:
        (ruby / ('konig_%s.c' % unit)).write_text(
            '/* KERBERUS_ONIG: Oniguruma %s %s.c, part of the Ruby 1.8 core */\n'
            '#include "kerberus-onig/src/%s.c"\n' % (ONIG_VERSION, unit, unit))


def patch_regex_h(path):
    text = path.read_text(encoding='latin-1')
    if MARK in text:
        return False
    text = replace_once(text, '''    unsigned char **best_regend;
  };''', '''    unsigned char **best_regend;

    /* KERBERUS_ONIG: pattern compiled by Oniguruma (kerberus_onig.c)
       because the GNU compiler rejected it; 0 otherwise. */
    void *kerberus_onig;
  };''', 'struct re_pattern_buffer (regex.h)')
    path.write_text(text, encoding='latin-1')
    return True


def patch_regex_c(path):
    text = path.read_text(encoding='latin-1')
    if MARK in text:
        return False
    text = replace_once(text, '''const char *
re_compile_pattern(pattern, size, bufp)
     const char *pattern;
     int size;
     struct re_pattern_buffer *bufp;
{
  register char *b = bufp->buffer;''', '''/* KERBERUS_ONIG: Oniguruma for the patterns GNU rejects (kerberus_onig.c) */
void *kerberus_onig_compile _((const char *, int, int, int, int, int, int *));
int kerberus_onig_exec _((void *, const char *, int, int, int, int));
int kerberus_onig_registers _((void *, int **, int **));
void kerberus_onig_free _((void *));
static int kerberus_onig_result _((struct re_pattern_buffer *, const char *, int, int, int, int,
				   struct re_registers *));

static const char *
kerberus_gnu_compile_pattern(pattern, size, bufp)
     const char *pattern;
     int size;
     struct re_pattern_buffer *bufp;
{
  register char *b = bufp->buffer;''', 're_compile_pattern (regex.c)')

    text = replace_once(text, ''' invalid_escape:
  FREE_AND_RETURN(stackb, "Invalid escape character syntax");
}

void
re_free_pattern(bufp)
     struct re_pattern_buffer *bufp;
{
  xfree(bufp->buffer);''', ''' invalid_escape:
  FREE_AND_RETURN(stackb, "Invalid escape character syntax");
}

/* KERBERUS_ONIG: RGSS1 (RPG Maker XP) compiled regular expressions with
   Oniguruma. GNU stays the engine for every pattern it accepts; a pattern
   it rejects (look-behind, named groups, ...) is compiled by Oniguruma in
   the current $KCODE and matched by it. When Oniguruma rejects it too, the
   GNU error is returned, as before. */
const char *
re_compile_pattern(pattern, size, bufp)
     const char *pattern;
     int size;
     struct re_pattern_buffer *bufp;
{
  long options = bufp->options;
  const char *err;
  void *onig;
  int nregs = 0;

  if (bufp->kerberus_onig) {
    kerberus_onig_free(bufp->kerberus_onig);
    bufp->kerberus_onig = 0;
  }
  err = kerberus_gnu_compile_pattern(pattern, size, bufp);
  if (err == 0) return 0;
  onig = kerberus_onig_compile(pattern, size,
			       (options & RE_OPTION_IGNORECASE) != 0,
			       (options & RE_OPTION_EXTENDED) != 0,
			       (options & RE_OPTION_MULTILINE) != 0,
			       current_mbctype, &nregs);
  if (!onig) return err;
  bufp->kerberus_onig = onig;
  bufp->options = options & (RE_OPTION_IGNORECASE|RE_OPTION_EXTENDED|RE_OPTION_MULTILINE);
  bufp->used = 0;
  bufp->must = 0;
  bufp->re_nsub = nregs;
  bufp->fastmap_accurate = 1;
  return 0;
}

void
re_free_pattern(bufp)
     struct re_pattern_buffer *bufp;
{
  if (bufp->kerberus_onig) kerberus_onig_free(bufp->kerberus_onig);
  xfree(bufp->buffer);''', 're_free_pattern (regex.c)')

    text = replace_once(text, '''{
  (void)re_compile_fastmap0(bufp);
}''', '''{
  if (bufp->kerberus_onig) return;
  (void)re_compile_fastmap0(bufp);
}''', 're_compile_fastmap (regex.c)')

    text = replace_once(text, '''  /* Update the fastmap now if not correct already.  */
  if (!bufp->fastmap_accurate) {''', '''  /* Update the fastmap now if not correct already.  */
  if (!bufp->kerberus_onig && !bufp->fastmap_accurate) {''', 're_adjust_startpos (regex.c)')

    text = replace_once(text, '''  register char *fastmap = bufp->fastmap;
  int val, anchor = 0, initpos = startpos;

  /* Check for out-of-range starting position.  */
  if (startpos < 0  ||  startpos > size)
    return -1;
  if (!string) {
    if (size == 0) string = "";
    else return -1;
  }
''', '''  register char *fastmap = bufp->fastmap;
  int val, anchor = 0, initpos = startpos;

  /* Check for out-of-range starting position.  */
  if (startpos < 0  ||  startpos > size)
    return -1;
  if (!string) {
    if (size == 0) string = "";
    else return -1;
  }
  if (bufp->kerberus_onig)
    return kerberus_onig_result(bufp, string, size, startpos, range, 0, regs);
''', 're_search (regex.c)')

    text = replace_once(text, '''int
re_match(bufp, string_arg, size, pos, regs)
     struct re_pattern_buffer *bufp;
     const char *string_arg;
     int size, pos;
     struct re_registers *regs;
{
  return re_match_exec(bufp, string_arg, size, pos, pos, regs);
}''', '''/* KERBERUS_ONIG: search (ANCHORED == 0) or match at STARTPOS of an
   Oniguruma pattern, with GNU return values (position or length, -1 no
   match, -2 matcher failure) and registers. */
static int
kerberus_onig_result(bufp, string, size, startpos, range, anchored, regs)
     struct re_pattern_buffer *bufp;
     const char *string;
     int size, startpos, range, anchored;
     struct re_registers *regs;
{
  int val, num_regs, i;
  int *beg, *end;

  if (startpos < 0 || startpos > size)
    return -1;
  if (!string) {
    if (size == 0) string = "";
    else return -1;
  }
  if (range > 0 && startpos + range > size) range = size - startpos;
  if (range < 0 && startpos + range < 0) range = -startpos;
  val = kerberus_onig_exec(bufp->kerberus_onig, string, size, startpos, range, anchored);
  if (val < 0 || !regs) return val;
  num_regs = kerberus_onig_registers(bufp->kerberus_onig, &beg, &end);
  init_regs(regs, num_regs);
  for (i = 0; i < num_regs; i++) {
    regs->beg[i] = beg[i];
    regs->end[i] = end[i];
  }
  return val;
}

int
re_match(bufp, string_arg, size, pos, regs)
     struct re_pattern_buffer *bufp;
     const char *string_arg;
     int size, pos;
     struct re_registers *regs;
{
  if (bufp->kerberus_onig)
    return kerberus_onig_result(bufp, string_arg, size, pos, 0, 1, regs);
  return re_match_exec(bufp, string_arg, size, pos, pos, regs);
}''', 're_match (regex.c)')
    path.write_text(text, encoding='latin-1')
    return True


def patch_re_c(path):
    text = path.read_text(encoding='latin-1')
    if MARK in text:
        return False
    text = replace_once(text, '''
void
Init_Regexp()
''', '''
/* KERBERUS_ONIG: [Oniguruma version, patterns it compiled because the GNU
   engine rejected them] (kerberus_onig.c). */
const char *kerberus_onig_version _((void));
long kerberus_onig_count _((void));

static VALUE
kerberus_reg_s_oniguruma(klass)
    VALUE klass;
{
    return rb_assoc_new(rb_str_new2(kerberus_onig_version()), LONG2NUM(kerberus_onig_count()));
}

void
Init_Regexp()
''', 'Init_Regexp (re.c)')
    text = replace_once(text, '''    rb_define_singleton_method(rb_cRegexp, "union", rb_reg_s_union_m, -2);
''', '''    rb_define_singleton_method(rb_cRegexp, "union", rb_reg_s_union_m, -2);
    rb_define_singleton_method(rb_cRegexp, "kerberus_oniguruma", kerberus_reg_s_oniguruma, 0);
''', 'Regexp.union (re.c)')
    path.write_text(text, encoding='latin-1')
    return True


def patch_common_mk(path):
    text = path.read_text(encoding='latin-1')
    if MARK in text:
        return False
    text = replace_once(text, '\t\tregex.$(OBJEXT) \\\n',
                        '\t\tregex.$(OBJEXT) \\\n\t\t$(KERBERUS_ONIG_OBJS) \\\n',
                        'regex.$(OBJEXT) na lista de objetos (common.mk)')
    units = ['kerberus_onig'] + ['konig_' + unit for unit in ONIG_UNITS]
    # Variables first: make expands prerequisites ($(LIBRUBY_A): $(OBJS))
    # when it reads the rule, so the list must exist before that line.
    variables = ['# KERBERUS_ONIG: Oniguruma %s (BSD 2-Clause, kerberus-onig/COPYING) for the' % ONIG_VERSION,
                 '# regex syntax the GNU engine rejects; see kerberus_onig.c. C99 sources.',
                 'KERBERUS_ONIG_CFLAGS = -std=gnu99',
                 'KERBERUS_ONIG_OBJS = ' + ' '.join(u + '.$(OBJEXT)' for u in units),
                 '', '']
    rules = ['', '# KERBERUS_ONIG objects']
    for unit in units:
        rules.append('%s.$(OBJEXT): $(srcdir)/%s.c' % (unit, unit))
        rules.append('\t$(CC) $(CFLAGS) $(CPPFLAGS) $(KERBERUS_ONIG_CFLAGS) -c $(srcdir)/%s.c -o $@' % unit)
    text = '\n'.join(variables) + text.rstrip('\n') + '\n' + '\n'.join(rules) + '\n'
    path.write_text(text, encoding='latin-1')
    return True


def main():
    if len(sys.argv) == 3 and sys.argv[1] == '--regex-h':
        # Reference check of the Android build: the prebuilt regex.h plus
        # exactly this field must give the regex.h of the new build.
        patch_regex_h(pathlib.Path(sys.argv[2]))
        return
    if len(sys.argv) != 3:
        fail('uso: patch-ruby18-oniguruma.py RUBY_SRC ONIG_CHECKOUT | --regex-h ARQUIVO')
    ruby = pathlib.Path(sys.argv[1])
    onig = pathlib.Path(sys.argv[2])
    for name in ('regex.c', 'regex.h', 're.c', 'common.mk'):
        if not (ruby / name).is_file():
            fail('%s ausente em %s' % (name, ruby))
    copy_onig(ruby, onig)
    changed = [patch_regex_h(ruby / 'regex.h'), patch_regex_c(ruby / 'regex.c'),
               patch_re_c(ruby / 're.c'), patch_common_mk(ruby / 'common.mk')]
    state = 'aplicado' if any(changed) else 'ja presente'
    print('[RUBY18] Oniguruma %s (%s) para regex que o GNU rejeita: %s' % (ONIG_VERSION, ONIG_COMMIT[:12], state))


if __name__ == '__main__':
    main()
