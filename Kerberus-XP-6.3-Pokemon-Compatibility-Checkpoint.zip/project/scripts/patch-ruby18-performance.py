#!/usr/bin/env python3
"""Kerberus: Ruby 1.8 GC/method-cache tuning and GC statistics.

Ruby 1.8 was tuned for 2000-era desktops: a full mark-and-sweep every 8 MB
of new allocations (GC_MALLOC_LIMIT), a first heap of 10 000 objects that
grows 1.8x at a time, and a 2048-entry global method cache. A Pokemon
Essentials game keeps a few hundred thousand live objects, so every
collection walks all of them and a game stutters every few seconds.

This patch keeps the algorithms and changes only numbers:
  gc.c   - malloc limit and first heap size read once from the environment
           (KERBERUS_GC_MALLOC_LIMIT, KERBERUS_GC_HEAP_SLOTS), with Kerberus
           defaults; GC.kerberus_stats -> [collections, total_ns, max_ns,
           heap_slots, malloc_limit] for the runtime's performance report.
  eval.c - method cache size from KERBERUS_METHOD_CACHE_SIZE (compile time).
  gc.c   - (6.4.3) GC.kerberus_pressure -> how far (percent) the process is
           from its next collection: the larger of the malloc growth against
           malloc_limit and the free object slots used since the last
           collection. The runtime collects at scene transitions, while the
           screen is frozen, when it is high (legacy18 94_idle_gc.rb).

Usage: patch-ruby18-performance.py path/to/ruby-source   (idempotent)
"""
import pathlib
import sys

MARK = 'KERBERUS_RUBY18_PERF'
PRESSURE_MARK = 'KERBERUS_RUBY18_GC_PRESSURE'
DEFAULT_MALLOC = 16000000
DEFAULT_SLOTS = 10000
DEFAULT_CACHE = '0x4000'


def fail(message):
    sys.exit('[RUBY18][ERRO] patch de desempenho: ' + message)


def replace_once(text, old, new, what):
    if text.count(old) != 1:
        fail(what + ' nao encontrado exatamente uma vez')
    return text.replace(old, new)


def patch_gc(path):
    text = path.read_text(encoding='latin-1')
    if MARK in text:
        return False
    text = replace_once(text, '''static unsigned long malloc_increase = 0;
static unsigned long malloc_limit = GC_MALLOC_LIMIT;''', '''static unsigned long malloc_increase = 0;
/* KERBERUS_RUBY18_PERF: tunable limits and collection statistics */
#include <time.h>
#ifndef KERBERUS_GC_MALLOC_LIMIT
#define KERBERUS_GC_MALLOC_LIMIT %d
#endif
#ifndef KERBERUS_GC_HEAP_SLOTS
#define KERBERUS_GC_HEAP_SLOTS %d
#endif
static unsigned long malloc_limit = KERBERUS_GC_MALLOC_LIMIT;
static unsigned long kerberus_malloc_floor = KERBERUS_GC_MALLOC_LIMIT;
static unsigned long kerberus_gc_count = 0;
static unsigned long long kerberus_gc_total_ns = 0;
static unsigned long long kerberus_gc_max_ns = 0;

static unsigned long
kerberus_env_ulong(const char *name, unsigned long fallback, unsigned long low, unsigned long high)
{
    const char *text = getenv(name);
    char *end = 0;
    unsigned long value;
    if (!text || !*text) return fallback;
    value = strtoul(text, &end, 10);
    if (!end || *end) return fallback;
    if (value < low) value = low;
    if (value > high) value = high;
    return value;
}

static unsigned long long
kerberus_now_ns()
{
    struct timespec now;
    if (clock_gettime(CLOCK_MONOTONIC, &now) != 0) return 0;
    return (unsigned long long)now.tv_sec * 1000000000ULL + (unsigned long long)now.tv_nsec;
}''' % (DEFAULT_MALLOC, DEFAULT_SLOTS), 'malloc_limit')
    text = replace_once(text, '''	if (malloc_limit < GC_MALLOC_LIMIT) malloc_limit = GC_MALLOC_LIMIT;''',
                        '''	if (malloc_limit < kerberus_malloc_floor) malloc_limit = kerberus_malloc_floor;''', 'piso do malloc_limit')
    text = replace_once(text, '''static void
garbage_collect()
{
    struct gc_list *list;''', '''static void garbage_collect_0();

/* KERBERUS_RUBY18_PERF: time every collection that actually sweeps. */
static void
garbage_collect()
{
    unsigned long before = kerberus_gc_count;
    unsigned long long start = kerberus_now_ns();
    unsigned long long spent;
    garbage_collect_0();
    if (kerberus_gc_count == before) return;
    spent = kerberus_now_ns() - start;
    kerberus_gc_total_ns += spent;
    if (spent > kerberus_gc_max_ns) kerberus_gc_max_ns = spent;
}

static void
garbage_collect_0()
{
    struct gc_list *list;''', 'garbage_collect')
    text = replace_once(text, '''    gc_sweep();
}

void
rb_gc()''', '''    kerberus_gc_count++;
    gc_sweep();
}

void
rb_gc()''', 'fim de garbage_collect')
    text = replace_once(text, '''void
Init_heap()
{
    if (!rb_gc_stack_start) {
	Init_stack(0);
    }
    add_heap();
}''', '''void
Init_heap()
{
    if (!rb_gc_stack_start) {
	Init_stack(0);
    }
    kerberus_malloc_floor = kerberus_env_ulong("KERBERUS_GC_MALLOC_LIMIT", KERBERUS_GC_MALLOC_LIMIT, 1000000UL, 1000000000UL);
    malloc_limit = kerberus_malloc_floor;
    heap_slots = (int)kerberus_env_ulong("KERBERUS_GC_HEAP_SLOTS", KERBERUS_GC_HEAP_SLOTS, HEAP_MIN_SLOTS, 4000000UL);
    add_heap();
}

/* GC.kerberus_stats -> [collections, total_ns, max_ns, heap_slots, malloc_limit] */
static VALUE
gc_kerberus_stats(self)
    VALUE self;
{
    unsigned long slots = 0;
    int i;
    for (i = 0; i < heaps_used; i++) slots += heaps[i].limit;
    return rb_ary_new3(5, ULONG2NUM(kerberus_gc_count), ULL2NUM(kerberus_gc_total_ns),
                       ULL2NUM(kerberus_gc_max_ns), ULONG2NUM(slots), ULONG2NUM(malloc_limit));
}''', 'Init_heap')
    text = replace_once(text, '''    rb_define_singleton_method(rb_mGC, "start", rb_gc_start, 0);''',
                        '''    rb_define_singleton_method(rb_mGC, "start", rb_gc_start, 0);
    rb_define_singleton_method(rb_mGC, "kerberus_stats", gc_kerberus_stats, 0);''', 'Init_GC')
    path.write_text(text, encoding='latin-1')
    return True


def patch_gc_pressure(path):
    text = path.read_text(encoding='latin-1')
    if PRESSURE_MARK in text:
        return False
    if MARK not in text:
        fail('pressao do GC exige o patch de desempenho do gc.c')
    text = replace_once(text, '''static unsigned long long kerberus_gc_max_ns = 0;
''', '''static unsigned long long kerberus_gc_max_ns = 0;
/* KERBERUS_RUBY18_GC_PRESSURE: slots on the free list now and right after
   the last collection (GC.kerberus_pressure); counted where the free list
   changes: add_heap, add_freelist (sweep, finalizers, force_recycle),
   rb_newobj */
static long kerberus_free_slots = 0;
static long kerberus_free_base = 0;
''', 'contadores de slots livres')
    text = replace_once(text, '''    heap_slots *= 1.8;
    if (heap_slots <= 0) heap_slots = HEAP_MIN_SLOTS;

    while (p < pend) {''', '''    heap_slots *= 1.8;
    if (heap_slots <= 0) heap_slots = HEAP_MIN_SLOTS;
    kerberus_free_slots += pend - p;
    kerberus_free_base += pend - p;

    while (p < pend) {''', 'add_heap')
    text = replace_once(text, '''    obj = (VALUE)freelist;
    freelist = freelist->as.free.next;
    MEMZERO((void*)obj, RVALUE, 1);''', '''    obj = (VALUE)freelist;
    freelist = freelist->as.free.next;
    kerberus_free_slots--;
    MEMZERO((void*)obj, RVALUE, 1);''', 'rb_newobj')
    text = replace_once(text, '''add_freelist(p)
    RVALUE *p;
{
    p->as.free.flags = 0;''', '''add_freelist(p)
    RVALUE *p;
{
    kerberus_free_slots++;
    p->as.free.flags = 0;''', 'add_freelist')
    text = replace_once(text, '''    freelist = 0;
    final_list = deferred_final_list;''', '''    freelist = 0;
    kerberus_free_slots = 0;
    final_list = deferred_final_list;''', 'gc_sweep')
    text = replace_once(text, '''	RVALUE *final = final_list;
	int deferred;
''', '''	RVALUE *final = final_list;
	int deferred;
	long kerberus_page_start = kerberus_free_slots;
''', 'pagina do gc_sweep')
    text = replace_once(text, '''	    freelist = free;	/* cancel this page from freelist */''',
                        '''	    freelist = free;	/* cancel this page from freelist */
	    kerberus_free_slots = kerberus_page_start;''', 'pagina liberada')
    text = replace_once(text, '''    if (kerberus_gc_count == before) return;
''', '''    if (kerberus_gc_count == before) return;
    kerberus_free_base = kerberus_free_slots;
''', 'garbage_collect')
    text = replace_once(text, '''                       ULL2NUM(kerberus_gc_max_ns), ULONG2NUM(slots), ULONG2NUM(malloc_limit));
}''', '''                       ULL2NUM(kerberus_gc_max_ns), ULONG2NUM(slots), ULONG2NUM(malloc_limit));
}

/* GC.kerberus_pressure -> 0..100, how far the process is from its next
   collection (malloc growth or object slots, the larger) */
static VALUE
gc_kerberus_pressure(self)
    VALUE self;
{
    long heap = 0, memory;
    if (kerberus_free_base > 0)
        heap = (kerberus_free_base - kerberus_free_slots) * 100 / kerberus_free_base;
    memory = (long)(malloc_increase / (malloc_limit / 100 + 1));
    if (memory > heap) heap = memory;
    if (heap < 0) heap = 0;
    if (heap > 100) heap = 100;
    return LONG2NUM(heap);
}''', 'gc_kerberus_stats')
    text = replace_once(text, '''    rb_define_singleton_method(rb_mGC, "kerberus_stats", gc_kerberus_stats, 0);''',
                        '''    rb_define_singleton_method(rb_mGC, "kerberus_stats", gc_kerberus_stats, 0);
    rb_define_singleton_method(rb_mGC, "kerberus_pressure", gc_kerberus_pressure, 0);''', 'Init_GC pressao')
    path.write_text(text, encoding='latin-1')
    return True


def patch_eval(path):
    text = path.read_text(encoding='latin-1')
    if MARK in text:
        return False
    text = replace_once(text, '''#define CACHE_SIZE 0x800
#define CACHE_MASK 0x7ff''', '''/* KERBERUS_RUBY18_PERF: larger global method cache */
#ifndef KERBERUS_METHOD_CACHE_SIZE
#define KERBERUS_METHOD_CACHE_SIZE %s
#endif
#define CACHE_SIZE KERBERUS_METHOD_CACHE_SIZE
#define CACHE_MASK (CACHE_SIZE - 1)''' % DEFAULT_CACHE, 'CACHE_SIZE')
    path.write_text(text, encoding='latin-1')
    return True


def main():
    if len(sys.argv) != 2:
        fail('uso: patch-ruby18-performance.py pasta-do-ruby')
    root = pathlib.Path(sys.argv[1])
    steps = (('gc.c', 'gc.c', patch_gc), ('gc.c (pressao)', 'gc.c', patch_gc_pressure), ('eval.c', 'eval.c', patch_eval))
    changed = [name for name, file, fn in steps if fn(root / file)]
    print('[RUBY18] patch de desempenho ' + ('aplicado: ' + ', '.join(changed) if changed else 'ja aplicado'))


main()
