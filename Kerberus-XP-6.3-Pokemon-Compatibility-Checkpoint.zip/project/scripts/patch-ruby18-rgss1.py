#!/usr/bin/env python3
"""Kerberus: RGSS1 superclass rule (Ruby 1.8.1) in a Ruby 1.8 eval.c.

RPG Maker XP and VX run game scripts on Ruby 1.8.1. When a script reopens
a class with a different superclass, 1.8.1's NODE_CLASS jumps to
"override_class" and defines a new class under that name. Ruby 1.8.2 and
later raise "superclass mismatch for class X" instead (Pokemon Uranium,
Window_PokemonBag). This restores the 1.8.1 rule in the interpreter.

Differences from 1.8.1, both invisible to game code: the old constant is
removed before the new class is stored, so Ruby does not print "already
initialized constant"; and each case is reported to the optional hook
$__kerberus_rgss1_class_override (called with cbase, name, old superclass,
new superclass; errors inside the hook are ignored).

Usage: patch-ruby18-rgss1.py path/to/eval.c   (idempotent; fails loudly
if the expected Ruby 1.8 code is not found)
"""
import pathlib
import sys

MARK = 'KERBERUS_RGSS1_CLASS_RULE'

RAISE = '''		    if (tmp != super) {
			rb_raise(rb_eTypeError, "superclass mismatch for class %s",
				 rb_id2name(cname));
		    }
		    super = 0;'''
OVERRIDE = '''		    if (tmp != super) {
			/* KERBERUS_RGSS1_CLASS_RULE: Ruby 1.8.1 "override_class" */
			kerberus_rgss1_class_override(cbase, cname, tmp, super);
			goto kerberus_rgss1_override_class;
		    }
		    super = 0;'''
DEFINE = '''	    else {
		if (!super) super = rb_cObject;
		klass = rb_define_class_id(cname, super);'''
DEFINE_LABEL = '''	    else {
	      kerberus_rgss1_override_class:
		if (!super) super = rb_cObject;
		klass = rb_define_class_id(cname, super);'''
RB_EVAL = '''static VALUE
rb_eval(self, n)'''
HELPERS = '''/* KERBERUS_RGSS1_CLASS_RULE
 * RPG Maker XP/VX scripts ran on Ruby 1.8.1: reopening a class with a
 * different superclass defined a new class under that name. The old
 * constant is removed first (1.8.1 rebound it and warned), and the case
 * is reported to $__kerberus_rgss1_class_override when that is callable. */
static VALUE
kerberus_rgss1_call_hook(VALUE data)
{
    VALUE *argv = (VALUE *)data;
    return rb_funcall(argv[0], rb_intern("call"), 4, argv[1], argv[2], argv[3], argv[4]);
}

static void
kerberus_rgss1_class_override(VALUE cbase, ID cname, VALUE old_super, VALUE new_super)
{
    VALUE hook = rb_gv_get("$__kerberus_rgss1_class_override");
    if (!NIL_P(hook) && rb_respond_to(hook, rb_intern("call"))) {
        VALUE argv[5];
        int state = 0;
        argv[0] = hook;
        argv[1] = cbase;
        argv[2] = rb_str_new2(rb_id2name(cname));
        argv[3] = old_super;
        argv[4] = new_super;
        rb_protect(kerberus_rgss1_call_hook, (VALUE)argv, &state);
        if (state) ruby_errinfo = Qnil;
    }
    /* Only an own constant is removed; one seen through an included
     * module is shadowed by the new class, exactly as in 1.8.1. */
    if (RCLASS(cbase)->iv_tbl && st_lookup(RCLASS(cbase)->iv_tbl, (st_data_t)cname, 0))
        rb_mod_remove_const(cbase, ID2SYM(cname));
}

'''


def fail(message):
    sys.exit('[RUBY18][ERRO] patch RGSS1: ' + message)


def main():
    if len(sys.argv) != 2:
        fail('uso: patch-ruby18-rgss1.py eval.c')
    path = pathlib.Path(sys.argv[1])
    text = path.read_text(encoding='latin-1')
    if MARK in text:
        if text.count('goto kerberus_rgss1_override_class;') != 1 or 'kerberus_rgss1_override_class:' not in text:
            fail('eval.c parcialmente alterado')
        print('[RUBY18] patch RGSS1 ja aplicado: ' + str(path))
        return
    start = text.find('      case NODE_CLASS:')
    end = text.find('      case NODE_MODULE:', start)
    if start < 0 or end < 0:
        fail('NODE_CLASS nao encontrado')
    block = text[start:end]
    if block.count(RAISE) != 1 or block.count(DEFINE) != 1:
        fail('NODE_CLASS diferente do Ruby 1.8 esperado')
    block = block.replace(RAISE, OVERRIDE).replace(DEFINE, DEFINE_LABEL)
    text = text[:start] + block + text[end:]
    if text.count(RB_EVAL) != 1:
        fail('definicao de rb_eval nao encontrada')
    text = text.replace(RB_EVAL, HELPERS + RB_EVAL)
    path.write_text(text, encoding='latin-1')
    print('[RUBY18] patch RGSS1 aplicado: ' + str(path))


main()
