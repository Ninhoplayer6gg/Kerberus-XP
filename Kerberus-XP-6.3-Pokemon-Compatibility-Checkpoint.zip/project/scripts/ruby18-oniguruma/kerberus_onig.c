/**********************************************************************

  kerberus_onig.c - Oniguruma fallback for the Ruby 1.8 regex engine
  (Kerberus XP, legacy18 only; copied into the Ruby 1.8 source tree by
  scripts/patch-ruby18-oniguruma.py)

  RPG Maker XP compiles game scripts with a Ruby 1.8.1 whose regular
  expressions accept syntax the GNU engine of Ruby 1.8.7 rejects when the
  script is parsed: look-behind (?<=...) (?<!...), named groups
  (?<name>...), possessive quantifiers, \h ... One such literal makes the
  whole script section a SyntaxError ("undefined (?...) sequence",
  Pokemon Uranium, Section253).

  regex.c keeps the GNU engine for every pattern it accepts, so their
  behaviour does not change; only the patterns it rejects are compiled
  here, by Oniguruma 6.9.10 with Ruby syntax and the encoding of the
  $KCODE in effect (as GNU does). Only the patched regex.c and re.c call
  this file.

  Oniguruma: Copyright (c) 2002-2021 K.Kosako, BSD 2-Clause licence
  (kerberus-onig/COPYING, THIRD-PARTY-NOTICES.md).

**********************************************************************/

#include <stdlib.h>
#include <string.h>
#include "kerberus-onig/src/oniguruma.h"

struct kerberus_onig {
  OnigRegex reg;          /* pattern in the $KCODE encoding */
  OnigRegex bytes;        /* same pattern byte-wise, for invalid strings */
  OnigRegion *region;     /* registers of the last match */
  OnigOptionType options;
  OnigUChar *pattern;
  int size;
};

static int kerberus_onig_ready = 0;
static long kerberus_onig_compiled = 0;

/* Ruby 1.8 MBCTYPE_ASCII, _EUC, _SJIS, _UTF8 (regex.h). */
static OnigEncoding
kerberus_onig_encoding(int mbctype)
{
  switch (mbctype) {
  case 1: return ONIG_ENCODING_EUC_JP;
  case 2: return ONIG_ENCODING_SJIS;
  case 3: return ONIG_ENCODING_UTF8;
  default: return ONIG_ENCODING_ASCII;
  }
}

static int
kerberus_onig_init(void)
{
  if (!kerberus_onig_ready) {
    OnigEncoding encodings[4];
    encodings[0] = ONIG_ENCODING_ASCII;
    encodings[1] = ONIG_ENCODING_EUC_JP;
    encodings[2] = ONIG_ENCODING_SJIS;
    encodings[3] = ONIG_ENCODING_UTF8;
    if (onig_initialize(encodings, 4) != ONIG_NORMAL) return 0;
    kerberus_onig_ready = 1;
  }
  return 1;
}

void
kerberus_onig_free(void *handle)
{
  struct kerberus_onig *k = (struct kerberus_onig *)handle;
  if (!k) return;
  if (k->reg) onig_free(k->reg);
  if (k->bytes) onig_free(k->bytes);
  if (k->region) onig_region_free(k->region, 1);
  free(k->pattern);
  free(k);
}

/* Compiles PATTERN; returns a handle or 0 when Oniguruma rejects it too
   (the caller then reports the GNU error, as before). *NREGS receives the
   number of registers (groups + 1). */
void *
kerberus_onig_compile(const char *pattern, int size, int ignorecase,
                      int extended, int multiline, int mbctype, int *nregs)
{
  struct kerberus_onig *k;
  OnigErrorInfo einfo;
  const OnigUChar *p = (const OnigUChar *)pattern;

  if (size < 0 || !kerberus_onig_init()) return 0;
  k = (struct kerberus_onig *)calloc(1, sizeof(*k));
  if (!k) return 0;
  k->options = ONIG_OPTION_NONE;
  if (ignorecase) k->options |= ONIG_OPTION_IGNORECASE;
  if (extended) k->options |= ONIG_OPTION_EXTEND;
  if (multiline) k->options |= ONIG_OPTION_MULTILINE;
  k->size = size;
  k->pattern = (OnigUChar *)malloc(size > 0 ? size : 1);
  k->region = onig_region_new();
  if (!k->pattern || !k->region) {
    kerberus_onig_free(k);
    return 0;
  }
  if (size > 0) memcpy(k->pattern, pattern, size);
  if (onig_new(&k->reg, p, p + size, k->options, kerberus_onig_encoding(mbctype),
               ONIG_SYNTAX_RUBY, &einfo) != ONIG_NORMAL) {
    k->reg = 0;
    kerberus_onig_free(k);
    return 0;
  }
  *nregs = onig_number_of_captures(k->reg) + 1;
  kerberus_onig_compiled++;
  return k;
}

/* GNU re_search (ANCHORED == 0: returns the match position) or re_match
   (ANCHORED != 0 at START: returns the match length). -1: no match;
   -2: engine error (re.c raises, as for a GNU matcher failure).
   RANGE follows re_search: tries START .. START+RANGE, backwards when
   negative (the same mapping Ruby 1.9 uses for onig_search). */
int
kerberus_onig_exec(void *handle, const char *string, int size, int start,
                   int range, int anchored)
{
  struct kerberus_onig *k = (struct kerberus_onig *)handle;
  const OnigUChar *str = (const OnigUChar *)(string ? string : "");
  const OnigUChar *end = str + size;
  OnigRegex reg = k->reg;
  int r;

  /* Oniguruma needs valid strings in the pattern's encoding; GNU steps
     over bad bytes one at a time, so match such strings byte-wise. */
  if (!onigenc_is_valid_mbc_string(onig_get_encoding(k->reg), str, end)) {
    if (!k->bytes) {
      OnigErrorInfo einfo;
      if (onig_new(&k->bytes, k->pattern, k->pattern + k->size, k->options,
                   ONIG_ENCODING_ASCII, ONIG_SYNTAX_RUBY, &einfo) != ONIG_NORMAL) {
        k->bytes = 0;
        return -2;
      }
    }
    reg = k->bytes;
  }
  onig_region_clear(k->region);
  if (anchored)
    r = onig_match(reg, str, end, str + start, k->region, ONIG_OPTION_NONE);
  else
    r = onig_search(reg, str, end, str + start, str + start + range,
                    k->region, ONIG_OPTION_NONE);
  if (r >= 0) return r;
  if (r == ONIG_MISMATCH) return -1;
  return -2;
}

/* Registers of the last successful kerberus_onig_exec (-1 = unset). */
int
kerberus_onig_registers(void *handle, int **beg, int **end)
{
  struct kerberus_onig *k = (struct kerberus_onig *)handle;
  *beg = k->region->beg;
  *end = k->region->end;
  return k->region->num_regs;
}

/* Regexp.kerberus_oniguruma (re.c): version and patterns compiled here. */
const char *
kerberus_onig_version(void)
{
  return onig_version();
}

long
kerberus_onig_count(void)
{
  return kerberus_onig_compiled;
}
