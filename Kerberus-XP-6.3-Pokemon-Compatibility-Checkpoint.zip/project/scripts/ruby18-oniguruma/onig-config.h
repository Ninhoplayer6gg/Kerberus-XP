/* Kerberus XP: Oniguruma 6.9.10 configuration for the Ruby 1.8 core
   (replaces the config.h that Oniguruma's CMake/autotools would write;
   copied to kerberus-onig/src/config.h by patch-ruby18-oniguruma.py).
   Sizes come from the compiler, so one file serves every target. */
#ifndef KERBERUS_ONIG_CONFIG_H
#define KERBERUS_ONIG_CONFIG_H
#define HAVE_ALLOCA 1
#define HAVE_ALLOCA_H 1
#define HAVE_STDINT_H 1
#define HAVE_INTTYPES_H 1
#define HAVE_SYS_TYPES_H 1
#define HAVE_SYS_TIME_H 1
#define HAVE_SYS_TIMES_H 1
#define HAVE_UNISTD_H 1
#define SIZEOF_INT __SIZEOF_INT__
#define SIZEOF_LONG __SIZEOF_LONG__
#define SIZEOF_LONG_LONG __SIZEOF_LONG_LONG__
#define SIZEOF_VOIDP __SIZEOF_POINTER__
#define PACKAGE "onig"
#define PACKAGE_VERSION "6.9.10"
#define VERSION "6.9.10"
#endif
