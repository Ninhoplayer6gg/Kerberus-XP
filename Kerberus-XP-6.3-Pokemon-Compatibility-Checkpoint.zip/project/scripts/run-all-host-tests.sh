#!/usr/bin/env bash
# Kerberus XP 6.3 - every host-side check in one place.
#   RUBY18=<Ruby 1.8.7>  RUBY31=<Ruby 3.1>  [DEPS=<header checkouts> RUBY18_INCLUDE=... for C++ checks]
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
bash scripts/validate-host.sh
python3 tools/gen-legacy18-header.py --check
RUBY18="${RUBY18:?defina RUBY18 (Ruby 1.8.7 real)}" bash tests/legacy18/run-legacy18-tests.sh
KERBERUS_TEST_WORK="${TMPDIR:-/tmp}/kerberus-catalog-$$" "$RUBY18" tools/gen-legacy18-catalog.rb --check
RUBY31="${RUBY31:?defina RUBY31 (Ruby 3.1)}" bash tests/modern31/run-modern31-tests.sh
if [ -n "${DEPS:-}" ]; then
  bash tools/host-compile-check.sh
  bash tests/native/run-lifecycle-test.sh
else
  echo "[AVISO] DEPS nao definido: checagem C++ e teste nativo de ciclo de vida pulados"
fi
echo KERBERUS_63_ALL_HOST_TESTS_OK
