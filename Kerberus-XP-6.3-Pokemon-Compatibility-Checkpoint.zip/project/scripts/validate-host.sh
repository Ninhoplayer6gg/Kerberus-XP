#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${TMPDIR:-/tmp}/kerberus-63-host-tests"
rm -rf "$OUT"; mkdir -p "$OUT/classes"

javac -encoding UTF-8 -d "$OUT/classes" \
  "$ROOT/app/src/main/java/com/kerberus/launcher/GameIni.java" \
  "$ROOT/app/src/main/java/com/kerberus/launcher/GameIntelligence.java" \
  "$ROOT/app/src/main/java/com/kerberus/launcher/RuntimeSelector.java" \
  "$ROOT/tests/RuntimeSelectorHostTest.java"
java -cp "$OUT/classes" com.kerberus.launcher.RuntimeSelectorHostTest

javac -encoding UTF-8 -d "$OUT/classes" \
  "$ROOT/app/src/main/java/com/kerberus/toolkit/SessionLock.java" \
  "$ROOT/tests/SessionLockHostTest.java"
java -cp "$OUT/classes" com.kerberus.toolkit.SessionLockHostTest

javac -encoding UTF-8 -d "$OUT/classes" \
  "$ROOT/app/src/main/java/com/kerberus/launcher/ControlGeometry.java" \
  "$ROOT/app/src/main/java/com/kerberus/launcher/ControlInput.java" \
  "$ROOT/tests/ControlsHostTest.java"
java -cp "$OUT/classes" com.kerberus.launcher.ControlsHostTest

javac -encoding UTF-8 -d "$OUT/classes" \
  "$ROOT/app/src/main/java/com/kerberus/launcher/GameIni.java" \
  "$ROOT/app/src/main/java/com/kerberus/launcher/GameIntelligence.java" \
  "$ROOT/app/src/main/java/com/kerberus/launcher/RuntimeOptions.java" \
  "$ROOT/app/src/main/java/com/kerberus/x/compat/ScriptPackReader.java" \
  "$ROOT/app/src/main/java/com/kerberus/x/compat/CompatibilityAnalyzer.java" \
  "$ROOT/app/src/main/java/com/kerberus/x/compat/CompatibilityStatus.java" \
  "$ROOT/tests/CompatibilityStatusHostTest.java"
java -Dkerberus.root="$ROOT" -cp "$OUT/classes" com.kerberus.x.compat.CompatibilityStatusHostTest

echo KERBERUS_63_HOST_VALIDATION_OK
