package com.kerberus.x.compat;
import com.kerberus.launcher.RuntimeOptions;
import java.io.File;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.Map;
public final class CompatibilityStatusHostTest {
  static void check(boolean ok,String message){if(!ok)throw new AssertionError(message);System.out.println("OK "+message);}
  public static void main(String[] a)throws Exception{
    File dir=Files.createTempDirectory("k63status").toFile();
    CompatibilityStatus empty=CompatibilityStatus.read(dir);
    check(empty.level()==CompatibilityStatus.Level.NOT_TESTED,"sem evidencia = Nao testado");
    check(empty.report().startsWith("Estado: Não testado"),"relatorio vazio");
    Files.write(new File(dir,"milestones.log").toPath(),("MILESTONE\tBOOT\tmodern31\t1790000000\t812 secoes carregadas; iniciando Main\n"
        +"MILESTONE\tMAP\tlegacy18\t1790000100\tmap_id=5 movimento confirmado\n"
        +"MILESTONE\tBOOT\tlegacy18\t1790000200\tsegunda sessao\n"
        +"lixo\tqualquer\n"
        +"MILESTONE\tDESCONHECIDO\tlegacy18\t1\tx\n").getBytes(StandardCharsets.UTF_8));
    CompatibilityStatus status=CompatibilityStatus.read(dir);
    check(status.level()==CompatibilityStatus.Level.MAP,"nivel = maior marco com evidencia");
    check(status.reached.get(CompatibilityStatus.Level.BOOT).runtime.equals("modern31"),"primeira evidencia de cada marco e mantida");
    check(!status.reached.containsKey(CompatibilityStatus.Level.BATTLE),"batalha nao confirmada");
    String report=status.report();
    check(report.contains("[x] Mapa confirmado")&&report.contains("[ ] Batalha confirmada"),"relatorio marca confirmados e pendentes");
    Files.write(new File(dir,"milestones.log.previous").toPath(),"MILESTONE\tSAVE\tlegacy18\t1780000000\tGame.rxdata\n".getBytes(StandardCharsets.UTF_8));
    check(CompatibilityStatus.read(dir).level()==CompatibilityStatus.Level.SAVE,"geracao anterior do registro tambem conta");

    File game=Files.createTempDirectory("k63opts").toFile();
    Map<String,String> env=RuntimeOptions.environment(game);
    check(env.get("KERBERUS_WINTRACE").equals("summary")&&env.get("KERBERUS_FS_COMPAT").equals("on"),"padroes");
    Files.write(new File(game,RuntimeOptions.FILE_NAME).toPath(),"# opcoes\nwintrace=detail\nfilesystem=native\ndump_scripts=on\nports_disable=klein_bitmap,gif_dll\n".getBytes(StandardCharsets.UTF_8));
    env=RuntimeOptions.environment(game);
    check(env.get("KERBERUS_WINTRACE").equals("detail"),"wintrace=detail");
    check(env.get("KERBERUS_FS_COMPAT").equals("off"),"filesystem=native desliga a camada Windows");
    check(env.get("KERBERUS_DUMP_SCRIPTS").equals("1"),"dump_scripts");
    check(env.get("KERBERUS_PORTS_DISABLE").equals("klein_bitmap,gif_dll"),"ports_disable");
    Files.write(new File(game,RuntimeOptions.FILE_NAME).toPath(),"wintrace=tudo\n".getBytes(StandardCharsets.UTF_8));
    try{RuntimeOptions.environment(game);throw new AssertionError("valor invalido aceito");}catch(java.io.IOException expected){System.out.println("OK valor invalido rejeitado: "+expected.getMessage());}
    Files.write(new File(game,RuntimeOptions.FILE_NAME).toPath(),"LD_PRELOAD=/x\n".getBytes(StandardCharsets.UTF_8));
    try{RuntimeOptions.environment(game);throw new AssertionError("chave desconhecida aceita");}catch(java.io.IOException expected){System.out.println("OK chave desconhecida rejeitada");}
    System.out.println("KERBERUS_COMPATIBILITY_STATUS_HOST_TEST_OK");
  }
}
