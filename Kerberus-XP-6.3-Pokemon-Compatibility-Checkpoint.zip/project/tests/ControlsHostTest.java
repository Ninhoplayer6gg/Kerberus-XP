package com.kerberus.launcher;
import java.util.*;
public final class ControlsHostTest {
    private static final class Sink implements ControlInput.Sink {
        final List<String> events = new ArrayList<>();
        public void down(int key) { events.add("D" + key); }
        public void up(int key) { events.add("U" + key); }
    }
    public static void main(String[] args) {
        if (ControlGeometry.direction(1,0,true) != ControlGeometry.RIGHT) throw new AssertionError("right");
        int diagonal = ControlGeometry.direction(1,-1,true);
        if ((diagonal & ControlGeometry.RIGHT)==0 || (diagonal & ControlGeometry.UP)==0) throw new AssertionError("diagonal");
        Sink sink = new Sink(); ControlInput input = new ControlInput(sink);
        input.set("a", 10, 0); input.set("b", 10, 0); input.release("a");
        if (!sink.events.equals(Arrays.asList("D10"))) throw new AssertionError(sink.events.toString());
        input.release("b");
        if (!sink.events.equals(Arrays.asList("D10","U10"))) throw new AssertionError(sink.events.toString());

        // Same source swapping between two keys must not leave the old key stuck.
        sink.events.clear(); input = new ControlInput(sink);
        input.set("a", 10, 0); input.set("a", 20, 0); input.set("a", 30, 0);
        if (!sink.events.equals(Arrays.asList("D10","D20","U10","D30","U20"))) throw new AssertionError("swap " + sink.events);
        input.release("a");
        if (!sink.events.equals(Arrays.asList("D10","D20","U10","D30","U20","U30"))) throw new AssertionError("release " + sink.events);

        // Swapping must not bounce a key that stays held by another source.
        sink.events.clear(); input = new ControlInput(sink);
        input.set("a", 10, 0); input.set("b", 10, 0); input.set("a", 20, 0);
        if (!sink.events.equals(Arrays.asList("D10","D20"))) throw new AssertionError("shared " + sink.events);
        input.release("a"); input.release("b");
        if (!sink.events.equals(Arrays.asList("D10","D20","U20","U10"))) throw new AssertionError("sharedRelease " + sink.events);

        // Re-pressing the same key from the same source must stay a single hold.
        sink.events.clear(); input = new ControlInput(sink);
        input.set("a", 10, 0); input.set("a", 10, 0);
        if (!sink.events.equals(Arrays.asList("D10"))) throw new AssertionError("steady " + sink.events);
        input.release("a"); input.release("a");
        if (!sink.events.equals(Arrays.asList("D10","U10"))) throw new AssertionError("doubleRelease " + sink.events);

        // releaseAll frees everything exactly once.
        sink.events.clear(); input = new ControlInput(sink);
        input.set("a", 10, 20); input.set("b", 10, 0); input.releaseAll();
        List<String> ups = new ArrayList<>();
        for (String event : sink.events) if (event.startsWith("U")) ups.add(event);
        if (!sink.events.equals(Arrays.asList("D10","D20")) && !sink.events.equals(Arrays.asList("D10","D20","U10","U20"))
                && !sink.events.equals(Arrays.asList("D10","D20","U20","U10"))) throw new AssertionError("releaseAll " + sink.events);
        if (ups.size() != 2 || !ups.contains("U10") || !ups.contains("U20")) throw new AssertionError("releaseAllUps " + sink.events);
        input.releaseAll();
        if (sink.events.size() != 4) throw new AssertionError("releaseAllAgain " + sink.events);

        System.out.println("KERBERUS_CONTROLS_HOST_TEST_OK");
    }
}
