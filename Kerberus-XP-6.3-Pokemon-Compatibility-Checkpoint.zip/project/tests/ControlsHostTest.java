package com.kerberus.launcher;
import java.util.*;
public final class ControlsHostTest {
    private static final class Sink implements ControlInput.Sink {
        final List<String> events = new ArrayList<>();
        public void down(int key) { events.add("D" + key); }
        public void up(int key) { events.add("U" + key); }
    }
    public static void main(String[] args) {
        if (ControlGeometry.direction(1,0,true) != ControlGeometry.RIGHT) throw new AssertionError("right");
        int diagonal = ControlGeometry.direction(1,-1,true);
        if ((diagonal & ControlGeometry.RIGHT)==0 || (diagonal & ControlGeometry.UP)==0) throw new AssertionError("diagonal");
        Sink sink = new Sink(); ControlInput input = new ControlInput(sink);
        input.set("a", 10, 0); input.set("b", 10, 0); input.release("a");
        if (!sink.events.equals(Arrays.asList("D10"))) throw new AssertionError(sink.events.toString());
        input.release("b");
        if (!sink.events.equals(Arrays.asList("D10","U10"))) throw new AssertionError(sink.events.toString());
        System.out.println("KERBERUS_CONTROLS_HOST_TEST_OK");
    }
}
