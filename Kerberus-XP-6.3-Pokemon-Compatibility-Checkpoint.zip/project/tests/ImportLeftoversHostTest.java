package com.kerberus.launcher;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

/** Leftovers of an import killed with the process (ImportTask.removeLeftovers). */
public final class ImportLeftoversHostTest {
    private static void write(File file, int bytes) throws IOException {
        File parent = file.getParentFile();
        if (!parent.isDirectory() && !parent.mkdirs()) throw new IOException("mkdir " + parent);
        try (FileOutputStream out = new FileOutputStream(file)) { out.write(new byte[bytes]); }
    }

    private static void check(boolean condition, String what) {
        if (!condition) throw new AssertionError(what);
    }

    public static void main(String[] args) throws Exception {
        File root = new File(System.getProperty("java.io.tmpdir"), "kerberus-leftovers-" + System.nanoTime());
        File cache = new File(root, "cache");
        File games = new File(root, "games");
        write(new File(games, ".import-1111/Data/Map001.rxdata"), 1000);
        write(new File(games, ".import-1111/Graphics/Titles/title.png"), 500);
        write(new File(games, ".import-2222/Game.ini"), 10);
        write(new File(games, "game-3333/Game.ini"), 10);
        write(new File(games, "game-3333/Data/Scripts.rxdata"), 300);
        write(new File(games, ".nomedia/keep"), 1);
        write(new File(cache, "kerberus-import-44.zip"), 2000);
        write(new File(cache, "kerberus-folder-55.zip"), 3000);
        write(new File(cache, "other.zip"), 7);
        write(new File(cache, "kerberus-import-66.tmp"), 7);

        long freed = ImportTask.removeLeftovers(cache, games);
        check(freed == 1000 + 500 + 10 + 2000 + 3000, "bytes liberados: " + freed);
        check(!new File(games, ".import-1111").exists() && !new File(games, ".import-2222").exists(), "pastas de importacao parcial apagadas");
        check(new File(games, "game-3333/Data/Scripts.rxdata").isFile(), "jogo importado intacto");
        check(new File(games, ".nomedia/keep").isFile(), "outras pastas ocultas intactas");
        check(!new File(cache, "kerberus-import-44.zip").exists() && !new File(cache, "kerberus-folder-55.zip").exists(), "copias de ZIP apagadas");
        check(new File(cache, "other.zip").isFile() && new File(cache, "kerberus-import-66.tmp").isFile(), "outros arquivos do cache intactos");
        check(ImportTask.removeLeftovers(cache, games) == 0, "segunda chamada nao apaga nada");
        check(ImportTask.removeLeftovers(new File(root, "sem-cache"), new File(root, "sem-jogos")) == 0, "pastas ausentes");
        System.out.println("KERBERUS_IMPORT_LEFTOVERS_HOST_TEST_OK");
    }
}
