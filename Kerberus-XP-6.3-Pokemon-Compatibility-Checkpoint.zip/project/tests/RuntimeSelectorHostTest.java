package com.kerberus.launcher;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
public final class RuntimeSelectorHostTest {
  static File game(File root,String folder,String title,String ext)throws Exception{
    File g=new File(root,folder);new File(g,"Data").mkdirs();String script="Data/Scripts."+ext;
    Files.write(new File(g,"Game.ini").toPath(),("[Game]\nTitle="+title+"\nScripts="+script+"\nLibrary=RGSS102E.dll\n").getBytes(StandardCharsets.UTF_8));
    new File(g,script).createNewFile();return g;
  }
  static void expect(RuntimeSelector.Runtime r,File g,String reasonPart)throws Exception{
    RuntimeSelector.Selection s=RuntimeSelector.select(g);
    if(s.runtime!=r)throw new AssertionError(g+" -> "+s.runtime+" expected "+r+" ("+s.reason+")");
    if(reasonPart!=null&&!s.reason.contains(reasonPart))throw new AssertionError(g+" reason '"+s.reason+"' lacks '"+reasonPart+"'");
    System.out.println("OK "+g.getName()+" -> "+s.runtime.id+" | "+s.reason);
  }
  static void touch(File f)throws Exception{f.getParentFile().mkdirs();Files.write(f.toPath(),"x".getBytes(StandardCharsets.UTF_8));}
  public static void main(String[]a)throws Exception{
    File root=Files.createTempDirectory("k63").toFile();
    File generic=game(root,"ClassicXP","Meu RPG","rxdata");
    expect(RuntimeSelector.Runtime.LEGACY18,generic,"RGSS1");
    // Infinite Fusion regression: by folder name, by title only, and by mkxp-z evidence.
    expect(RuntimeSelector.Runtime.MODERN31,game(root,"Pokemon Infinite Fusion","Pokemon Infinite Fusion","rxdata"),"Infinite Fusion");
    expect(RuntimeSelector.Runtime.MODERN31,game(root,"pif-6.2","Pokémon Infinite Fusion","rxdata"),"Infinite Fusion");
    File fusionLike=game(root,"FusionLike","Some Fangame","rxdata");
    touch(new File(fusionLike,"x64-msvcrt-ruby310.dll"));
    expect(RuntimeSelector.Runtime.MODERN31,fusionLike,"x64-msvcrt-ruby310.dll");
    File json=game(root,"WithMkxpJson","Other","rxdata");
    touch(new File(json,"mkxp.json"));
    expect(RuntimeSelector.Runtime.MODERN31,json,"mkxp.json");
    File external=game(root,"EssentialsV20","Fangame v20","rxdata");
    touch(new File(external,"Data/Scripts/001_Technical/001_MKXP_Compatibility.rb"));
    expect(RuntimeSelector.Runtime.MODERN31,external,"Data/Scripts");
    File v19=game(root,"EssentialsV19","Fangame v19","rxdata");
    new File(v19,"Data/Scripts").mkdirs();
    Files.write(new File(v19,"Data/Scripts/001_Settings.rb").toPath(),"#==\n# Pokémon Essentials\n# Version 19.1\n".getBytes(StandardCharsets.UTF_8));
    expect(RuntimeSelector.Runtime.MODERN31,v19,"Data/Scripts");
    // Old Ruby 1.8 DLLs are not modern evidence.
    File classicDll=game(root,"ClassicDll","Classic","rxdata");
    touch(new File(classicDll,"msvcrt-ruby18.dll"));
    expect(RuntimeSelector.Runtime.LEGACY18,classicDll,null);
    // Priority fangames stay on real Ruby 1.8.
    expect(RuntimeSelector.Runtime.LEGACY18,game(root,"Pokemon Uranium","Pokemon Uranium","rxdata"),"Uranium");
    expect(RuntimeSelector.Runtime.LEGACY18,game(root,"Insurgence","Pokémon Insurgence","rxdata"),"Insurgence");
    expect(RuntimeSelector.Runtime.LEGACY18,game(root,"Xeno","Pokémon Xenoverse","rxdata"),"Xenoverse");
    // RGSS2/3 never go to legacy18.
    File vx=new File(root,"VX");new File(vx,"Data").mkdirs();
    Files.write(new File(vx,"Game.ini").toPath(),"[Game]\nTitle=VX\nScripts=Data\\Scripts.rvdata2\nLibrary=System\\RGSS301.dll\n".getBytes(StandardCharsets.UTF_8));
    new File(vx,"Data/Scripts.rvdata2").createNewFile();
    expect(RuntimeSelector.Runtime.MODERN31,vx,"RGSS3");
    // The local override always wins.
    Files.write(new File(generic,RuntimeSelector.OVERRIDE_FILE).toPath(),"modern31\n".getBytes(StandardCharsets.UTF_8));
    expect(RuntimeSelector.Runtime.MODERN31,generic,"override");
    Files.write(new File(json,RuntimeSelector.OVERRIDE_FILE).toPath(),"legacy18".getBytes(StandardCharsets.UTF_8));
    expect(RuntimeSelector.Runtime.LEGACY18,json,"override");
    System.out.println("KERBERUS_RUNTIME_SELECTOR_HOST_TEST_OK");
  }
}
