package com.kerberus.toolkit;
import java.io.File;
public final class SessionLockHostTest {
    public static void main(String[] args) throws Exception {
        File dir = new File(System.getProperty("java.io.tmpdir"), "kerberus-lock-test-" + System.nanoTime());
        if (!dir.mkdirs()) throw new AssertionError("mkdir");
        if (SessionLock.isLocked(dir)) throw new AssertionError("fresh directory reported locked");
        SessionLock lock = SessionLock.acquire(dir);
        if (!SessionLock.isLocked(dir)) throw new AssertionError("active lock not detected");
        lock.close();
        if (SessionLock.isLocked(dir)) throw new AssertionError("released lock still detected");
        new File(dir, "kerberus-session.lock").delete(); dir.delete();
        System.out.println("KERBERUS_SESSION_LOCK_HOST_TEST_OK");
    }
}
