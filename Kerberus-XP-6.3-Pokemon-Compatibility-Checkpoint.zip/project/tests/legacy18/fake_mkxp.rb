# Minimal stand-in for the mkxp-z Ruby 1.8 bindings used by the Legacy18
# bootstrap. Behaviour mirrors mkxp-z where the tests depend on it.
#
# Input follows mkxp-z exactly: the SDL event thread owns the LIVE state
# (EventThread::keyStates, mouseState, controllerState). Input.pressex?,
# triggerex?, mouse_x/mouse_y and Input::Controller read a COPY of it that
# only the native Input.update refreshes. KerberusNative exposes the live
# state like binding/kerberus/pokemon-native.h does in the legacy18 build.
module FakeMKXP
  @log = []
  @frame = 0
  @text = ''
  @text_mode = false
  class << self
    attr_accessor :log, :keys, :mouse, :mouse_buttons, :controller, :focused,
                  :snapshot, :snapshot_old, :snapshot_mouse, :snapshot_controller,
                  :native_updates, :frame, :text, :text_mode
  end

  def self.reset!
    @log = []
    @keys = {}            # live keyboard/touch-pad keys by VK
    @mouse = [120, 45]    # live pointer, game coordinates
    @mouse_buttons = {}   # live mouse buttons by VK (1, 2, 4)
    @controller = nil     # live pad: {:buttons => [bool], :axes => [int16], :power}
    @focused = true
    @snapshot = {}
    @snapshot_old = {}
    @snapshot_mouse = [0, 0]
    @snapshot_controller = nil
    @native_updates = 0
    @frame = 0
    @text = ''
    @text_mode = false
  end
  reset!

  # What native Input.update copies out of the event thread.
  def self.native_input_update
    @native_updates += 1
    @snapshot_old = @snapshot
    @snapshot = @keys.dup
    @mouse_buttons.each { |vk, down| @snapshot[vk] = down }
    @snapshot_mouse = @mouse.dup
    @snapshot_controller = @controller && { :buttons => @controller[:buttons].dup, :axes => @controller[:axes].dup }
  end
end

module Input
  def self.update; FakeMKXP.native_input_update; nil; end
  def self.press?(button); false; end
  def self.trigger?(button); false; end
  def self.repeat?(button); false; end
  def self.release?(button); false; end
  def self.count(button); 0; end
  def self.pressex?(vk); FakeMKXP.snapshot[vk] ? true : false; end
  def self.triggerex?(vk); FakeMKXP.snapshot[vk] && !FakeMKXP.snapshot_old[vk] ? true : false; end
  def self.repeatex?(vk); false; end
  def self.releaseex?(vk); false; end
  def self.repeatcount(vk); 0; end
  def self.mouse_x; FakeMKXP.snapshot_mouse[0]; end
  def self.mouse_y; FakeMKXP.snapshot_mouse[1]; end
  def self.scroll_v; 2; end
  def self.mouse_in_window?; true; end
  def self.gets
    value = FakeMKXP.text
    FakeMKXP.text = ''
    value
  end
  def self.text_input; FakeMKXP.text_mode; end
  def self.text_input=(value); FakeMKXP.text_mode = value; end

  module Controller
    def self.connected?; !FakeMKXP.controller.nil?; end
    def self.raw_button_states; (FakeMKXP.snapshot_controller || { :buttons => [] })[:buttons]; end
    def self.raw_axes; (FakeMKXP.snapshot_controller || { :axes => [] })[:axes].map { |value| value / 32767.0 }; end
    def self.power_level; (FakeMKXP.controller || {})[:power] || :WIRED; end
    def self.name; 'Fake Pad'; end
  end
end

# Live accessors of the legacy18 build (binding/kerberus/pokemon-native.h).
module KerberusNative
  def self.focused?; FakeMKXP.focused; end
  def self.key_down?(vk)
    FakeMKXP.keys[vk] || FakeMKXP.mouse_buttons[vk] ? true : false
  end
  def self.mouse_position; FakeMKXP.mouse.dup; end
  def self.pad_buttons
    pad = FakeMKXP.controller
    return nil if pad.nil?
    mask = 0
    pad[:buttons].each_with_index { |down, index| mask |= (1 << index) if down }
    mask
  end
  def self.pad_axis(index)
    pad = FakeMKXP.controller
    pad.nil? ? 0 : (pad[:axes][index] || 0)
  end
end

module Audio
  %w(bgm bgs me se).each do |channel|
    module_eval <<-RUBY
      def self.#{channel}_play(*args); FakeMKXP.log << [:#{channel}_play] + args; nil; end
      def self.#{channel}_stop; FakeMKXP.log << [:#{channel}_stop]; nil; end
    RUBY
  end
  %w(bgm bgs me).each do |channel|
    module_eval <<-RUBY
      def self.#{channel}_fade(ms); FakeMKXP.log << [:#{channel}_fade, ms]; nil; end
    RUBY
  end
  def self.bgm_pos; 12.5; end
  def self.bgs_pos; 3.0; end
end

class Color
  attr_accessor :red, :green, :blue, :alpha
  def initialize(r, g, b, a = 255)
    @red = r
    @green = g
    @blue = b
    @alpha = a
  end
end

class Rect
  attr_accessor :x, :y, :width, :height
  def initialize(x, y, w, h)
    @x = x
    @y = y
    @width = w
    @height = h
  end
end

# RGBA byte buffer bitmap (mkxp-z raw_data order).
class Bitmap
  attr_reader :width, :height
  def initialize(*args)
    if args[0].is_a?(String)
      FakeMKXP.log << [:bitmap_load, args[0]]
      @width = 4
      @height = 2
    else
      @width = args[0]
      @height = args[1]
    end
    @data = "\0" * (@width * @height * 4)
    @disposed = false
  end
  def raw_data; @data.dup; end
  def raw_data=(value)
    raise ArgumentError, 'tamanho' unless value.length == @data.length
    @data = value.dup
  end
  def set_pixel_rgba(x, y, rgba)
    @data[(y * @width + x) * 4, 4] = rgba.pack('C4')
  end
  def pixel_rgba(x, y)
    @data[(y * @width + x) * 4, 4].unpack('C4')
  end
  def rect; Rect.new(0, 0, @width, @height); end
  def clone
    copy = Bitmap.new(@width, @height)
    copy.raw_data = @data
    copy
  end
  def clear; @data = "\0" * @data.length; end
  def blt(x, y, source, rect)
    rect.height.times do |sy|
      rect.width.times do |sx|
        tx = x + sx
        ty = y + sy
        next if tx < 0 || ty < 0 || tx >= @width || ty >= @height
        set_pixel_rgba(tx, ty, source.pixel_rgba(rect.x + sx, rect.y + sy))
      end
    end
  end
  def dispose; @disposed = true; end
  def disposed?; @disposed; end
  def to_file(path)
    FakeMKXP.log << [:to_file, path]
    File.open(path, 'wb') { |file| file.write('IMG') }
  end
  def hue_change(hue); FakeMKXP.log << [:hue_change, hue]; end
  def animated?; false; end
end

class Sprite
  attr_accessor :bitmap
  def initialize(viewport = nil); @disposed = false; end
  def dispose; @disposed = true; end
  def disposed?; @disposed; end
end

module Graphics
  def self.update; FakeMKXP.frame += 1; nil; end
  def self.frame_count; FakeMKXP.frame; end
  def self.frame_rate; 40; end
  def self.width; 512; end
  def self.height; 384; end
  def self.snap_to_bitmap; Bitmap.new(8, 8); end
  def self.play_movie(file, volume, skippable); FakeMKXP.log << [:play_movie, file, volume, skippable]; end
end

module System
  @puts = []
  class << self
    attr_accessor :lines, :language, :power
  end
  @lines = []
  @language = 'pt_BR'
  @power = { :percent => 80, :seconds => 3600, :discharging => true }
  def self.puts(text); @lines << text.to_s; end
  def self.user_language; @language; end
  def self.power_state; @power; end
  def self.nproc; 8; end
  def self.memory; 4096; end
  def self.window_title; 'Pokemon Test'; end
  def self.set_window_title(text); FakeMKXP.log << [:title, text]; end
  def self.game_title; 'Pokemon Test'; end
end

# mkxp-z MiniFFI surface: real loads fail on Android for Windows DLLs.
class Win32API
  def initialize(*args)
    raise RuntimeError, 'Win32API ' + args[0].to_s + '!' + args[1].to_s + ' indisponivel no Android.' unless args[0].to_s =~ /\.so\z/
    @native = args
  end
  def call(*args)
    raise RuntimeError, 'native call ' + @native.inspect if @native.nil?
    [:native_call, @native[1]] + args
  end
  alias_method :Call, :call
end

module Kernel
  def save_data(object, path)
    File.open(path, 'wb') { |file| Marshal.dump(object, file) }
  end
  module_function :save_data
  def print(text)
    FakeMKXP.log << [:print, text]
  end
  module_function :print
end
