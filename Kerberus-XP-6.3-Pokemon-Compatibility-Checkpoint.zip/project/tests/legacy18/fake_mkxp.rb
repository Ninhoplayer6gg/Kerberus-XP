# Minimal stand-in for the mkxp-z Ruby 1.8 bindings used by the Legacy18
# bootstrap. Behaviour mirrors mkxp-z where the tests depend on it.
module FakeMKXP
  @log = []
  @keys = {}
  @triggered = {}
  @frame = 0
  @controller = nil
  @text = ''
  @text_mode = false
  class << self
    attr_accessor :log, :keys, :triggered, :frame, :controller, :text, :text_mode
  end

  def self.reset!
    @log = []
    @keys = {}
    @triggered = {}
    @frame = 0
    @controller = nil
    @text = ''
    @text_mode = false
  end
end

module Input
  def self.update; end
  def self.press?(button); false; end
  def self.trigger?(button); false; end
  def self.repeat?(button); false; end
  def self.release?(button); false; end
  def self.count(button); 0; end
  def self.pressex?(vk); FakeMKXP.keys[vk] ? true : false; end
  def self.triggerex?(vk); FakeMKXP.triggered[vk] ? true : false; end
  def self.repeatex?(vk); false; end
  def self.releaseex?(vk); false; end
  def self.repeatcount(vk); 0; end
  def self.mouse_x; 120; end
  def self.mouse_y; 45; end
  def self.scroll_v; 2; end
  def self.mouse_in_window?; true; end
  def self.gets
    value = FakeMKXP.text
    FakeMKXP.text = ''
    value
  end
  def self.text_input; FakeMKXP.text_mode; end
  def self.text_input=(value); FakeMKXP.text_mode = value; end

  module Controller
    def self.connected?; !FakeMKXP.controller.nil?; end
    def self.raw_button_states; FakeMKXP.controller[:buttons]; end
    def self.raw_axes; FakeMKXP.controller[:axes]; end
    def self.power_level; FakeMKXP.controller[:power] || :WIRED; end
    def self.name; 'Fake Pad'; end
  end
end

module Audio
  %w(bgm bgs me se).each do |channel|
    module_eval <<-RUBY
      def self.#{channel}_play(*args); FakeMKXP.log << [:#{channel}_play] + args; nil; end
      def self.#{channel}_stop; FakeMKXP.log << [:#{channel}_stop]; nil; end
    RUBY
  end
  %w(bgm bgs me).each do |channel|
    module_eval <<-RUBY
      def self.#{channel}_fade(ms); FakeMKXP.log << [:#{channel}_fade, ms]; nil; end
    RUBY
  end
  def self.bgm_pos; 12.5; end
  def self.bgs_pos; 3.0; end
end

class Color
  attr_accessor :red, :green, :blue, :alpha
  def initialize(r, g, b, a = 255)
    @red = r
    @green = g
    @blue = b
    @alpha = a
  end
end

class Rect
  attr_accessor :x, :y, :width, :height
  def initialize(x, y, w, h)
    @x = x
    @y = y
    @width = w
    @height = h
  end
end

# RGBA byte buffer bitmap (mkxp-z raw_data order).
class Bitmap
  attr_reader :width, :height
  def initialize(*args)
    if args[0].is_a?(String)
      FakeMKXP.log << [:bitmap_load, args[0]]
      @width = 4
      @height = 2
    else
      @width = args[0]
      @height = args[1]
    end
    @data = "\0" * (@width * @height * 4)
    @disposed = false
  end
  def raw_data; @data.dup; end
  def raw_data=(value)
    raise ArgumentError, 'tamanho' unless value.length == @data.length
    @data = value.dup
  end
  def set_pixel_rgba(x, y, rgba)
    @data[(y * @width + x) * 4, 4] = rgba.pack('C4')
  end
  def pixel_rgba(x, y)
    @data[(y * @width + x) * 4, 4].unpack('C4')
  end
  def rect; Rect.new(0, 0, @width, @height); end
  def clone
    copy = Bitmap.new(@width, @height)
    copy.raw_data = @data
    copy
  end
  def clear; @data = "\0" * @data.length; end
  def blt(x, y, source, rect)
    rect.height.times do |sy|
      rect.width.times do |sx|
        tx = x + sx
        ty = y + sy
        next if tx < 0 || ty < 0 || tx >= @width || ty >= @height
        set_pixel_rgba(tx, ty, source.pixel_rgba(rect.x + sx, rect.y + sy))
      end
    end
  end
  def dispose; @disposed = true; end
  def disposed?; @disposed; end
  def to_file(path)
    FakeMKXP.log << [:to_file, path]
    File.open(path, 'wb') { |file| file.write('IMG') }
  end
  def hue_change(hue); FakeMKXP.log << [:hue_change, hue]; end
  def animated?; false; end
end

class Sprite
  attr_accessor :bitmap
  def initialize(viewport = nil); @disposed = false; end
  def dispose; @disposed = true; end
  def disposed?; @disposed; end
end

module Graphics
  def self.update; FakeMKXP.frame += 1; nil; end
  def self.frame_count; FakeMKXP.frame; end
  def self.frame_rate; 40; end
  def self.width; 512; end
  def self.height; 384; end
  def self.snap_to_bitmap; Bitmap.new(8, 8); end
  def self.play_movie(file, volume, skippable); FakeMKXP.log << [:play_movie, file, volume, skippable]; end
end

module System
  @puts = []
  class << self
    attr_accessor :lines, :language, :power
  end
  @lines = []
  @language = 'pt_BR'
  @power = { :percent => 80, :seconds => 3600, :discharging => true }
  def self.puts(text); @lines << text.to_s; end
  def self.user_language; @language; end
  def self.power_state; @power; end
  def self.nproc; 8; end
  def self.memory; 4096; end
  def self.window_title; 'Pokemon Test'; end
  def self.set_window_title(text); FakeMKXP.log << [:title, text]; end
  def self.game_title; 'Pokemon Test'; end
end

# mkxp-z MiniFFI surface: real loads fail on Android for Windows DLLs.
class Win32API
  def initialize(*args)
    raise RuntimeError, 'Win32API ' + args[0].to_s + '!' + args[1].to_s + ' indisponivel no Android.' unless args[0].to_s =~ /\.so\z/
    @native = args
  end
  def call(*args)
    raise RuntimeError, 'native call ' + @native.inspect if @native.nil?
    [:native_call, @native[1]] + args
  end
  alias_method :Call, :call
end

module Kernel
  def save_data(object, path)
    File.open(path, 'wb') { |file| Marshal.dump(object, file) }
  end
  module_function :save_data
  def print(text)
    FakeMKXP.log << [:print, text]
  end
  module_function :print
end
