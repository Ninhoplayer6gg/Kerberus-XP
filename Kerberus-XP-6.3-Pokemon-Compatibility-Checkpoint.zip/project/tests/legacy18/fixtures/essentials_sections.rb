# Minimal sections reproducing the STRUCTURE (markers, entry points) of the
# Windows-only systems handled by Kerberus Ports. No game code is copied.
module Fixtures
  LINKER = <<-'RUBY'
# RGSS Linker (Uranium.ini reads the language)
RGSSLinker_Initialize = Win32API.new('RGSS Linker.dll', 'RGSSLinker_Initialize', 'p', 'i')
def load_module(library, symbol)
  RGSSLinker_Initialize.call(library)
end
  RUBY

  FMOD = <<-'RUBY'
LOOP_TABLE = [
]
load_module('RGSS FmodEx', 'Init_FmodEx')
def Audio_bgm_play(name, volume, pitch, position = 0)
  FMod.bgm_play(name, volume * $PokemonSystem.bgmvolume / 100, pitch)
end
def fmod_extra_helper; end
  RUBY

  AUDIO_DLL = <<-'RUBY'
class AudioContext
  def initialize
    @context = Win32API.new('audio.dll', 'AudioContextInitialize', '', 'l').call
  end
end
module AudioState
  @@BGMContext = AudioContext.new
end
def Audio_bgm_play(name, volume, pitch, position = 0); end
  RUBY

  GIF = <<-'RUBY'
module GifLibrary
  @@loadlib = Win32API.new('Kernel32.dll', 'LoadLibrary', 'p', '')
  PngDll = Win32API.new('gif.dll', 'GifToPngFilesInMemory', 'plp', 'l')
end
class GifBitmap
  def initialize(file, hue = 0)
    if safeExists?("gif.dll")
      GifLibrary::PngDll.call(file, 0, '')
    end
    @static = true
  end
end
  RUBY

  KLEIN = <<-'RUBY'
KLEIN_BFUNCS_DLL = 'kleinbitmap.dll'
def klein_dll(name)
  Win32API.new(KLEIN_BFUNCS_DLL, name, 'l', 'v')
end
def compare_klein_bitmaps(a, b)
  klein_dll('compare_bitmap').call(a.__id__)
end
class Bitmap
  def to_negative; klein_dll('to_negative').call(__id__); end
end
  RUBY

  BITMAP_MEMORY = <<-'RUBY'
RtlMoveMemory_pi = Win32API.new('kernel32', 'RtlMoveMemory', 'pii', 'i')
def pbSetResizeFactor2(factor, norecalc = false)
  $resize_factor = factor
end
class Bitmap
  def saveToPng(file); raise 'uses RtlMoveMemory_pi'; end
end
  RUBY

  TEXT_ENTRY = "class Window_TextEntry_Keyboard\n  attr_accessor :active\n  def initialize\n    @text = ''\n    @active = true\n  end\n  def insert(ch)\n    @text << ch\n  end\n  def text; @text; end\n  def dispose; @disposed = true; end\n  def update\n    return if !@active\n    if !@toUnicode\n      @toUnicode = Win32API.new('user32.dll', 'ToUnicode', 'iippii', 'i')\n      @getKeyboardState = Win32API.new('user32.dll', 'GetKeyboardState', 'p', 'i')\n    end\n    keystate = \"\\0\" * 256\n    @getKeyboardState.call(keystate)\n  end\nend\n"

  UNICODE = <<-'RUBY'
def getUnicodeStringFromAnsi(addr)
  return Win32API.new('kernel32', 'lstrlenA', 'l', 'l').call(addr)
end

def getUnicodeString(addr)
  return Win32API.new('kernel32', 'lstrlenW', 'l', 'l').call(addr)
end
  RUBY

  ZEUS = <<-'RUBY'
$imported ||= {}
$imported[:Zeus_Video_Player] = 1.0
ZVP_OldAviMode = true
MciSendString = Win32API.new('winmm', 'mciSendString', 'pplp', 'l')
  RUBY
  # Win32 keyboard input as written by Essentials v15-v17 era games
  # (Uranium, Insurgence, Xenoverse): a Win32API window lookup, an Input
  # module that polls GetAsyncKeyState itself, and a later section that
  # wraps Input.update again. Structure only; written for these tests.
  RGSS_WINDOW = <<-'RUBY'
class Win32API
  @@RGSSWINDOW = nil
  @@GetCurrentThreadId = Win32API.new('kernel32', 'GetCurrentThreadId', %w(), 'l')
  @@GetWindowThreadProcessId = Win32API.new('user32', 'GetWindowThreadProcessId', %w(l p), 'l')
  @@FindWindowEx = Win32API.new('user32', 'FindWindowEx', %w(l l p p), 'l')
  def Win32API.pbFindRgssWindow
    return @@RGSSWINDOW if @@RGSSWINDOW
    processid = [0].pack('l')
    threadid = @@GetCurrentThreadId.call
    nextwindow = 0
    begin
      nextwindow = @@FindWindowEx.call(0, nextwindow, 'RGSS Player', 0)
      if nextwindow != 0 && @@GetWindowThreadProcessId.call(nextwindow, processid) == threadid
        @@RGSSWINDOW = nextwindow
        return @@RGSSWINDOW
      end
    end until nextwindow == 0
    raise 'RGSS Player nao encontrado'
  end
end
  RUBY

  WIN32_INPUT = <<-'RUBY'
module Input
  DOWN = 2
  LEFT = 4
  RIGHT = 6
  UP = 8
  A = 11
  B = 12
  C = 13
  @GetKeyState = Win32API.new('user32', 'GetAsyncKeyState', 'i', 'i')
  @GetForegroundWindow = Win32API.new('user32', 'GetForegroundWindow', '', 'i')
  def self.getstate(key)
    (@GetKeyState.call(key) & 0x8000) > 0
  end
  def self.buttonToKey(button)
    case button
    when Input::DOWN then [0x28]
    when Input::LEFT then [0x25]
    when Input::RIGHT then [0x27]
    when Input::UP then [0x26]
    when Input::A then [0x5A, 0x10]
    when Input::B then [0x58, 0x1B]
    when Input::C then [0x43, 0x0D, 0x20]
    else []
    end
  end
  def self.updateKeyState(i)
    return if @stateUpdated[i]
    newstate = getstate(i) && @GetForegroundWindow.call == Win32API.pbFindRgssWindow
    @keystate[i] += 1 if newstate
    @triggerstate[i] = (newstate && @keystate[i] == 1)
    @releasestate[i] = (!newstate && @keystate[i] > 0)
    @keystate[i] = 0 if !newstate
    @stateUpdated[i] = true
  end
  def self.update
    if @keystate
      for i in 0...256
        @stateUpdated[i] = false
        updateKeyState(i) if @keystate[i] > 0
      end
    else
      @stateUpdated = []
      @keystate = []
      @triggerstate = []
      @releasestate = []
      for i in 0...256
        @stateUpdated[i] = true
        @keystate[i] = getstate(i) ? 1 : 0
        @triggerstate[i] = false
        @releasestate[i] = false
      end
    end
  end
  def self.pressex?(key)
    return false if !@keystate
    updateKeyState(key)
    @keystate[key] > 0
  end
  def self.triggerex?(key)
    return false if !@triggerstate
    updateKeyState(key)
    @triggerstate[key]
  end
  def self.press?(button)
    buttonToKey(button).any? { |key| pressex?(key) }
  end
  def self.trigger?(button)
    buttonToKey(button).any? { |key| triggerex?(key) }
  end
end
  RUBY

  UPDATE_WRAPPER = <<-'RUBY'
module Input
  unless defined?(update_KGC_ScreenCapture)
    class << Input
      alias update_KGC_ScreenCapture update
    end
  end
  def self.update
    update_KGC_ScreenCapture
  end
end
  RUBY
end
