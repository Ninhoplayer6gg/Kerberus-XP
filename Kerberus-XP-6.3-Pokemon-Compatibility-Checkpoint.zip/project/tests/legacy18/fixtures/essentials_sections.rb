# Minimal sections reproducing the STRUCTURE (markers, entry points) of the
# Windows-only systems handled by Kerberus Ports. No game code is copied.
module Fixtures
  LINKER = <<-'RUBY'
# RGSS Linker (Uranium.ini reads the language)
RGSSLinker_Initialize = Win32API.new('RGSS Linker.dll', 'RGSSLinker_Initialize', 'p', 'i')
def load_module(library, symbol)
  RGSSLinker_Initialize.call(library)
end
  RUBY

  FMOD = <<-'RUBY'
LOOP_TABLE = [
]
load_module('RGSS FmodEx', 'Init_FmodEx')
def Audio_bgm_play(name, volume, pitch, position = 0)
  FMod.bgm_play(name, volume * $PokemonSystem.bgmvolume / 100, pitch)
end
def fmod_extra_helper; end
  RUBY

  AUDIO_DLL = <<-'RUBY'
class AudioContext
  def initialize
    @context = Win32API.new('audio.dll', 'AudioContextInitialize', '', 'l').call
  end
end
module AudioState
  @@BGMContext = AudioContext.new
end
def Audio_bgm_play(name, volume, pitch, position = 0); end
  RUBY

  GIF = <<-'RUBY'
module GifLibrary
  @@loadlib = Win32API.new('Kernel32.dll', 'LoadLibrary', 'p', '')
  PngDll = Win32API.new('gif.dll', 'GifToPngFilesInMemory', 'plp', 'l')
end
class GifBitmap
  def initialize(file, hue = 0)
    if safeExists?("gif.dll")
      GifLibrary::PngDll.call(file, 0, '')
    end
    @static = true
  end
end
  RUBY

  KLEIN = <<-'RUBY'
KLEIN_BFUNCS_DLL = 'kleinbitmap.dll'
def klein_dll(name)
  Win32API.new(KLEIN_BFUNCS_DLL, name, 'l', 'v')
end
def compare_klein_bitmaps(a, b)
  klein_dll('compare_bitmap').call(a.__id__)
end
class Bitmap
  def to_negative; klein_dll('to_negative').call(__id__); end
end
  RUBY

  BITMAP_MEMORY = <<-'RUBY'
RtlMoveMemory_pi = Win32API.new('kernel32', 'RtlMoveMemory', 'pii', 'i')
def pbSetResizeFactor2(factor, norecalc = false)
  $resize_factor = factor
end
class Bitmap
  def saveToPng(file); raise 'uses RtlMoveMemory_pi'; end
end
  RUBY

  TEXT_ENTRY = "class Window_TextEntry_Keyboard\n  attr_accessor :active\n  def initialize\n    @text = ''\n    @active = true\n  end\n  def insert(ch)\n    @text << ch\n  end\n  def text; @text; end\n  def dispose; @disposed = true; end\n  def update\n    return if !@active\n    if !@toUnicode\n      @toUnicode = Win32API.new('user32.dll', 'ToUnicode', 'iippii', 'i')\n      @getKeyboardState = Win32API.new('user32.dll', 'GetKeyboardState', 'p', 'i')\n    end\n    keystate = \"\\0\" * 256\n    @getKeyboardState.call(keystate)\n  end\nend\n"

  UNICODE = <<-'RUBY'
def getUnicodeStringFromAnsi(addr)
  return Win32API.new('kernel32', 'lstrlenA', 'l', 'l').call(addr)
end

def getUnicodeString(addr)
  return Win32API.new('kernel32', 'lstrlenW', 'l', 'l').call(addr)
end
  RUBY

  ZEUS = <<-'RUBY'
$imported ||= {}
$imported[:Zeus_Video_Player] = 1.0
ZVP_OldAviMode = true
MciSendString = Win32API.new('winmm', 'mciSendString', 'pplp', 'l')
  RUBY
end
