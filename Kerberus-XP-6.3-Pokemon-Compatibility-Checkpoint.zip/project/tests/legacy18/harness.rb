# Tiny assertion harness (no stdlib dependency beyond Ruby 1.8 core).
$KCODE = 'U'
HARNESS_DIR = File.expand_path(File.dirname(__FILE__))
ROOT = File.expand_path(File.join(HARNESS_DIR, '..', '..'))
BOOTSTRAP = File.join(ROOT, 'app/jni/mkxp-z/binding/kerberus-legacy18-compat.rb')
WORK = File.expand_path(ENV['KERBERUS_TEST_WORK'] || '/tmp/kerberus-legacy18-tests')

module Check
  @count = 0
  @failures = []
  class << self
    attr_reader :count, :failures
  end

  def self.ok(condition, message)
    @count += 1
    @failures << message unless condition
    condition
  end

  def self.equal(expected, actual, message)
    ok(expected == actual, message + ': esperado ' + expected.inspect + ', obtido ' + actual.inspect)
  end

  def self.raises(klass, message)
    begin
      yield
    rescue Exception => error
      return ok(error.is_a?(klass), message + ': esperado ' + klass.name + ', obtido ' + error.class.name + ' ' + error.message) ? error : nil
    end
    ok(false, message + ': nenhuma excecao')
    nil
  end

  def self.report(name)
    if @failures.empty?
      puts 'OK ' + name + ' (' + @count.to_s + ' verificacoes)'
      exit 0
    end
    puts 'FALHOU ' + name + ':'
    @failures.each { |failure| puts '  - ' + failure }
    exit 1
  end
end

def fresh_workdir(name)
  path = File.join(WORK, name)
  system('rm', '-rf', path)
  Dir.mkdir(WORK) unless File.directory?(WORK)
  Dir.mkdir(path)
  path
end

# Loads fake mkxp + bootstrap inside a clean game folder.
def boot(name, scripts, env)
  game = fresh_workdir(name)
  compat = File.join(game, '.compat')
  Dir.mkdir(compat)
  ENV['KERBERUS_COMPAT_LOG'] = File.join(compat, 'events.log')
  ENV['KERBERUS_LOG_PATH'] = File.join(game, 'kerberus-runtime.log')
  ENV['KERBERUS_WINTRACE'] = nil
  ENV['KERBERUS_COMPAT_MODE'] = nil
  ENV['KERBERUS_FS_COMPAT'] = nil
  ENV['KERBERUS_PORTS_DISABLE'] = nil
  (env || {}).each { |key, value| ENV[key] = value }
  Dir.chdir(game)
  load File.join(HARNESS_DIR, 'fake_mkxp.rb')
  $RGSS_SCRIPTS = scripts
  load BOOTSTRAP
  game
end

def section(name, source)
  [0, name, '', source]
end

def api(dll, function, imports, exports)
  Win32API.new(dll, function, imports, exports)
end
