#!/usr/bin/env bash
# Runs the Legacy18 bootstrap tests on a REAL Ruby 1.8 interpreter.
#   RUBY18=/path/to/ruby-1.8.7 tests/legacy18/run-legacy18-tests.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
RUBY18="${RUBY18:-ruby1.8}"
"$RUBY18" -e 'exit(RUBY_VERSION =~ /\A1\.8\./ ? 0 : 1)' || {
  echo "ERRO: $RUBY18 nao e Ruby 1.8 ($("$RUBY18" -v 2>&1))"; exit 1; }
python3 "$ROOT/tools/gen-legacy18-header.py" --check
"$RUBY18" -c "$ROOT/app/jni/mkxp-z/binding/kerberus-legacy18-compat.rb" >/dev/null
export KERBERUS_TEST_WORK="${TMPDIR:-/tmp}/kerberus-legacy18-tests-$$"
rm -rf "$KERBERUS_TEST_WORK"
FAIL=0
for test in "$ROOT"/tests/legacy18/test_*.rb; do
  if ! (cd "$ROOT" && "$RUBY18" "$test"); then FAIL=1; fi
done
rm -rf "$KERBERUS_TEST_WORK"
[ "$FAIL" -eq 0 ] || { echo "ERRO: testes Legacy18 falharam"; exit 1; }
echo "KERBERUS_LEGACY18_TESTS_OK ($("$RUBY18" -v))"
