require File.join(File.dirname(__FILE__), 'harness')
require File.join(File.dirname(__FILE__), 'fixtures', 'essentials_sections')
scripts = [section('RGSS Linker', Fixtures::LINKER), section('FMOD', Fixtures::FMOD),
           section('Main', "# Pokemon Essentials\n# Version 17.2\n$ok = true\n")]
game = boot('activation', scripts, { 'KERBERUS_DUMP_SCRIPTS' => '1', 'KERBERUS_WINTRACE' => 'detail' })
Check.ok(KerberusLegacy18.activated?, 'bootstrap ativado')
Check.ok(!KerberusLegacy18.activate(scripts), 'ativacao unica')
runtime = File.read('kerberus-runtime.log')
Check.ok(runtime.index('[LEGACY18_READY] Kerberus 6.3.3'), 'pronto registrado')
Check.ok(runtime.index('perfis=Pokemon Uranium essentials=17.2'), 'perfil e versao do Essentials por evidencia')
Check.ok(runtime.index('[PORT_APPLIED] rgss_linker Section000 (RGSS Linker)'), 'port com secao e nome')
Check.ok(File.file?(File.join(game, '.compat', 'winbridge', 'scripts', '002-Main.rb')), 'dump de scripts opcional fora do jogo')
scripts.each_with_index { |entry, index| eval(entry[3], nil, format('Section%03d', index), 1) }
Check.ok($ok, 'scripts executam apos ativacao')
Check.ok(Win32API.instance_method(:call).owner == Win32API, 'Win32API#call do WinBridge')
Check.ok(File.respond_to?(:kerberus_raw_exist?), 'filesystem Windows instalado')

# Filesystem layer can be turned off per game.
Check.ok(KerberusLegacy18::Paths.installed?, 'Paths instalado por padrao')
Check.report('activation')
