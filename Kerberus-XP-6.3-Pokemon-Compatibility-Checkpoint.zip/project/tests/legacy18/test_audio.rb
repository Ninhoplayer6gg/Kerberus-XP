require File.join(File.dirname(__FILE__), 'harness')
boot('audio', [], {})
A = KerberusLegacy18::WinBridge::AudioBridge
FakeMKXP.log.clear
A.play(:bgm, 'Audio/BGM/Title', 80, 100, 2.5)
Check.equal([:bgm_play, 'Audio/BGM/Title', 80, 100, 2.5], FakeMKXP.log.last, 'BGM com posicao')
Check.ok(A.playing?(:bgm), 'estado BGM')
A.play(:me, 'Audio/ME/Win', 90, 100, 0)
Check.equal([:me_play, 'Audio/ME/Win', 90, 100], FakeMKXP.log.last, 'ME sem posicao')
A.play(:se, 'Audio/SE/Choose', 70, 110, 0)
Check.equal([:se_play, 'Audio/SE/Choose', 70, 110], FakeMKXP.log.last, 'SE')
A.set_volume(:bgm, 40)
Check.equal([:bgm_play, 'Audio/BGM/Title', 40, 100, 12.5], FakeMKXP.log.last, 'volume sem reiniciar (mesma faixa e posicao)')
A.fade(:bgm, 500)
Check.equal([:bgm_fade, 500], FakeMKXP.log.last, 'fade')
Check.ok(!A.playing?(:bgm), 'fade encerra estado')
A.play(:bgm, 'Audio/BGM/Route', 100, 100, 0)
A.fade_in(1000)
Check.equal(0, FakeMKXP.log.last[2], 'fade-in comeca em volume 0')
Check.ok(A.fading_in?, 'fade-in ativo')
sleep 0.05
A.tick
Check.ok(FakeMKXP.log.last[2] > 0 && FakeMKXP.log.last[2] < 100, 'fade-in progride: ' + FakeMKXP.log.last.inspect)
sleep 1.0
A.tick
Check.equal(100, FakeMKXP.log.last[2], 'fade-in termina no volume alvo')
Check.ok(!A.fading_in?, 'fade-in encerrado')
Check.equal(100, A.info(:bgm)[1], 'volume logico preservado')
Check.raises(ArgumentError, 'canal invalido') { A.play(:voice, 'x', 100, 100, 0) }
A.play(:bgm, '', 100, 100, 0)
Check.equal([:bgm_stop], FakeMKXP.log.last, 'nome vazio para a musica (RGSS)')

# Uranium/Essentials option volume.
class PokemonSystemFake
  def bgmvolume; 50; end
  def sevolume; 20; end
end
$PokemonSystem = PokemonSystemFake.new
A.use_profile_volume!
A.play(:bgm, 'Audio/BGM/X', 80, 100, 0)
Check.equal(40, FakeMKXP.log.last[2], 'volume do menu de opcoes aplicado a BGM')
A.play(:se, 'Audio/SE/X', 100, 100, 0)
Check.equal(20, FakeMKXP.log.last[2], 'volume do menu aplicado a SE')
$PokemonSystem = nil

# MCI and PlaySound adapters share the same channels.
Dir.mkdir('Audio')
Dir.mkdir('Audio/BGM')
File.open('Audio/BGM/Theme.ogg', 'wb') { |file| file.write('OGG') }
mci = Win32API.new('winmm', 'mciSendString', 'pplp', 'l')
Check.equal(0, mci.call('open "audio\\bgm\\theme.ogg" type mpegvideo alias music', nil, 0, 0), 'MCI open com caminho Windows')
Check.equal(0, mci.call('setaudio music volume to 500', nil, 0, 0), 'MCI volume')
Check.equal(0, mci.call('play music repeat', nil, 0, 0), 'MCI play repeat')
Check.equal([:bgm_play, 'Audio/BGM/Theme.ogg', 50, 100, 0.0], FakeMKXP.log.last, 'MCI repeat usa canal BGM')
status = "\0" * 32
mci.call('status music mode', status, 32, 0)
Check.equal("playing\0", status[0, 8], 'MCI status')
Check.equal(0, mci.call('stop music', nil, 0, 0), 'MCI stop')
Check.equal([:bgm_stop], FakeMKXP.log.last, 'MCI stop para o canal que abriu')
Check.equal(0, mci.call('close music', nil, 0, 0), 'MCI close')
Check.equal(263, mci.call('play music', nil, 0, 0), 'alias fechado')
Check.equal(274, mci.call('open "movie.avi" type avivideo alias v', nil, 0, 0), 'video MCI indisponivel')
Check.equal(261, mci.call('', nil, 0, 0), 'comando vazio')
text = "\0" * 64
Check.equal(1, Win32API.new('winmm', 'mciGetErrorString', 'lpl', 'i').call(263, text, 64), 'mensagem MCI')
Check.ok(text.index('not open'), 'texto do erro MCI')
Check.equal(1, Win32API.new('winmm', 'PlaySoundA', 'pli', 'i').call('Audio\\BGM\\Theme.ogg', 0, 0x20001), 'PlaySound arquivo')
Check.equal([:se_play, 'Audio/BGM/Theme.ogg', 100, 100], FakeMKXP.log.last, 'PlaySound -> SE nativo')
Check.equal(1, Win32API.new('winmm', 'PlaySoundA', 'pli', 'i').call(nil, 0, 0), 'PlaySound NULL para som')
Check.equal(8, Win32API.new('winmm', 'waveOutOpen', 'plllll', 'l').call("\0" * 4, 0, 0, 0, 0, 0), 'waveOut MMSYSERR_NOTSUPPORTED')
Check.equal(0, Win32API.new('winmm', 'waveOutGetNumDevs', '', 'l').call, 'nenhum dispositivo waveOut')
Check.report('audio')
