require File.join(File.dirname(__FILE__), 'harness')
scripts = [section('Mouse Input', "$m = Win32API.new('user32', 'Foo', 'PPI', 'I')\n$x = 1\n"),
           section('Main', "def call_foo\n  $m.call('a', 'b', 3)\nend\n")]
boot('deferred', scripts, {})
W = KerberusLegacy18::WinBridge

# Section evaluation as mkxp-z does it (filename SectionNNN).
eval(scripts[0][3], nil, 'Section000', 1)
Check.ok($m.is_a?(Win32API), 'objeto continua sendo Win32API')
Check.equal(1, $x, 'declaracao de API opcional nao derruba o jogo')
eval(scripts[1][3], nil, 'Section001', 1)
error = Check.raises(W::Unavailable, 'chamada de API ausente') { eval("call_foo\n", nil, 'Section001', 5) }
if error
  text = error.message
  %w(WINBRIDGE_UNAVAILABLE dll=user32 function=Foo imports=PPI exports=I runtime=legacy18 call_count=1 provider=missing).each do |field|
    Check.ok(text.index(field), 'mensagem contem ' + field + "\n" + text)
  end
  Check.ok(text.index('script=Main'), 'mensagem mapeia a secao para o nome do script')
  Check.ok(text.index('section=Section001'), 'mensagem contem section')
  Check.ok(text =~ /line=\d+/, 'mensagem contem linha')
  Check.ok(text.index('declared=Section000:1 (Mouse Input)'), 'mensagem contem local da declaracao')
  Check.ok(error.is_a?(RuntimeError), 'Unavailable e RuntimeError (rescue padrao funciona)')
end
error = Check.raises(W::Unavailable, 'segunda chamada') { $m.call('a', 'b', 3) }
Check.ok(error && error.message.index('call_count=2'), 'call_count incrementa')
report = File.read('kerberus-runtime.log')
Check.ok(report.index('[WINBRIDGE]') && report.index('function=Foo'), 'bloco WINBRIDGE no relatorio de runtime')

# Known unavailable API: same deferred behaviour, reason included.
hm7 = Win32API.new('MGC_Hmode7.dll', 'renderHM7', 'lll', 'l')
error = Check.raises(W::Unavailable, 'HMode7 conhecido') { hm7.call(1, 2, 3) }
Check.ok(error && error.message.index('provider=unavailable') && error.message.index('HMode7'), 'motivo conhecido informado')

# Real providers.
tick = Win32API.new('kernel32', 'GetTickCount', '', 'L')
Check.ok(tick.call.is_a?(Integer), 'GetTickCount chamavel')
Check.equal(0, Win32API.new('kernel32', 'SetLastError', 'I', 'V').call(5), 'export void retorna 0 como Win32API')
Check.equal(5, Win32API.new('kernel32.dll', 'GetLastError', [], 'I').call, 'GetLastError')
Check.equal(5, Win32API.new('KERNEL32', 'GetLastError', '', 'i').Call, 'alias Call')
same = Win32API.new('kernel32', 'GetTickCount', '', 'L')
Check.ok(tick.instance_variable_get(:@_kerberus_winbridge).equal?(same.instance_variable_get(:@_kerberus_winbridge)), 'binding compartilhado por assinatura')

yielded = nil
Win32API.new('user32', 'GetFocus', '', 'L') { |object| yielded = object }
Check.ok(yielded.is_a?(Win32API), 'bloco do construtor recebe o objeto (MiniFFI)')

error = Check.raises(RuntimeError, 'aridade errada') { tick.call(1) }
Check.ok(error && error.message.index('wrong number of parameters: expected 0, got 1'), 'mensagem de aridade do Win32API')
Check.raises(ArgumentError, 'Win32API.new com 1 argumento') { Win32API.new('user32') }
Check.raises(TypeError, 'DLL nao-String') { Win32API.new(5, 'Foo', '', '') }
error = Check.raises(TypeError, 'assinatura invalida detalhada') { Win32API.new('user32', 'GetFocus', 5, '') }
Check.ok(error && error.message.index('WINBRIDGE_SIGNATURE') && error.message.index('function=GetFocus'), 'erro de assinatura com dll/funcao')

# Scripts that reopen Win32API and wrap #call keep working.
class Win32API
  alias_method :game_original_call, :call
  def call(*args)
    $wrapped = true
    game_original_call(*args)
  end
end
$wrapped = false
Check.ok(Win32API.new('kernel32', 'GetTickCount', '', 'L').call.is_a?(Integer), 'call reaberto pelo jogo')
Check.ok($wrapped, 'wrapper do jogo executado')
class Win32API
  def game_helper; 42; end
end
Check.equal(42, tick.game_helper, 'metodos adicionados pelo jogo existem nos objetos WinBridge')

# Real shared objects still go to MiniFFI.
native = Win32API.new('libfoo.so', 'bar', 'I', 'I')
Check.equal([:native_call, 'bar', 7], native.call(7), '.so usa MiniFFI nativo')

# Too few declared parameters: precise error only when called.
short = Win32API.new('user32', 'GetClientRect', 'L', 'I')
error = Check.raises(ArgumentError, 'assinatura curta') { short.call(1) }
Check.ok(error && error.message.index('requer 2 parametros'), 'erro de assinatura curta detalhado')
Check.report('deferred')
