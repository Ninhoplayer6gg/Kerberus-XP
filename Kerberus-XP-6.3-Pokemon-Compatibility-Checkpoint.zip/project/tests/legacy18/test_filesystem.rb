require File.join(File.dirname(__FILE__), 'harness')
game = boot('filesystem', [], {})
Dir.mkdir('Data')
Dir.mkdir('Graphics')
Dir.mkdir('Graphics/Pictures')
File.open('Data/Tileset.txt', 'wb') { |file| file.write("linha1\nlinha2\n") }
File.open('Graphics/Pictures/Title.PNG', 'wb') { |file| file.write('PNG') }
File.open("Graphics/Pictures/Ma\xC3\xA7\xC3\xA3.png", 'wb') { |file| file.write('U') }
File.open('Save1.rxdata', 'wb') { |file| file.write('old') }

Check.ok(File.exist?('data/TILESET.TXT'), 'exist? sem diferenciar maiusculas')
Check.ok(File.exists?('DATA\\tileset.txt'), 'exists? com barra invertida')
Check.ok(FileTest.exist?('graphics\\pictures\\title.png'), 'FileTest.exist?')
Check.ok(File.file?('Graphics/pictures/TITLE.png'), 'file?')
Check.ok(File.directory?('graphics\\PICTURES'), 'directory?')
Check.ok(!File.exist?('Graphics/Pictures/Nada.png'), 'arquivo ausente continua ausente')
Check.equal(14, File.size('data\\tileset.txt'), 'size resolvido')
Check.equal("linha1\nlinha2\n", File.open('DATA/TILESET.TXT', 'rb') { |file| file.read }, 'File.open leitura')
Check.equal("linha1\nlinha2\n", IO.read('data\\Tileset.TXT'), 'IO.read')
Check.equal(["linha1\n", "linha2\n"], File.readlines('Data\\TILESET.txt'), 'File.readlines')
file = File.new('data/tileset.txt', 'rb')
file.seek(7)
Check.equal('linha2', file.read(6), 'seek em arquivo resolvido')
file.close
Check.ok(File.exist?("graphics/pictures/MA\xC3\xA7\xC3\xA3.PNG"), 'nome Unicode com ASCII em outra caixa')
Check.equal(['Graphics/Pictures/Title.PNG'], Dir.glob('graphics/pictures/*.png').select { |name| name.index('Title') }, 'Dir.glob sem diferenciar maiusculas')
Check.ok(Dir['GRAPHICS\\Pictures\\*'].length >= 2, 'Dir[] com barra invertida')
Check.ok(Dir.entries('graphics/pictures').include?('Title.PNG'), 'Dir.entries')
Check.raises(Errno::ENOENT, 'erro original preservado quando nao existe') { File.open('Data/Inexistente.txt', 'rb') }

# Writes reuse the existing file with another case (NTFS semantics).
File.open('SAVE1.RXDATA', 'wb') { |handle| handle.write('new') }
Check.equal(['Save1.rxdata'], Dir.entries('.').select { |name| name.downcase == 'save1.rxdata' }, 'sem arquivo duplicado')
Check.equal('new', File.read('Save1.rxdata'), 'escrita no arquivo existente')
File.open('data\\Nova.txt', 'wb') { |handle| handle.write('x') }
Check.ok(File.file?('Data/Nova.txt'), 'novo arquivo criado na pasta resolvida')
Check.ok(File.exist?('data/nova.txt'), 'cache de misses invalidado apos escrita')
save_data({ :a => 1 }, 'GAME.rxdata')
Check.equal({ :a => 1 }, Marshal.load(File.open('Game.rxdata', 'rb') { |handle| handle.read }), 'save_data resolvido')
Dir.mkdir('SAVES')
Check.raises(Errno::EEXIST, 'mkdir de pasta existente em outra caixa') { Dir.mkdir('saves') }
File.rename('data/nova.txt', 'Data/Renomeada.txt')
Check.ok(File.file?('Data/Renomeada.txt') && !File.exist?('Data/Nova.txt'), 'rename resolvido')
File.delete('DATA/renomeada.TXT')
Check.ok(!File.exist?('Data/Renomeada.txt'), 'delete resolvido')
Dir.chdir('graphics') { Check.ok(File.exist?('pictures/title.png'), 'chdir resolvido') }

# Absolute paths and paths with dots.
Check.ok(File.exist?(File.join(game, 'DATA', 'tileset.txt')), 'caminho absoluto')
Check.ok(File.exist?('./Graphics/../data/TILESET.txt'), 'componentes . e ..')

# Kernel#load resolves like Windows too.
File.open('Data/Extra.rb', 'wb') { |handle| handle.write("$loaded_extra = 42\n") }
load 'data\\EXTRA.rb'
Check.equal(42, $loaded_extra, 'load com barra invertida e outra caixa')
Check.raises(LoadError, 'load de arquivo inexistente continua LoadError') { load 'data/nada.rb' }

# Raw helpers are untouched.
Check.ok(!File.kerberus_raw_exist?('data/tileset.txt'), 'helper raw nao resolve')

# Windows path providers.
attributes = Win32API.new('kernel32', 'GetFileAttributesA', 'p', 'l')
Check.equal(0x20, attributes.call('data\\TILESET.txt'), 'GetFileAttributes arquivo')
Check.equal(0x10, attributes.call('GRAPHICS'), 'GetFileAttributes pasta')
Check.equal(-1, attributes.call('C:\\Windows\\win.ini'), 'caminho de drive Windows')
find = "\0" * 320
handle = Win32API.new('kernel32', 'FindFirstFileA', 'pp', 'l').call('graphics\\pictures\\*.png', find)
Check.ok(handle > 0, 'FindFirstFile com curinga')
names = [find[44, 260].split("\0")[0]]
names << find[44, 260].split("\0")[0] while Win32API.new('kernel32', 'FindNextFileA', 'lp', 'i').call(handle, find) == 1
Check.ok(names.include?('Title.PNG'), 'FindNextFile lista arquivos: ' + names.inspect)
Check.equal(1, Win32API.new('kernel32', 'FindClose', 'l', 'i').call(handle), 'FindClose')
create = Win32API.new('kernel32', 'CreateFileA', 'pllllll', 'l')
write = Win32API.new('kernel32', 'WriteFile', 'lpipp', 'i')
read = Win32API.new('kernel32', 'ReadFile', 'lpipp', 'i')
close = Win32API.new('kernel32', 'CloseHandle', 'l', 'i')
out = create.call('data\\blob.bin', 0x40000000, 0, 0, 2, 0x80, 0)
written = "\0" * 4
Check.equal(1, write.call(out, "\x01\x02\x03", 3, written, 0), 'WriteFile')
Check.equal(3, written.unpack('V')[0], 'bytes escritos')
close.call(out)
input = create.call('DATA/BLOB.BIN', 0x80000000, 1, 0, 3, 0x80, 0)
buffer = "\0" * 3
got = "\0" * 4
read.call(input, buffer, 3, got, 0)
Check.equal("\x01\x02\x03", buffer, 'ReadFile binario')
Check.equal(3, Win32API.new('kernel32', 'GetFileSize', 'lp', 'l').call(input, 0), 'GetFileSize')
close.call(input)
Check.equal(-1, create.call('Data\\none.bin', 0x80000000, 1, 0, 3, 0x80, 0), 'OPEN_EXISTING ausente')
Check.report('filesystem')
