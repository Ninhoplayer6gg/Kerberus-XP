require File.join(File.dirname(__FILE__), 'harness')
game = boot('ini', [], {})
W = KerberusLegacy18::WinBridge

File.open('Game.ini', 'wb') do |file|
  file.write("; comentario\r\n[Game]\r\nLibrary=RGSS102E.dll\r\nScripts=Data\\Scripts.rxdata\r\nTitle = \"Pokemon Teste\" \r\n#Nao=comentario\r\n\r\n[Options]\r\nVolume=  75 \r\nNegativo=-3\r\nHex=0x10\r\nTexto=abc\r\n")
end
read = Win32API.new('kernel32', 'GetPrivateProfileString', 'pppplp', 'l')
buffer = "\0" * 256
Check.equal(13, read.call('Game', 'Title', '', buffer, 256, '.\\Game.ini'), 'tamanho do valor com aspas removidas')
Check.equal("Pokemon Teste\0", buffer[0, 14], 'valor sem aspas e sem espacos')
buffer = "\0" * 256
read.call('GAME', 'scripts', '', buffer, 256, './Game.ini')
Check.equal("Data\\Scripts.rxdata\0", buffer[0, 20], 'secao/chave sem diferenciar maiusculas')
buffer = "\0" * 256
Check.equal(10, read.call('Game', '#Nao', '', buffer, 256, '.\\Game.ini'), '# nao e comentario no Windows')
buffer = "\0" * 32
Check.equal(6, read.call('Game', 'Ausente', 'padrao  ', buffer, 32, '.\\Game.ini'), 'default com espacos finais removidos')
Check.equal("padrao\0", buffer[0, 7], 'default copiado')
Check.equal(2, W.last_error, 'ERROR_FILE_NOT_FOUND ao usar default')
small = "\0" * 5
Check.equal(4, read.call('Game', 'Title', '', small, 5, '.\\Game.ini'), 'truncamento retorna nSize-1')
Check.equal("Poke\0", small, 'truncado com NUL')
list = "\0" * 64
count = read.call(nil, nil, '', list, 64, '.\\Game.ini')
Check.equal("Game\0Options\0\0", list[0, count + 1], 'lista de secoes com duplo NUL')
list = "\0" * 8
Check.equal(6, read.call(nil, nil, '', list, 8, '.\\Game.ini'), 'lista truncada retorna nSize-2')
Check.equal("\0\0", list[6, 2], 'lista truncada termina com duplo NUL')
keys = "\0" * 128
count = read.call('Options', nil, '', keys, 128, '.\\Game.ini')
Check.equal("Volume\0Negativo\0Hex\0Texto\0\0", keys[0, count + 1], 'lista de chaves')

# A bare file name lives in the (virtual) Windows directory, as on Windows.
buffer = "\0" * 64
read.call('Game', 'Title', 'nao-lido', buffer, 64, 'Game.ini')
Check.equal("nao-lido\0", buffer[0, 9], 'nome sem pasta nao le Game.ini do jogo')

int = Win32API.new('kernel32', 'GetPrivateProfileIntA', 'ppip', 'i')
Check.equal(75, int.call('Options', 'Volume', 5, '.\\Game.ini'), 'GetPrivateProfileInt')
Check.equal(0, int.call('Options', 'Negativo', 5, '.\\Game.ini'), 'negativo retorna 0')
Check.equal(16, int.call('Options', 'Hex', 5, '.\\Game.ini'), 'hexadecimal')
Check.equal(0, int.call('Options', 'Texto', 5, '.\\Game.ini'), 'texto nao numerico')
Check.equal(5, int.call('Options', 'Nada', 5, '.\\Game.ini'), 'default inteiro')

write = Win32API.new('kernel32', 'WritePrivateProfileString', 'pppp', 'i')
Check.equal(1, write.call('Options', 'volume', '90', '.\\Game.ini'), 'altera chave existente')
Check.equal(1, write.call('Options', 'Novo', 'x y', '.\\Game.ini'), 'insere chave')
Check.equal(1, write.call('Extra', 'Chave', '1', '.\\Game.ini'), 'cria secao')
Check.equal(1, write.call('Options', 'Texto', nil, '.\\Game.ini'), 'remove chave')
text = File.open('Game.ini', 'rb') { |file| file.read }
Check.ok(text.index("; comentario\r\n"), 'comentario preservado')
Check.ok(text.index("volume=90\r\n") || text.index("Volume=90\r\n"), 'valor alterado com CRLF')
Check.ok(text.index("Novo=x y\r\n"), 'chave nova')
Check.ok(!text.index('Texto='), 'chave removida')
Check.ok(text.index("[Extra]\r\nChave=1\r\n"), 'secao nova')
Check.equal(90, int.call('Options', 'Volume', 0, '.\\Game.ini'), 'cache invalidado apos escrita')
Check.equal(1, write.call('Extra', nil, nil, '.\\Game.ini'), 'remove secao inteira')
Check.ok(!File.read('Game.ini').index('[Extra]'), 'secao removida')
Check.equal(1, Win32API.new('kernel32', 'WriteProfileString', 'ppp', 'i').call('Fonts', 'Fonte', 'x.ttf'), 'win.ini virtual')
Check.ok(File.file?(File.join(game, '.compat', 'winbridge', 'Windows', 'win.ini')), 'win.ini fora da pasta do jogo')

# Registry.
open = Win32API.new('advapi32', 'RegOpenKeyExA', 'lpllp', 'l')
query = Win32API.new('advapi32', 'RegQueryValueExA', 'lpppp', 'l')
handle = "\0" * 4
Check.equal(0, open.call(0x80000001, 'Software\\Enterbrain\\RGSS', 0, 0x20019, handle), 'abre chave RGSS')
key = handle.unpack('V')[0]
type = "\0" * 4
size = [4].pack('V')
data = "\0" * 4
query = Win32API.new('advapi32', 'RegQueryValueExA', 'lppppp', 'l')
Check.equal(0, query.call(key, 'PlayMusic', 0, type, data, size), 'le PlayMusic')
Check.equal([4, 1, 4], [type.unpack('V')[0], data.unpack('V')[0], size.unpack('V')[0]], 'REG_DWORD 1')
size = [0].pack('V')
Check.equal(234, query.call(key, 'PlayMusic', 0, 0, "\0" * 4, size), 'buffer curto = ERROR_MORE_DATA')
Check.equal(4, size.unpack('V')[0], 'tamanho necessario informado')
size = [0].pack('V')
Check.equal(0, query.call(key, 'PlayMusic', 0, 0, 0, size), 'consulta de tamanho')
Check.equal(2, query.call(key, 'Nada', 0, 0, 0, [4].pack('V')), 'valor ausente')
Check.equal(2, open.call(0x80000002, 'SOFTWARE\\Enterbrain\\RGSS\\RTP', 0, 0x20019, "\0" * 4), 'RTP ausente')
create = Win32API.new('advapi32', 'RegCreateKeyExA', 'lpipiippp', 'l')
created = "\0" * 4
disposition = "\0" * 4
Check.equal(0, create.call(0x80000001, 'Software\\Kerberus\\Test', 0, 0, 0, 0xF003F, 0, created, disposition), 'cria chave')
Check.equal(1, disposition.unpack('V')[0], 'REG_CREATED_NEW_KEY')
set = Win32API.new('advapi32', 'RegSetValueExA', 'lpiipi', 'l')
Check.equal(0, set.call(created.unpack('V')[0], 'Nome', 0, 1, 'Red', 3), 'grava REG_SZ')
KerberusLegacy18::WinBridge::Registry.reset!
reopened = "\0" * 4
Check.equal(0, open.call(0x80000001, 'software\\kerberus\\test', 0, 0x20019, reopened), 'persistencia entre sessoes')
data = "\0" * 16
size = [16].pack('V')
query.call(reopened.unpack('V')[0], 'nome', 0, 0, data, size)
Check.equal("Red\0", data[0, 4], 'REG_SZ com terminador')
Check.equal(0, Win32API.new('advapi32', 'RegCloseKey', 'l', 'l').call(reopened.unpack('V')[0]), 'fecha handle')
Check.equal(6, Win32API.new('advapi32', 'RegCloseKey', 'l', 'l').call(12345), 'handle invalido')
name = "\0" * 16
size = [16].pack('V')
Check.equal(1, Win32API.new('advapi32', 'GetUserName', 'pp', 'i').call(name, size), 'GetUserName')
Check.equal("Player\0", name[0, 7], 'nome virtual sem dado pessoal')
Check.report('ini_registry')
