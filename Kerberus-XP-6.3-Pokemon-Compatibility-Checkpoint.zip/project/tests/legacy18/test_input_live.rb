# Essentials v15-v17 games (Uranium, Insurgence, Xenoverse) replace
# Input.update with their own GetAsyncKeyState polling and never run the
# native mkxp-z Input.update. The Win32 key APIs must therefore read the
# LIVE SDL state, exactly like Windows reads the live keyboard.
require File.join(File.dirname(__FILE__), 'harness')
require File.join(File.dirname(__FILE__), 'fixtures', 'essentials_sections')
scripts = [section('Win32API', Fixtures::RGSS_WINDOW), section('PSystem_Controls', Fixtures::WIN32_INPUT),
           section('PSystem_Utilities', Fixtures::UPDATE_WRAPPER), section('Main', "$main = true\n")]
boot('input_live', scripts, {})
scripts.each_with_index { |entry, index| eval(entry[3], nil, format('Section%03d', index), 1) }
Check.ok($main, 'secoes executam')

def frame
  Graphics.update
  Input.update
end

frame
# On-screen gamepad "C" sends Android KEYCODE_C -> SDL scancode C -> VK 0x43.
FakeMKXP.keys[0x43] = true
frame
Check.ok(Input.trigger?(Input::C), 'toque C: trigger no primeiro quadro')
Check.ok(Input.press?(Input::C), 'toque C: pressionado')
frame
Check.ok(!Input.trigger?(Input::C), 'trigger so uma vez')
Check.ok(Input.press?(Input::C), 'segue pressionado')
FakeMKXP.keys[0x43] = false
frame
Check.ok(!Input.press?(Input::C), 'solto ao levantar o dedo')
FakeMKXP.keys[0x28] = true
frame
Check.ok(Input.press?(Input::DOWN), 'direcional do toque (DPAD_DOWN -> VK_DOWN)')
FakeMKXP.keys.clear
frame
Check.ok(!Input.press?(Input::DOWN), 'direcional solto')
Check.equal(0, FakeMKXP.native_updates, 'cenario real: o Input.update nativo nunca roda')

# Physical controller -> same keys as the on-screen gamepad
# (mkxp-z default bindings: A=C, B=B, X=A, D-pad and left stick).
buttons = Array.new(21, false)
axes = [0, 0, 0, 0, 0, 0]
FakeMKXP.controller = { :buttons => buttons, :axes => axes }
buttons[0] = true
frame
Check.ok(Input.trigger?(Input::C), 'botao A do controle confirma (Input::C)')
buttons[0] = false
buttons[1] = true
frame
Check.ok(Input.press?(Input::B), 'botao B do controle cancela (Input::B)')
buttons[1] = false
buttons[2] = true
frame
Check.ok(Input.press?(Input::A), 'botao X do controle = Input::A')
buttons[2] = false
buttons[12] = true
frame
Check.ok(Input.press?(Input::DOWN), 'D-pad do controle')
buttons[12] = false
axes[1] = -20000
frame
Check.ok(Input.press?(Input::UP), 'analogico esquerdo para cima')
axes[1] = -0x4000
frame
Check.ok(!Input.press?(Input::UP), 'zona morta igual a do mkxp-z (0x4000)')
axes[0] = 30000
frame
Check.ok(Input.press?(Input::RIGHT), 'analogico esquerdo para a direita')
axes[0] = 0
FakeMKXP.controller = nil
frame
Check.ok(!Input.press?(Input::RIGHT), 'controle desconectado')

# Without focus, Windows reports no key and Essentials also checks
# GetForegroundWindow against the RGSS window.
FakeMKXP.keys[0x43] = true
FakeMKXP.focused = false
frame
Check.ok(!Input.press?(Input::C), 'sem foco nenhuma tecla')
FakeMKXP.focused = true
frame
Check.ok(Input.press?(Input::C), 'foco de volta')
FakeMKXP.keys.clear

# Pointer and mouse buttons are live too.
FakeMKXP.mouse = [200, 150]
point = "\0" * 8
Win32API.new('user32', 'GetCursorPos', 'p', 'i').call(point)
Check.equal([200, 150], point.unpack('l2'), 'GetCursorPos ao vivo')
FakeMKXP.mouse_buttons[0x01] = true
Check.ok((Win32API.new('user32', 'GetAsyncKeyState', 'i', 'i').call(0x01) & 0x8000) != 0, 'toque = botao esquerdo')
FakeMKXP.mouse_buttons.clear
Check.equal(0, FakeMKXP.native_updates, 'nada acima dependeu do Input.update nativo')


# Builds without the live accessors fall back to the mkxp-z copy, which is
# only current when something runs the native Input.update.
class << KerberusNative
  remove_method :key_down?
  remove_method :pad_buttons
  remove_method :pad_axis
  remove_method :mouse_position
end
KerberusLegacy18::WinBridge::InputBridge.reset!
Check.ok(!KerberusLegacy18::WinBridge::InputBridge.live?, 'sem acessores ao vivo')
async = Win32API.new('user32', 'GetAsyncKeyState', 'i', 'i')
FakeMKXP.keys[0x43] = true
Check.equal(0, async.call(0x43), 'fallback: copia do mkxp-z ainda antiga')
FakeMKXP.native_input_update
Check.ok((async.call(0x43) & 0x8000) != 0, 'fallback: copia atualizada pelo Input.update nativo')

Check.report('input ao vivo (Essentials Win32)')
