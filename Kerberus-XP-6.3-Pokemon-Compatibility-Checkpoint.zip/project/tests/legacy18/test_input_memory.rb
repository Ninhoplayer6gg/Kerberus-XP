require File.join(File.dirname(__FILE__), 'harness')
boot('input', [], {})
W = KerberusLegacy18::WinBridge

async = Win32API.new('user32', 'GetAsyncKeyState', 'i', 'i')
state = Win32API.new('user32', 'GetKeyState', 'i', 'i')
FakeMKXP.keys[0x41] = true
FakeMKXP.triggered[0x41] = true
FakeMKXP.frame = 10
Check.equal(-32767, async.call(0x41), 'pressionada e recem-pressionada')
Check.equal(-32768, async.call(0x41), 'bit 0x0001 informado so uma vez por quadro')
Check.ok((async.call(0x41) & 0x8000) != 0, 'teste & 0x8000 continua verdadeiro')
Check.equal(0, async.call(0x42), 'tecla solta')
Check.equal(-128, state.call(0x41), 'GetKeyState pressionada (0xFF80)')
Check.equal(0, state.call(0x42), 'GetKeyState solta')
Check.equal(0, async.call(300), 'vk fora de 0..255')

keyboard = "\0" * 256
FakeMKXP.keys[0x10] = true
Check.equal(1, Win32API.new('user32', 'GetKeyboardState', 'p', 'i').call(keyboard), 'GetKeyboardState')
Check.equal(0x80, keyboard[0x41], 'A no estado')
Check.equal(0x80, keyboard[0x10], 'Shift no estado')
Check.equal(0, keyboard[0x42], 'B solto')

to_unicode = Win32API.new('user32', 'ToUnicode', 'iipppi', 'i')
out = "\0" * 8
Check.equal(1, to_unicode.call(0x41, 0x1E, keyboard, out, 4, 0), 'ToUnicode letra')
Check.equal('A', out[0, 2].unpack('v').pack('U'), 'Shift gera maiuscula')
plain = "\0" * 256
to_unicode.call(0x41, 0x1E, plain, out, 4, 0)
Check.equal('a', out[0, 2].unpack('v').pack('U'), 'sem Shift gera minuscula')
caps = "\0" * 256
caps[0x14] = 1
to_unicode.call(0x41, 0x1E, caps, out, 4, 0)
Check.equal('A', out[0, 2].unpack('v').pack('U'), 'Caps Lock')
to_unicode.call(0x31, 0x02, keyboard, out, 4, 0)
Check.equal('!', out[0, 2].unpack('v').pack('U'), 'Shift+1')
Check.equal(0, to_unicode.call(0x70, 0x3B, plain, out, 4, 0), 'F1 nao gera caractere')
map = Win32API.new('user32', 'MapVirtualKey', 'ii', 'i')
Check.equal(0x1E, map.call(0x41, 0), 'VK->scan')
Check.equal(0x41, map.call(0x1E, 1), 'scan->VK')
Check.equal(0x41, map.call(0x41, 2), 'VK->char maiusculo')

point = "\0" * 8
Check.equal(1, Win32API.new('user32', 'GetCursorPos', 'p', 'i').call(point), 'GetCursorPos')
Check.equal([120, 45], point.unpack('l2'), 'coordenadas do toque/mouse')
rect = "\0" * 16
Check.equal(1, Win32API.new('user32', 'GetClientRect', 'lp', 'i').call(1, rect), 'GetClientRect')
Check.equal([0, 0, 512, 384], rect.unpack('l4'), 'retangulo = resolucao do jogo')
Check.equal(0, Win32API.new('user32', 'GetClientRect', 'lp', 'i').call(99, rect), 'HWND invalido')
Check.equal(1400, W.last_error, 'ERROR_INVALID_WINDOW_HANDLE')
Check.equal(1, Win32API.new('user32', 'FindWindowA', 'pp', 'l').call('RGSS Player', nil), 'FindWindow RGSS Player')
Check.equal(0, Win32API.new('user32', 'FindWindowA', 'pp', 'l').call('Notepad', nil), 'FindWindow outra classe')
Check.equal(512, Win32API.new('user32', 'GetSystemMetrics', 'i', 'i').call(0), 'SM_CXSCREEN')
Check.equal(240, Win32API.new('rpg.net', 'InputGetWheelDelta', '', 'i').call, 'roda do mouse')

# XInput over Input::Controller.
xstate = Win32API.new('xinput1_3', 'XInputGetState', 'lp', 'l')
pad = "\0" * 16
Check.equal(1167, xstate.call(0, pad), 'sem controle: ERROR_DEVICE_NOT_CONNECTED')
buttons = Array.new(15, false)
buttons[0] = true
buttons[11] = true
FakeMKXP.controller = { :buttons => buttons, :axes => [1.0, 1.0, 0.0, -1.0, 1.0, 0.0] }
Check.equal(0, xstate.call(0, pad), 'controle conectado')
values = pad.unpack('VvCCssss')
Check.equal(0x1001, values[1], 'A + DPAD_UP')
Check.equal([255, 0], [values[2], values[3]], 'gatilhos')
Check.equal([32767, -32767, 0, 32767], values[4, 4], 'eixos com Y invertido como no XInput')
packet = values[0]
xstate.call(0, pad)
Check.equal(packet, pad.unpack('V')[0], 'pacote so muda com o estado')
Check.equal(1167, xstate.call(1, pad), 'somente jogador 0')
Check.equal(0, Win32API.new('xinput9_1_0', 'XInputSetState', 'lp', 'l').call(0, [65535, 0].pack('vv')), 'vibracao')
caps_buffer = "\0" * 20
Check.equal(0, Win32API.new('XInput1_4.dll', 'XInputGetCapabilities', 'llp', 'l').call(0, 0, caps_buffer), 'capabilities')

# Virtual heap and text conversion.
M = W::Memory
handle = M.alloc("abc\0def")
Check.equal('abc', M.c_string(handle), 'string ANSI no heap')
Check.equal('def', M.c_string(handle + 4), 'ponteiro dentro do bloco')
destination = "\0" * 3
Win32API.new('kernel32', 'RtlMoveMemory', 'pll', 'v').call(destination, handle + 4, 3)
Check.equal('def', destination, 'RtlMoveMemory a partir do heap virtual')
Check.raises(W::InvalidPointer, 'endereco real rejeitado') { Win32API.new('kernel32', 'RtlMoveMemory', 'pll', 'v').call(destination, 0x12345678, 3) }
wide = M.alloc_wide("S\xC3\xA3o \xF0\x9F\x98\x80")
Check.equal("S\xC3\xA3o \xF0\x9F\x98\x80", M.wide_string(wide), 'UTF-16 com par substituto')
Check.equal(6, Win32API.new('kernel32', 'lstrlenW', 'l', 'i').call(wide), 'lstrlenW conta unidades UTF-16')
Check.equal(0, Win32API.new('kernel32', 'lstrlenW', 'l', 'i').call(0), 'lstrlenW(NULL) = 0')
Check.ok(M.free(wide), 'libera bloco')
Check.equal(0, Win32API.new('ole32', 'CoTaskMemFree', 'l', 'v').call(0), 'CoTaskMemFree(NULL)')
to_wide = Win32API.new('kernel32', 'MultiByteToWideChar', 'ilpipi', 'i')
Check.equal(4, to_wide.call(65001, 0, "\xC3\xA7\xC3\xA3o", -1, 0, 0), 'tamanho UTF-16 incluindo NUL')
buffer = "\0" * 8
to_wide.call(65001, 0, "\xC3\xA7\xC3\xA3o", -1, buffer, 4)
Check.equal([0xE7, 0xE3, 0x6F, 0], buffer.unpack('v4'), 'conversao UTF-8 -> UTF-16')
narrow = "\0" * 8
from_wide = Win32API.new('kernel32', 'WideCharToMultiByte', 'ilpipipp', 'i')
Check.equal(6, from_wide.call(65001, 0, buffer, -1, narrow, 8, nil, nil), 'UTF-16 -> UTF-8 com NUL (bytes)')
Check.equal("\xC3\xA7\xC3\xA3o\0", narrow[0, 6], 'bytes UTF-8')
ansi = "\0" * 8
from_wide.call(1252, 0, [0x20AC, 0x41, 0].pack('v3'), -1, ansi, 8, nil, nil)
Check.equal("\x80A\0", ansi[0, 3], 'Euro em Windows-1252')
Check.equal(0x0416, Win32API.new('kernel32', 'GetUserDefaultLangID', '', 'i').call, 'pt_BR -> 0x0416')
Check.equal(32, Win32API.new('kernel32', 'GetUserGeoID', 'i', 'i').call(16), 'BR -> GEOID 32')
System.language = 'es'
Check.equal(0x040A, Win32API.new('kernel32', 'GetUserDefaultLangID', '', 'i').call, 'idioma sem regiao')
power = "\0" * 12
Check.equal(1, Win32API.new('kernel32', 'GetSystemPowerStatus', 'p', 'i').call(power), 'energia')
Check.equal([0, 1, 80, 0, 3600], power.unpack('CCCCV'), 'bateria descarregando 80%')
Check.equal(-1, Win32API.new('kernel32', 'GetCurrentProcess', '', 'l').call, 'pseudo-handle -1')
counter = "\0" * 8
Check.equal(1, Win32API.new('kernel32', 'QueryPerformanceCounter', 'p', 'i').call(counter), 'QPC')
Check.ok(counter.unpack('VV')[1] > 0 || counter.unpack('VV')[0] > 0, 'QPC escreveu 64 bits')
Check.equal(1, W.to_i32(Win32API.new('kernel32', 'LoadLibrary', 'p', 'l').call('xinput1_3.dll') != 0 ? 1 : 0), 'LoadLibrary de DLL com provider')
Check.equal(0, Win32API.new('kernel32', 'LoadLibrary', 'p', 'l').call('foo.dll'), 'LoadLibrary sem provider = NULL')
Check.equal(126, W.last_error, 'ERROR_MOD_NOT_FOUND')
message = "\0" * 128
length = Win32API.new('kernel32', 'FormatMessageA', 'lplipip', 'i').call(0x1000, nil, 2, 0, message, 128, nil)
Check.equal("The system cannot find the file specified.\r\n", message[0, length], 'FormatMessage de sistema')
Check.report('input_memory')
