require File.join(File.dirname(__FILE__), 'harness')
# Values written by RuntimeOptions.java from .kerberus-options.
game = boot('options', [section('Main', "$x = Win32API.new('user32', 'Nada', '', '')\n")],
            { 'KERBERUS_FS_COMPAT' => 'off', 'KERBERUS_WINTRACE' => 'off', 'KERBERUS_DUMP_SCRIPTS' => '0',
              'KERBERUS_PORTS_DISABLE' => 'klein_bitmap' })
Check.ok(!KerberusLegacy18::Paths.installed?, 'filesystem=native nao instala a camada Windows')
Check.ok(!File.respond_to?(:kerberus_raw_exist?), 'File intacto')
Check.ok(KerberusLegacy18::WinBridge.installed?, 'WinBridge continua ativo')
Check.equal(['klein_bitmap'], KerberusLegacy18.config[:ports_disabled], 'lista de ports desativados')
eval("$x = Win32API.new('user32', 'Nada', '', '')\n", nil, 'Section000', 1)
Check.raises(KerberusLegacy18::WinBridge::Unavailable, 'erro preciso mesmo com trace desligado') { $x.call }
Check.ok(!File.exist?(File.join(game, '.compat', 'events.log')), 'trace off nao grava events.log')
Check.ok(File.read('kerberus-runtime.log').index('[WINBRIDGE]'), 'bloqueios sempre vao para o relatorio')
Check.report('options')
