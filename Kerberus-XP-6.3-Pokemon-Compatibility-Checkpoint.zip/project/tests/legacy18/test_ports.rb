require File.join(File.dirname(__FILE__), 'harness')
require File.join(File.dirname(__FILE__), 'fixtures', 'essentials_sections')
scripts = [section('RGSS Linker', Fixtures::LINKER), section('FMOD', Fixtures::FMOD),
           section('AudioPlay', Fixtures::AUDIO_DLL), section('GifLibrary', Fixtures::GIF),
           section('Klein', Fixtures::KLEIN), section('BitmapUtils', Fixtures::BITMAP_MEMORY),
           section('TextEntry', Fixtures::TEXT_ENTRY), section('Unicode', Fixtures::UNICODE),
           section('Zeus', Fixtures::ZEUS), section('Main', "$main = true\n")]
originals = scripts.map { |entry| entry[3].dup }
boot('ports', scripts, {})
applied = KerberusLegacy18::Ports.applied.map { |pair| pair[0] }
%w(rgss_linker fmodex_audio audio_dll gif_dll klein_bitmap bitmap_memory text_entry unicode_pointer zeus_video).each do |id|
  Check.ok(applied.include?(id), 'port aplicado: ' + id + ' ' + applied.inspect)
end
Check.ok($KERBERUS_URANIUM_COMPAT_ACTIVE, 'Uranium detectado por evidencia (RGSS Linker + Uranium.ini)')
Check.equal(originals[9], scripts[9][3], 'secao sem marcadores intocada')
Check.equal(originals[5].count("\n") + 2, scripts[5][3].count("\n"), 'bitmap_memory preserva linhas originais')
Check.equal(originals[6].count("\n") + 2, scripts[6][3].count("\n"), 'text_entry preserva numeracao das linhas')
Check.equal(originals[7].count("\n"), scripts[7][3].count("\n"), 'unicode_pointer preserva numeracao das linhas')
runtime = File.read('kerberus-runtime.log')
Check.ok(runtime.index('PORT_COVERAGE') && runtime.index('fmod_extra_helper'), 'cobertura incompleta relatada com nomes')

scripts.each_with_index { |entry, index| eval(entry[3], nil, format('Section%03d', index), 1) }
Check.ok($main, 'todas as secoes executam')

# RGSS Linker + FMOD -> native audio.
Check.equal(true, load_module('RGSS FmodEx', 'Init_FmodEx'), 'load_module FMOD')
error = Check.raises(KerberusLegacy18::WinBridge::Unavailable, 'extensao Linker desconhecida') { load_module('Other.dll', 'Init_Other') }
Check.ok(error && error.message.index('Other.dll!Init_Other'), 'extensao nomeada no erro')
FakeMKXP.log.clear
Audio_bgm_play('Audio/BGM/Route 1', 80, 100)
Check.equal([:bgm_play, 'Audio/BGM/Route 1', 80, 100, 0.0], FakeMKXP.log.last, 'Audio_bgm_play -> Audio nativo')
Check.equal('Audio/BGM/Route 1', Audio_bgm_name(), 'nome da BGM')
Check.equal(true, Audio_bgm_playing?, 'BGM tocando')
Audio.se_play('Audio/SE/Select', 70)
Check.equal([:se_play, 'Audio/SE/Select', 70, 100], FakeMKXP.log.last, 'Audio.se_play roteado pela ponte unica')
Check.ok(safeExists?('kerberus-runtime.log'), 'safeExists? do FMOD')
Check.ok(getPlayMusic && getPlaySound, 'getPlayMusic/getPlaySound')
Check.ok(AudioState.respond_to?(:update), 'AudioState minimo')
Check.raises(KerberusLegacy18::WinBridge::Unavailable, 'AudioState desconhecido e preciso') { AudioState.algo }

# GIF -> animated Bitmap.
gif = GifBitmap.new('Graphics/Characters/anim', 0)
Check.ok(gif.bitmap.is_a?(Bitmap), 'GifBitmap usa Bitmap nativo')
Check.equal(1, gif.length, 'bitmap estatico tem 1 quadro')
Check.equal(gif.bitmap, gif[0], 'quadro 0')
empty = GifBitmap.new('Graphics/Autotiles/', 0)
Check.equal([32, 32], [empty.width, empty.height], 'autotile vazio vira bitmap transparente')
GifBitmap.new('Graphics\\Pictures', 'logo.gif', 40)
Check.ok(FakeMKXP.log.include?([:hue_change, 40]), 'forma (dir, arquivo, hue)')

# KleinBitmap operations on raw_data.
bitmap = Bitmap.new(2, 1)
bitmap.set_pixel_rgba(0, 0, [10, 20, 30, 255])
bitmap.set_pixel_rgba(1, 0, [200, 200, 200, 0])
bitmap.to_negative
Check.equal([245, 235, 225, 255], bitmap.pixel_rgba(0, 0), 'to_negative')
bitmap.modify_color(Color.new(245, 235, 225), Color.new(1, 2, 3))
Check.equal([1, 2, 3, 255], bitmap.pixel_rgba(0, 0), 'modify_color')
retro = Bitmap.new(4, 1)
[[0, 0, 0], [90, 90, 90], [150, 150, 150], [255, 255, 255]].each_with_index { |rgb, x| retro.set_pixel_rgba(x, 0, rgb + [255]) }
palette = [Color.new(15, 56, 15), Color.new(48, 98, 48), Color.new(139, 172, 15), Color.new(155, 188, 15)]
retro.to_retro(*palette)
Check.equal([[15, 56, 15], [48, 98, 48], [139, 172, 15], [155, 188, 15]], (0..3).map { |x| retro.pixel_rgba(x, 0)[0, 3] }, 'to_retro em 4 tons')
outline = Bitmap.new(3, 3)
outline.set_pixel_rgba(1, 1, [9, 9, 9, 255])
outline.add_outline(Color.new(255, 0, 0, 255), 1)
Check.equal([255, 0, 0, 255], outline.pixel_rgba(0, 0), 'add_outline pinta vizinhos transparentes')
Check.equal([9, 9, 9, 255], outline.pixel_rgba(1, 1), 'add_outline preserva o sprite')
scroll = Bitmap.new(2, 1)
scroll.set_pixel_rgba(0, 0, [1, 1, 1, 255])
scroll.scroll_right(1)
Check.equal([1, 1, 1, 255], scroll.pixel_rgba(1, 0), 'scroll_right circular')
Check.ok(compare_klein_bitmaps(scroll, scroll.clone), 'compare_klein_bitmaps')
Check.raises(KerberusLegacy18::WinBridge::Unavailable, 'paleta proprietaria indisponivel') { scroll.save_pallete('x') }
sprite = Sprite.new
sprite.bitmap = Bitmap.new(2, 2)
pattern = Bitmap.new(1, 1)
pattern.set_pixel_rgba(0, 0, [100, 0, 0, 255])
sprite.bitmap.set_pixel_rgba(0, 0, [0, 0, 0, 255])
original_bitmap = sprite.bitmap
sprite.set_pattern(pattern, 255)
Check.equal([100, 0, 0, 255], sprite.bitmap.pixel_rgba(0, 0), 'set_pattern mistura pattern')
sprite.delete_pattern
Check.ok(sprite.bitmap.equal?(original_bitmap) || sprite.bitmap.pixel_rgba(0, 0) == [0, 0, 0, 255], 'delete_pattern restaura')
Check.ok(KLEIN_BFUNCS_WORKING, 'constante KLEIN_BFUNCS_WORKING')

# Bitmap memory helpers.
pbSetResizeFactor2(2.0)
Check.equal(1.0, $resize_factor, 'escala de janela fixa no Android')
data = Bitmap.new(1, 1)
data.set_pixel_rgba(0, 0, [1, 2, 3, 4])
Check.equal([3, 2, 1, 4], data.getData.unpack('C4'), 'getData em BGRA')
data.setData([9, 8, 7, 6].pack('C4'))
Check.equal([7, 8, 9, 6], data.pixel_rgba(0, 0), 'setData de BGRA')
Check.raises(KerberusLegacy18::WinBridge::Unavailable, 'Bitmap#address') { data.address }

# Text entry -> Input.gets (Android IME).
window = Window_TextEntry_Keyboard.new
FakeMKXP.text = "S\xC3\xA3o\n"
window.update
Check.equal("S\xC3\xA3o", window.text, 'texto do IME inserido (controle filtrado)')
Check.equal(true, FakeMKXP.text_mode, 'teclado Android ativado com a janela')
window.dispose
Check.equal(false, FakeMKXP.text_mode, 'teclado desativado no dispose')

# Unicode strings from pointers.
Check.equal('', getUnicodeString(0), 'ponteiro nulo')
wide = KerberusLegacy18::WinBridge::Memory.alloc_wide("P\xC3\xA1th")
Check.equal("P\xC3\xA1th", getUnicodeString(wide), 'UTF-16 do heap virtual')
Check.equal("\xC3\xA9", getUnicodeStringFromAnsi("\xE9\0"), 'ANSI Windows-1252 para UTF-8')

# Zeus video -> native player.
Dir.mkdir('Movies')
File.open('Movies/Intro.ogv', 'wb') { |file| file.write('OGV') }
Graphics.play_movie('Movies\\intro.avi')
Check.equal([:play_movie, 'Movies/Intro.ogv', 100, true], FakeMKXP.log.last, 'video OGV equivalente')
Check.equal(nil, Graphics.play_movie('Movies/none.avi'), 'video sem OGV pulado com diagnostico')

# Compat mode off disables ports but not the WinBridge.
ENV['KERBERUS_COMPAT_MODE'] = 'off'
KerberusLegacy18.reset_config!
copy = [section('FMOD', Fixtures::FMOD.dup)]
Check.equal(0, KerberusLegacy18::Ports.apply_all(copy), 'ports desativados pelo usuario')
Check.equal(Fixtures::FMOD, copy[0][3], 'script intacto com ports desativados')
ENV['KERBERUS_COMPAT_MODE'] = nil
ENV['KERBERUS_PORTS_DISABLE'] = 'fmodex_audio'
KerberusLegacy18.reset_config!
Check.equal(0, KerberusLegacy18::Ports.apply_all(copy), 'port individual desativado')

# A port that cannot parse its target leaves it untouched.
broken = [section('Dup', "def getUnicodeStringFromAnsi(addr)\nend\ndef getUnicodeStringFromAnsi(addr)\nend\ndef getUnicodeString(addr)\nend\n")]
ENV['KERBERUS_PORTS_DISABLE'] = nil
KerberusLegacy18.reset_config!
before = broken[0][3].dup
KerberusLegacy18::Ports.apply_all(broken)
Check.equal(before, broken[0][3], 'falha de port preserva a secao')
Check.ok(File.read('kerberus-runtime.log').index('PORT_FAILED'), 'falha de port relatada')
Check.report('ports')
