require File.join(File.dirname(__FILE__), 'harness')
scripts = [section('Unused', "if false\n  Win32API.new('shell32', 'NeverDeclared', 'p', 'i')\nend\n"),
           section('Keys', "$async = Win32API.new('user32', 'GetAsyncKeyState', 'i', 'i')\n$count = Win32API.new('kernel32', 'GetTickCount', '', 'l')\n"),
           section('Net', "$sock = Win32API.new('ws2_32', 'socket', 'iii', 'i')\n$bad = Win32API.new('foo', 'Bar', 'i', 'i')\n$dyn = Win32API.new(DLL_NAME, 'X', '', '')\n")]
game = boot('recorder', scripts, {})
R = KerberusLegacy18::Recorder
Check.ok(R.static.has_key?('shell32!NeverDeclared'), 'DETECTED_STATIC encontrado')
Check.ok(R.static.has_key?('user32!GetAsyncKeyState'), 'literal detectado')
DLL_NAME = 'dyn'
scripts.each_with_index { |entry, index| eval(entry[3], nil, format('Section%03d', index), 1) }
50.times { $async.call(0x41) }
$count.call
Check.equal(-1, $sock.call(2, 1, 6), 'socket sem rede = INVALID_SOCKET')
Check.equal(10050, Win32API.new('ws2_32', 'WSAGetLastError', '', 'i').call, 'WSAENETDOWN')
Check.equal(10091, Win32API.new('ws2_32', 'WSAStartup', 'ip', 'i').call(0x202, "\0" * 400), 'WSASYSNOTREADY')
Check.raises(KerberusLegacy18::WinBridge::Unavailable, 'API ausente chamada') { eval("$bad.call(1)\n", nil, 'Section002', 2) }
lines = R.summary_lines
text = lines.join("\n")
Check.ok(text.index('API calls (distinct): 6'), 'APIs distintas chamadas: ' + text)
Check.ok(text.index('Native/equivalent: 3'), 'categoria nativa')
Check.ok(text.index('Limited: 2'), 'categoria limitada')
Check.ok(text.index('Unavailable called: 1'), 'bloqueios chamados')
Check.ok(text.index('user32!GetAsyncKeyState - 50 calls'), 'top APIs com contagem')
Check.ok(text.index("BLOCKERS:\nfoo!Bar - 1 calls @Section002:2 (Net)"), 'bloqueio com local')
Check.ok(text.index('shell32!NeverDeclared sections=000'), 'DETECTED_STATIC separado de CALLED_RUNTIME')
Check.ok(text.index("DECLARED (never called):\ndyn!X"), 'declarada mas nunca chamada')
Check.ok(text.index('Dynamic Win32API.new sites: 1'), 'declaracoes dinamicas contadas')
Check.ok(R.flush('teste'), 'wintrace gravado')
report = File.read(File.join(game, '.compat', 'winbridge', 'wintrace.txt'))
Check.ok(report.index('WINTRACE Kerberus 6.3.0 legacy18'), 'arquivo WINTRACE fora da pasta do jogo')
events = File.read(File.join(game, '.compat', 'events.log'))
Check.ok(events.index('[CALLED_RUNTIME] user32!GetAsyncKeyState'), 'primeira chamada registrada uma vez')
Check.equal(1, events.scan('[CALLED_RUNTIME] user32!GetAsyncKeyState').length, 'sem log por chamada')

# Trace off: counting continues, files are not written.
ENV['KERBERUS_WINTRACE'] = 'off'
KerberusLegacy18.reset_config!
Check.ok(!R.flush('off'), 'trace desligado nao grava')
ENV['KERBERUS_WINTRACE'] = nil
KerberusLegacy18.reset_config!

# Milestones from real game state.
M = KerberusLegacy18::Milestones
class Scene_Title; end
class Scene_Map; end
class Scene_Battle; end
class FakeMap
  def map_id; 5; end
end
class FakePlayer
  attr_accessor :x, :y
end
$scene = Scene_Title.new
M.poll
Check.ok(M.reached['TITLE'], 'TITLE pela cena')
$scene = Scene_Map.new
$game_map = FakeMap.new
$game_player = FakePlayer.new
$game_player.x = 1
$game_player.y = 1
M.poll
Check.ok(!M.reached['MAP'], 'MAP exige movimento')
$game_player.x = 2
M.poll
Check.ok(M.reached['MAP'], 'MAP com movimento')
$scene = Scene_Battle.new
M.poll
Check.ok(M.reached['BATTLE'], 'BATTLE pela cena')
save_data([1, 2], 'Game.rxdata')
save_data([1, 2], 'Data/Compiled.rxdata') rescue nil
M.poll
Check.ok(M.reached['SAVE'], 'SAVE apos gravar save real')
milestones = File.read(File.join(game, '.compat', 'milestones.log'))
%w(TITLE MAP BATTLE SAVE).each { |name| Check.ok(milestones.index("MILESTONE\t" + name + "\tlegacy18"), 'marco persistido: ' + name) }
Check.equal(4, milestones.split("\n").length, 'cada marco uma vez')
Check.ok(File.read('kerberus-runtime.log').index('[MILESTONE] MAP'), 'marco no relatorio de runtime')

# Frame hook drives polling and survives diagnostic failures.
FakeMKXP.frame = 0
60.times { Graphics.update }
Check.equal(60, FakeMKXP.frame, 'Graphics.update nativo continua sendo chamado')
Check.report('recorder')
