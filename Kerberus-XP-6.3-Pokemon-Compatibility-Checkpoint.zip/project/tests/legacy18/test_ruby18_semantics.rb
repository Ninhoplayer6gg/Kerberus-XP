require File.join(File.dirname(__FILE__), 'harness')
# Snapshot core classes before the bootstrap: it must not monkey patch them.
CORE = [String, Array, Hash, Integer, Fixnum, Float, Symbol, Object, Regexp, Range, Enumerable, Comparable]
before = {}
CORE.each { |klass| before[klass] = klass.instance_methods(false).sort + klass.private_instance_methods(false).sort }
boot('semantics', [], {})
CORE.each do |klass|
  after = klass.instance_methods(false).sort + klass.private_instance_methods(false).sort
  Check.equal(before[klass], after, 'bootstrap nao altera ' + klass.name)
end
Check.equal('1.8.7', RUBY_VERSION, 'Ruby 1.8 real')
Check.equal(97, 'abc'[0], 'String#[Integer] retorna byte')
Check.equal('b', 'abc'[1, 1], 'String#[start, len]')
bytes = []
"\xC3\xA9a".each_byte { |byte| bytes << byte }
Check.equal([0xC3, 0xA9, 0x61], bytes, 'each_byte Integer')
Check.equal(3, "\xC3\xA9a".length, 'length em bytes')
Check.equal(:b, { :b => 1 }.index(1), 'Hash#index')
Check.equal(2, [1, nil, 2].nitems, 'Array#nitems')
Check.equal(6, [1, 2, 3].inject { |sum, value| sum + value }, 'Enumerable#inject')
Check.equal("\xFF\x00", "\xFF\x00".dup, 'String binaria')
require 'stringio'
io = StringIO.new("\x01\x02\x03")
Check.equal(1, io.getc, 'StringIO#getc retorna Integer')
Check.equal("\x02\x03", io.read, 'StringIO#read')
data = Marshal.dump([1, 'x', { 'k' => [2.5, :s] }, "\xFF\xFE"])
Check.equal([1, 'x', { 'k' => [2.5, :s] }, "\xFF\xFE"], Marshal.load(data), 'Marshal ida e volta')
Check.equal(4, Marshal.dump('ab').length > 0 ? 4 : 0, 'Marshal.dump String')
Check.ok("\xC3\xA9" =~ /\xC3/n, 'Regexp /n byte')
Check.equal(['a', 'b'], 'a,b'.split(','), 'String#split')
Check.equal('1,2', [1, 2].join(','), 'Array#join')
Check.equal(true, 5.is_a?(Fixnum), 'Fixnum existe')
Check.ok(defined?(Thread.critical), 'Thread.critical do 1.8')
File.open('bin.dat', 'wb') { |file| file.write("\x00\x01\x02\x03") }
File.open('bin.dat', 'rb') do |file|
  file.seek(2)
  Check.equal(2, file.getc, 'IO#getc retorna Integer')
  Check.equal(4, file.stat.size, 'File::Stat#size')
end
Check.report('ruby18_semantics')
