require File.join(File.dirname(__FILE__), 'harness')
boot('signatures', [], {})
S = KerberusLegacy18::WinBridge::Signatures
W = KerberusLegacy18::WinBridge

def sig(imports, exports)
  S.parse(imports, exports).text
end

# Forms required by the 6.3 specification.
Check.equal('V:V', sig('', ''), 'string vazia')
Check.equal('V:V', sig([], ''), 'array vazio')
Check.equal('V:V', sig(%w(), 'v'), '%w() real (array vazio)')
Check.equal('V:V', sig('%w()', ''), 'texto literal "%w()" nao e tipo')
Check.equal('V:V', sig('%W()', nil), 'texto literal "%W()"')
Check.equal('PI:I', sig('%w(p i)', 'i'), 'texto literal %w(p i)')
Check.equal('PI:V', sig('%W[P L]', nil), 'texto literal %W[...]')
Check.equal('PPI:I', sig('PPI', 'I'), 'PPI string')
Check.equal('PPI:I', sig('ppi', 'i'), 'minusculas equivalentes')
Check.equal('PPI:I', sig(['P', 'P', 'I'], 'I'), 'array PPI')
Check.equal('PPI:I', sig(%w(p p i), 'i'), 'array minusculo')
Check.equal('PPI:I', sig('PPI:I', ''), 'forma combinada PPI:I')
Check.equal('PPI:I', sig('PPI:I', nil), 'forma combinada com export nil')
Check.equal('B:B', sig('B', 'B'), 'BOOL do MiniFFI')
Check.equal('P:P', sig('S', 'S'), 'S = ponteiro de string')
Check.equal('V:V', sig('V', 'V'), 'V void')
Check.equal('V:V', sig('0', '0'), '"0" void')
Check.equal('V:V', sig(0, 0), 'Integer 0 legado')
Check.equal('V:V', sig(nil, nil), 'nil')
Check.equal('III:I', sig('LNI', 'L'), 'L/N/I = inteiro 32 bits')
Check.equal('PI:I', sig('P, I', 'i'), 'separadores ignorados')
Check.equal('PI:I', sig(['pointer', 'long'], 'long'), 'itens longos usam o primeiro caractere (Win32API)')
Check.equal('I:V', sig('I?', ''), 'caractere desconhecido ignorado como no Win32API')
Check.equal('V:V', sig('', 'X'), 'export desconhecido vira void')

warnings = S.parse('I?', '').warnings
Check.ok(warnings.any? { |w| w.index('ignorados') }, 'caractere ignorado gera aviso')
Check.ok(S.parse('%w()', '').warnings.any? { |w| w.index('interpretado') }, '%w() literal gera aviso')

Check.raises(TypeError, 'imports numerico invalido') { S.parse(5, '') }
Check.raises(TypeError, 'item de array nao-String') { S.parse([1, 2], '') }
Check.raises(TypeError, 'imports Hash') { S.parse({}, '') }
Check.raises(TypeError, 'mais de 16 parametros') { S.parse('P' * 17, '') }

# DLL aliases.
Check.equal('user32', W.library('user32'), 'user32')
Check.equal('user32', W.library('USER32'), 'USER32')
Check.equal('user32', W.library('user32.dll'), 'user32.dll')
Check.equal('user32', W.library('User32.DLL'), 'User32.DLL')
Check.equal('user32', W.library('C:\\Windows\\System32\\user32.dll'), 'caminho Windows')
Check.equal('kleinbitmap', W.library('System/KleinBitmap.dll'), 'caminho relativo')
%w(xinput1_1 xinput1_2 xinput1_3 XINPUT1_4.DLL xinput9_1_0).each do |name|
  Check.equal('xinput', W.library(name), 'alias ' + name)
end
Check.equal('rgss1', W.library('RGSS102E.dll'), 'DLL do player RGSS1')
Check.equal('rgss_fmodex', W.library('RGSS FmodEx.dll'), 'FMOD do RGSS Linker')

# ANSI "A" fallback like Win32API: exact name first, then name + "A".
Check.ok(!W.lookup('kernel32', 'GetPrivateProfileString').nil?, 'GetPrivateProfileString -> ...A')
Check.ok(!W.lookup('kernel32', 'GetPrivateProfileStringA').nil?, 'GetPrivateProfileStringA exato')
Check.ok(W.lookup('kernel32', 'GetPrivateProfileStringW').nil?, 'variante W nao e confundida com A')
Check.ok(W.lookup('user32', 'getasynckeystate').nil?, 'GetProcAddress diferencia maiusculas')

# RGSS1 return conversion.
Check.equal(-32768, W.to_i32(0x8000 | 0xFFFF0000), 'SHORT com sinal')
Check.equal(-2147467263, W.to_i32(0x80004001), 'HRESULT como long 32 bits')
Check.equal(1, W.to_i32(true), 'true -> 1')
Check.equal(0, W.to_i32(nil), 'nil -> 0')
Check.report('signatures')
