// Ruby 1.8 extension that exercises the REAL mkxp-z disposable-binding.h and
// binding-util.h templates with an Essentials-style subclass that never
// calls the RGSS base initialize (LargePlane < Plane). Built and run by
// tests/native/run-lifecycle-test.sh against a real Ruby 1.8.7.
#include "disposable-binding.h"

SharedState *shState = 0;
int rgssVer = 1;

// binding-util.cpp is not linked into this test: minimal equivalents that
// keep the message text, which is what the test verifies.
void raiseRbExc(const Exception &exc) { rb_raise(rb_eRuntimeError, "%s", exc.msg.c_str()); }
void raiseDisposedAccess(VALUE self) { rb_raise(rb_eRuntimeError, "disposed %s", rb_obj_classname(self)); }

class FakePlane : public Disposable {
    void releaseResources() {}
    const char *klassName() const { return "plane"; }
};

static VALUE fakeAllocate(VALUE klass) {
    // Same shape as mkxp-z's Ruby 1.8 allocator: the native object is only
    // created by #initialize.
    return Data_Wrap_Struct(klass, 0, 0, 0);
}

RB_METHOD(fakeOx) {
    RB_UNUSED_PARAM;
    getPrivateData<FakePlane>(self);
    return INT2FIX(0);
}

extern "C" void Init_lifecycle_ext() {
    VALUE klass = rb_define_class("FakePlane", rb_cObject);
    rb_define_alloc_func(klass, fakeAllocate);
    disposableBindingInit<FakePlane>(klass);
    _rb_define_method(klass, "ox", fakeOx);
}
