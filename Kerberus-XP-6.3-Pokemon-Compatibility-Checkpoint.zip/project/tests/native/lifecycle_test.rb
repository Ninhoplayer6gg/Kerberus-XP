require File.join(File.dirname(__FILE__), '..', 'legacy18', 'harness')
require ARGV[0]

# Essentials LargePlane: a Ruby facade that never calls Plane#initialize
# but still calls super in dispose.
class LargePlane < FakePlane
  def initialize
    @sprite = :sprite
  end

  def dispose
    @sprite = nil
    super
  end
end

plane = LargePlane.new
Check.equal(true, plane.disposed?, 'objeto sem nativo e tratado como descartado')
begin
  plane.dispose
  Check.ok(true, 'dispose sem super#initialize nao levanta excecao (RGSS1)')
rescue Exception => error
  Check.ok(false, 'dispose levantou ' + error.class.name + ': ' + error.message)
end
plane.dispose
Check.ok(true, 'dispose duplo seguro')
Check.equal(true, plane.respond_to?(:_mkxp_dispose_alias), 'alias interno do RGSS1 para filhos de Viewport')
plane.send(:_mkxp_dispose_alias)
Check.ok(true, 'descarte via Viewport (alias) seguro')
error = Check.raises(RuntimeError, 'acesso a propriedade sem nativo continua sendo erro') { plane.ox }
Check.ok(error && error.message.index('No instance data for LargePlane'), 'mensagem nomeia a classe: ' + (error ? error.message : ''))
Check.report('native_lifecycle')
