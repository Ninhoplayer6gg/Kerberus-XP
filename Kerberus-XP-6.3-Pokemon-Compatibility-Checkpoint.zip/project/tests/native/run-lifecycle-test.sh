#!/usr/bin/env bash
# Builds tests/native/lifecycle_ext.cpp against a real Ruby 1.8 and the real
# mkxp-z binding headers, then runs tests/native/lifecycle_test.rb.
#   RUBY18=... RUBY18_INCLUDE=... DEPS=... tests/native/run-lifecycle-test.sh
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
M="$ROOT/app/jni/mkxp-z"
B="$ROOT/app/jni/build-arm64-v8a"
OUT="${TMPDIR:-/tmp}/kerberus-lifecycle-$$"
mkdir -p "$OUT"
"${CXX:-clang++}" -std=c++14 -shared -fPIC -w -Wno-register -include cstring -include cstdlib \
  -DGLES2_HEADER -DMKXPZ_BUILD_ANDROID -DMKXPZ_LEGACY_RUBY -DKERBERUS_RUBY_RUNTIME_18=1 \
  -I"$M/src" -I"$M/src/util" -I"$M/src/display" -I"$M/src/display/gl" -I"$M/src/etc" \
  -I"$M/src/filesystem" -I"$M/src/input" -I"$M/src/audio" -I"$M/src/system" -I"$M/binding" \
  -I"$B/include" -I"$DEPS/SDL2/include" -I"$DEPS/SDL2_ttf" -I"$DEPS/SDL2_image" \
  -I"$DEPS/SDL2_sound/src" -I"$DEPS/physfs/src" -I"$ROOT/tools/host-stubs" \
  -I"$RUBY18_INCLUDE" -Wl,--unresolved-symbols=ignore-all \
  "$ROOT/tests/native/lifecycle_ext.cpp" -o "$OUT/lifecycle_ext.so"
KERBERUS_TEST_WORK="$OUT/work" "$RUBY18" "$ROOT/tests/native/lifecycle_test.rb" "$OUT/lifecycle_ext.so"
rm -rf "$OUT"
